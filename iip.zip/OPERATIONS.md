﻿# IIP — Operations Guide

> Server management, deployment, environment configuration, and troubleshooting.

**Server:** `si0vm14401` — `rb-alm-01-d8.de.bosch.com`
**OS:** Red Hat Enterprise Linux 9.7 (Plow)
**App root:** `/opt/IBM/IIP`
**Last verified:** April 24, 2026

---

## Service Architecture

| Component | Technology | Port | Config |
|---|---|---|---|
| Frontend / static files | Apache httpd | 80 → redirect, 443 SSL | `/etc/httpd/conf.d/rb-alm-01-d8.conf` |
| Backend API | Uvicorn (FastAPI) — `iip-fastapi.service` | 127.0.0.1:3001 | `/etc/systemd/system/iip-fastapi.service` |
| Database | PostgreSQL 13.23 | 127.0.0.1:5432 | system service `postgresql` |
| SMT API | Uvicorn (separate app) | 127.0.0.1:8765 | `smt-api.service` |

**Expected listening ports:**
```
127.0.0.1:3001   — IIP FastAPI backend
127.0.0.1:5432   — PostgreSQL
127.0.0.1:8765   — SMT API
0.0.0.0:443      — Apache HTTPS
0.0.0.0:80       — Apache HTTP (redirect only)
```

Anything else on `:8080` or `0.0.0.0` that isn't httpd is an orphan — kill it.

---

## Deploying New Code

Use `deploy.sh` for all code updates. Do not manually restart or copy files.

```bash
cd /opt/IBM/IIP

# Full deploy: backup snapshot + clear cache + migrations + restart + health check
bash deploy.sh

# Restart only (no snapshot, no migration — e.g. after config change)
bash deploy.sh --restart-only

# Deploy without snapshot (faster, use when you know what changed)
bash deploy.sh --skip-backup
```

`deploy.sh` does in order:
1. Verifies DB is reachable — aborts if not
2. Snapshots `backend/` to `/opt/IBM/IIP_backups/backend_TIMESTAMP/`
3. Clears `.pyc` bytecode cache
4. Applies any pending `.sql` files from `migrations/` (tracked in `schema_migrations` table)
5. Restarts `iip-fastapi.service`
6. Health checks `GET /api/v2/health` — if it fails, auto-restores the snapshot and restarts
7. Sets `chmod 755` on frontend and backend

---

## Service Management

### FastAPI backend

```bash
# Status
systemctl status iip-fastapi.service

# Start / stop / restart
systemctl start iip-fastapi.service
systemctl stop iip-fastapi.service
systemctl restart iip-fastapi.service

# Follow logs live (preferred)
journalctl -u iip-fastapi -f

# Last 50 log lines
journalctl -u iip-fastapi -n 50 --no-pager

# File logs (same content, also rotated by logrotate)
tail -f /var/log/iip/iip-fastapi.log
tail -f /var/log/iip/iip-fastapi-error.log
```

### Apache httpd

```bash
# Test config before restarting (always do this first)
httpd -t

# Reload config without dropping connections (preferred for config changes)
systemctl reload httpd

# Full restart
systemctl restart httpd

# Status
systemctl status httpd

# Access log
tail -f /var/log/httpd/rb-alm-01-d8_access.log

# Error log
tail -f /var/log/httpd/rb-alm-01-d8_error.log
```

### Quick restart both

```bash
cd /opt/IBM/IIP
bash restart.sh
```

---

## Systemd Unit File

`/etc/systemd/system/iip-fastapi.service`

```ini
[Unit]
Description=IIP FastAPI Backend
Documentation=https://rb-alm-01-d8.de.bosch.com/iip
After=network.target postgresql.service
Wants=postgresql.service

[Service]
Type=simple
User=root
Group=root
WorkingDirectory=/opt/IBM/IIP
EnvironmentFile=/opt/IBM/IIP/backend/.env

ExecStart=/usr/bin/python3.9 -m uvicorn backend.main:app \
    --host 127.0.0.1 \
    --port 3001 \
    --no-access-log \
    --log-level info

Restart=always
RestartSec=5
StartLimitInterval=120
StartLimitBurst=5

StandardOutput=append:/var/log/iip/iip-fastapi.log
StandardError=append:/var/log/iip/iip-fastapi-error.log

LimitNOFILE=65536
TimeoutStopSec=30

[Install]
WantedBy=multi-user.target
```

After editing the unit file:
```bash
systemctl daemon-reload
systemctl restart iip-fastapi.service
```

---

## Environment Variables

File: `/opt/IBM/IIP/backend/.env`

| Variable | Description | Default |
|---|---|---|
| `DB_HOST` | PostgreSQL host | `localhost` |
| `DB_PORT` | PostgreSQL port | `5432` |
| `DB_NAME` | Database name | `iip_db` |
| `DB_USER` | Database user | `iip_user` |
| `DB_PASSWORD` | Database password | *(required)* |
| `DB_SSL` | Enable SSL for DB connection | `false` |
| `DB_POOL_MIN` | Minimum pool connections | `2` |
| `DB_POOL_MAX` | Maximum pool connections | `20` |
| `DB_CMD_TIMEOUT` | Query timeout in seconds | `60` |
| `CORS_ORIGIN` | Allowed CORS origin(s), comma-separated | `https://rb-alm-01-d8.de.bosch.com` |
| `IIP_LOG_LEVEL` | Log level: DEBUG/INFO/WARNING/ERROR | `INFO` |
| `IIP_MAX_UPLOAD_BYTES` | Max upload file size in bytes | `104857600` (100 MB) |
| `SSE_REQUIRE_AUTH` | Require token to connect to SSE stream | `false` |
| `APP_ENV` | Environment tag (production/staging) | `production` |

To change an env var:
```bash
nano /opt/IBM/IIP/backend/.env
systemctl restart iip-fastapi.service
```

---

## Apache Virtual Host

Config: `/etc/httpd/conf.d/rb-alm-01-d8.conf`
**This is the only active proxy config file.** `iip-api-proxy.conf` was removed on April 24, 2026 — it was a duplicate causing 301 redirect conflicts.

Key routing rules:
- `http://` → permanent redirect to `https://`
- `/iip/` → `Alias /opt/IBM/IIP/frontend/` — serves static files
- `/iip/api/*` → `ProxyPass http://127.0.0.1:3001/api/*` — backend API
- `/iip/api/events` → SSE proxy (`flushpackets=on`, buffering disabled)
- `/smt/api` → `http://127.0.0.1:8765/api` — separate SMT service

Security headers applied on all responses:
- `X-Content-Type-Options: nosniff`
- `X-Frame-Options: SAMEORIGIN`
- `X-XSS-Protection: 1; mode=block`
- `Strict-Transport-Security: max-age=31536000; includeSubDomains`

SSL certificate:
- Cert: `/etc/ssl/certs/cert_rb-alm-01-d8.de.bosch.com_20250416.pem`
- Key: `/etc/ssl/certs/rb-alm-01-d8.de.bosch.com_20250416.key`
- Chain: `/etc/ssl/certs/RB_CA_RSA_combined.pem`
- Protocol: TLSv1.2+ only

---

## Database

### Connect to DB

```bash
# Recommended — use db.sh wrapper
cd /opt/IBM/IIP
bash db.sh

# Direct
PGPASSWORD=Admin@123 psql -U iip_user -h localhost -p 5432 -d iip_db
```

### Useful queries

```sql
-- Table row counts
SELECT relname AS table, n_live_tup AS rows
FROM pg_stat_user_tables
ORDER BY n_live_tup DESC;

-- Recent uploads
SELECT id, filename, file_type, status, rows_imported, upload_date
FROM uploads ORDER BY upload_date DESC LIMIT 10;

-- Active sessions
SELECT token, username, expires_at FROM admin_sessions WHERE expires_at > NOW();

-- Force re-login all users
DELETE FROM admin_sessions;

-- Recent audit log
SELECT changed_at, action, entity_type, entity_id, changed_by
FROM audit_log ORDER BY changed_at DESC LIMIT 20;

-- App settings
SELECT key, length(value::text) AS val_bytes, description FROM app_settings;

-- KV store keys
SELECT key, length(value::text) AS bytes, updated_at FROM iip_kv ORDER BY bytes DESC;

-- Weekly tracker summary
SELECT year, week_label, COUNT(*) AS cases
FROM weekly_closed_cases GROUP BY year, week_label ORDER BY year DESC, week_label DESC LIMIT 10;

-- Applied migrations
SELECT migration, applied_at FROM schema_migrations ORDER BY applied_at;
```

### Reset admin password

```bash
cd /opt/IBM/IIP
python3.9 backend/reset_admin.py
```

### Run a SQL migration manually

```bash
PGPASSWORD=Admin@123 psql -U iip_user -h localhost -p 5432 -d iip_db \
  -f /opt/IBM/IIP/migrations/your_migration.sql
```

`deploy.sh` applies all unapplied migrations automatically — manual runs are only needed for one-off fixes.

### Reclaim disk space after large deletes

```bash
PGPASSWORD=Admin@123 psql -U iip_user -h localhost -p 5432 -d iip_db \
  -c "VACUUM ANALYZE;"
```

> `VACUUM` marks space for reuse but doesn't return it to the OS. `VACUUM FULL` does, but locks the table. Only use `VACUUM FULL` on very large tables during a maintenance window.

---

## Automated Backups

Daily backup runs at 02:00 via cron:
```
0 2 * * * /usr/local/bin/iip_db_backup.sh
```

Script: `/usr/local/bin/iip_db_backup.sh`
Output: `/opt/IBM/IIP_backups/db/iip_db_YYYYMMDD_HHMMSS.sql.gz`
Retention: 7 days (older files auto-deleted)

```bash
# Check backup log
tail -20 /var/log/iip/db_backup.log

# List backups
ls -lh /opt/IBM/IIP_backups/db/

# Run a manual backup right now
/usr/local/bin/iip_db_backup.sh

# Restore from backup
gunzip -c /opt/IBM/IIP_backups/db/iip_db_20260424_020000.sql.gz | \
  PGPASSWORD=Admin@123 psql -U iip_user -h localhost -p 5432 -d iip_db
```

---

## Health Watchdog

Cron runs every 5 minutes:
```
*/5 * * * * /usr/local/bin/iip_watchdog.sh
```

Script: `/usr/local/bin/iip_watchdog.sh`
- Hits `GET http://localhost:3001/api/v2/health`
- If not 200: runs `systemctl restart iip-fastapi.service`, waits 5s, re-checks
- Logs all events to `/var/log/iip/watchdog.log`
- Log is capped at 1 MB (last 500 lines kept)

```bash
# Check watchdog log
tail -50 /var/log/iip/watchdog.log
```

---

## Log Rotation

Config: `/etc/logrotate.d/iip`
- Rotates all files in `/var/log/iip/*.log`
- Daily, 14 rotations kept, compressed with `delaycompress`
- Uses `copytruncate` — no service signal needed

```bash
# Test rotation config
logrotate --debug /etc/logrotate.d/iip

# Force rotate now
logrotate --force /etc/logrotate.d/iip
```

---

## Crontab Summary

```
# System (Ansible-managed — do not edit)
20 4 * * *  find /var/tmp -type f -atime +4 -exec rm -rf {} \;
30 4 * * *  find /var/preserve -type f -mtime +4 -exec rm -f {} \;

# IIP
0  2 * * *  /usr/local/bin/iip_db_backup.sh
*/5 * * * * /usr/local/bin/iip_watchdog.sh
```

---

## Log Files Reference

| Path | Content |
|---|---|
| `/var/log/iip/iip-fastapi.log` | Backend stdout (requests, info) |
| `/var/log/iip/iip-fastapi-error.log` | Backend stderr (errors, exceptions) |
| `/var/log/iip/db_backup.log` | Daily backup results |
| `/var/log/iip/watchdog.log` | Watchdog restart events |
| `/var/log/httpd/rb-alm-01-d8_access.log` | Apache access log |
| `/var/log/httpd/rb-alm-01-d8_error.log` | Apache error log |

Also available via journald:
```bash
journalctl -u iip-fastapi -f          # live
journalctl -u iip-fastapi --since today
journalctl -u iip-fastapi -n 100 --no-pager
```

---

## File Locations Reference

| Path | Description |
|---|---|
| `/opt/IBM/IIP/` | Application root |
| `/opt/IBM/IIP/backend/.env` | Environment variables |
| `/opt/IBM/IIP/migrations/` | SQL migration files (applied by deploy.sh) |
| `/opt/IBM/IIP/deploy.sh` | Zero-downtime deploy script |
| `/opt/IBM/IIP/restart.sh` | Quick restart (httpd + backend) |
| `/opt/IBM/IIP/Excel_sheets/` | Archived IBM Support CSV exports |
| `/opt/IBM/IIP/Datas/` | Weekly tracker XLSMs and Ideas CSV |
| `/opt/IBM/IIP_backups/db/` | Daily gzip DB backups |
| `/opt/IBM/IIP_backups/backend_*/` | Per-deploy backend snapshots |
| `/etc/systemd/system/iip-fastapi.service` | Systemd unit file |
| `/etc/httpd/conf.d/rb-alm-01-d8.conf` | Apache virtual host (only active proxy config) |
| `/etc/httpd/conf.d/backups/` | Backed-up old httpd configs |
| `/etc/ssl/certs/` | SSL certificates |
| `/usr/local/bin/iip_db_backup.sh` | DB backup script |
| `/usr/local/bin/iip_watchdog.sh` | Health watchdog script |
| `/var/log/iip/` | All IIP log files |

---

## Troubleshooting

### Backend won't start

```bash
# Check logs
journalctl -u iip-fastapi -n 50 --no-pager
tail -50 /var/log/iip/iip-fastapi-error.log

# Common causes:
# 1. DB not reachable
systemctl status postgresql
PGPASSWORD=Admin@123 psql -U iip_user -h localhost -p 5432 -d iip_db -c 'SELECT 1'

# 2. Port 3001 already in use
ss -tlnp | grep 3001
# Kill stale process: kill $(lsof -ti :3001)

# 3. Syntax error after deploy
cd /opt/IBM/IIP
python3.9 -c "import backend.main" 2>&1

# 4. .env missing or malformed
cat /opt/IBM/IIP/backend/.env
```

### 502 Bad Gateway from browser

Apache is running but FastAPI is not:
```bash
systemctl status iip-fastapi.service
curl -s http://127.0.0.1:3001/api/v2/health
# If down: systemctl start iip-fastapi.service
```

### 301 redirect loop on /iip/api/

Check that `iip-api-proxy.conf` does not exist (it was removed April 24, 2026):
```bash
ls /etc/httpd/conf.d/iip-api-proxy.conf   # should: No such file
httpd -t && systemctl reload httpd
```

### Database connection errors

```bash
systemctl status postgresql
journalctl -u postgresql -n 20 --no-pager
PGPASSWORD=Admin@123 psql -U iip_user -h localhost -p 5432 -d iip_db -c 'SELECT 1'
```

### Upload fails with "duplicate file"

Same SHA-256 hash already imported. Check:
```bash
PGPASSWORD=Admin@123 psql -U iip_user -h localhost -p 5432 -d iip_db \
  -c "SELECT id, filename, file_type, upload_date, status, rows_imported FROM uploads ORDER BY upload_date DESC LIMIT 5;"
```

### SSE events not reaching browser

Verify SSE proxy in `/etc/httpd/conf.d/rb-alm-01-d8.conf`:
```apache
<Location /iip/api/events>
    ProxyPass http://127.0.0.1:3001/api/events flushpackets=on
    ...
</Location>
```
Check proxy modules:
```bash
httpd -M | grep proxy
```

### Orphan process on unexpected port

```bash
ss -tlnp
# Kill anything on 0.0.0.0 or unexpected ports
kill $(lsof -ti :<port>)
```

### Check deploy rollback triggered

```bash
ls -lt /opt/IBM/IIP_backups/backend_*/   # multiple snapshots = rollbacks happened
journalctl -u iip-fastapi -n 30 --no-pager
```
