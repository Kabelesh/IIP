#!/bin/bash
set -e

echo "=== Restarting IIP ==="

# 1. Test Apache config before touching anything
httpd -t || { echo "ERROR: Apache config syntax error — aborting"; exit 1; }

# 2. Restart Apache (system httpd — has IIP proxy config)
#    Stop IHS first if it crept back onto port 443
if systemctl is-active --quiet ihs; then
    echo "WARNING: IHS is running and will steal port 443 — stopping it"
    systemctl stop ihs
fi
systemctl restart httpd && echo "Apache restarted OK" || { echo "ERROR: Apache failed to restart"; exit 1; }

# 3. Clean pyc cache and restart FastAPI backend
find /opt/IBM/IIP/backend -name "*.pyc" -delete
systemctl restart iip-fastapi.service && echo "Backend restarted OK" || { echo "ERROR: FastAPI failed to restart"; exit 1; }

# 4. Fix permissions — explicit paths only, never run from wrong dir
chmod -R 755 /opt/IBM/IIP/frontend
chmod -R 755 /opt/IBM/IIP/backend
chmod 600 /opt/IBM/IIP/backend/.env 2>/dev/null || true

# 5. Status
echo ""
echo "=== Status ==="
systemctl status iip-fastapi.service --no-pager | tail -5
journalctl -u iip-fastapi -n 3 --no-pager
echo ""
echo "=== Health check ==="
sleep 2
curl -sk https://localhost/iip/api/v2/health || echo "WARNING: health check failed"
echo ""
