﻿# IIP — Architecture Reference

> Technical deep-dive: API routes, database schema, frontend structure, and data flow.

**App version:** v2.0.5
**Last verified against live server:** May 2, 2026
**Schema version:** v5

---

## System Overview

```
Browser (HTTPS:443)
    │
    ▼
Apache httpd  ← rb-alm-01-d8.de.bosch.com
    │  /iip/          → serves static files from /opt/IBM/IIP/frontend
    │  /iip/api/*     → ProxyPass → 127.0.0.1:3001/api/*
    │  /iip/api/events → SSE (flushpackets=on, no buffering)
    ▼
FastAPI + Uvicorn  (127.0.0.1:3001)
    │
    ▼
asyncpg connection pool
    │
    ▼
PostgreSQL 13.23  (127.0.0.1:5432)  db=iip_db  user=iip_user
```

---

## Backend — FastAPI Application

**Entry point:** `backend/main.py`
**ASGI server:** `uvicorn backend.main:app --host 127.0.0.1 --port 3001 --no-access-log`

### Middleware

| Middleware | Purpose |
|---|---|
| `CORSMiddleware` | Allows only the origin in `CORS_ORIGIN` env var |
| `request_id_middleware` | Adds `X-Request-ID` to every request; logs method + path + status + duration |

### Error Responses

All errors return a consistent JSON body:
```json
{ "ok": false, "error": "...", "status": 404, "request_id": "abc123" }
```

### SSE (Server-Sent Events)

`GET /api/events` streams real-time events to all connected browsers.
Events broadcast on: case save, file upload complete, admin config change.

---

## API Routes

### Authentication — `/api/auth`

| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/api/auth/status` | No | Check if admin password is configured |
| POST | `/api/auth` | No | Login — returns `{ token }` |
| POST | `/api/auth/logout` | Token | Revoke session |
| POST | `/api/auth/set-password` | Token (or none if first boot) | Set / change admin password |
| POST | `/api/auth/security-questions` | Token | Configure password-reset Q&A |
| POST | `/api/auth/reset-via-security` | No | Reset password using security answers |

Auth header: `X-IIP-Admin-Token: <token>`
Session TTL: 12 hours. Expired sessions are purged on each new login.

---

### Config / KV Store — `/api/store` & `/api/config`

| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/api/config` | No | Read app settings from `app_settings` table |
| GET | `/api/team-config` | No | Team members, ALM lines, contacts, name aliases |
| GET | `/api/team-members` | No | Team members list |
| GET | `/api/store/{key}` | No* | Read a KV key |
| POST | `/api/store/{key}` | Token | Write a KV key |
| DELETE | `/api/store/{key}` | Token | Delete a KV key |
| POST | `/api/store-public/{key}` | No | Write to public-write-allowed keys only |
| POST | `/api/store-bulk-get` | No* | Read multiple keys |
| POST | `/api/store-bulk-set` | Token | Write multiple keys |

---

### Core Data API — `/api/v2`

All endpoints in `routers/db_cases.py`.

#### Health

| Method | Path | Description |
|---|---|---|
| GET | `/api/v2/health` | DB liveness check — returns case/weekly/upload counts |

#### File Uploads

| Method | Path | Auth | Description |
|---|---|---|---|
| POST | `/api/v2/upload/cases` | Token | Upload IBM Support Case listing CSV |
| POST | `/api/v2/upload/weekly` | Token | Upload Weekly Closed Cases XLSM/XLSX |
| POST | `/api/v2/upload/ideas` | Token | Upload IBM Ideas CSV |
| POST | `/api/v2/upload/team-members` | Token | Upload Team_Members.xlsx |
| GET | `/api/v2/uploads` | Token | List all uploads with status |
| GET | `/api/v2/uploads/{id}` | Token | Single upload status |

Upload size cap: `IIP_MAX_UPLOAD_BYTES` (default 100 MB).
SHA-256 deduplication: re-uploading the same file is rejected.

#### Cases

| Method | Path | Auth | Description |
|---|---|---|---|
| POST | `/api/v2/cases` | Token | Save parsed cases JSON (triggers SSE) |
| GET | `/api/v2/cases` | No | Paginated case list with filters |
| GET | `/api/v2/cases/search` | No | Full-text search (trigram) |
| GET | `/api/v2/cases/performance-summary` | No | Performance-tagged cases with work items |
| GET | `/api/v2/cases/{case_number}` | No | Full case detail + weekly history |
| GET | `/api/v2/cases/{case_number}/wednesday-comments` | No | Performance review comments |
| PATCH | `/api/v2/cases/{case_number}/wednesday-comments` | Token | Upsert wednesday comment |
| GET | `/api/v2/cases/{case_number}/slot-days` | No | Slot day overrides |
| PATCH | `/api/v2/cases/{case_number}/slot-days` | Token | Upsert slot day override |
| PATCH | `/api/v2/cases/{case_number}/availability` | Token | Set performance availability |
| PATCH | `/api/v2/cases/{case_number}/performance` | Token | Tag/untag as performance case |
| POST | `/api/v2/cases/{case_number}/reopen` | Token | Log a manual reopen action → `case_reopen_log` |

#### Weekly Tracker

| Method | Path | Description |
|---|---|---|
| GET | `/api/v2/weekly/{year}` | All week summaries for a year |
| GET | `/api/v2/weekly/{year}/{week}` | Cases for a specific CW (e.g. CW05) |
| POST | `/api/v2/reopened/sync` | Sync cross-week reopened cases to `weekly_reopened_sync` |
| GET | `/api/v2/reopened` | All reopened cases (from `mv_reopened_cases`) |
| GET | `/api/v2/duplicates` | All duplicate case entries |

#### Ideas / RFE

| Method | Path | Description |
|---|---|---|
| GET | `/api/v2/ideas` | IBM Ideas / RFE list |
| GET | `/api/v2/ideas/{idea_id}` | Single idea detail |

#### Saved Searches — `routers/saved_searches.py`

| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/api/saved-searches?dashboard=` | No | List saved searches for a dashboard |
| POST | `/api/saved-searches` | No | Create a saved search |
| DELETE | `/api/saved-searches/{id}` | No | Delete a saved search |
| POST | `/api/saved-searches/{id}/use` | No | Increment use_count + set last_used |

---

### Admin CRUD — `/api/admin`

All endpoints require `X-IIP-Admin-Token`. All writes recorded in `audit_log`.

| Method | Path | Description |
|---|---|---|
| GET | `/api/admin/bootstrap` | Full config dump (team, contacts, ALM, settings) |
| GET/POST | `/api/admin/team-members` | List / create team members |
| PUT/DELETE | `/api/admin/team-members/{id}` | Update / delete team member |
| GET/POST | `/api/admin/escalation-contacts` | List / create escalation contacts |
| PUT/DELETE | `/api/admin/escalation-contacts/{id}` | Update / delete |
| GET/POST | `/api/admin/ibm-contacts` | List / create IBM contacts |
| PUT/DELETE | `/api/admin/ibm-contacts/{id}` | Update / delete |
| GET/POST | `/api/admin/alm-lines` | List / create ALM lines |
| PUT/DELETE | `/api/admin/alm-lines/{alm_line}` | Update / delete ALM line |
| POST/GET | `/api/admin/audit-log` | Write / read audit entries |
| GET/POST | `/api/admin/elm-upgrades` | List / create ELM upgrade records |
| GET/POST | `/api/admin/app-settings` | Read / write app settings |

---

## Database Schema

**Host:** 127.0.0.1:5432 | **DB:** `iip_db` | **Owner:** `iip_user`
**Schema file:** `schema/iip_schema.sql` (v5, single source of truth)

```
27 tables  |  3 views  |  1 matview  |  9 triggers  |  90 indexes  |  13 FKs
```

### Live Row Counts (May 2, 2026)

| Table | Rows | Purpose |
|---|---|---|
| `case_status_history` | 276,096 | Per-upload status snapshot — largest table |
| `cases` | 3,690 | IBM Support cases — primary fact table |
| `audit_log` | 1,136 | Append-only admin write trail |
| `weekly_closed_cases` | 1,601 | Weekly tracker close entries |
| `uploads` | 153 | File import registry (SHA-256 dedup) |
| `duplicate_references` | 42 | Detected duplicate case pairs |
| `team_members` | 35 | Team roster |
| `ibm_contacts` | 25 | IBM side contacts by group |
| `performance_wednesday_comments` | 22 | Performance review notes |
| `weekly_reopened_sync` | 18 | Denormalized reopened snapshot for tracker UI |
| `alm_lines` | 21 | ALM line contact directory |
| `app_settings` | 16 | Typed key-value app config |
| `app_settings_backup` | 17 | Snapshot copy — read-only reference |
| `ibm_ideas` | 9 | IBM Ideas / RFE records |
| `escalation_contacts` | 8 | Escalation contact list |
| `idea_case_links` | 2 | Idea ↔ case M:M junction |
| `performance_slot_days` | 2 | Slot day overrides per case/month |
| `case_grayout_state` | 10 | Per-case per-week grayout flag for tracker UI |
| `elm_upgrades` | 1 | ELM version upgrade log |
| `admin_credentials` | 1 | Single bcrypt password hash |
| `admin_sessions` | 1 | Active 12-hour session tokens |
| `security_questions` | 1 | Two Q&A pairs for password reset |
| `availability_alerts` | 0 | Per-case per-week follow-up tracking |
| `error_log` | 0 | Append-only frontend error capture |
| `rfe_annotations` | 0 | Per-idea notes / tags / target-release |
| `case_reopen_log` | 0 | Append-only manual reopen action log |
| `saved_searches` | 0 | Per-dashboard saved filter presets |

### Table Groups

#### Core import pipeline
```
uploads              → file import registry; SHA-256 dedup; case_fingerprint
cases                → primary fact table; 28 columns; FK → uploads
case_status_history  → one row per (case, upload); ~276K rows
```

#### Weekly tracker
```
weekly_closed_cases  → source: Weekly_Closed_Cases_Tracking_YYYY.xlsm
weekly_reopened_sync → denormalized snapshot; avoids live mv join in UI
case_grayout_state   → per (case, week, year) crossed-out flag
```

#### RFE / Ideas
```
ibm_ideas            → source: IBM_Ideas.csv
idea_case_links      → idea ↔ case M:M; ON DELETE CASCADE both sides
rfe_annotations      → per-idea notes/tags/target-release; replaces old JSON blob
```

#### Reference data (admin-managed)
```
team_members         → name UNIQUE; display_name alias; status Active/Inactive
alm_lines            → PK: alm_line; 4 contact pairs (customer, LM, responsible, proxy)
ibm_contacts         → group_name + name + email
escalation_contacts  → group_name + name + email
```

#### Analytics / derived
```
duplicate_references  → populated at import time from weekly category + TS\d+ pattern
availability_alerts   → per-case per-week followup tracking (currently unused)
mv_reopened_cases     → materialized view; refreshed after every CSV/XLSM import
```

#### Performance module
```
performance_slot_days          → slot day overrides per case/year/month
performance_wednesday_comments → per-case per-date review comments
```

#### Action logs
```
case_reopen_log  → append-only; written by POST /api/v2/cases/{n}/reopen
audit_log        → append-only; written by all admin writes
error_log        → append-only; written by POST /api/store-public/ibm_error_log_v1
```

#### User preferences
```
saved_searches  → per-dashboard filter presets; JSONB query blob; is_shared flag
```

#### System / auth
```
app_settings        → 16 typed keys; see below
app_settings_backup → snapshot from last migration; no trigger; read-only
elm_upgrades        → ELM version tracking; UNIQUE (elm_version, ifix_version)
admin_credentials   → single row: username=admin, bcrypt hash
admin_sessions      → TTL 12h; pruned on each login
security_questions  → two Q&A pairs; answers matched case-insensitively
```

### app_settings keys (16)

| Key | Default / Example | Purpose |
|---|---|---|
| `app_title` | `IBM CASES` | Header title |
| `app_subtitle` | `IBM Case Intelligence Platform` | Header subtitle |
| `team_name` | `"BD/TOA-ETS5"` | Team label in header/sidebar |
| `case_number_pattern` | `TS\d{8,}` | Regex to validate case numbers on import |
| `customer_account_id` | `881812` | IBM account ID for case filtering |
| `customer_products` | `[...]` | JSON array of product names for filter |
| `closed_statuses` | `["Closed by IBM",...]` | JSON array of closed status strings |
| `defect_base_url` | `https://rb-ubk-clm-01...` | Base URL for work-item deep links |
| `idle_timeout_ms` | `1800000` | Idle timeout (30 min) |
| `idle_warning_ms` | `1620000` | Idle warning (27 min) |
| `sender_name` | `IIP Admin` | Sender name in reminder emails |
| `sla_closure_days` | `30` | SLA closure window in days |
| `sla_target_pct` | `80` | SLA target % |
| `table_page_size` | `50` | Default rows per page |
| `wt_categories` | `[{name, color},...]` | Weekly tracker category list with CSS colors |
| `tracker_ui_state` | `{history:[...]}` | Performance tracker UI state (history/overrides) |

### Views & Materialized View

| Name | Type | Purpose |
|---|---|---|
| `v_duplicate_cases` | View | Duplicate + original case joined detail |
| `v_weekly_summary` | View | Per-week count rollup (total, reopened, dup, rfe, perf) |
| `v_reopened_cases` | View | Legacy reopened view — kept for compat; **slow** |
| `mv_reopened_cases` | Matview | Fast version of v_reopened_cases — use this for all queries |

`mv_reopened_cases` refresh (run after every import):
```sql
REFRESH MATERIALIZED VIEW CONCURRENTLY mv_reopened_cases;
```

### Triggers (9)

All are `BEFORE UPDATE` → call `set_updated_at()` or `_set_updated_at()`:

```
trg_uploads_updated_at              trg_team_members_updated_at
trg_cases_updated_at                trg_ibm_ideas_updated_at
trg_ibm_contacts_updated_at         trg_escalation_contacts_updated_at
trg_alm_lines_updated_at            trg_availability_alerts_updated_at
trg_app_settings_ts
```

Two trigger function variants exist (both in production):
- `set_updated_at()` — sets `updated_at = CURRENT_TIMESTAMP` (timestamp without tz)
- `_set_updated_at()` — sets `updated_at = NOW()` (used by `app_settings`, TIMESTAMPTZ)

---

## Authentication Flow

```
1. POST /api/auth  { password }
   → bcrypt verify against admin_credentials.password_hash
   → INSERT INTO admin_sessions (token, expires_at=now+12h)
   → return { token }

2. Frontend stores token in sessionStorage

3. Admin requests include: X-IIP-Admin-Token: <token>

4. Backend: SELECT 1 FROM admin_sessions WHERE token=$1 AND expires_at > NOW()

5. POST /api/auth/logout → DELETE FROM admin_sessions WHERE token=$1
```

---

## Data Import Flow

```
Admin uploads file via Admin portal
    ↓
POST /api/v2/upload/{type}  (multipart/form-data)
    ↓
Validate extension, size cap, compute SHA-256
    ↓
Check uploads.file_hash — reject if duplicate
    ↓
Save to /tmp, call data_importer.import_*(filepath)
    ↓
Parse CSV/XLSM → upsert rows into DB tables
    ↓
For CSV imports: REFRESH MATERIALIZED VIEW CONCURRENTLY mv_reopened_cases
    ↓
Update uploads.status = 'success' / 'failed'
    ↓
Broadcast SSE event: { type: 'upload-complete', upload_id }
    ↓
All browser tabs receive event → refresh their data
```

---

## Frontend — Dashboard Modules

Each dashboard is an independent JS file in `js/dashboards/`.

| File | Dashboard |
|---|---|
| `overview.js` | Case overview — counts, severity breakdown |
| `created.js` | Cases created over time |
| `closed.js` | Weekly close tracking |
| `members.js` | Per-member workload |
| `team.js` | Team-level aggregates |
| `customer.js` | Cases by customer number |
| `performance.js` | Performance cases, slot days, Wednesday review |
| `investigate.js` | Case investigation archive |
| `weekly-tracker.js` | Weekly close tracker with grayout + categories |
| `rfe-tracking-advanced.js` | IBM Ideas / RFE with annotations |
| `info.js` | Static info / announcements |
| `documentation.js` | In-app knowledge base |
| `how-it-works.js` | How-to guides |
| `app-tour.js` | Guided tour |
| `admin-dash.js` | Admin portal |

### Shared Modules (`js/modules/`)

```
api/         — fetch wrappers, base URL resolution
auth/        — session token management
data/        — case parsing, filtering, aggregation
ui/          — toasts, modals, tabs, loading states
tracker/     — weekly tracker state machine + render
platform/    — SSE client, hash router, saved-search helpers
admin/       — admin CRUD helpers
legacy/      — backward-compat shims
patches.js   — runtime patches for render bugs
similarity.js — case similarity scoring
```

---

## Schema Version History

| Version | Date | Changes |
|---|---|---|
| v1 | 2026-04-21 | Initial 22-table schema: `iip_kv`, `name_aliases` |
| v2 | 2026-04-25 | Dropped `iip_kv`, `name_aliases`; added `error_log`, `case_grayout_state`, `weekly_reopened_sync`; expanded app_settings 4 → 15 rows |
| v3 | 2026-04-27 | Added `mv_reopened_cases` (matview), `rfe_annotations`; migrated `tracker_persist_meta` → `tracker_ui_state` |
| v4 | 2026-05-01 | Full live-DB audit; added `app_settings_backup`, `elm_upgrades`, `uploads.case_fingerprint`; fixed `team_members.display_name` → TEXT; removed 10 stale dup indexes |
| v5 | 2026-05-02 | Full live-DB audit via `check_db.sql`; added `case_reopen_log`, `saved_searches` to schema; dropped 10 orphan indexes → 90 total; corrected table count 28 → 27 |

**Dropped objects (kept for reference):**

| Object | Dropped | Reason |
|---|---|---|
| `iip_kv` | v2 | KV migrated to proper tables |
| `name_aliases` | v2 | Aliases moved to `team_members.display_name` |
| `defect_work_items` | pre-v4 | Consolidated into `cases.work_item` + `cases.perf_type` |
