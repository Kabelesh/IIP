﻿# IIP — IBM Issue & Performance Portal

> Internal analytics platform for the BD/TOA-ETS5 IBM ELM support team at Bosch.

**Version:** v1.0.0
**Status:** Live
**URL:** `https://rb-alm-01-d8.de.bosch.com/iip/`
**Last verified:** April 24, 2026

---

## What is IIP?

IIP is a single-page analytics web application that centralises IBM ELM support case intelligence for the Bosch BD/TOA-ETS5 team. It replaces manual Excel-based tracking with a live, multi-user portal backed by PostgreSQL.

**Core capabilities:**
- 14 dashboard views for open cases, weekly close tracking, performance, investigations, customers, team workload, ideas (RFE), and more
- Admin portal for team/contact directory management and data uploads
- Real-time cross-user sync via Server-Sent Events (SSE)
- Duplicate IBM Support case export detection and deduplication
- SHA-256 file hash deduplication (re-uploading the same file is a no-op)
- Audit log for all admin writes

---

## Technology Stack

| Layer | Technology |
|---|---|
| Frontend | Vanilla JavaScript ES6+ — no build step, no framework |
| Charting | Chart.js 4.4.2 |
| Spreadsheet parse | SheetJS 0.18.5 |
| Backend | Python 3.9.25 — FastAPI 0.115.5 + Uvicorn 0.32.1 |
| Database driver | asyncpg 0.30.0 (no ORM — plain SQL) |
| Database | PostgreSQL 13.23 |
| Auth | bcrypt + per-session token (12h TTL), stored in `admin_sessions` table |
| Web server | Apache httpd — reverse proxy on RHEL 9.7 |
| Host OS | Red Hat Enterprise Linux 9.7 (Plow) |

---

## Project Structure

```
/opt/IBM/IIP/
├── frontend/                    # Apache DocumentRoot — all static assets
│   ├── index.html               # Single-page app shell
│   ├── favicon.ico
│   ├── admin/
│   │   ├── admin.html           # Admin portal shell
│   │   └── admin_login.html
│   ├── js/
│   │   ├── app.js               # Bootstrap, router, tab orchestration
│   │   ├── dashboards/          # One JS file per dashboard tab (14 files)
│   │   ├── data/                # Static reference data
│   │   └── modules/
│   │       ├── api/             # Fetch wrappers, admin API client
│   │       ├── data/            # Config, storage, dynamic-config
│   │       ├── ui/              # Modals, state, onboarding, chrome
│   │       ├── tracker/         # Weekly tracker state + render
│   │       ├── platform/        # SSE client, hash router, saved search
│   │       ├── admin/           # Admin CRUD helpers
│   │       └── legacy/          # Backward-compat shims
│   ├── css/
│   │   ├── ui-system.css        # Design tokens, typography, layout
│   │   ├── core/                # base, components, layout, variables
│   │   └── features/            # Per-dashboard styles (14 files)
│   └── data/                    # Runtime JSON data files
├── backend/
│   ├── main.py                  # FastAPI app, middleware, lifespan
│   ├── database.py              # asyncpg connection pool
│   ├── auth.py                  # bcrypt + session token helpers
│   ├── models.py                # Pydantic request/response models
│   ├── data_importer.py         # CSV/XLSX/XLSM parsing logic
│   ├── seed_data.py             # Auto-seed on first boot
│   └── routers/
│       ├── auth.py              # POST /api/auth, logout, password, security Qs
│       ├── store.py             # KV store API (/api/store/*)
│       ├── db_cases.py          # Core data API (/api/v2/*)
│       ├── admin.py             # Admin CRUD API (/api/admin/*)
│       └── cases.py             # Stub (legacy compatibility)
├── schema/
│   └── iip_schema.sql           # Complete DB schema — single source of truth
├── migrations/                  # Incremental SQL migration files (tracked by schema_migrations)
├── Excel_sheets/                # Archived IBM Support CSV exports
├── Datas/                       # Weekly tracker XLSMs and Ideas CSV
├── IIP_backups/                 # Daily DB backups (7-day retention)
│   └── db/                      # iip_db_YYYYMMDD_HHMMSS.sql.gz
├── README.md
├── ARCHITECTURE.md
├── OPERATIONS.md
├── deploy.sh                    # Zero-downtime deploy + migration runner
├── restart.sh                   # Quick restart (httpd + backend)
├── zip.sh
└── db.sh
```

---

## User Access

| Role | How to access | Authentication |
|---|---|---|
| Read-only user | Open `https://rb-alm-01-d8.de.bosch.com/iip/` in browser | None — all dashboards are public read |
| Admin | Click the lock icon → enter admin password | Session token (12h), stored in DB |

> Admin password is set via `POST /api/auth/set-password` on first boot or via `backend/reset_admin.py` on the server.

---

## Data Sources

| File type | Content | Where to upload |
|---|---|---|
| IBM Support Case CSV | All open/closed cases | Admin → Upload Cases |
| `Weekly_Closed_Cases_Tracking_20XX.xlsm` | Weekly close tracking by CW | Admin → Upload Weekly |
| `IBM_Ideas.csv` | RFE/Idea tracking | Admin → Upload Ideas |
| `Team_Members.xlsx` | Team roster | Admin → Upload Team |
| Admin UI | ALM lines, IBM contacts, escalation contacts | Admin → respective tabs |

For architecture, API reference, and DB schema see [ARCHITECTURE.md](ARCHITECTURE.md).
For server operations, deployment, and troubleshooting see [OPERATIONS.md](OPERATIONS.md).

---

## Changelog

### v1.0.0 — May 12, 2026
- **Ops:** Replaced manual `nohup` process with proper `systemd` unit (`iip-fastapi.service`) — `Restart=always`, starts on boot
- **Ops:** Killed orphan uvicorn process on `:8080` (publicly exposed, unproxied)
- **Ops:** Removed duplicate `iip-api-proxy.conf` httpd config that caused 301 redirects
- **Ops:** Created `name_aliases` table (was missing from DB despite being in schema)
- **Ops:** Drained 4 legacy oversized blobs from `iip_kv` (815 KB) — exported to disk, DB is now authoritative
- **Ops:** Installed daily DB backup cron (`/usr/local/bin/iip_db_backup.sh`) with 7-day gzip retention
- **Ops:** Added 14-day log rotation via `/etc/logrotate.d/iip`
- **Ops:** Added health watchdog cron every 5 minutes with auto-restart
- **Ops:** Added `deploy.sh` — snapshot, migration runner, health-checked restart, automatic rollback
- **Ops:** Added `schema_migrations` table for tracked incremental DB migrations
- **Ops:** Added `migrations/` directory for future SQL migration files
