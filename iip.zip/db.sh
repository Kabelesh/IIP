PGPASSWORD="Admin@123" psql -U iip_user -h localhost -p 5432 -d iip_db

