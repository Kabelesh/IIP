-- ================================================================
-- IIP Database Schema — Single Source of Truth
-- ================================================================
-- Database:   iip_db
-- User:       iip_user
-- PostgreSQL: 13.23
-- Server:     si0vm14401 (rb-alm-01-d8.de.bosch.com)
-- Last verified against live DB: 2026-05-02
--
-- Objects:  27 tables | 3 views | 1 matview | 9 triggers
--
-- ----------------------------------------------------------------
-- HOW TO USE
-- ----------------------------------------------------------------
--   Fresh install (empty DB):
--     psql -U iip_user -d iip_db -f schema/iip_schema.sql
--
--   Verify live DB matches this file:
--     psql -U iip_user -d iip_db -f schema/check_db.sql
--
--   Full reset  *** DESTROYS ALL DATA ***:
--     Uncomment the DROP block below, run the file, re-comment it.
--
--   Idempotency:
--     - Indexes: idempotent (IF NOT EXISTS)
--     - Tables / views: NOT idempotent — run on an empty DB only
--     - app_settings seed: idempotent (ON CONFLICT DO NOTHING)
--
-- ----------------------------------------------------------------
-- SCHEMA HISTORY (consolidated — patch files no longer needed)
-- ----------------------------------------------------------------
--   v1  (2026-04-21): Initial 22-table schema (iip_kv, name_aliases)
--   v2  (2026-04-25): Dropped iip_kv → migrated to proper tables
--                     Dropped name_aliases → team_members.display_name
--                     Added error_log, case_grayout_state,
--                       weekly_reopened_sync
--                     Expanded app_settings seed 4 → 15 rows
--   v3  (2026-04-27): Added mv_reopened_cases (materialized view)
--                     Added rfe_annotations
--                     Migrated tracker_persist_meta → tracker_ui_state
--   v4  (2026-05-01): Full live-DB audit & reconciliation
--                     Added app_settings_backup, elm_upgrades
--                     Added uploads.case_fingerprint
--                     Fixed team_members.display_name → TEXT
--                     Removed 10 duplicate indexes from live DB
--                     Fixed team_name seed: '2026' → 'BD/TOA-ETS5'
--                     Consolidated schema_patch_v2 + v3 into this file
--                     Archived: schema_patch_v2.sql, schema_patch_v3.sql
--   v5  (2026-05-02): Full live-DB audit (check_db.sql)
--   v6  (2026-05-09): Added wt_case_history (was created live, missing from schema)
--                     Removed 394-line duplicate route block from db_cases.py
--                     Added case_reopen_log (manual reopen workflow)
--                     Added saved_searches (per-dashboard saved filters)
--                     Corrected table count: 28 → 27 (app_settings_backup
--                       is a snapshot, not a missing table)
--                     Identified 8 orphan duplicate indexes for cleanup
--   v7  (2026-05-09): Removed 17 dead API routes (no frontend callers)
--                     Dropped 3 unused tables from live DB:
--                       app_settings_backup, availability_alerts, case_reopen_log
--                     Table count: 28 → 25
--   v8  (2026-05-12): DB maintenance run on live server
--                     Added idx_csh_status_closed (partial composite) on
--                       case_status_history — eliminates 280K-row seq scan in
--                       /weekly-tracker CTE
--                     Dropped idx_case_grayout_lookup (duplicate of PK)
--                     REFRESH MATERIALIZED VIEW CONCURRENTLY mv_reopened_cases
--                     ANALYZE on case_status_history, weekly_closed_cases,
--                       cases, mv_reopened_cases
--                     JS: cleaned _applySeed() body (dead _svy ref removed)
--                     JS: removed duplicate _renderWeekNav call in _renderContent
--
-- ----------------------------------------------------------------
-- TABLES (25)
-- ----------------------------------------------------------------
--   Core data:
--     uploads               file import log (dedup via SHA-256 hash)
--     team_members          team roster from Team_Members.xlsx
--     cases                 IBM Support case listing (CSV/XLSX import)
--     case_status_history   per-upload status snapshot (~280K rows)
--
--   Weekly tracker:
--     weekly_closed_cases   Weekly_Closed_Cases_Tracking_YYYY.xlsm
--     weekly_reopened_sync  denormalized snapshot for tracker UI
--     case_grayout_state    per-case per-week grayout flag
--
--   RFE / Ideas:
--     ibm_ideas             IBM_Ideas.csv import
--     idea_case_links       idea ↔ case M:M junction
--     rfe_annotations       per-idea notes / tags / target-release
--
--   Reference data:
--     alm_lines             ALM_Line_Details.xlsx
--     ibm_contacts          IBM_Contact_Details.xlsx
--     escalation_contacts   Escalation_Contact_Details.xlsx
--
--   Derived / analytics:
--     duplicate_references  auto-detected from weekly categories
--
--   Performance:
--     performance_slot_days          slot-day overrides per case/month
--     performance_wednesday_comments Wednesday review comments
--
--   System:
--     audit_log             append-only admin action log
--     error_log             append-only frontend error capture
--     app_settings          typed key-value config
--     elm_upgrades          ELM version tracking
--     admin_credentials     single-row bcrypt password
--     admin_sessions        12-hour session tokens
--     security_questions    two Q&A pairs for password reset
--     saved_searches        per-dashboard saved filter presets
--     wt_case_history       append-only audit log for Weekly Tracker edits
--
-- ----------------------------------------------------------------
-- VIEWS (3)
-- ----------------------------------------------------------------
--   v_duplicate_cases   duplicate + original case detail
--   v_weekly_summary    per-week count rollup
--   v_reopened_cases    legacy reopened-case view (kept for compat)
--                       → prefer mv_reopened_cases for hot queries
--
-- ----------------------------------------------------------------
-- MATERIALIZED VIEWS (1)
-- ----------------------------------------------------------------
--   mv_reopened_cases   fast version of v_reopened_cases
--                       refresh: REFRESH MATERIALIZED VIEW
--                                CONCURRENTLY mv_reopened_cases;
--
-- ----------------------------------------------------------------
-- TRIGGERS (9)
-- ----------------------------------------------------------------
--   trg_uploads_updated_at
--   trg_team_members_updated_at
--   trg_cases_updated_at
--   trg_ibm_ideas_updated_at
--   trg_ibm_contacts_updated_at
--   trg_escalation_contacts_updated_at
--   trg_alm_lines_updated_at
--   trg_availability_alerts_updated_at
--   trg_app_settings_ts
--
-- ----------------------------------------------------------------
-- DROPPED OBJECTS (kept here for reference only)
-- ----------------------------------------------------------------
--   iip_kv              (v2)  KV store — migrated to proper tables
--   name_aliases        (v2)  aliases → team_members.display_name
--   defect_work_items   (pre-v4) consolidated into cases.work_item
-- ================================================================


-- ================================================================
-- FULL RESET — uncomment only when rebuilding from scratch
-- Drop order respects FK dependencies
-- ================================================================
-- DROP MATERIALIZED VIEW IF EXISTS mv_reopened_cases             CASCADE;
-- DROP VIEW  IF EXISTS v_weekly_summary                          CASCADE;
-- DROP VIEW  IF EXISTS v_duplicate_cases                         CASCADE;
-- DROP VIEW  IF EXISTS v_reopened_cases                          CASCADE;
-- DROP TABLE IF EXISTS audit_log                                 CASCADE;
-- DROP TABLE IF EXISTS availability_alerts                       CASCADE;
-- DROP TABLE IF EXISTS duplicate_references                      CASCADE;
-- DROP TABLE IF EXISTS idea_case_links                           CASCADE;
-- DROP TABLE IF EXISTS ibm_ideas                                 CASCADE;
-- DROP TABLE IF EXISTS rfe_annotations                           CASCADE;
-- DROP TABLE IF EXISTS performance_wednesday_comments            CASCADE;
-- DROP TABLE IF EXISTS performance_slot_days                     CASCADE;
-- DROP TABLE IF EXISTS case_status_history                       CASCADE;
-- DROP TABLE IF EXISTS weekly_closed_cases                       CASCADE;
-- DROP TABLE IF EXISTS weekly_reopened_sync                      CASCADE;
-- DROP TABLE IF EXISTS case_grayout_state                        CASCADE;
-- DROP TABLE IF EXISTS cases                                     CASCADE;
-- DROP TABLE IF EXISTS alm_lines                                 CASCADE;
-- DROP TABLE IF EXISTS ibm_contacts                              CASCADE;
-- DROP TABLE IF EXISTS escalation_contacts                       CASCADE;
-- DROP TABLE IF EXISTS team_members                              CASCADE;
-- DROP TABLE IF EXISTS uploads                                   CASCADE;
-- DROP TABLE IF EXISTS app_settings                              CASCADE;
-- DROP TABLE IF EXISTS app_settings_backup                       CASCADE;
-- DROP TABLE IF EXISTS elm_upgrades                              CASCADE;
-- DROP TABLE IF EXISTS error_log                                 CASCADE;
-- DROP TABLE IF EXISTS admin_credentials                         CASCADE;
-- DROP TABLE IF EXISTS admin_sessions                            CASCADE;
-- DROP TABLE IF EXISTS security_questions                        CASCADE;
-- DROP TABLE IF EXISTS saved_searches                              CASCADE;
-- DROP TABLE IF EXISTS case_reopen_log                            CASCADE;
-- DROP TABLE IF EXISTS wt_case_history                            CASCADE;
-- DROP FUNCTION IF EXISTS set_updated_at()                       CASCADE;
-- DROP FUNCTION IF EXISTS _set_updated_at()                      CASCADE;


-- ================================================================
-- EXTENSIONS
-- ================================================================
CREATE EXTENSION IF NOT EXISTS pg_trgm;  -- required for GIN trigram indexes on cases


-- ================================================================
-- TRIGGER FUNCTIONS
-- Both variants exist in production (created by different migrations).
-- set_updated_at  — used by most tables (TIMESTAMP without time zone)
-- _set_updated_at — used by app_settings (TIMESTAMPTZ)
-- ================================================================
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION _set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$;


-- ================================================================
-- UPLOADS
-- Tracks every file import. All data tables reference upload_id
-- to know which import created / last-updated each row.
-- file_hash (SHA-256) prevents the same file being imported twice.
-- case_fingerprint: hash of the case set in this upload (dedup).
-- ================================================================
CREATE TABLE uploads (
  id               SERIAL        PRIMARY KEY,
  filename         VARCHAR(255)  NOT NULL,
  file_type        VARCHAR(10)   NOT NULL CHECK (file_type IN ('CSV','XLSX','XLSM')),
  upload_date      TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
  uploaded_by      VARCHAR(100),
  file_size        BIGINT,
  file_hash        VARCHAR(64),                       -- SHA-256 dedup key
  record_count     INT,
  status           VARCHAR(20)   DEFAULT 'pending'
                                 CHECK (status IN ('pending','processing','success','failed')),
  error_message    TEXT,
  notes            TEXT,
  case_fingerprint TEXT,                              -- hash of case set (added v4)
  created_at       TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
  updated_at       TIMESTAMP     DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_uploads_date      ON uploads (upload_date DESC);
CREATE INDEX IF NOT EXISTS idx_uploads_file_hash ON uploads (file_hash);
CREATE INDEX IF NOT EXISTS idx_uploads_status    ON uploads (status);
CREATE TRIGGER trg_uploads_updated_at
  BEFORE UPDATE ON uploads FOR EACH ROW EXECUTE FUNCTION set_updated_at();


-- ================================================================
-- TEAM MEMBERS
-- Source: Team_Members.xlsx
-- Columns: Team member | Email | Team | Status
-- display_name: optional short alias shown in UI instead of full name.
--   Replaces the old name_aliases table (dropped v2).
--   Matched/applied in store.py: /api/team-config → nameAliases map.
-- ================================================================
CREATE TABLE team_members (
  id           SERIAL        PRIMARY KEY,
  name         VARCHAR(255)  NOT NULL UNIQUE,
  email        VARCHAR(255),
  team         VARCHAR(100),
  status       VARCHAR(50)   DEFAULT 'Active',
  display_name TEXT,                                 -- short alias; NULL = use name as-is
  created_at   TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
  updated_at   TIMESTAMP     DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_team_members_name   ON team_members (name);
CREATE INDEX IF NOT EXISTS idx_team_members_status ON team_members (status);
CREATE INDEX IF NOT EXISTS idx_tm_name_lower        ON team_members (lower(name));
CREATE TRIGGER trg_team_members_updated_at
  BEFORE UPDATE ON team_members FOR EACH ROW EXECUTE FUNCTION set_updated_at();


-- ================================================================
-- CASES
-- Source: IBM Support Case listing export CSVs
-- CSV columns: Title | Status | Case Number | Legacy number |
--   Severity | Age | Owner | Customer number | Created | Updated |
--   Product | Solution date | Closed Date | Client Asset Identifier |
--   Serial Number | Machine Model | Machine Type | Country Name | Account ISO
-- Extra columns added by app: availability, is_active, business flags
-- work_item consolidated from dropped defect_work_items table (Apr 2026)
-- ================================================================
CREATE TABLE cases (
  case_number             VARCHAR(50)   PRIMARY KEY,
  title                   TEXT,
  status                  VARCHAR(100),
  legacy_number           VARCHAR(50),
  severity                VARCHAR(10),
  age_days                INT,
  owner_name              VARCHAR(255),
  customer_number         VARCHAR(50),
  created_date            DATE,
  updated_date            DATE,
  product                 VARCHAR(255),
  solution_date           DATE,
  closed_date             DATE,
  client_asset_identifier VARCHAR(255),
  serial_number           VARCHAR(100),
  machine_model           VARCHAR(100),
  machine_type            VARCHAR(100),
  country_name            VARCHAR(100),
  account_iso             VARCHAR(10),
  -- App-managed flags
  is_performance_case     BOOLEAN       DEFAULT FALSE,  -- admin-tagged (default FALSE, never NULL)
  is_team_case            BOOLEAN       DEFAULT FALSE,  -- owner found in team_members
  availability            VARCHAR(50)   DEFAULT '',     -- performance availability string
  is_active               BOOLEAN       DEFAULT TRUE,   -- soft-delete flag
  -- Work item (formerly defect_work_items table — consolidated Apr 2026)
  work_item               VARCHAR(100),                 -- e.g. 'Defect 55749' or 'Task 56725'
  perf_type               VARCHAR(50),                  -- 'Performance' | 'Non-performance'
  latest_upload_id        INT           REFERENCES uploads(id) ON DELETE SET NULL,
  created_at              TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
  updated_at              TIMESTAMP     DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_cases_owner_name       ON cases (owner_name);
CREATE INDEX IF NOT EXISTS idx_cases_owner_lower       ON cases (lower(owner_name));
CREATE INDEX IF NOT EXISTS idx_cases_customer_number  ON cases (customer_number);
CREATE INDEX IF NOT EXISTS idx_cases_status           ON cases (status);
CREATE INDEX IF NOT EXISTS idx_cases_closed_date      ON cases (closed_date);
CREATE INDEX IF NOT EXISTS idx_cases_created_date     ON cases (created_date DESC NULLS LAST);
CREATE INDEX IF NOT EXISTS idx_cases_updated_date     ON cases (updated_date DESC NULLS LAST);
CREATE INDEX IF NOT EXISTS idx_cases_is_performance   ON cases (is_performance_case) WHERE is_performance_case = TRUE;
CREATE INDEX IF NOT EXISTS idx_cases_is_perf_false    ON cases (is_performance_case) WHERE is_performance_case = FALSE;
CREATE INDEX IF NOT EXISTS idx_cases_is_team_case     ON cases (is_team_case)        WHERE is_team_case = TRUE;
CREATE INDEX IF NOT EXISTS idx_cases_is_active        ON cases (is_active)           WHERE is_active = TRUE;
CREATE INDEX IF NOT EXISTS idx_cases_work_item        ON cases (work_item)           WHERE work_item IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_cases_perf_type        ON cases (perf_type)           WHERE perf_type IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_cases_case_number_trgm ON cases USING gin (case_number gin_trgm_ops);
CREATE INDEX IF NOT EXISTS idx_cases_title_trgm       ON cases USING gin (title      gin_trgm_ops);
CREATE TRIGGER trg_cases_updated_at
  BEFORE UPDATE ON cases FOR EACH ROW EXECUTE FUNCTION set_updated_at();


-- ================================================================
-- CASE STATUS HISTORY
-- One row per (case, upload) snapshot — tracks status over time.
-- ~280,000 rows in production (largest table by actual count).
-- pg_stat estimate is unreliable here — run SELECT COUNT(*) for truth.
-- Powers mv_reopened_cases materialized view.
-- ================================================================
CREATE TABLE case_status_history (
  id          SERIAL        PRIMARY KEY,
  case_number VARCHAR(50)   NOT NULL REFERENCES cases(case_number) ON DELETE CASCADE,
  upload_id   INT           NOT NULL REFERENCES uploads(id)        ON DELETE CASCADE,
  upload_date DATE          NOT NULL,
  status      VARCHAR(100),
  closed_date DATE,
  UNIQUE (case_number, upload_id)
);
CREATE INDEX IF NOT EXISTS idx_csh_case   ON case_status_history (case_number);
CREATE INDEX IF NOT EXISTS idx_csh_upload ON case_status_history (upload_id);
CREATE INDEX IF NOT EXISTS idx_csh_date   ON case_status_history (upload_date);
-- Partial composite index for the /weekly-tracker CTE (eliminates 280K-row seq scan)
CREATE INDEX IF NOT EXISTS idx_csh_status_closed
  ON case_status_history (case_number, upload_id DESC)
  WHERE status IN ('Closed by IBM', 'Closed by Client', 'Closed - Archived');


-- ================================================================
-- WEEKLY CLOSED CASES
-- Source: Weekly_Closed_Cases_Tracking_YYYY.xlsm
-- One sheet per CW (CW01–CW53). Row 1 = headers (inlineStr format).
-- category values: Duplicate | Reopened | RFE | Performance
-- Duplicate detection: category ILIKE 'duplicate' AND comments ~ 'TS0\d+'
-- ================================================================
CREATE TABLE weekly_closed_cases (
  id                   SERIAL        PRIMARY KEY,
  case_number          VARCHAR(50)   NOT NULL REFERENCES cases(case_number) ON DELETE CASCADE,
  week_number          INT           NOT NULL CHECK (week_number BETWEEN 1 AND 53),
  year                 INT           NOT NULL CHECK (year BETWEEN 2020 AND 2099),
  week_label           VARCHAR(10),
  week_start_date      DATE,
  week_end_date        DATE,
  owner                VARCHAR(255),
  comments             TEXT,
  category             VARCHAR(100),
  availability         VARCHAR(255),
  is_reopened          BOOLEAN       DEFAULT FALSE,
  is_duplicate         BOOLEAN       DEFAULT FALSE,
  original_case_number VARCHAR(50),  -- TS0\d+ extracted from comments when is_duplicate=TRUE
  upload_id            INT           REFERENCES uploads(id) ON DELETE SET NULL,
  year_source          INT,
  created_at           TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (case_number, week_number, year)
);
CREATE INDEX IF NOT EXISTS idx_wcc_case_number ON weekly_closed_cases (case_number);
CREATE INDEX IF NOT EXISTS idx_wcc_year_week   ON weekly_closed_cases (year, week_number);
CREATE INDEX IF NOT EXISTS idx_wcc_week_label  ON weekly_closed_cases (week_label);
CREATE INDEX IF NOT EXISTS idx_wcc_category    ON weekly_closed_cases (category);
CREATE INDEX IF NOT EXISTS idx_wcc_is_dup      ON weekly_closed_cases (is_duplicate) WHERE is_duplicate = TRUE;
CREATE INDEX IF NOT EXISTS idx_wcc_is_reopened ON weekly_closed_cases (is_reopened)  WHERE is_reopened = TRUE;


-- ================================================================
-- WEEKLY REOPENED SYNC
-- Denormalized snapshot of reopened case data keyed by
-- (case_number, week, year). Allows the Weekly Tracker to show
-- reopened-case detail without joining mv_reopened_cases live.
-- Populated/refreshed by the backend on each weekly import.
-- ================================================================
CREATE TABLE weekly_reopened_sync (
  case_number VARCHAR(50)   NOT NULL,
  week        VARCHAR(10)   NOT NULL,
  year        INT           NOT NULL,
  closed_date TEXT,
  status      TEXT,
  owner       TEXT,
  title       TEXT,
  severity    TEXT,
  synced_at   TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  PRIMARY KEY (case_number, week, year)
);


-- ================================================================
-- CASE GRAYOUT STATE
-- Per-case per-week grayout flag for the Weekly Tracker UI.
-- is_grayed=TRUE  — case is crossed out (later-week entry supersedes it).
-- is_grayed=FALSE — explicitly un-grayed by admin override.
-- metadata JSONB  — reserved for additional UI state.
-- ================================================================
CREATE TABLE case_grayout_state (
  case_number VARCHAR(50)   NOT NULL,
  week        VARCHAR(10)   NOT NULL,
  year        INT           NOT NULL,
  is_grayed   BOOLEAN       NOT NULL DEFAULT TRUE,
  later_week  VARCHAR(10),
  later_year  INT,
  metadata    JSONB,
  updated_at  TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  PRIMARY KEY (case_number, week, year)
);
-- idx_case_grayout_lookup dropped (2026-05-12): exact duplicate of the PK above


-- ================================================================
-- IBM IDEAS  (RFE Tracking)
-- Source: IBM_Ideas.csv
-- ================================================================
CREATE TABLE ibm_ideas (
  idea_reference     VARCHAR(50)   PRIMARY KEY,
  idea_name          VARCHAR(500),
  product            VARCHAR(255),
  product_reference  VARCHAR(255),
  product_categories TEXT,
  workflow_state     VARCHAR(100),
  is_complete        BOOLEAN       DEFAULT FALSE,
  idea_created_at    TIMESTAMP,
  idea_updated_at    TIMESTAMP,
  url                VARCHAR(500),
  vote_count         INT           DEFAULT 0,
  comment_count      INT           DEFAULT 0,
  tags               TEXT,
  description        TEXT,
  visibility         VARCHAR(100),
  upload_id          INT           REFERENCES uploads(id) ON DELETE SET NULL,
  created_at         TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
  updated_at         TIMESTAMP     DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_ideas_workflow ON ibm_ideas (workflow_state);
CREATE INDEX IF NOT EXISTS idx_ideas_product  ON ibm_ideas (product);
CREATE TRIGGER trg_ibm_ideas_updated_at
  BEFORE UPDATE ON ibm_ideas FOR EACH ROW EXECUTE FUNCTION set_updated_at();


-- ================================================================
-- IDEA CASE LINKS
-- Links an IBM Idea to a case.
-- ================================================================
CREATE TABLE idea_case_links (
  id             SERIAL        PRIMARY KEY,
  idea_reference VARCHAR(50)   NOT NULL REFERENCES ibm_ideas(idea_reference) ON DELETE CASCADE,
  case_number    VARCHAR(50)   NOT NULL REFERENCES cases(case_number)        ON DELETE CASCADE,
  source         TEXT,
  linked_by      VARCHAR(50)   DEFAULT 'system',
  linked_date    TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (idea_reference, case_number)
);
CREATE INDEX IF NOT EXISTS idx_icl_idea_reference ON idea_case_links (idea_reference);
CREATE INDEX IF NOT EXISTS idx_icl_case_number    ON idea_case_links (case_number);


-- ================================================================
-- RFE ANNOTATIONS
-- Per-idea notes/tags/target-release. Added v3.
-- Replaces the rfe_tracking_metadata JSON blob in app_settings.
-- ================================================================
CREATE TABLE rfe_annotations (
  idea_reference VARCHAR(50)  PRIMARY KEY REFERENCES ibm_ideas(idea_reference) ON DELETE CASCADE,
  notes          TEXT         NOT NULL DEFAULT '',
  tags           TEXT         NOT NULL DEFAULT '',
  target_release VARCHAR(100) NOT NULL DEFAULT '',
  updated_at     TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  updated_by     VARCHAR(100)
);
CREATE INDEX IF NOT EXISTS idx_rfe_annotations_updated ON rfe_annotations (updated_at DESC);


-- ================================================================
-- ALM LINES
-- Source: ALM_Line_Details.xlsx
-- ================================================================
CREATE TABLE alm_lines (
  alm_line                     VARCHAR(50)   PRIMARY KEY,
  customer_contact             VARCHAR(255),
  customer_email               VARCHAR(255),
  line_manager                 VARCHAR(255),
  line_manager_email           VARCHAR(255),
  case_responsible             VARCHAR(255),
  case_responsible_email       VARCHAR(255),
  case_responsible_proxy       VARCHAR(255),
  case_responsible_proxy_email VARCHAR(255),
  created_at                   TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
  updated_at                   TIMESTAMP     DEFAULT CURRENT_TIMESTAMP
);
CREATE TRIGGER trg_alm_lines_updated_at
  BEFORE UPDATE ON alm_lines FOR EACH ROW EXECUTE FUNCTION set_updated_at();


-- ================================================================
-- IBM CONTACTS
-- Source: IBM_Contact_Details.xlsx
-- ================================================================
CREATE TABLE ibm_contacts (
  id         SERIAL        PRIMARY KEY,
  group_name VARCHAR(255),
  name       VARCHAR(255),
  email      VARCHAR(255),
  created_at TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP     DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_ibm_contacts_group ON ibm_contacts (group_name);
CREATE TRIGGER trg_ibm_contacts_updated_at
  BEFORE UPDATE ON ibm_contacts FOR EACH ROW EXECUTE FUNCTION set_updated_at();


-- ================================================================
-- ESCALATION CONTACTS
-- Source: Escalation_Contact_Details.xlsx
-- ================================================================
CREATE TABLE escalation_contacts (
  id         SERIAL        PRIMARY KEY,
  group_name VARCHAR(255),
  name       VARCHAR(255),
  email      VARCHAR(255),
  created_at TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP     DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_esc_contacts_group ON escalation_contacts (group_name);
CREATE TRIGGER trg_escalation_contacts_updated_at
  BEFORE UPDATE ON escalation_contacts FOR EACH ROW EXECUTE FUNCTION set_updated_at();


-- ================================================================
-- DUPLICATE REFERENCES
-- Populated at import time when BOTH conditions are true:
--   1. weekly_closed_cases.category ILIKE 'duplicate'
--   2. weekly_closed_cases.comments matches TS0\d+
-- original_case_number has NO FK — the original may predate our data.
-- ================================================================
CREATE TABLE duplicate_references (
  id                    SERIAL        PRIMARY KEY,
  duplicate_case_number VARCHAR(50)   NOT NULL REFERENCES cases(case_number) ON DELETE CASCADE,
  original_case_number  VARCHAR(50),
  detected_in_week      VARCHAR(10),
  detected_by           VARCHAR(50)   DEFAULT 'system',
  detected_date         TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
  reason                TEXT,
  UNIQUE (duplicate_case_number, original_case_number)
);
CREATE INDEX IF NOT EXISTS idx_dr_duplicate_case ON duplicate_references (duplicate_case_number);
CREATE INDEX IF NOT EXISTS idx_dr_original_case  ON duplicate_references (original_case_number);


-- ================================================================
-- AVAILABILITY ALERTS
-- Per-case per-week follow-up tracking for weekly calls.
-- ================================================================
CREATE TABLE availability_alerts (
  id                   SERIAL        PRIMARY KEY,
  case_number          VARCHAR(50)   NOT NULL REFERENCES cases(case_number) ON DELETE CASCADE,
  week_number          INT           NOT NULL CHECK (week_number BETWEEN 1 AND 53),
  year                 INT           NOT NULL CHECK (year BETWEEN 2020 AND 2099),
  needs_followup       BOOLEAN       DEFAULT FALSE,
  followup_reason      TEXT,
  followup_assigned_to VARCHAR(255),
  status               VARCHAR(50)   DEFAULT 'pending'
                                     CHECK (status IN ('pending','in_progress','completed','deferred')),
  notes                TEXT,
  created_at           TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
  updated_at           TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (case_number, week_number, year)
);
CREATE INDEX IF NOT EXISTS idx_alerts_case   ON availability_alerts (case_number);
CREATE INDEX IF NOT EXISTS idx_alerts_week   ON availability_alerts (year, week_number);
CREATE INDEX IF NOT EXISTS idx_alerts_status ON availability_alerts (status);
CREATE TRIGGER trg_availability_alerts_updated_at
  BEFORE UPDATE ON availability_alerts FOR EACH ROW EXECUTE FUNCTION set_updated_at();


-- ================================================================
-- AUDIT LOG
-- Append-only record of all admin writes. No updated_at.
-- ================================================================
CREATE TABLE audit_log (
  id          SERIAL        PRIMARY KEY,
  action      VARCHAR(100),
  entity_type VARCHAR(50),
  entity_id   VARCHAR(100),
  old_value   TEXT,
  new_value   TEXT,
  admin_user  VARCHAR(100),
  change_date TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
  ip_address  VARCHAR(45),
  notes       TEXT
);
CREATE INDEX IF NOT EXISTS idx_audit_entity      ON audit_log (entity_type, entity_id);
CREATE INDEX IF NOT EXISTS idx_audit_change_date ON audit_log (change_date DESC NULLS LAST);
CREATE INDEX IF NOT EXISTS idx_audit_admin_user  ON audit_log (admin_user);


-- ================================================================
-- PERFORMANCE: SLOT DAYS
-- Admin-configurable slot day overrides per case per month.
-- ================================================================
CREATE TABLE performance_slot_days (
  id          SERIAL        PRIMARY KEY,
  case_number VARCHAR(50)   NOT NULL REFERENCES cases(case_number) ON DELETE CASCADE,
  year        INT           NOT NULL,
  month       INT           NOT NULL,
  slot_index  INT           NOT NULL,
  day_of_week INT           NOT NULL,
  updated_by  VARCHAR(255),
  updated_at  TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (case_number, year, month, slot_index)
);
CREATE INDEX IF NOT EXISTS idx_psd_case ON performance_slot_days (case_number);


-- ================================================================
-- PERFORMANCE: WEDNESDAY COMMENTS
-- Per-case per-date comments for the Wednesday performance review.
-- ================================================================
CREATE TABLE performance_wednesday_comments (
  id          SERIAL        PRIMARY KEY,
  case_number VARCHAR(50)   NOT NULL REFERENCES cases(case_number) ON DELETE CASCADE,
  date_key    DATE          NOT NULL,
  comment     TEXT          NOT NULL DEFAULT '',
  updated_by  VARCHAR(255),
  updated_at  TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (case_number, date_key)
);
CREATE INDEX IF NOT EXISTS idx_pwc_case ON performance_wednesday_comments (case_number);
CREATE INDEX IF NOT EXISTS idx_pwc_date ON performance_wednesday_comments (date_key);


-- ================================================================
-- ERROR LOG
-- Append-only frontend error capture.
-- Written by POST /api/store-public/ibm_error_log_v1.
-- No updated_at — rows are never modified after insert.
-- ================================================================
CREATE TABLE error_log (
  id          SERIAL        PRIMARY KEY,
  occurred_at TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  message     TEXT,
  stack       TEXT,
  context     JSONB
);
CREATE INDEX IF NOT EXISTS idx_error_log_occurred ON error_log (occurred_at DESC);


-- ================================================================
-- APP SETTINGS
-- Typed key-value config for admin-controlled application settings.
-- Exposed via GET /api/team-config and GET /api/config.
-- Writes go through the admin panel (authenticated).
-- ================================================================
CREATE TABLE app_settings (
  key         VARCHAR(100)  PRIMARY KEY,
  value       TEXT          NOT NULL DEFAULT '',
  description TEXT,
  updated_at  TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  updated_by  VARCHAR(100)
);
CREATE TRIGGER trg_app_settings_ts
  BEFORE UPDATE ON app_settings FOR EACH ROW EXECUTE FUNCTION _set_updated_at();

INSERT INTO app_settings (key, value, description) VALUES
  ('case_number_pattern',
   'TS\d{8,}',
   'Regex (case-insensitive) to validate case numbers on import'),
  ('customer_account_id',
   '881812',
   'IBM customer account ID used for case API filtering'),
  ('defect_base_url',
   '',
   'Base URL for defect/work-item deep links (leave blank to hide links)'),
  ('customer_products',
   '["Engineering Lifecycle Management Base","Engineering Lifecycle Management Suite","Engineering Requirements Management DOORS Next","Engineering Test Management","Engineering Workflow Management"]',
   'JSON array of customer product names shown in product filter'),
  ('app_title',
   'IBM CASES',
   'Application title shown in header'),
  ('app_subtitle',
   'IBM Case Intelligence Platform',
   'Application subtitle shown in header'),
  ('closed_statuses',
   '["Closed by IBM","Closed by Client","Closed - Archived"]',
   'JSON array of closed status strings'),
  ('idle_timeout_ms',
   '1800000',
   'Idle timeout in milliseconds (30 min)'),
  ('idle_warning_ms',
   '1620000',
   'Idle warning threshold in milliseconds (27 min)'),
  ('sender_name',
   '',
   'Sender name used in reminder emails'),
  ('sla_closure_days',
   '30',
   'SLA closure window in days'),
  ('sla_target_pct',
   '80',
   'SLA target percentage'),
  ('table_page_size',
   '50',
   'Default rows per page in case tables'),
  ('team_name',
   '"BD/TOA-ETS5"',
   'Team name shown in header and sidebar'),
  ('wt_categories',
   '[{"name":"Backup & Restore","color":"var(--red)"},{"name":"Database Connectivity Issues","color":"var(--orange)"},{"name":"DCM Connectivity Issues","color":"var(--orange)"},{"name":"Duplicate","color":"var(--red)"},{"name":"Export / Import Issues","color":"var(--yellow-text)"},{"name":"Insufficient Information in Logs","color":"#555"},{"name":"Issue Fixed in iFix","color":"var(--green)"},{"name":"Known Defect","color":"var(--red)"},{"name":"LQE Validation / Reindexing","color":"var(--ibm-blue-60)"},{"name":"Out of Memory / Heap Issues","color":"#c00"},{"name":"Reopened","color":"var(--purple)"},{"name":"RFE","color":""},{"name":"Single Occurrence Issue","color":"var(--purple)"},{"name":"TRS Feed Validation","color":"var(--ibm-blue-50)"}]',
   'Weekly Tracker category list with colors')
ON CONFLICT (key) DO NOTHING;


-- ================================================================
-- APP SETTINGS BACKUP
-- Snapshot copy of app_settings created by migration scripts.
-- No PK, no trigger — read-only reference / rollback safety net.
-- Do not write to this table directly; it is managed by migrations.
-- ================================================================
CREATE TABLE app_settings_backup (
  key         VARCHAR(100),
  value       TEXT,
  description TEXT,
  updated_at  TIMESTAMPTZ,
  updated_by  VARCHAR(100)
);


-- ================================================================
-- ELM UPGRADES
-- Tracks ELM (Engineering Lifecycle Management) version upgrades.
-- One row per unique (elm_version, ifix_version) combination.
-- Created by admin via the Admin Portal.
-- ================================================================
CREATE TABLE elm_upgrades (
  id           SERIAL        PRIMARY KEY,
  elm_version  VARCHAR(50)   NOT NULL,
  ifix_version VARCHAR(50)   NOT NULL,
  upgrade_date DATE          NOT NULL,
  notes        TEXT,
  created_by   VARCHAR(100),
  created_at   TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (elm_version, ifix_version)
);


-- ================================================================
-- ADMIN CREDENTIALS
-- Single row: username='admin', bcrypt password hash.
-- Default password seeded by seed_data.py on first boot.
-- ================================================================
CREATE TABLE admin_credentials (
  username      TEXT          PRIMARY KEY,
  password_hash TEXT          NOT NULL,
  created_at    TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);


-- ================================================================
-- ADMIN SESSIONS
-- One row per active session token. TTL = 12 hours.
-- Expired sessions are purged on each new login.
-- ================================================================
CREATE TABLE admin_sessions (
  token      TEXT          PRIMARY KEY,
  username   TEXT          NOT NULL DEFAULT 'admin',
  created_at TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  expires_at TIMESTAMPTZ   NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_admin_sessions_expires  ON admin_sessions (expires_at);
CREATE INDEX IF NOT EXISTS idx_admin_sessions_username ON admin_sessions (username);


-- ================================================================
-- SECURITY QUESTIONS
-- Two Q&A pairs for password self-reset.
-- Answers stored and matched case-insensitively (lowercased).
-- ================================================================
CREATE TABLE security_questions (
  username   TEXT          PRIMARY KEY,
  q1         TEXT          NOT NULL,
  a1         TEXT          NOT NULL,
  q2         TEXT          NOT NULL,
  a2         TEXT          NOT NULL,
  updated_at TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);



-- ================================================================
-- CASE REOPEN LOG
-- Append-only log of manual case reopen actions.
-- Written by the backend when a user explicitly reopens a case
-- via the UI (reason_code + justification required).
-- assign_to: optional team member to assign the case to on reopen.
-- No updated_at — rows are never modified after insert.
-- ================================================================
CREATE TABLE case_reopen_log (
  id            SERIAL        PRIMARY KEY,
  case_number   TEXT          NOT NULL,
  reason_code   TEXT          NOT NULL,
  reason_label  TEXT          NOT NULL,
  justification TEXT          NOT NULL,
  assign_to     TEXT          NOT NULL DEFAULT '',
  reopened_at   TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_reopen_log_case ON case_reopen_log (case_number);


-- ================================================================
-- SAVED SEARCHES
-- Per-dashboard saved filter presets. Users can save and reuse
-- complex filter combinations across sessions.
-- dashboard: identifier for the dashboard this search belongs to.
-- query:     JSONB blob of filter state (filters, sorts, etc.).
-- is_shared: TRUE = visible to all users, FALSE = creator only.
-- use_count: incremented each time the search is applied.
-- last_used: updated each time the search is applied.
-- No updated_at — use last_used to track recency.
-- ================================================================
CREATE TABLE saved_searches (
  id         SERIAL        PRIMARY KEY,
  dashboard  TEXT          NOT NULL DEFAULT '',
  name       TEXT          NOT NULL,
  query      JSONB         NOT NULL DEFAULT '{}',
  is_shared  BOOLEAN       NOT NULL DEFAULT FALSE,
  use_count  INT           NOT NULL DEFAULT 0,
  last_used  TIMESTAMPTZ,
  created_at TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_saved_searches_dashboard ON saved_searches (dashboard);


-- ================================================================
-- WT CASE HISTORY
-- Append-only audit log for the Weekly Tracker.
-- One row is inserted every time a user saves a comment, category,
-- or availability change on a weekly tracker row.
-- Used by the History tab in the Weekly Tracker UI.
-- comment_before / comment_after: the text before and after the edit.
-- status_before / status_after:   case status when the change was made.
-- availability: the availability value set at save time (may be blank).
-- is_reopen: TRUE when this entry represents a cross-week reopened case.
-- prev_week: the week the case was previously seen in (for reopened cases).
-- seed_id: dedup key for history seeded from the frontend (_seedId).
-- changed_by: 'user' | 'csv-upload' | 'reopened' | 'system'.
-- ================================================================
CREATE TABLE wt_case_history (
  id             SERIAL        PRIMARY KEY,
  case_number    TEXT          NOT NULL,
  owner          TEXT          NOT NULL DEFAULT '',
  week           TEXT          NOT NULL,
  year           INT           NOT NULL,
  status_before  TEXT          NOT NULL DEFAULT '',
  status_after   TEXT          NOT NULL DEFAULT '',
  comment_before TEXT          NOT NULL DEFAULT '',
  comment_after  TEXT          NOT NULL DEFAULT '',
  availability   TEXT          NOT NULL DEFAULT '',
  is_reopen      BOOLEAN       NOT NULL DEFAULT FALSE,
  prev_week      TEXT          NOT NULL DEFAULT '',
  changed_by     TEXT          NOT NULL DEFAULT 'user',
  seed_id        TEXT          UNIQUE,
  created_at     TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_wt_hist_case    ON wt_case_history (case_number);
CREATE INDEX IF NOT EXISTS idx_wt_hist_week    ON wt_case_history (week, year);
CREATE INDEX IF NOT EXISTS idx_wt_hist_created ON wt_case_history (created_at DESC);


-- ================================================================
-- VIEWS
-- ================================================================

-- Duplicate cases with original case details
CREATE VIEW v_duplicate_cases AS
SELECT
  dr.duplicate_case_number,
  dc.title      AS duplicate_title,
  dc.owner_name AS duplicate_owner,
  dr.original_case_number,
  oc.title      AS original_title,
  dr.detected_in_week,
  dr.reason,
  dr.detected_date
FROM duplicate_references dr
LEFT JOIN cases dc ON dr.duplicate_case_number = dc.case_number
LEFT JOIN cases oc ON dr.original_case_number  = oc.case_number;

-- Per-week summary counts
CREATE VIEW v_weekly_summary AS
SELECT
  w.year,
  w.week_number,
  w.week_label,
  w.week_start_date,
  w.week_end_date,
  COUNT(DISTINCT w.case_number)                                                      AS total_cases_closed,
  COUNT(DISTINCT CASE WHEN w.is_reopened = TRUE         THEN w.case_number END)     AS reopened_count,
  COUNT(DISTINCT CASE WHEN w.is_duplicate = TRUE        THEN w.case_number END)     AS duplicate_count,
  COUNT(DISTINCT CASE WHEN w.category ILIKE 'rfe'       THEN w.case_number END)     AS rfe_count,
  COUNT(DISTINCT CASE WHEN c.is_performance_case = TRUE THEN w.case_number END)     AS performance_count,
  COUNT(DISTINCT CASE WHEN c.is_team_case = TRUE        THEN w.case_number END)     AS team_count
FROM weekly_closed_cases w
LEFT JOIN cases c ON w.case_number = c.case_number
GROUP BY w.year, w.week_number, w.week_label, w.week_start_date, w.week_end_date;

-- Reopened cases: legacy view (kept for compatibility).
-- Use mv_reopened_cases for all hot query paths — it is much faster.
CREATE VIEW v_reopened_cases AS
WITH closed_statuses AS (
  SELECT x.case_number, x.closed_date AS final_closed_date,
         x.status AS final_closed_status, x.upload_date AS final_closed_upload
  FROM (
    SELECT case_number, closed_date, status, upload_date,
           row_number() OVER (PARTITION BY case_number ORDER BY upload_date DESC) AS rn
    FROM case_status_history
    WHERE status IN ('Closed - Archived','Closed by IBM','Closed by Client')
  ) x WHERE x.rn = 1
),
reopen_pairs AS (
  SELECT h1.case_number,
         h1.upload_date AS closed_upload_date,
         h1.closed_date AS first_closed_date,
         h1.status      AS first_closed_status,
         min(h2.upload_date) AS reopened_upload_date
  FROM case_status_history h1
  JOIN case_status_history h2
    ON h1.case_number = h2.case_number AND h2.upload_date > h1.upload_date
  JOIN closed_statuses f ON h1.case_number = f.case_number
  WHERE h1.status IN ('Closed - Archived','Closed by IBM','Closed by Client')
    AND h2.status NOT IN ('Closed - Archived','Closed by IBM','Closed by Client')
    AND h2.status IS NOT NULL
    AND f.final_closed_date > h1.closed_date
  GROUP BY h1.case_number, h1.upload_date, h1.closed_date, h1.status
),
first_reopen AS (
  SELECT z.case_number, z.first_closed_date, z.first_closed_status, z.reopened_upload_date
  FROM (
    SELECT *, row_number() OVER (PARTITION BY case_number ORDER BY closed_upload_date) AS rn
    FROM reopen_pairs
  ) z WHERE z.rn = 1
),
week_data AS (
  SELECT case_number,
         count(*)                                                                       AS times_in_weekly,
         array_agg(week_label  ORDER BY year, week_number)                             AS week_labels,
         array_agg(year        ORDER BY year, week_number)                             AS week_years,
         array_agg(COALESCE(comments,'') ORDER BY year, week_number)                   AS week_comments,
         bool_or(is_duplicate)                                                         AS has_overlap_duplicate
  FROM weekly_closed_cases
  WHERE is_reopened = TRUE
  GROUP BY case_number
)
SELECT
  r.case_number,
  c.title,
  c.owner_name,
  c.severity,
  c.customer_number,
  c.product,
  c.status                                 AS current_status,
  r.first_closed_date,
  r.first_closed_status,
  r.reopened_upload_date,
  f.final_closed_date,
  f.final_closed_status,
  w.times_in_weekly,
  w.week_labels,
  w.week_years,
  w.week_comments,
  COALESCE(w.has_overlap_duplicate, FALSE) AS has_overlap_duplicate
FROM first_reopen r
JOIN cases c           ON r.case_number = c.case_number
JOIN closed_statuses f ON r.case_number = f.case_number
LEFT JOIN week_data w  ON r.case_number = w.case_number;


-- ================================================================
-- MATERIALIZED VIEW: mv_reopened_cases  (added v3)
-- Replaces v_reopened_cases for all hot query paths.
-- Refreshed by the backend after every CSV / XLSM import:
--   REFRESH MATERIALIZED VIEW CONCURRENTLY mv_reopened_cases;
-- CONCURRENTLY requires the unique index below (zero-downtime refresh).
-- ================================================================
CREATE MATERIALIZED VIEW IF NOT EXISTS mv_reopened_cases AS
WITH closed_statuses AS (
  SELECT x.case_number, x.closed_date AS final_closed_date,
         x.status AS final_closed_status, x.upload_date AS final_closed_upload
  FROM (
    SELECT case_number, closed_date, status, upload_date,
           row_number() OVER (PARTITION BY case_number ORDER BY upload_date DESC) AS rn
    FROM case_status_history
    WHERE status IN ('Closed - Archived','Closed by IBM','Closed by Client')
  ) x WHERE x.rn = 1
),
reopen_pairs AS (
  SELECT h1.case_number,
         h1.upload_date AS closed_upload_date,
         h1.closed_date AS first_closed_date,
         h1.status      AS first_closed_status,
         min(h2.upload_date) AS reopened_upload_date
  FROM case_status_history h1
  JOIN case_status_history h2
    ON h1.case_number = h2.case_number AND h2.upload_date > h1.upload_date
  JOIN closed_statuses f ON h1.case_number = f.case_number
  WHERE h1.status IN ('Closed - Archived','Closed by IBM','Closed by Client')
    AND h2.status NOT IN ('Closed - Archived','Closed by IBM','Closed by Client')
    AND h2.status IS NOT NULL
    AND f.final_closed_date > h1.closed_date
  GROUP BY h1.case_number, h1.upload_date, h1.closed_date, h1.status
),
first_reopen AS (
  SELECT z.case_number, z.first_closed_date, z.first_closed_status, z.reopened_upload_date
  FROM (
    SELECT *, row_number() OVER (PARTITION BY case_number ORDER BY closed_upload_date) AS rn
    FROM reopen_pairs
  ) z WHERE z.rn = 1
),
week_data AS (
  SELECT case_number,
         count(*)                                                                       AS times_in_weekly,
         array_agg(week_label  ORDER BY year, week_number)                             AS week_labels,
         array_agg(year        ORDER BY year, week_number)                             AS week_years,
         array_agg(COALESCE(comments,'') ORDER BY year, week_number)                   AS week_comments,
         bool_or(is_duplicate)                                                         AS has_overlap_duplicate
  FROM weekly_closed_cases
  WHERE is_reopened = TRUE
  GROUP BY case_number
)
SELECT
  r.case_number,
  c.title,
  c.owner_name,
  c.severity,
  c.customer_number,
  c.product,
  c.status                                 AS current_status,
  r.first_closed_date,
  r.first_closed_status,
  r.reopened_upload_date,
  f.final_closed_date,
  f.final_closed_status,
  w.times_in_weekly,
  w.week_labels,
  w.week_years,
  w.week_comments,
  COALESCE(w.has_overlap_duplicate, FALSE) AS has_overlap_duplicate
FROM first_reopen r
JOIN cases c           ON r.case_number = c.case_number
JOIN closed_statuses f ON r.case_number = f.case_number
LEFT JOIN week_data w  ON r.case_number = w.case_number;

CREATE UNIQUE INDEX IF NOT EXISTS idx_mv_reopened_cases_pk ON mv_reopened_cases (case_number);


-- ================================================================
-- END OF SCHEMA
-- ================================================================
-- 27 tables | 3 views | 1 matview | 9 triggers
--
-- Patch files superseded by this consolidated file:
--   schema_patch_v2.sql  → archive or delete
--   schema_patch_v3.sql  → archive or delete
--
-- Verify live DB:
--   psql -U iip_user -d iip_db -f schema/check_db.sql
-- ================================================================
