-- ================================================================
-- IIP Schema Patch v3  (2026-04-27)
-- Run ONCE on a live DB after deploying the v3 backend.
-- Safe to re-run: all statements use IF NOT EXISTS / ON CONFLICT.
--
-- Changes:
--   1. mv_reopened_cases  — materialized view replaces expensive v_reopened_cases
--   2. rfe_annotations    — per-idea notes/tags/target-release (replaces blob)
--   3. tracker_ui_state   — copy old blob if present; drop old key
-- ================================================================


-- ================================================================
-- 1. MATERIALIZED VIEW: mv_reopened_cases
--    Replaces v_reopened_cases for all hot query paths.
--    Refreshed by the backend after every CSV / XLSM import.
--    CONCURRENTLY requires the unique index below.
-- ================================================================

CREATE MATERIALIZED VIEW IF NOT EXISTS mv_reopened_cases AS
WITH closed_statuses AS (
  SELECT x.case_number, x.closed_date AS final_closed_date,
         x.status AS final_closed_status, x.upload_date AS final_closed_upload
  FROM (
    SELECT case_number, closed_date, status, upload_date,
           row_number() OVER (PARTITION BY case_number ORDER BY upload_date DESC) AS rn
    FROM case_status_history
    WHERE status IN ('Closed - Archived','Closed by IBM','Closed by Client')
  ) x WHERE x.rn = 1
),
reopen_pairs AS (
  SELECT h1.case_number,
         h1.upload_date AS closed_upload_date,
         h1.closed_date AS first_closed_date,
         h1.status      AS first_closed_status,
         min(h2.upload_date) AS reopened_upload_date
  FROM case_status_history h1
  JOIN case_status_history h2
    ON h1.case_number = h2.case_number AND h2.upload_date > h1.upload_date
  JOIN closed_statuses f ON h1.case_number = f.case_number
  WHERE h1.status IN ('Closed - Archived','Closed by IBM','Closed by Client')
    AND h2.status NOT IN ('Closed - Archived','Closed by IBM','Closed by Client')
    AND h2.status IS NOT NULL
    AND f.final_closed_date > h1.closed_date
  GROUP BY h1.case_number, h1.upload_date, h1.closed_date, h1.status
),
first_reopen AS (
  SELECT z.case_number, z.first_closed_date, z.first_closed_status, z.reopened_upload_date
  FROM (
    SELECT *, row_number() OVER (PARTITION BY case_number ORDER BY closed_upload_date) AS rn
    FROM reopen_pairs
  ) z WHERE z.rn = 1
),
week_data AS (
  SELECT case_number,
         count(*)                                                                             AS times_in_weekly,
         array_agg(week_label  ORDER BY year, week_number)                                   AS week_labels,
         array_agg(year        ORDER BY year, week_number)                                   AS week_years,
         array_agg(COALESCE(comments,'') ORDER BY year, week_number)                         AS week_comments,
         bool_or(is_duplicate)                                                               AS has_overlap_duplicate
  FROM weekly_closed_cases
  WHERE is_reopened = TRUE
  GROUP BY case_number
)
SELECT
  r.case_number,
  c.title,
  c.owner_name,
  c.severity,
  c.customer_number,
  c.product,
  c.status                              AS current_status,
  r.first_closed_date,
  r.first_closed_status,
  r.reopened_upload_date,
  f.final_closed_date,
  f.final_closed_status,
  w.times_in_weekly,
  w.week_labels,
  w.week_years,
  w.week_comments,
  COALESCE(w.has_overlap_duplicate, FALSE) AS has_overlap_duplicate
FROM first_reopen r
JOIN cases c           ON r.case_number = c.case_number
JOIN closed_statuses f ON r.case_number = f.case_number
LEFT JOIN week_data w  ON r.case_number = w.case_number;

-- Required for REFRESH MATERIALIZED VIEW CONCURRENTLY (zero-downtime refresh)
CREATE UNIQUE INDEX IF NOT EXISTS idx_mv_reopened_cases_pk ON mv_reopened_cases (case_number);


-- ================================================================
-- 2. RFE ANNOTATIONS TABLE
--    Replaces the rfe_tracking_metadata JSON blob in app_settings.
--    One row per idea_reference — proper queryable structure.
-- ================================================================

CREATE TABLE IF NOT EXISTS rfe_annotations (
  idea_reference VARCHAR(50)  PRIMARY KEY REFERENCES ibm_ideas(idea_reference) ON DELETE CASCADE,
  notes          TEXT         NOT NULL DEFAULT '',
  tags           TEXT         NOT NULL DEFAULT '',
  target_release VARCHAR(100) NOT NULL DEFAULT '',
  updated_at     TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  updated_by     VARCHAR(100)
);
CREATE INDEX IF NOT EXISTS idx_rfe_annotations_updated ON rfe_annotations (updated_at DESC);


-- ================================================================
-- 3. MIGRATE tracker_persist_meta → tracker_ui_state
--    Copy old blob if the new key doesn't exist yet.
--    The new key stores only UI state (no perf classification).
-- ================================================================

INSERT INTO app_settings (key, value, description)
SELECT
  'tracker_ui_state',
  value,
  'Performance tracker UI state — history/logs/overrides only (migrated from tracker_persist_meta)'
FROM app_settings
WHERE key = 'tracker_persist_meta'
ON CONFLICT (key) DO NOTHING;

-- Mark old key as superseded (keep for rollback safety, don't delete)
UPDATE app_settings
SET description = '[SUPERSEDED by tracker_ui_state — safe to delete after v3 verification]'
WHERE key = 'tracker_persist_meta';


-- ================================================================
-- END OF PATCH v3
-- ================================================================
