-- ================================================================
-- IIP Schema Patch v2  —  Reconcile live DB vs iip_schema.sql
-- Apply on live DB:  psql -U iip_user -d iip_db -f schema_patch_v2.sql
-- Safe to re-run:    all statements are idempotent
--
-- Changes:
--   1. Add error_log          (exists in prod, missing from schema)
--   2. Add case_grayout_state (exists in prod, missing from schema)
--   3. Add weekly_reopened_sync (exists in prod, missing from schema)
--   4. Seed missing app_settings rows (11 keys)
--
-- Removed from schema.sql (already dropped in prod — do NOT recreate):
--   - iip_kv        (fully dropped; KV migrated to proper tables)
--   - name_aliases  (dropped; aliases live in team_members.display_name)
-- ================================================================


-- ================================================================
-- 1. ERROR LOG
-- Append-only frontend error capture. Written by /api/store-public/ibm_error_log_v1.
-- No updated_at — append only.
-- ================================================================
CREATE TABLE IF NOT EXISTS error_log (
  id          SERIAL        PRIMARY KEY,
  occurred_at TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  message     TEXT,
  stack       TEXT,
  context     JSONB
);
CREATE INDEX IF NOT EXISTS idx_error_log_occurred ON error_log (occurred_at DESC);


-- ================================================================
-- 2. CASE GRAYOUT STATE
-- Per-case per-week grayout flag for the Weekly Tracker.
-- is_grayed=TRUE means the case is crossed-out in the tracker UI
-- because a later-week entry supersedes it.
-- later_week / later_year point to the superseding entry.
-- metadata JSONB holds any extra UI state.
-- ================================================================
CREATE TABLE IF NOT EXISTS case_grayout_state (
  case_number VARCHAR(50)          NOT NULL,
  week        VARCHAR(10)          NOT NULL,
  year        INT                  NOT NULL,
  is_grayed   BOOLEAN              NOT NULL DEFAULT TRUE,
  later_week  VARCHAR(10),
  later_year  INT,
  metadata    JSONB,
  updated_at  TIMESTAMPTZ          NOT NULL DEFAULT NOW(),
  PRIMARY KEY (case_number, week, year)
);
CREATE INDEX IF NOT EXISTS idx_case_grayout_lookup ON case_grayout_state (case_number, week, year);


-- ================================================================
-- 3. WEEKLY REOPENED SYNC
-- Denormalized snapshot of reopened case data keyed by
-- (case_number, week, year). Allows the Weekly Tracker to show
-- reopened-case detail without joining v_reopened_cases live.
-- ================================================================
CREATE TABLE IF NOT EXISTS weekly_reopened_sync (
  case_number VARCHAR(50)   NOT NULL,
  week        VARCHAR(10)   NOT NULL,
  year        INT           NOT NULL,
  closed_date TEXT,
  status      TEXT,
  owner       TEXT,
  title       TEXT,
  severity    TEXT,
  synced_at   TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  PRIMARY KEY (case_number, week, year)
);


-- ================================================================
-- 4. APP SETTINGS — seed missing rows
-- Original schema.sql only seeded 4 keys. Live DB has 15.
-- ON CONFLICT DO NOTHING = safe to re-run; never overwrites live values.
-- ================================================================
INSERT INTO app_settings (key, value, description) VALUES
  ('app_title',
   'IBM CASES',
   'Application title shown in header'),

  ('app_subtitle',
   'IBM Case Intelligence Platform',
   'Application subtitle shown in header'),

  ('closed_statuses',
   '["Closed by IBM","Closed by Client","Closed - Archived"]',
   'JSON array of closed status strings'),

  ('idle_timeout_ms',
   '1800000',
   'Idle timeout in milliseconds (30 min)'),

  ('idle_warning_ms',
   '1620000',
   'Idle warning threshold in milliseconds (27 min)'),

  ('sender_name',
   '',
   'Sender name used in reminder emails'),

  ('sla_closure_days',
   '30',
   'SLA closure window in days'),

  ('sla_target_pct',
   '80',
   'SLA target percentage'),

  ('table_page_size',
   '50',
   'Default rows per page in case tables'),

  ('team_name',
   '2026',
   'Team name / year label'),

  ('wt_categories',
   '[{"name":"Backup & Restore","color":"var(--red)"},{"name":"Database Connectivity Issues","color":"var(--orange)"},{"name":"DCM Connectivity Issues","color":"var(--orange)"},{"name":"Duplicate","color":"var(--red)"},{"name":"Export / Import Issues","color":"var(--yellow-text)"},{"name":"Insufficient Information in Logs","color":"#555"},{"name":"Issue Fixed in iFix","color":"var(--green)"},{"name":"Known Defect","color":"var(--red)"},{"name":"LQE Validation / Reindexing","color":"var(--ibm-blue-60)"},{"name":"Out of Memory / Heap Issues","color":"#c00"},{"name":"Reopened","color":"var(--purple)"},{"name":"RFE","color":""},{"name":"Single Occurrence Issue","color":"var(--purple)"},{"name":"TRS Feed Validation","color":"var(--ibm-blue-50)"}]',
   'Weekly Tracker category list with colors')

ON CONFLICT (key) DO NOTHING;


-- ================================================================
-- VERIFY
-- ================================================================
SELECT 'error_log'           AS tbl, COUNT(*) FROM error_log
UNION ALL
SELECT 'case_grayout_state',         COUNT(*) FROM case_grayout_state
UNION ALL
SELECT 'weekly_reopened_sync',       COUNT(*) FROM weekly_reopened_sync
UNION ALL
SELECT 'app_settings total',         COUNT(*) FROM app_settings;
