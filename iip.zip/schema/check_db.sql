-- ================================================================
-- IIP Live DB — Full Audit Script
-- Run:  psql -U iip_user -d iip_db -f check_db.sql
-- Or:   ./db.sh < check_db.sql
-- ================================================================

\pset border 2
\pset format aligned

-- ================================================================
-- 1. DATABASE INFO
-- ================================================================
\echo ''
\echo '=== DATABASE INFO ==='
SELECT current_database() AS db,
       current_user        AS connected_as,
       version()           AS pg_version;

-- ================================================================
-- 2. ALL TABLES  (with row counts and sizes)
-- ================================================================
\echo ''
\echo '=== TABLES (name | rows | size) ==='
SELECT
  t.relname                                          AS table_name,
  t.reltuples::BIGINT                                AS est_rows,
  pg_size_pretty(pg_total_relation_size(t.oid))      AS total_size
FROM pg_class t
JOIN pg_namespace n ON n.oid = t.relnamespace
WHERE n.nspname = 'public'
  AND t.relkind = 'r'
ORDER BY t.relname;

-- ================================================================
-- 2b. EXACT ROW COUNTS for key large tables
-- ================================================================
\echo ''
\echo '=== EXACT ROW COUNTS (key tables) ==='
SELECT 'uploads'              AS tbl, COUNT(*) FROM uploads
UNION ALL SELECT 'cases',                COUNT(*) FROM cases
UNION ALL SELECT 'case_status_history',  COUNT(*) FROM case_status_history
UNION ALL SELECT 'weekly_closed_cases',  COUNT(*) FROM weekly_closed_cases
UNION ALL SELECT 'weekly_reopened_sync', COUNT(*) FROM weekly_reopened_sync
UNION ALL SELECT 'wt_case_history',      COUNT(*) FROM wt_case_history
UNION ALL SELECT 'case_grayout_state',   COUNT(*) FROM case_grayout_state
UNION ALL SELECT 'team_members',         COUNT(*) FROM team_members
UNION ALL SELECT 'ibm_ideas',            COUNT(*) FROM ibm_ideas
UNION ALL SELECT 'idea_case_links',      COUNT(*) FROM idea_case_links
UNION ALL SELECT 'rfe_annotations',      COUNT(*) FROM rfe_annotations
UNION ALL SELECT 'alm_lines',            COUNT(*) FROM alm_lines
UNION ALL SELECT 'ibm_contacts',         COUNT(*) FROM ibm_contacts
UNION ALL SELECT 'escalation_contacts',  COUNT(*) FROM escalation_contacts
UNION ALL SELECT 'duplicate_references', COUNT(*) FROM duplicate_references
UNION ALL SELECT 'availability_alerts',  COUNT(*) FROM availability_alerts
UNION ALL SELECT 'audit_log',            COUNT(*) FROM audit_log
UNION ALL SELECT 'performance_slot_days',COUNT(*) FROM performance_slot_days
UNION ALL SELECT 'performance_wednesday_comments', COUNT(*) FROM performance_wednesday_comments
UNION ALL SELECT 'error_log',            COUNT(*) FROM error_log
UNION ALL SELECT 'app_settings',         COUNT(*) FROM app_settings
UNION ALL SELECT 'app_settings_backup',  COUNT(*) FROM app_settings_backup
UNION ALL SELECT 'elm_upgrades',         COUNT(*) FROM elm_upgrades
UNION ALL SELECT 'admin_credentials',    COUNT(*) FROM admin_credentials
UNION ALL SELECT 'admin_sessions',       COUNT(*) FROM admin_sessions
UNION ALL SELECT 'security_questions',   COUNT(*) FROM security_questions
ORDER BY 1;

-- ================================================================
-- 3. VIEWS & MATERIALIZED VIEWS
-- ================================================================
\echo ''
\echo '=== VIEWS ==='
SELECT viewname, definition
FROM pg_views
WHERE schemaname = 'public'
ORDER BY viewname;

\echo ''
\echo '=== MATERIALIZED VIEWS ==='
SELECT matviewname,
       ispopulated,
       pg_size_pretty(pg_total_relation_size(oid)) AS size
FROM pg_matviews
JOIN pg_class ON relname = matviewname AND relnamespace = (SELECT oid FROM pg_namespace WHERE nspname='public')
WHERE schemaname = 'public'
ORDER BY matviewname;

-- ================================================================
-- 4. TRIGGERS
-- ================================================================
\echo ''
\echo '=== TRIGGERS ==='
SELECT
  trigger_name,
  event_object_table   AS on_table,
  event_manipulation   AS event,
  action_timing        AS timing,
  action_statement
FROM information_schema.triggers
WHERE trigger_schema = 'public'
ORDER BY event_object_table, trigger_name;

-- ================================================================
-- 5. INDEXES
-- ================================================================
\echo ''
\echo '=== INDEXES (table | index | columns) ==='
SELECT
  t.relname                         AS table_name,
  i.relname                         AS index_name,
  ix.indisunique                    AS is_unique,
  ix.indisprimary                   AS is_primary,
  pg_get_indexdef(ix.indexrelid)    AS definition
FROM pg_index ix
JOIN pg_class t  ON t.oid  = ix.indrelid
JOIN pg_class i  ON i.oid  = ix.indexrelid
JOIN pg_namespace n ON n.oid = t.relnamespace
WHERE n.nspname = 'public'
  AND t.relkind = 'r'
ORDER BY t.relname, i.relname;

-- ================================================================
-- 6. FOREIGN KEYS
-- ================================================================
\echo ''
\echo '=== FOREIGN KEYS ==='
SELECT
  tc.table_name                    AS from_table,
  kcu.column_name                  AS from_col,
  ccu.table_name                   AS to_table,
  ccu.column_name                  AS to_col,
  rc.delete_rule                   AS on_delete,
  tc.constraint_name
FROM information_schema.table_constraints tc
JOIN information_schema.key_column_usage kcu
  ON tc.constraint_name = kcu.constraint_name
  AND tc.table_schema   = kcu.table_schema
JOIN information_schema.referential_constraints rc
  ON tc.constraint_name = rc.constraint_name
JOIN information_schema.constraint_column_usage ccu
  ON ccu.constraint_name = rc.unique_constraint_name
WHERE tc.constraint_type = 'FOREIGN KEY'
  AND tc.table_schema    = 'public'
ORDER BY tc.table_name, kcu.column_name;

-- ================================================================
-- 7. COLUMNS — FULL SCHEMA DUMP (all tables, all columns)
-- ================================================================
\echo ''
\echo '=== FULL COLUMN LISTING ==='
SELECT
  table_name,
  ordinal_position  AS pos,
  column_name,
  data_type         || COALESCE('(' || character_maximum_length::TEXT || ')', '')
                    AS type,
  column_default,
  is_nullable
FROM information_schema.columns
WHERE table_schema = 'public'
ORDER BY table_name, ordinal_position;

-- ================================================================
-- 8. APP SETTINGS — all keys
-- ================================================================
\echo ''
\echo '=== APP SETTINGS (all keys) ==='
SELECT key, LEFT(value, 80) AS value_preview, description, updated_at, updated_by
FROM app_settings
ORDER BY key;

-- ================================================================
-- 9. DUPLICATE / STALE INDEXES check
-- ================================================================
\echo ''
\echo '=== DUPLICATE INDEX CANDIDATES ==='
SELECT
  a.schemaname,
  a.tablename,
  a.indexname  AS index_a,
  b.indexname  AS index_b,
  a.indexdef
FROM pg_indexes a
JOIN pg_indexes b
  ON  a.schemaname = b.schemaname
  AND a.tablename  = b.tablename
  AND a.indexname  < b.indexname
  AND a.indexdef   = b.indexdef
WHERE a.schemaname = 'public'
ORDER BY a.tablename, a.indexname;

-- ================================================================
-- 10. EXTENSIONS
-- ================================================================
\echo ''
\echo '=== INSTALLED EXTENSIONS ==='
SELECT extname, extversion FROM pg_extension ORDER BY extname;

-- ================================================================
-- 11. SEQUENCE STATUS
-- ================================================================
\echo ''
\echo '=== SEQUENCES (current value) ==='
SELECT sequencename, last_value, increment_by
FROM pg_sequences
WHERE schemaname = 'public'
ORDER BY sequencename;

-- ================================================================
-- 12. FUNCTION CHECK
-- ================================================================
\echo ''
\echo '=== TRIGGER FUNCTIONS ==='
SELECT proname AS function_name,
       pg_get_functiondef(oid) AS definition
FROM pg_proc
WHERE proname IN ('set_updated_at', '_set_updated_at')
  AND pronamespace = (SELECT oid FROM pg_namespace WHERE nspname = 'public');

-- ================================================================
-- 13. SUMMARY COUNTS
-- ================================================================
\echo ''
\echo '=== SUMMARY ==='
SELECT
  (SELECT COUNT(*) FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
   WHERE n.nspname='public' AND c.relkind='r')                            AS tables,
  (SELECT COUNT(*) FROM pg_views WHERE schemaname='public')               AS views,
  (SELECT COUNT(*) FROM pg_matviews WHERE schemaname='public')            AS matviews,
  (SELECT COUNT(*) FROM information_schema.triggers
   WHERE trigger_schema='public')                                          AS triggers,
  (SELECT COUNT(*) FROM pg_indexes WHERE schemaname='public')             AS indexes,
  (SELECT COUNT(*) FROM information_schema.table_constraints
   WHERE constraint_type='FOREIGN KEY' AND table_schema='public')         AS foreign_keys;

\echo ''
\echo '=== AUDIT COMPLETE ==='
