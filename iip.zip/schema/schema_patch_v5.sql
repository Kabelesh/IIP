-- ================================================================
-- IIP Schema Patch v5  (2026-05-02)
-- Run ONCE on live DB after deploying.
-- Safe to re-run: DROP INDEX IF EXISTS is idempotent.
--
-- Changes:
--   1. Drop 8 orphan duplicate indexes (confirmed by check_db.sql)
--   2. (No structural table changes — see iip_schema.sql v5 for
--      case_reopen_log and saved_searches, which already exist
--      in the live DB and need no action here.)
--
-- Run:
--   /opt/IBM/IIP/db.sh < /opt/IBM/IIP/schema/schema_patch_v5.sql
-- ================================================================


-- ================================================================
-- VERIFY current state before dropping
-- ================================================================
\echo ''
\echo '=== INDEXES TO BE DROPPED ==='
SELECT indexname, tablename
FROM pg_indexes
WHERE schemaname = 'public'
  AND indexname IN (
    'idx_audit_date',
    'idx_audit_user',
    'idx_dupes_duplicate',
    'idx_dupes_original',
    'idx_uploads_hash',
    'idx_wcc_case',
    'idx_wcc_label',
    'idx_wcc_week',
    'idx_icl_case',
    'idx_icl_idea'
  )
ORDER BY tablename, indexname;


-- ================================================================
-- DROP DUPLICATE INDEXES
-- Each dropped index has a retained canonical replacement shown.
-- ================================================================

-- audit_log
-- idx_audit_date       ≈  idx_audit_change_date  (same column, minor NULLS diff)
-- idx_audit_user       =  idx_audit_admin_user    (exact duplicate)
DROP INDEX IF EXISTS idx_audit_date;
DROP INDEX IF EXISTS idx_audit_user;

-- duplicate_references
-- idx_dupes_duplicate  =  idx_dr_duplicate_case   (exact duplicate)
-- idx_dupes_original   =  idx_dr_original_case    (exact duplicate)
DROP INDEX IF EXISTS idx_dupes_duplicate;
DROP INDEX IF EXISTS idx_dupes_original;

-- uploads
-- idx_uploads_hash     =  idx_uploads_file_hash   (exact duplicate)
DROP INDEX IF EXISTS idx_uploads_hash;

-- weekly_closed_cases
-- idx_wcc_case         =  idx_wcc_case_number     (exact duplicate)
-- idx_wcc_label        =  idx_wcc_week_label      (exact duplicate)
-- idx_wcc_week         =  idx_wcc_year_week       (exact duplicate)
DROP INDEX IF EXISTS idx_wcc_case;
DROP INDEX IF EXISTS idx_wcc_label;
DROP INDEX IF EXISTS idx_wcc_week;

-- idea_case_links
-- idx_icl_case         =  idx_icl_case_number     (exact duplicate)
-- idx_icl_idea         =  idx_icl_idea_reference  (exact duplicate)
DROP INDEX IF EXISTS idx_icl_case;
DROP INDEX IF EXISTS idx_icl_idea;


-- ================================================================
-- VERIFY: confirm the orphan indexes are gone
-- ================================================================
\echo ''
\echo '=== REMAINING INDEXES (should be 0 rows for the names above) ==='
SELECT indexname, tablename
FROM pg_indexes
WHERE schemaname = 'public'
  AND indexname IN (
    'idx_audit_date',
    'idx_audit_user',
    'idx_dupes_duplicate',
    'idx_dupes_original',
    'idx_uploads_hash',
    'idx_wcc_case',
    'idx_wcc_label',
    'idx_wcc_week',
    'idx_icl_case',
    'idx_icl_idea'
  );

\echo ''
\echo '=== NEW INDEX COUNT ==='
SELECT COUNT(*) AS total_indexes
FROM pg_indexes
WHERE schemaname = 'public';

\echo ''
\echo '=== PATCH v5 COMPLETE ==='
