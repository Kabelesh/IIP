rm -rf iip.zip
zip -r iip.zip . \
  -x "wheels/*" \
  -x "Datas/*" \
  -x "Excel_sheets/*" \
  -x "*.zip" \
  -x "nohup.out" \
  -x "backend.log"
chmod -R 755 /opt/IBM/IIP/frontend /opt/IBM/IIP/backend
clear
