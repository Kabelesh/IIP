from pydantic import BaseModel, Field
from typing import Optional, Any, Dict, List

# auth.py models
class AuthRequest(BaseModel):
    password: str
    username: Optional[str] = "admin"

class SetPasswordRequest(BaseModel):
    username: Optional[str] = "admin"
    # Accept both currentPassword (camelCase — sent by frontend) and old_password (legacy)
    currentPassword: Optional[str] = Field(default="", alias="old_password")
    newPassword: str = Field(..., alias="new_password")

    class Config:
        populate_by_name = True

class SecurityQuestionSetupRequest(BaseModel):
    username: Optional[str] = "admin"
    q1: str
    a1: str
    q2: str
    a2: str

class SecurityQuestionResetRequest(BaseModel):
    username: Optional[str] = "admin"
    a1: str
    a2: str
    newPassword: str = Field(..., alias="new_password")

    class Config:
        populate_by_name = True

# store.py models
class StoreWriteRequest(BaseModel):
    value: Any

class BulkGetRequest(BaseModel):
    keys: List[str]

class BulkSetRequest(BaseModel):
    entries: Dict[str, Any]
