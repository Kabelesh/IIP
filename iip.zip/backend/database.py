"""
database.py — asyncpg connection pool for IIP FastAPI backend
"""
import asyncpg
import logging
import os
from pathlib import Path
from typing import Optional
from dotenv import load_dotenv

# Load env from whichever .env exists. systemd unit points at backend/.env;
# legacy deployments put it at the project root. Load both so either works.
_BACKEND_ENV = Path(__file__).resolve().parent / ".env"
_ROOT_ENV    = Path(__file__).resolve().parent.parent / ".env"
if _BACKEND_ENV.exists():
    load_dotenv(dotenv_path=_BACKEND_ENV, override=False)
if _ROOT_ENV.exists():
    load_dotenv(dotenv_path=_ROOT_ENV, override=False)

log = logging.getLogger(__name__)

_pool: Optional[asyncpg.Pool] = None


async def get_pool() -> asyncpg.Pool:
    global _pool
    if _pool is None:
        ssl = os.getenv("DB_SSL", "false").lower() == "true"
        try:
            _pool = await asyncpg.create_pool(
                host=os.getenv("DB_HOST", "localhost"),
                port=int(os.getenv("DB_PORT", "5432")),
                database=os.getenv("DB_NAME", "iip_db"),
                user=os.getenv("DB_USER", "iip_user"),
                password=os.getenv("DB_PASSWORD", ""),
                min_size=int(os.getenv("DB_POOL_MIN", "2")),
                max_size=int(os.getenv("DB_POOL_MAX", "20")),
                command_timeout=int(os.getenv("DB_CMD_TIMEOUT", "60")),
                ssl="require" if ssl else None,
            )
            log.info(
                "Postgres pool created (host=%s db=%s min=%s max=%s ssl=%s)",
                os.getenv("DB_HOST", "localhost"),
                os.getenv("DB_NAME", "iip_db"),
                os.getenv("DB_POOL_MIN", "2"),
                os.getenv("DB_POOL_MAX", "20"),
                ssl,
            )
        except Exception as e:
            log.error("Failed to create asyncpg pool: %s", e)
            _pool = None  # reset so next request retries
            raise
    return _pool


async def close_pool():
    global _pool
    if _pool:
        await _pool.close()
        _pool = None
