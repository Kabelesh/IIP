"""
IBM IIP â€” Data Importer
Maps all 9 verified source files into the 13-table PostgreSQL schema.

Import order respects FK dependencies:
  uploads â†’ team_members â†’ cases
  â†’ alm_lines, ibm_contacts, escalation_contacts, ibm_ideas
  â†’ weekly_closed_cases (populates duplicate_references + idea_case_links)
  â†’ defect_work_items

XLSX/XLSM parsing uses stdlib zipfile + xml.etree (zero extra deps beyond pandas).
pandas is used only for CSV reading.
"""

import asyncio
import hashlib
import logging
import os
import re
import xml.etree.ElementTree as ET
import zipfile
from datetime import date, datetime
from pathlib import Path
from typing import Optional

import pandas as pd

from database import get_pool

logging.basicConfig(level=logging.INFO, format="%(levelname)s  %(message)s")
log = logging.getLogger(__name__)

# Customer number prefix for performance tracker eligibility.
# Must match IIP_PERF_CUSTOMER_PREFIX in backend .env.
PERF_CUSTOMER_PREFIX = os.getenv("IIP_PERF_CUSTOMER_PREFIX", "08")

# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
# XML namespaces
# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
_NS = {"s": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
_REL_NS = "http://schemas.openxmlformats.org/package/2006/relationships"

# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
# Type-coercion helpers
# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

def _str(val, maxlen: int = None) -> Optional[str]:
    if val is None:
        return None
    try:
        if pd.isnull(val):
            return None
    except (TypeError, ValueError):
        pass
    s = str(val).strip()
    if not s or s.lower() in ("none", "nan", "nat"):
        return None
    return s[:maxlen] if maxlen else s


def _int(val) -> Optional[int]:
    if val is None:
        return None
    try:
        s = str(val).strip().split()[0]
        return int(float(s))
    except (TypeError, ValueError, IndexError):
        return None


def _bool_val(val) -> bool:
    if val is None:
        return False
    return str(val).strip().lower() in ("true", "yes", "1", "complete", "completed")


def _parse_date(val) -> Optional[date]:
    if val is None:
        return None
    try:
        if pd.isnull(val):
            return None
    except (TypeError, ValueError):
        pass
    if isinstance(val, datetime):
        return val.date()
    if isinstance(val, date):
        return val
    s = str(val).strip()
    if not s or s.lower() in ("none", "nan", "nat"):
        return None
    dt = pd.to_datetime(s, errors="coerce")
    return None if pd.isnull(dt) else dt.date()


def _parse_ts(val) -> Optional[datetime]:
    d = _parse_date(val)
    if d is None:
        return None
    if isinstance(d, datetime):
        return d
    return datetime(d.year, d.month, d.day)


# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
# XLSX / XLSM reader  (stdlib only â€” no openpyxl)
# Handles:
#   â€¢ shared-string cells  (t="s")
#   â€¢ inline-string cells  (t="inlineStr")  â† used in XLSM header rows
#   â€¢ numeric / date cells (t="" or absent)
#   â€¢ absolute Target paths in workbook.xml.rels  (/xl/worksheets/sheet1.xml)
# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

def _col_index(ref: str) -> int:
    """Convert Excel column letters (A, B, AA â€¦) to 0-based int."""
    letters = re.match(r"([A-Z]+)", ref)
    if not letters:
        return -1
    n = 0
    for ch in letters.group(1):
        n = n * 26 + (ord(ch) - 64)
    return n - 1  # 0-based


def _cell_value(c, sst: list) -> str:
    t = c.get("t", "")
    if t == "inlineStr":
        it = c.find(".//s:t", _NS)
        return it.text if it is not None else ""
    v = c.find("s:v", _NS)
    if v is None or not v.text:
        return ""
    if t == "s":
        idx = int(v.text)
        return sst[idx] if idx < len(sst) else ""
    return v.text


def read_excel_sheets(path: str) -> dict:
    """
    Parse XLSX or XLSM file. Returns {sheet_name: [row_dict, â€¦]}.
    Row dicts use the first-row values as keys.
    """
    results = {}
    with zipfile.ZipFile(path) as z:
        names = set(z.namelist())

        # Shared strings table
        sst = []
        if "xl/sharedStrings.xml" in names:
            tree = ET.parse(z.open("xl/sharedStrings.xml"))
            for si in tree.findall(".//s:si", _NS):
                sst.append("".join(t.text or "" for t in si.findall(".//s:t", _NS)))

        # Sheet inventory
        wb = ET.parse(z.open("xl/workbook.xml"))
        sheet_list = [
            (
                sh.get("name"),
                sh.get(f"{{{_NS['s'].replace('main', 'relationships')}}}id")
                or sh.get("{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id"),
            )
            for sh in wb.findall(".//s:sheet", _NS)
        ]

        # Relationship map rId â†’ Target
        rels = ET.parse(z.open("xl/_rels/workbook.xml.rels"))
        rel_map = {
            r.get("Id"): r.get("Target")
            for r in rels.findall(f"{{{_REL_NS}}}Relationship")
        }

        for sh_name, rid in sheet_list:
            target = rel_map.get(rid, "").lstrip("/")
            sheet_path = target if target.startswith("xl/") else "xl/" + target
            if sheet_path not in names:
                continue

            ws = ET.parse(z.open(sheet_path))
            all_rows = ws.findall(".//s:row", _NS)
            if not all_rows:
                continue

            # Build headers from row 0 using column refs
            hdr_map: dict[int, str] = {}
            for c in all_rows[0].findall("s:c", _NS):
                ref = c.get("r", "")
                ci = _col_index(ref)
                if ci >= 0:
                    hdr_map[ci] = _cell_value(c, sst)
            max_col = max(hdr_map.keys()) if hdr_map else -1
            if max_col < 0:
                continue
            headers = [hdr_map.get(i, "") for i in range(max_col + 1)]

            records = []
            for row in all_rows[1:]:
                col_val: dict[int, str] = {}
                for c in row.findall("s:c", _NS):
                    ci = _col_index(c.get("r", ""))
                    if ci >= 0:
                        col_val[ci] = _cell_value(c, sst)
                row_dict = {headers[i]: col_val.get(i, "") for i in range(len(headers))}
                if any(v.strip() for v in row_dict.values()):
                    records.append(row_dict)

            results[sh_name] = records

    return results


# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
# Upload record helpers
# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

def _sha256(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


async def _create_upload(pool, filename: str, file_type: str, file_path: str) -> int:
    """
    Creates an upload record.
    Returns the new upload id, or -1 if the same file hash already succeeded
    (prevents duplicate imports).
    """
    size = os.path.getsize(file_path)
    fhash = _sha256(file_path)
    async with pool.acquire() as conn:
        existing = await conn.fetchval(
            "SELECT id FROM uploads WHERE file_hash=$1 AND status='success'", fhash
        )
        if existing:
            log.info(f"  â†©  {filename} unchanged (upload #{existing}) â€” skipped")
            return -1
        uid = await conn.fetchval(
            """INSERT INTO uploads (filename, file_type, file_size, file_hash,
                                    uploaded_by, status)
               VALUES ($1,$2,$3,$4,'system','processing') RETURNING id""",
            filename, file_type, size, fhash,
        )
    return uid


async def _finish_upload(pool, uid: int, count: int,
                         status: str = "success", error: str = None):
    async with pool.acquire() as conn:
        await conn.execute(
            "UPDATE uploads SET status=$1, record_count=$2, error_message=$3 WHERE id=$4",
            status, count, error, uid,
        )


# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
# 1. TEAM MEMBERS  (Team_Members.xlsx)
#    Columns: Name | Email | Team | Status
# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

async def import_team_members(pool, path: str = "Datas/Team_Members.xlsx"):
    log.info(f"[1/8] Team members  â†  {path}")
    uid = await _create_upload(pool, Path(path).name, "XLSX", path)
    if uid == -1:
        return

    data = read_excel_sheets(path)
    sheet = next(iter(data.values()))
    count = 0
    async with pool.acquire() as conn:
        for row in sheet:
            name = _str(row.get("Name"))
            if not name:
                continue
            await conn.execute(
                """INSERT INTO team_members (name, email, team, status)
                   VALUES ($1,$2,$3,$4)
                   ON CONFLICT (name) DO UPDATE SET
                     email   = EXCLUDED.email,
                     team    = EXCLUDED.team,
                     status  = EXCLUDED.status""",
                name,
                _str(row.get("Email"), 255),
                _str(row.get("Team"), 100),
                _str(row.get("Status"), 50) or "Active",
            )
            count += 1

    await _finish_upload(pool, uid, count)
    log.info(f"  âœ“  {count} team members")


# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
# 2. CASES  (IBM Support CSV exports in Excel_sheets/)
#    Columns (19): Title | Status | Case Number | Legacy number | Severity |
#      Age | Owner | Customer number | Created | Updated | Product |
#      Solution date | Closed Date | Client Asset Identifier | Serial Number |
#      Machine Model | Machine Type | Country Name | Account ISO
# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

async def import_cases_csv(pool, path: str, original_name: str = None):
    display = original_name or Path(path).name
    log.info(f"[2/8] Cases  {display}")
    uid = await _create_upload(pool, display, "CSV", path)
    if uid == -1:
        return

    async with pool.acquire() as conn:
        team_names: set = {r["name"] for r in await conn.fetch("SELECT name FROM team_members")}

    df = pd.read_csv(path, dtype=str, keep_default_na=False)
    df.columns = df.columns.str.strip()
    count = 0

    async with pool.acquire() as conn:
        for _, row in df.iterrows():
            cn = _str(row.get("Case Number"), 50)
            if not cn:
                continue
            owner = _str(row.get("Owner"), 255)
            await conn.execute(
                """INSERT INTO cases (
                     case_number, title, status, legacy_number, severity, age_days,
                     owner_name, customer_number, created_date, updated_date,
                     product, solution_date, closed_date, client_asset_identifier,
                     serial_number, machine_model, machine_type, country_name,
                     account_iso, is_team_case, latest_upload_id
                   ) VALUES (
                     $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21
                   )
                   ON CONFLICT (case_number) DO UPDATE SET
                     title                   = EXCLUDED.title,
                     status                  = EXCLUDED.status,
                     legacy_number           = EXCLUDED.legacy_number,
                     severity                = EXCLUDED.severity,
                     age_days                = EXCLUDED.age_days,
                     owner_name              = CASE WHEN EXISTS (SELECT 1 FROM audit_log WHERE entity_id = cases.case_number AND action = 'reassign' AND change_date > NOW() - INTERVAL '90 days') THEN cases.owner_name ELSE EXCLUDED.owner_name END,
                     customer_number         = EXCLUDED.customer_number,
                     created_date            = EXCLUDED.created_date,
                     updated_date            = EXCLUDED.updated_date,
                     product                 = EXCLUDED.product,
                     solution_date           = EXCLUDED.solution_date,
                     closed_date             = EXCLUDED.closed_date,
                     client_asset_identifier = EXCLUDED.client_asset_identifier,
                     serial_number           = EXCLUDED.serial_number,
                     machine_model           = EXCLUDED.machine_model,
                     machine_type            = EXCLUDED.machine_type,
                     country_name            = EXCLUDED.country_name,
                     account_iso             = EXCLUDED.account_iso,
                     is_team_case            = EXCLUDED.is_team_case,
                     latest_upload_id        = EXCLUDED.latest_upload_id""",
                cn,
                _str(row.get("Title")),
                _str(row.get("Status"), 100),
                _str(row.get("Legacy number"), 50),
                _str(row.get("Severity"), 10),
                _int(row.get("Age")),
                owner,
                _str(row.get("Customer number"), 50),
                _parse_date(row.get("Created")),
                _parse_date(row.get("Updated")),
                _str(row.get("Product"), 255),
                _parse_date(row.get("Solution date")),
                _parse_date(row.get("Closed Date")),
                _str(row.get("Client Asset Identifier"), 255),
                _str(row.get("Serial Number"), 100),
                _str(row.get("Machine Model"), 100),
                _str(row.get("Machine Type"), 100),
                _str(row.get("Country Name"), 100),
                _str(row.get("Account ISO"), 10),
                bool(owner and owner in team_names),
                uid,
            )
            count += 1
            # ── Snapshot into case_status_history for reopen detection ────────────
            _csh_m = re.search(r"(\d{4}-\d{2}-\d{2})", str(path))
            _csh_udate = __import__("datetime").date.fromisoformat(_csh_m.group(1)) if _csh_m else __import__("datetime").date.today()
            _csh_status = _str(row.get("Status"), 100)
            _csh_closed = _parse_date(row.get("Closed Date")) or _csh_udate
            await conn.execute(
                """INSERT INTO case_status_history
                     (case_number, upload_id, upload_date, status, closed_date)
                   VALUES ($1,$2,$3,$4,$5)
                   ON CONFLICT (case_number, upload_id) DO UPDATE SET
                     status      = EXCLUDED.status,
                     closed_date = EXCLUDED.closed_date""",
                cn, uid, _csh_udate, _csh_status, _csh_closed,
            )
            # ── Auto-populate weekly_closed_cases from CSV closed dates ──────────
            _CLOSED_STATUSES = {"Closed - Archived", "Closed by IBM", "Closed by Client", "Cancelled"}
            if _csh_closed and _csh_status in _CLOSED_STATUSES and bool(owner and owner in team_names):
                # Use Sunday-based week numbering to match the frontend _isoWeek() logic
                _wk_yr, _wk_num = _date_to_sunday_week(_csh_closed)
                _wk_lbl = f"CW{_wk_num:02d}"
                _wk_sun, _wk_sat = _sunday_week_dates(_wk_yr, _wk_num)
                await conn.execute(
                    """INSERT INTO weekly_closed_cases (
                           case_number, week_number, year, week_label,
                           week_start_date, week_end_date,
                           owner, comments, category, availability,
                           is_reopened, is_duplicate, original_case_number,
                           upload_id, year_source
                       ) VALUES ($1,$2,$3,$4,$5,$6,$7,\'\',\'\',\'\',FALSE,FALSE,NULL,$8,$9)
                       ON CONFLICT (case_number, week_number, year) DO UPDATE SET
                           owner     = EXCLUDED.owner,
                           upload_id = EXCLUDED.upload_id""",
                    cn, _wk_num, _wk_yr, _wk_lbl,
                    _wk_sun, _wk_sat, owner, uid, _wk_yr,
                )
            elif _csh_status not in _CLOSED_STATUSES and bool(owner and owner in team_names):
                await conn.execute(
                    """UPDATE weekly_closed_cases
                       SET is_reopened = TRUE
                       WHERE case_number = $1
                         AND is_reopened = FALSE""",
                    cn,
                )

    # ── Stamp is_performance_case = FALSE for 08-customer team cases ────────
    # work_item and perf_type are only set by admin via the performance-tag UI.
    # Do NOT auto-populate work_item — CASE-<number> placeholders are not real
    # defect/task references and pollute the tracker.
    async with pool.acquire() as conn:
        await conn.execute("""
            UPDATE cases
            SET is_performance_case = FALSE
            WHERE customer_number LIKE $1 || '%'
              AND is_team_case = TRUE
              AND is_performance_case IS NULL
              AND latest_upload_id = $2
        """, PERF_CUSTOMER_PREFIX, uid)
    log.info(f"  ✔  08-customer team cases is_performance_case stamped (no work_item seeding)")

    # ── Auto-tag untagged 08-customer team cases as Non-performance ───────────
    async with pool.acquire() as conn:
        await conn.execute("""
            UPDATE cases
            SET perf_type = 'Non-performance'
            WHERE customer_number LIKE $1 || '%'
              AND is_team_case = TRUE
              AND is_performance_case = FALSE
              AND (perf_type IS NULL OR perf_type = '')
              AND latest_upload_id = $2
        """, PERF_CUSTOMER_PREFIX, uid)
    log.info(f"  ✔  08-customer untagged team cases auto-tagged as Non-performance")

    await _finish_upload(pool, uid, count)
    log.info(f"  âœ“  {count} cases")

    # Refresh the materialized view so reopened-cases queries stay fast
    try:
        async with pool.acquire() as _conn:
            await _conn.execute("REFRESH MATERIALIZED VIEW CONCURRENTLY mv_reopened_cases")
        log.info("  [OK] mv_reopened_cases refreshed")
    except Exception as _e:
        log.warning(f"  [WARN] mv_reopened_cases refresh failed (run schema_patch_v3.sql?): {_e}")


# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
# 3. ALM LINES  (ALM_Line_Details.xlsx)
#    Columns: ALM line | Customer Contact | Customer Email |
#      Line Manager | Line Manager Email | Case Responsible |
#      Case Responsible Email | Case Responsible Proxy |
#      Case Responsible Proxy Email
# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

async def import_alm_lines(pool, path: str = "Datas/ALM_Line_Details.xlsx"):
    log.info(f"[3/8] ALM lines  â†  {path}")
    uid = await _create_upload(pool, Path(path).name, "XLSX", path)
    if uid == -1:
        return

    data = read_excel_sheets(path)
    sheet = next(iter(data.values()))
    count = 0
    async with pool.acquire() as conn:
        for row in sheet:
            alm = _str(row.get("ALM line"), 50)
            if not alm:
                continue
            await conn.execute(
                """INSERT INTO alm_lines (
                     alm_line, customer_contact, customer_email,
                     line_manager, line_manager_email,
                     case_responsible, case_responsible_email,
                     case_responsible_proxy, case_responsible_proxy_email
                   ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
                   ON CONFLICT (alm_line) DO UPDATE SET
                     customer_contact             = EXCLUDED.customer_contact,
                     customer_email               = EXCLUDED.customer_email,
                     line_manager                 = EXCLUDED.line_manager,
                     line_manager_email           = EXCLUDED.line_manager_email,
                     case_responsible             = EXCLUDED.case_responsible,
                     case_responsible_email       = EXCLUDED.case_responsible_email,
                     case_responsible_proxy       = EXCLUDED.case_responsible_proxy,
                     case_responsible_proxy_email = EXCLUDED.case_responsible_proxy_email""",
                alm,
                _str(row.get("Customer Contact"), 255),
                _str(row.get("Customer Email"), 255),
                _str(row.get("Line Manager"), 255),
                _str(row.get("Line Manager Email"), 255),
                _str(row.get("Case Responsible"), 255),
                _str(row.get("Case Responsible Email"), 255),
                _str(row.get("Case Responsible Proxy"), 255),
                _str(row.get("Case Responsible Proxy Email"), 255),
            )
            count += 1

    await _finish_upload(pool, uid, count)
    log.info(f"  âœ“  {count} ALM lines")


# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
# 4. IBM CONTACTS  (IBM_Contact_Details.xlsx)
#    Columns: Group Name | Name | Email
# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

async def import_ibm_contacts(pool, path: str = "Datas/IBM_Contact_Details.xlsx"):
    log.info(f"[4/8] IBM contacts  â†  {path}")
    uid = await _create_upload(pool, Path(path).name, "XLSX", path)
    if uid == -1:
        return

    data = read_excel_sheets(path)
    sheet = next(iter(data.values()))
    count = 0
    async with pool.acquire() as conn:
        await conn.execute("DELETE FROM ibm_contacts")
        for row in sheet:
            name = _str(row.get("Name"), 255)
            if not name:
                continue
            await conn.execute(
                "INSERT INTO ibm_contacts (group_name, name, email) VALUES ($1,$2,$3)",
                _str(row.get("Group Name"), 255),
                name,
                _str(row.get("Email"), 255),
            )
            count += 1

    await _finish_upload(pool, uid, count)
    log.info(f"  âœ“  {count} IBM contacts")


# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
# 5. ESCALATION CONTACTS  (Escalation_Contact_Details.xlsx)
#    Columns: Group | Name | Email
# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

async def import_escalation_contacts(pool, path: str = "Datas/Escalation_Contact_Details.xlsx"):
    log.info(f"[5/8] Escalation contacts  â†  {path}")
    uid = await _create_upload(pool, Path(path).name, "XLSX", path)
    if uid == -1:
        return

    data = read_excel_sheets(path)
    sheet = next(iter(data.values()))
    count = 0
    async with pool.acquire() as conn:
        await conn.execute("DELETE FROM escalation_contacts")
        for row in sheet:
            name = _str(row.get("Name"), 255)
            if not name:
                continue
            await conn.execute(
                "INSERT INTO escalation_contacts (group_name, name, email) VALUES ($1,$2,$3)",
                _str(row.get("Group"), 255),
                name,
                _str(row.get("Email"), 255),
            )
            count += 1

    await _finish_upload(pool, uid, count)
    log.info(f"  âœ“  {count} escalation contacts")


# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
# 6. IBM IDEAS  (IBM_Ideas.csv)
#    Columns (15): Idea Reference | Idea Name | Product | Product Reference |
#      Product Categories | Workflow State | Is Complete | Created At |
#      Updated At | URL | Vote Count | Comment Count | Tags |
#      Description | Visibility of Idea
# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

async def import_ibm_ideas(pool, path: str = "Datas/IBM_Ideas.csv"):
    log.info(f"[6/8] IBM Ideas  â†  {path}")
    uid = await _create_upload(pool, Path(path).name, "CSV", path)
    if uid == -1:
        return

    df = pd.read_csv(path, dtype=str, keep_default_na=False)
    df.columns = df.columns.str.strip()
    count = 0

    async with pool.acquire() as conn:
        for _, row in df.iterrows():
            ref = _str(row.get("Idea Reference"), 50)
            if not ref:
                continue
            await conn.execute(
                """INSERT INTO ibm_ideas (
                     idea_reference, idea_name, product, product_reference,
                     product_categories, workflow_state, is_complete,
                     idea_created_at, idea_updated_at, url,
                     vote_count, comment_count, tags, description,
                     visibility, upload_id
                   ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16)
                   ON CONFLICT (idea_reference) DO UPDATE SET
                     idea_name          = EXCLUDED.idea_name,
                     product            = EXCLUDED.product,
                     product_reference  = EXCLUDED.product_reference,
                     product_categories = EXCLUDED.product_categories,
                     workflow_state     = EXCLUDED.workflow_state,
                     is_complete        = EXCLUDED.is_complete,
                     idea_created_at    = EXCLUDED.idea_created_at,
                     idea_updated_at    = EXCLUDED.idea_updated_at,
                     url                = EXCLUDED.url,
                     vote_count         = EXCLUDED.vote_count,
                     comment_count      = EXCLUDED.comment_count,
                     tags               = EXCLUDED.tags,
                     description        = EXCLUDED.description,
                     visibility         = EXCLUDED.visibility,
                     upload_id          = EXCLUDED.upload_id""",
                ref,
                _str(row.get("Idea Name"), 500),
                _str(row.get("Product"), 255),
                _str(row.get("Product Reference"), 255),
                _str(row.get("Product Categories")),
                _str(row.get("Workflow State"), 100),
                _bool_val(row.get("Is Complete")),
                _parse_ts(row.get("Created At")),
                _parse_ts(row.get("Updated At")),
                _str(row.get("URL"), 500),
                _int(row.get("Vote Count")) or 0,
                _int(row.get("Comment Count")) or 0,
                _str(row.get("Tags")),
                _str(row.get("Description")),
                _str(row.get("Visibility of Idea"), 100),
                uid,
            )
            count += 1

    await _finish_upload(pool, uid, count)
    log.info(f"  âœ“  {count} IBM Ideas")


# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
# 7. WEEKLY CLOSED CASES  (Weekly_Closed_Cases_Tracking_YYYY.xlsm)
#    Columns: SL.No | Case Number | Owner | Title | Customer number |
#      Product | Severity | Status | Age | Closed Date | Comments |
#      Category | Availability
#
#    Also auto-populates:
#      duplicate_references  when category='duplicate' AND comments ~ TS0\d+
#      idea_case_links       when category='rfe'       AND comments has Ideas URL/ref
# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

_TS_RE = re.compile(r'\bTS0\d+\b', re.IGNORECASE)
_IDEA_URL_RE = re.compile(r'https?://[^\s]*ideas\.aha\.io[^\s]*', re.IGNORECASE)
_IDEA_REF_RE = re.compile(r'\b[A-Z]+-I-\d+\b')


def _sunday_week_dates(year: int, week: int):
    """Return (sunday, saturday) for Sunday-based week number.

    Matches the frontend _isoWeek() logic:
      - W01 = the week (Sun–Sat) that contains Jan 1
      - Week starts on Sunday, ends on Saturday
    """
    import datetime as dt
    jan1 = dt.date(year, 1, 1)
    jan1_dow = (jan1.weekday() + 1) % 7  # 0=Sun, 1=Mon … 6=Sat  (like JS getDay())
    w1_sun = jan1 - dt.timedelta(days=jan1_dow)
    sun = w1_sun + dt.timedelta(weeks=week - 1)
    return sun, sun + dt.timedelta(days=6)


def _date_to_sunday_week(d) -> tuple:
    """Return (year, week_number) for a date using Sunday-based week numbering.

    Matches the frontend _isoWeek() logic:
      - W01 = the week (Sun–Sat) that contains Jan 1
      - Week starts on Sunday, ends on Saturday
    """
    import datetime as dt
    yr = d.year
    jan1 = dt.date(yr, 1, 1)
    jan1_dow = (jan1.weekday() + 1) % 7  # 0=Sun like JS getDay()
    w1_sun = jan1 - dt.timedelta(days=jan1_dow)
    d_date = dt.date(yr, d.month, d.day)
    if d_date < w1_sun:
        # Before W01 of this year — belongs to last week of previous year
        return _date_to_sunday_week(dt.date(yr - 1, 12, 31))
    wk = (d_date - w1_sun).days // 7 + 1
    return yr, wk


async def import_weekly_closed_cases(pool, path: str):
    log.info(f"[7/8] Weekly closed cases  â†  {Path(path).name}")
    uid = await _create_upload(pool, Path(path).name, "XLSM", path)
    if uid == -1:
        return

    m = re.search(r'(\d{4})', Path(path).name)
    year_src = int(m.group(1)) if m else datetime.now().year

    async with pool.acquire() as conn:
        known_cases: set = {r["case_number"] for r in await conn.fetch("SELECT case_number FROM cases")}
        known_ideas: set = {r["idea_reference"] for r in await conn.fetch("SELECT idea_reference FROM ibm_ideas")}

    sheets = read_excel_sheets(path)
    total, skipped = 0, 0

    async with pool.acquire() as conn:
        for sh_name, rows in sheets.items():
            wm = re.match(r'CW(\d+)', sh_name)
            if not wm:
                continue
            week_num = int(wm.group(1))
            week_start, week_end = _sunday_week_dates(year_src, week_num)
            week_label = f"CW{week_num:02d}"

            for row in rows:
                cn = _str(row.get("Case Number"), 50)
                if not cn:
                    continue
                if cn not in known_cases:
                    skipped += 1
                    continue

                comments = _str(row.get("Comments")) or ""
                category = _str(row.get("Category"), 100) or ""
                cat_lower = category.lower()

                is_dup = cat_lower == "duplicate" and bool(_TS_RE.search(comments))
                is_reopened = cat_lower == "reopened"
                orig_cn = None
                if is_dup:
                    dm = _TS_RE.search(comments)
                    orig_cn = dm.group(0).upper() if dm else None

                try:
                    await conn.execute(
                        """INSERT INTO weekly_closed_cases (
                             case_number, week_number, year, week_label,
                             week_start_date, week_end_date,
                             owner, comments, category, availability,
                             is_reopened, is_duplicate, original_case_number,
                             upload_id, year_source
                           ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)
                           ON CONFLICT (case_number, week_number, year) DO UPDATE SET
                             owner                = EXCLUDED.owner,
                             comments             = EXCLUDED.comments,
                             category             = EXCLUDED.category,
                             availability         = EXCLUDED.availability,
                             is_reopened          = EXCLUDED.is_reopened,
                             is_duplicate         = EXCLUDED.is_duplicate,
                             original_case_number = EXCLUDED.original_case_number,
                             upload_id            = EXCLUDED.upload_id""",
                        cn, week_num, year_src, week_label,
                        week_start, week_end,
                        _str(row.get("Owner"), 255),
                        comments or None,
                        category or None,
                        _str(row.get("Availability"), 255),
                        is_reopened, is_dup, orig_cn,
                        uid, year_src,
                    )
                    total += 1

                except Exception as e:
                    log.warning(f"  âš   {cn} {week_label}: {e}")
                    continue

                # Auto-populate duplicate_references
                if is_dup and orig_cn:
                    await conn.execute(
                        """INSERT INTO duplicate_references
                             (duplicate_case_number, original_case_number,
                              detected_in_week, detected_by, reason)
                           VALUES ($1,$2,$3,'system','category=Duplicate + TS0* in comments')
                           ON CONFLICT (duplicate_case_number, original_case_number)
                           DO NOTHING""",
                        cn, orig_cn, week_label,
                    )

                # Auto-populate idea_case_links (category=RFE + Ideas URL or ref in comments)
                if comments and (cat_lower == "rfe" or _IDEA_REF_RE.search(comments) or _IDEA_URL_RE.search(comments)):
                    idea_ref = None
                    url_m = _IDEA_URL_RE.search(comments)
                    ref_m = _IDEA_REF_RE.search(comments)
                    if ref_m:
                        idea_ref = ref_m.group(0).upper()
                    elif url_m:
                        rm = re.search(r'/([A-Z]+-I-\d+)', url_m.group(0), re.IGNORECASE)
                        idea_ref = rm.group(1).upper() if rm else None

                    if idea_ref and idea_ref in known_ideas:
                        src = url_m.group(0) if url_m else f"comment ref: {idea_ref}"
                        await conn.execute(
                            """INSERT INTO idea_case_links
                                 (idea_reference, case_number, source, linked_by)
                               VALUES ($1,$2,$3,'system')
                               ON CONFLICT (idea_reference, case_number) DO NOTHING""",
                            idea_ref, cn, src,
                        )

    await _finish_upload(pool, uid, total)
    log.info(f"  âœ“  {total} weekly rows   (skipped FK-missing: {skipped})")

    # Refresh the materialized view -- weekly import changes is_reopened flags
    try:
        async with pool.acquire() as _conn:
            await _conn.execute("REFRESH MATERIALIZED VIEW CONCURRENTLY mv_reopened_cases")
        log.info("  [OK] mv_reopened_cases refreshed after weekly import")
    except Exception as _e:
        log.warning(f"  [WARN] mv_reopened_cases refresh failed: {_e}")


    # Re-sync is_reopened flags from CSV history (source of truth)
    async with pool.acquire() as conn:
        await conn.execute("UPDATE weekly_closed_cases SET is_reopened = FALSE WHERE year = $1", year_src)
        await conn.execute("""
            WITH csv_reopened AS (
              SELECT DISTINCT h1.case_number
              FROM case_status_history h1
              JOIN case_status_history h2
                ON h1.case_number = h2.case_number AND h2.upload_date > h1.upload_date
              JOIN (
                SELECT DISTINCT ON (case_number) case_number, closed_date AS final_closed_date
                FROM case_status_history
                WHERE status IN ('Closed - Archived','Closed by IBM','Closed by Client')
                ORDER BY case_number, upload_date DESC
              ) f ON h1.case_number = f.case_number
              WHERE h1.status IN ('Closed - Archived','Closed by IBM','Closed by Client')
                AND h2.status NOT IN ('Closed - Archived','Closed by IBM','Closed by Client')
                AND h2.status IS NOT NULL
                AND f.final_closed_date > h1.closed_date
            )
            UPDATE weekly_closed_cases wcc
            SET is_reopened = TRUE
            WHERE wcc.case_number IN (SELECT case_number FROM csv_reopened)
        """)
    log.info("  ✔  is_reopened flags re-synced from CSV history")


# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
# 8. WORK ITEMS  (Defect_WorkItem_Details.xlsx)
#    Columns: Work Item | Case Number | Perf/Non-Perf
# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

async def import_work_items(pool, path: str = "Datas/Defect_WorkItem_Details.xlsx"):
    log.info(f"[8/8] Work items <- {path}")
    uid = await _create_upload(pool, Path(path).name, "XLSX", path)
    if uid == -1:
        return

    data = read_excel_sheets(path)
    sheet = next(iter(data.values()))
    count = 0
    async with pool.acquire() as conn:
        known_cases: set = {r["case_number"] for r in await conn.fetch("SELECT case_number FROM cases")}
        for row in sheet:
            work_item = _str(row.get("Work Item"), 100)
            cn = _str(row.get("Case Number"), 50)
            if not work_item or not cn or cn not in known_cases:
                continue
            await conn.execute(
                """UPDATE cases SET work_item=$1, perf_type=$2, updated_at=NOW()
                   WHERE case_number=$3""",
                work_item,
                _str(row.get("Perf/Non-Perf"), 50),
                cn,
            )
            count += 1

    # Sync is_performance_case from imported perf_type values
    async with pool.acquire() as conn:
        await conn.execute("""
            UPDATE cases
            SET is_performance_case = (perf_type = 'Performance')
            WHERE work_item IS NOT NULL
              AND perf_type IS NOT NULL
        """)
        # Default all perf-customer cases that are still untagged to non-performance
        await conn.execute("""
            UPDATE cases
            SET is_performance_case = FALSE
            WHERE customer_number LIKE $1 || '%'
              AND is_performance_case IS NULL
        """, PERF_CUSTOMER_PREFIX)
    log.info("  ✔  is_performance_case synced from imported work items")
    log.info("  ✔  08-account untagged cases defaulted to non-performance")

    await _finish_upload(pool, uid, count)
    log.info(f"  âœ“  {count} defect work items")


# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
# Full import pipeline
# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

async def run_full_import():
    pool = await get_pool()

    # 1. Reference data first (no FK deps)
    if Path("Datas/Team_Members.xlsx").exists():
        await import_team_members(pool)

    # 2. Cases â€” oldest CSV first so latest upload wins on upsert
    csv_dir = Path("Excel_sheets")
    if csv_dir.exists():
        for csv_path in sorted(csv_dir.glob("*.csv")):
            await import_cases_csv(pool, str(csv_path))

    # 3â€“5. Contact/lookup tables
    if Path("Datas/ALM_Line_Details.xlsx").exists():
        await import_alm_lines(pool)
    if Path("Datas/IBM_Contact_Details.xlsx").exists():
        await import_ibm_contacts(pool)
    if Path("Datas/Escalation_Contact_Details.xlsx").exists():
        await import_escalation_contacts(pool)

    # 6. Ideas (before weekly so FK links can be created)
    if Path("Datas/IBM_Ideas.csv").exists():
        await import_ibm_ideas(pool)

    # 7. Weekly closed cases (also populates duplicate_references + idea_case_links)
    for xlsm in sorted(Path("Datas").glob("Weekly_Closed_Cases_Tracking_*.xlsm")):
        await import_weekly_closed_cases(pool, str(xlsm))

    # 8. Work items
    if Path("Datas/Defect_WorkItem_Details.xlsx").exists():
        await import_work_items(pool)

    log.info("=== Import complete ===")


if __name__ == "__main__":
    asyncio.run(run_full_import())
