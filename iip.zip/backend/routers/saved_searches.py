"""
routers/saved_searches.py — Saved search CRUD endpoints
GET    /api/saved-searches?dashboard=  → list searches for dashboard
POST   /api/saved-searches             → create search
DELETE /api/saved-searches/{id}        → delete search
POST   /api/saved-searches/{id}/use    → increment use count
"""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Any
import json
from ..database import get_pool
import asyncpg

router = APIRouter(prefix="/api")


class _CreateRequest(BaseModel):
    dashboard: str
    name: str
    query: Any
    is_shared: bool = False


@router.get("/saved-searches")
async def list_searches(dashboard: str = "", pool: asyncpg.Pool = Depends(get_pool)):
    async with pool.acquire() as conn:
        rows = await conn.fetch(
            """
            SELECT id, dashboard, name, query, is_shared, use_count, created_at
            FROM saved_searches
            WHERE dashboard = $1
            ORDER BY use_count DESC, created_at DESC
            """,
            dashboard,
        )
    searches = [
        {
            "id":         r["id"],
            "dashboard":  r["dashboard"],
            "name":       r["name"],
            "query":      json.loads(r["query"]) if isinstance(r["query"], str) else r["query"],
            "is_shared":  r["is_shared"],
            "use_count":  r["use_count"],
            "created_at": r["created_at"].isoformat() if r["created_at"] else None,
        }
        for r in rows
    ]
    return {"searches": searches}


@router.post("/saved-searches")
async def create_search(body: _CreateRequest, pool: asyncpg.Pool = Depends(get_pool)):
    q = json.dumps(body.query) if not isinstance(body.query, str) else body.query
    async with pool.acquire() as conn:
        row = await conn.fetchrow(
            """
            INSERT INTO saved_searches (dashboard, name, query, is_shared)
            VALUES ($1, $2, $3, $4)
            RETURNING id, dashboard, name, query, is_shared, use_count, created_at
            """,
            body.dashboard, body.name, q, body.is_shared,
        )
    return {
        "id":        row["id"],
        "dashboard": row["dashboard"],
        "name":      row["name"],
        "query":     json.loads(row["query"]) if isinstance(row["query"], str) else row["query"],
        "is_shared": row["is_shared"],
        "use_count": row["use_count"],
    }


@router.delete("/saved-searches/{search_id}")
async def delete_search(search_id: int, pool: asyncpg.Pool = Depends(get_pool)):
    async with pool.acquire() as conn:
        result = await conn.execute("DELETE FROM saved_searches WHERE id = $1", search_id)
    if result == "DELETE 0":
        raise HTTPException(status_code=404, detail="Search not found")
    return {"status": "ok", "deleted": search_id}


@router.post("/saved-searches/{search_id}/use")
async def use_search(search_id: int, pool: asyncpg.Pool = Depends(get_pool)):
    async with pool.acquire() as conn:
        await conn.execute(
            "UPDATE saved_searches SET use_count = use_count + 1, last_used = NOW() WHERE id = $1",
            search_id,
        )
    return {"status": "ok"}
