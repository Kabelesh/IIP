from datetime import datetime
import os
"""
routers/store.py — KV store endpoints
"""
import json
from fastapi import APIRouter, Header, HTTPException, Response
from ..database import get_pool
from ..auth import is_valid_session
from ..models import StoreWriteRequest, BulkSetRequest

router = APIRouter(prefix="/api")

_broadcast = None

def set_broadcast(fn):
    global _broadcast
    _broadcast = fn

# Keys that represent admin config — broadcast config-updated when these change
_CONFIG_KEYS_PREFIX = "admin-"
_CONFIG_KEYS_EXACT  = {"ibm_team_config_v1"}

ALLOWED_KEYS = {
}

ALLOWED_PREFIXES = ()

PUBLIC_WRITE_KEYS = {
}


def is_key_allowed(key: str) -> bool:
    if not key or not isinstance(key, str) or key != key.strip():
        return False
    if key in ALLOWED_KEYS:
        return True
    return any(key.startswith(p) for p in ALLOWED_PREFIXES)


def _parse(v):
    if isinstance(v, str):
        try:
            return json.loads(v)
        except Exception:
            return v
    return v


async def _require_admin(conn, token: str):
    """Raise 403 if the session token is not valid."""
    if not await is_valid_session(conn, token):
        raise HTTPException(status_code=403, detail="Forbidden: invalid or expired session token.")


# ── List all keys ─────────────────────────────────────────────────
# ── List recent errors ───────────────────────────────────────────
@router.get("/store")
async def list_keys(response: Response, x_iip_admin_token: str = Header(default="")):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate, max-age=0"
    pool = await get_pool()
    async with pool.acquire() as conn:
        await _require_admin(conn, x_iip_admin_token)
        rows = await conn.fetch(
        )
    return {"keys": [{"key": r["key"], "updated_at": r["updated_at"].isoformat() if r["updated_at"] else None} for r in rows]}


# ── Cases count ───────────────────────────────────────────────────
@router.get("/store/cases-count")
async def cases_count(response: Response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate, max-age=0"
    pool = await get_pool()
    async with pool.acquire() as conn:
        row = await conn.fetchrow("SELECT COUNT(*) AS count FROM cases")
    return {"ok": True, "count": row["count"]}






@router.get("/config")
@router.get("/v2/config")
async def get_config(response: Response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate, max-age=0"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "0"

    pool = await get_pool()
    async with pool.acquire() as conn:
        rows = await conn.fetch("SELECT key, value FROM app_settings")
    cfg = {r["key"]: r["value"] for r in rows}
    return {"ok": True, "config": cfg}


# ── Team config ───────────────────────────────────────────────────
import time as _st_time
_store_cache: dict = {}

def _sc_get(k):
    e = _store_cache.get(k)
    return e["v"] if e and (_st_time.monotonic() - e["t"]) < e["ttl"] else None

def _sc_set(k, v, ttl=60.0):
    _store_cache[k] = {"t": _st_time.monotonic(), "v": v, "ttl": ttl}

@router.get("/team-config")
async def get_team_config(response: Response):
    cached = _sc_get("team_config")
    if cached is not None:
        response.headers["Cache-Control"] = "public, max-age=30"
        return cached
    pool = await get_pool()
    async with pool.acquire() as conn:
        member_rows  = await conn.fetch(
            "SELECT name, email, display_name, status, team FROM team_members ORDER BY name"
        )
        alm_rows     = await conn.fetch(
            """SELECT alm_line                     AS alm,
                      customer_contact             AS names,
                      customer_email               AS emails,
                      line_manager                 AS bd,
                      line_manager_email           AS "bdEmail",
                      case_responsible             AS ibm,
                      case_responsible_email       AS "ibmEmail",
                      case_responsible_proxy       AS proxy,
                      case_responsible_proxy_email AS "proxyEmail"
               FROM alm_lines ORDER BY alm_line"""
        )
        setting_rows = await conn.fetch("SELECT key, value FROM app_settings")
        esc_rows     = await conn.fetch(
            "SELECT group_name, name, email FROM escalation_contacts ORDER BY id"
        )
        ibm_rows     = await conn.fetch(
            "SELECT group_name, name, email FROM ibm_contacts ORDER BY group_name, name"
        )

    settings = {r["key"]: r["value"] for r in setting_rows}

    try:
        products = json.loads(settings.get("customer_products", "[]"))
    except Exception:
        products = []

    team_cfg = {
        "teamMembers":       [{"name": r["name"], "display_name": r["display_name"] or "", "email": r["email"], "team": r["team"] or ""} for r in member_rows if r.get("status") != "Departed"],
        "departedMembers":   [{"name": r["name"], "display_name": r["display_name"] or "", "email": r["email"], "team": r["team"] or ""} for r in member_rows if r.get("status") == "Departed"],
        "teamEmails":        {r["name"]: r["email"] for r in member_rows},
        "teamGroups":       {r["name"].lower(): (r["team"] or "").strip() for r in member_rows},
        "almResponsible":    [dict(r) for r in alm_rows],
        "caseNumberPattern": settings.get("case_number_pattern", "TS\\d{8,}"),
        "customerAccountId": settings.get("customer_account_id", os.getenv("CUSTOMER_ACCOUNT_ID", "")),
        "customerProducts":  products,
        "expertiseConnect": [
            {"name": r["name"], "email": r["email"]}
            for r in esc_rows if r["group_name"] in (
                "IBM Expertise Connect", "Expertise Connect", "IBM Escalation"
            )
        ],
        "bdEscalation": [
            {"name": r["name"], "email": r["email"]}
            for r in esc_rows if r["group_name"] in (
                "BD Escalation", "BD Escalation Contact"
            )
        ],
        "teamLead": [
            {"name": r["name"], "email": r["email"]}
            for r in esc_rows if r["group_name"] in (
                "Team Lead", "Team Lead Contact"
            )
        ],
        "config": {
            "defectBaseUrl": settings.get("defect_base_url", ""),
        },
    }

    # Build ibmDirectory from ibm_contacts rows
    _ibm_dir = {}
    for r in ibm_rows:
        grp = r["group_name"] or "Other"
        _ibm_dir.setdefault(grp, []).append({"name": r["name"], "email": r["email"]})
    team_cfg["ibmDirectory"] = _ibm_dir

    admin_cfg = {
        "appTitle":        settings.get("app_title", "IBM Cases"),
        "appSubtitle":     settings.get("app_subtitle", ""),
        "teamName":        settings.get("team_name", ""),
        "defectBaseUrl":   settings.get("defect_base_url", ""),
        "customerAccountId": settings.get("customer_account_id", os.getenv("CUSTOMER_ACCOUNT_ID", "")),
        "caseNumberPattern": settings.get("case_number_pattern", "TS\\d{8,}"),
        "senderName":      settings.get("sender_name", ""),
        "slaTargetPct":    settings.get("sla_target_pct", "80"),
        "slaClosureDays":  settings.get("sla_closure_days", "30"),
        "closedStatuses":  _parse(settings.get("closed_statuses", "[]")),
        "idleTimeoutMs":   int(settings.get("idle_timeout_ms", "1800000")),
        "idleWarningMs":   int(settings.get("idle_warning_ms", "1620000")),
        "tablePageSize":   int(settings.get("table_page_size", "50")),
    }

    result = {"ok": True, "data": {
        "ibm_team_config_v1": team_cfg,
        "admin-cfg":          admin_cfg,
    }}
    _sc_set("team_config", result, 60.0)
    response.headers["Cache-Control"] = "public, max-age=30"
    return result

# ── Public team members (read-only, no token needed) ─────────────
@router.get("/team-members")
async def get_team_members(response: Response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate, max-age=0"
    pool = await get_pool()
    async with pool.acquire() as conn:
        rows = await conn.fetch(
            "SELECT id, name, email, team, status, display_name FROM team_members ORDER BY name"
        )
    return [dict(r) for r in rows]


# ── Customer Products (independent — stored in app_settings) ─────
@router.get("/customer-products")
async def get_customer_products(response: Response):
    """Read customer products directly from app_settings table."""
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate, max-age=0"
    pool = await get_pool()
    async with pool.acquire() as conn:
        row = await conn.fetchrow(
            "SELECT value FROM app_settings WHERE key = 'customer_products'"
        )
    products = []
    if row:
        try:
            products = json.loads(row["value"])
        except Exception:
            products = []
    return {"ok": True, "products": products}


@router.put("/customer-products")
async def save_customer_products(
    body: StoreWriteRequest,
    x_iip_admin_token: str = Header(default=""),
):
    """Write customer products directly to app_settings table."""
    products = body.value
    if not isinstance(products, list):
        raise HTTPException(status_code=400, detail="Expected a JSON array of product names.")
    pool = await get_pool()
    async with pool.acquire() as conn:
        await _require_admin(conn, x_iip_admin_token)
        await conn.execute(
            "INSERT INTO app_settings (key, value, description, updated_at) "
            "VALUES ('customer_products', $1, 'JSON array of customer product names shown in product filter', NOW()) "
            "ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = NOW()",
            json.dumps(products),
        )
    if _broadcast:
        await _broadcast("config-updated", {"key": "customer_products"})
    return {"ok": True, "saved": len(products)}
