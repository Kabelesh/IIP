"""
routers/db_cases.py  â”€  IBM IIP production API router
Prefix: /api/v2
All queries target the verified 13-table schema (001_init_schema.sql).
Tables used: cases, weekly_closed_cases, ibm_ideas,
             idea_case_links, duplicate_references, availability_alerts,
             team_members, alm_lines, ibm_contacts, escalation_contacts,
             uploads, audit_log
Views used:  mv_reopened_cases (materialized), v_duplicate_cases, v_weekly_summary
"""

from __future__ import annotations
import json

import asyncio
import hashlib
import json
import logging
import os
import sys
import tempfile
from datetime import datetime, timezone, date
from typing import Optional
from pydantic import BaseModel

import asyncpg
from fastapi import APIRouter, BackgroundTasks, Depends, File, Header, HTTPException, Query, UploadFile, Request
from fastapi.responses import JSONResponse

# â”€â”€ path setup so data_importer can be imported when backend/ is not on sys.path
_backend_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _backend_dir not in sys.path:
    sys.path.insert(0, _backend_dir)

from database import get_pool  # noqa: E402
import data_importer as _di    # noqa: E402

# ── Simple TTL in-memory cache ────────────────────────────────────────────────
import time as _time
_cache: dict = {}

def _cache_get(key: str):
    entry = _cache.get(key)
    if entry and (_time.monotonic() - entry["ts"]) < entry["ttl"]:
        return entry["val"]
    return None

def _cache_set(key: str, val, ttl: float):
    _cache[key] = {"ts": _time.monotonic(), "val": val, "ttl": ttl}


log = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v2", tags=["db"])

_broadcast = None

def set_broadcast(fn):
    global _broadcast
    _broadcast = fn


async def _require_admin(conn, token: str):
    """Raise 403 if the session token is not valid."""
    from ..auth import is_valid_session  # noqa: E402
    if not await is_valid_session(conn, token):
        raise HTTPException(status_code=403, detail="Forbidden: invalid or expired session token.")


# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
# Helpers
# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


# ───────────────────────────────────────────────────────────────────────────────
# HEALTH
# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

@router.get("/data-version", summary="Latest successful upload timestamp as Unix ms")
async def get_data_version(pool: asyncpg.Pool = Depends(get_pool)):
    async with pool.acquire() as conn:
        row = await conn.fetchrow(
            "SELECT EXTRACT(EPOCH FROM MAX(upload_date)) * 1000 AS version_ts "
            "FROM uploads WHERE status = 'success'"
        )
    ts = int(row["version_ts"]) if row and row["version_ts"] else 0
    return {"ok": True, "versionTs": ts}


@router.get("/health")
async def health_check(pool: asyncpg.Pool = Depends(get_pool)):
    async with pool.acquire() as conn:
        row = await conn.fetchrow(
            "SELECT COUNT(*) AS cases, "
            "(SELECT COUNT(*) FROM weekly_closed_cases) AS weekly, "
            "(SELECT COUNT(*) FROM uploads) AS uploads "
            "FROM cases"
        )
    return {"status": "ok", "db": dict(row)}


# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
# FILE UPLOAD
# Saves file to tmp, passes path to the matching data_importer function.
# The importer creates the uploads record itself (including SHA-256 dedup).
# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

def _save_tmp(content: bytes, suffix: str) -> str:
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as f:
        f.write(content)
        return f.name


# Upload size cap (bytes). Override via env.
_MAX_UPLOAD_BYTES = int(os.getenv("IIP_MAX_UPLOAD_BYTES", str(100 * 1024 * 1024)))  # 100 MB

# Customer number prefix for the performance/non-performance tracker.
# All cases whose customer_number starts with this prefix are eligible
# for performance tracking. Override via env if the account number changes.
PERF_CUSTOMER_PREFIX = os.getenv("IIP_PERF_CUSTOMER_PREFIX", "08")


def _validate_filename(file: UploadFile, allowed_suffixes: tuple) -> str:
    """Return lower-cased filename or raise 400. Guards against None filenames."""
    name = (file.filename or "").strip()
    if not name:
        raise HTTPException(400, "Filename is required")
    lower = name.lower()
    if not any(lower.endswith(s) for s in allowed_suffixes):
        raise HTTPException(400, f"Only {' / '.join(allowed_suffixes)} files accepted")
    return lower


async def _read_upload(file: UploadFile) -> bytes:
    """Read upload into memory with a size cap."""
    content = await file.read()
    if len(content) > _MAX_UPLOAD_BYTES:
        raise HTTPException(413, f"File too large (>{_MAX_UPLOAD_BYTES // (1024*1024)} MB)")
    return content


async def _run_import_and_cleanup(coro, tmp_path: str):
    """Run an importer coroutine, then delete the tmp file regardless of outcome."""
    try:
        await coro
    except Exception as e:
        log.error(f"Background import failed: {e}")
    finally:
        try:
            if tmp_path and os.path.exists(tmp_path):
                os.unlink(tmp_path)
        except Exception as e:
            log.warning(f"Failed to unlink tmp upload {tmp_path}: {e}")


@router.post("/upload/cases", summary="Upload IBM Support Case listing CSV")
async def upload_cases(
    file: UploadFile = File(...),
    background_tasks: BackgroundTasks = None,
    pool: asyncpg.Pool = Depends(get_pool),
):
    _validate_filename(file, (".csv",))
    content = await _read_upload(file)
    file_hash = _sha256_bytes(content)

    # Dedup check before even starting
    async with pool.acquire() as conn:
        existing = await conn.fetchval(
            "SELECT id FROM uploads WHERE file_hash=$1 AND status='success'", file_hash
        )
    if existing:
        return JSONResponse({"status": "skipped", "reason": "identical file already imported",
                             "upload_id": existing})

    tmp = _save_tmp(content, ".csv")
    orig_name = file.filename
    # Run synchronously so frontend can immediately re-fetch the updated DB dataset
    await _run_import_and_cleanup(_di.import_cases_csv(pool, tmp, orig_name), tmp)
    if _broadcast:
        import time as _t
        _cache.pop("weekly_tracker_data", None)
        _cache.pop("perf_summary", None)
        _cache.pop("nonperf_summary", None)
        _cache.pop("wt_history", None)
        _cache.pop("tracker_meta", None)
        # Bust all cases_all_* keys
        for _k in list(_cache.keys()):
            if _k.startswith("cases_all_"):
                _cache.pop(_k, None)
        await _broadcast("data-updated", {"versionTs": int(_t.time() * 1000), "filename": orig_name})
    return JSONResponse({"status": "success", "filename": file.filename,
                         "file_hash": file_hash})


@router.get("/uploads", summary="List all file uploads with status")
async def list_uploads(
    limit: int = Query(50, ge=1, le=200),
    pool: asyncpg.Pool = Depends(get_pool),
):
    async with pool.acquire() as conn:
        rows = await conn.fetch(
            """SELECT id, filename, file_type, upload_date, status,
                      record_count, error_message, file_hash, case_fingerprint
               FROM uploads ORDER BY upload_date DESC LIMIT $1""",
            limit,
        )
    return [dict(r) for r in rows]


@router.get("/uploads/fingerprint-check", summary="Check if case fingerprint already uploaded")
async def check_fingerprint(fp: str, pool: asyncpg.Pool = Depends(get_pool)):
    async with pool.acquire() as conn:
        row = await conn.fetchrow(
            "SELECT id, filename, upload_date FROM uploads WHERE case_fingerprint = $1 AND status = 'success' LIMIT 1",
            fp
        )
    if row:
        return {"duplicate": True, "upload_id": row["id"], "filename": row["filename"], "upload_date": str(row["upload_date"])}
    return {"duplicate": False}

@router.patch("/uploads/{upload_id}/fingerprint", summary="Save case fingerprint to upload")
async def save_fingerprint(upload_id: int, body: dict, pool: asyncpg.Pool = Depends(get_pool)):
    fp = body.get("fingerprint", "")
    if not fp:
        raise HTTPException(400, "fingerprint required")
    async with pool.acquire() as conn:
        await conn.execute("UPDATE uploads SET case_fingerprint=$1 WHERE id=$2", fp, upload_id)
    return {"ok": True}

@router.get("/uploads/{upload_id}", summary="Get single upload status")
async def get_upload(upload_id: int, pool: asyncpg.Pool = Depends(get_pool)):
    async with pool.acquire() as conn:
        row = await conn.fetchrow("SELECT * FROM uploads WHERE id=$1", upload_id)
    if not row:
        raise HTTPException(404, "Upload not found")
    return dict(row)


# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
# CASES
# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

@router.get("/cases", summary="Paginated case list with optional filters")
async def list_cases(
    skip: int = Query(0, ge=0),
    limit: int = Query(10000, ge=1, le=50000),
    status: Optional[str] = None,
    owner: Optional[str] = None,
    customer_number: Optional[str] = None,
    is_team: Optional[bool] = None,
    is_performance: Optional[bool] = None,
    severity: Optional[str] = None,
    is_active: Optional[bool] = None,
    pool: asyncpg.Pool = Depends(get_pool),
):
    # Fast-path cache for the common no-filter full-load call
    _no_filter = not any([status, owner, customer_number,
                           is_team, is_performance, severity, is_active])
    if _no_filter and skip == 0:
        _ck = f"cases_all_{limit}"
        _hit = _cache_get(_ck)
        if _hit is not None:
            return _hit

    where, params = [], []

    def _add(clause: str, val):
        params.append(val)
        where.append(clause.replace("?", f"${len(params)}"))

    if status:
        _add("status ILIKE ?", f"%{status}%")
    if owner:
        _add("owner_name ILIKE ?", f"%{owner}%")
    if customer_number:
        _add("customer_number = ?", customer_number)
    if is_team is not None:
        _add("is_team_case = ?", is_team)
    if is_performance is not None:
        _add("is_performance_case = ?", is_performance)
    if severity:
        _add("severity = ?", severity)
    if is_active is not None:
        _add("is_active = ?", is_active)

    where_sql = ("WHERE " + " AND ".join(where)) if where else ""

    async with pool.acquire() as conn:
        # Single query: cases + latest_upload_id via scalar subquery.
        # COUNT(*) removed — frontend uses limit=10000 and never paginates.
        # LEFT JOIN team_members removed — display_name is resolved client-side
        # via DynamicConfig.nameAliases(), so the JOIN was redundant and expensive.
        rows = await conn.fetch(
            f"""SELECT c.case_number, c.title, c.status, c.severity, c.age_days,
                       c.owner_name,
                       c.owner_name AS display_name,
                       c.customer_number, c.product, c.created_date, c.updated_date,
                       c.closed_date, c.country_name, c.is_team_case, c.is_performance_case,
                       c.is_active, c.latest_upload_id,
                       (SELECT MAX(id) FROM uploads) AS _latest_upload_id
                FROM cases c
                {where_sql.replace("WHERE ", "WHERE c.") if where_sql else ""}
                ORDER BY c.updated_date DESC NULLS LAST, c.case_number
                LIMIT ${len(params)+1} OFFSET ${len(params)+2}""",
            *params, limit, skip,
        )
    latest_upload_id = rows[0]["_latest_upload_id"] if rows else None
    total = len(rows)
    _result = {"total": total, "skip": skip, "limit": limit,
               "latest_upload_id": latest_upload_id,
               "cases": [{k: v for k, v in dict(r).items() if k != "_latest_upload_id"} for r in rows]}
    if _no_filter and skip == 0:
        _cache_set(f"cases_all_{limit}", _result, 30.0)
    return _result


@router.get("/cases/distinct-products", summary="All unique product values from the cases table")
async def distinct_products(pool: asyncpg.Pool = Depends(get_pool)):
    async with pool.acquire() as conn:
        rows = await conn.fetch(
            "SELECT DISTINCT product FROM cases WHERE product IS NOT NULL AND product <> '' ORDER BY product"
        )
    return {"ok": True, "products": [r["product"] for r in rows]}


# PERFORMANCE SUMMARY — single endpoint for admin panel bootstrap
# ─────────────────────────────────────────────────────────────────

@router.get("/cases/performance-summary", summary="All performance-tagged cases with work items")
async def performance_summary(pool: asyncpg.Pool = Depends(get_pool)):
    cached = _cache_get("perf_summary")
    if cached is not None:
        return cached
    async with pool.acquire() as conn:

        # ── Query 1: Performance cases (explicit admin tag) ────────────────────────────────
        perf_rows = await conn.fetch(
            """
            SELECT
                c.case_number,
                c.title,
                c.status,
                c.owner_name,
                COALESCE(NULLIF(tm.display_name, ''), c.owner_name) AS display_name,
                c.work_item,
                c.perf_type
            FROM cases c
            LEFT JOIN team_members tm ON LOWER(tm.name) = LOWER(c.owner_name)
            WHERE c.is_performance_case = TRUE
            ORDER BY c.case_number
            """
        )

        # ── Query 2: Non-performance cases (dynamic: team member + customer 08) ──────────
        non_perf_rows = await conn.fetch(
            """
            SELECT
                c.case_number,
                c.title,
                c.status,
                c.owner_name,
                COALESCE(NULLIF(tm.display_name, ''), c.owner_name) AS display_name,
                c.customer_number,
                c.work_item,
                c.perf_type
            FROM cases c
            JOIN team_members tm ON LOWER(tm.name) = LOWER(c.owner_name)
            WHERE c.is_performance_case = FALSE
              AND c.customer_number     LIKE $1 || '%'
            ORDER BY c.case_number
            """,
            PERF_CUSTOMER_PREFIX,
        )

    def _build(r):
        wi = r["work_item"]
        pt = r["perf_type"]
        work_items = [{"work_item": wi, "perf_type": pt}] if wi else []
        return {
            "case_number":  r["case_number"],
            "title":        r["title"] or "",
            "status":       r["status"] or "",
            "owner_name":   r["owner_name"],
            "display_name": r["display_name"],
            "work_items":   work_items,
        }

    result = {
        "performance_cases":     [_build(r) for r in perf_rows],
        "non_performance_cases": [_build(r) for r in non_perf_rows],
    }
    _cache_set("perf_summary", result, 30.0)
    return result



# ─────────────────────────────────────────────────────────────────────────────
# GET /api/v2/cases/archive
# Returns all-time case archive enriched with weekly comments and
# wednesday comments — serves /api/v2/cases/archive for Investigate dashboard
# ─────────────────────────────────────────────────────────────────────────────
@router.get("/cases/archive", summary="All-time case archive enriched with comments")
async def cases_archive(pool: asyncpg.Pool = Depends(get_pool)):
    async with pool.acquire() as conn:
        rows = await conn.fetch(
            """
            SELECT
                c.case_number                          AS "Case Number",
                c.title                                AS "Title",
                c.product                              AS "Product",
                c.status                               AS "Status",
                c.owner_name                           AS "Owner",
                c.severity                             AS "Severity",
                MAX(csh.upload_date)::text             AS "_lastSeen",
                STRING_AGG(DISTINCT wcc.comments, ' '
                    ORDER BY wcc.comments)             AS "_wtComment",
                STRING_AGG(DISTINCT pwc.comment, ' '
                    ORDER BY pwc.comment)              AS "_wednesdayComments"
            FROM cases c
            LEFT JOIN case_status_history csh
                ON csh.case_number = c.case_number
            LEFT JOIN weekly_closed_cases wcc
                ON wcc.case_number = c.case_number
                AND wcc.comments IS NOT NULL
                AND wcc.comments <> ''
            LEFT JOIN performance_wednesday_comments pwc
                ON pwc.case_number = c.case_number
            GROUP BY
                c.case_number, c.title, c.product,
                c.status, c.owner_name, c.severity
            ORDER BY MAX(csh.upload_date) DESC NULLS LAST
            """
        )
    return [dict(r) for r in rows]


@router.get("/cases/nonperf-summary", summary="Non-performance team cases for the given customer prefix")
async def nonperf_summary(pool: asyncpg.Pool = Depends(get_pool)):
    cached = _cache_get("nonperf_summary")
    if cached is not None:
        return cached
    async with pool.acquire() as conn:
        rows = await conn.fetch("""
            SELECT c.case_number, c.work_item, c.perf_type FROM cases c
            JOIN team_members tm ON LOWER(tm.name) = LOWER(c.owner_name)
            WHERE c.customer_number LIKE $1 || '%'
              AND c.is_performance_case = FALSE
            ORDER BY c.case_number
        """, PERF_CUSTOMER_PREFIX)
    result = {"case_numbers": [r["case_number"] for r in rows], "count": len(rows),
            "cases": [{"case_number": r["case_number"], "work_item": r["work_item"] or "", "perf_type": r["perf_type"] or ""} for r in rows]}
    _cache_set("nonperf_summary", result, 30.0)
    return result




@router.get("/cases/{case_number}", summary="Full case detail including weekly history")
async def get_case(case_number: str, pool: asyncpg.Pool = Depends(get_pool)):
    async with pool.acquire() as conn:
        case = await conn.fetchrow(
            """SELECT case_number, title, status, legacy_number, severity, age_days,
                      owner_name, customer_number, created_date, updated_date,
                      product, solution_date, closed_date,
                      client_asset_identifier, serial_number,
                      machine_model, machine_type, country_name, account_iso,
                      is_performance_case, is_team_case, latest_upload_id,
                      created_at, updated_at, is_active
               FROM cases WHERE case_number = $1""",
            case_number,
        )
        if not case:
            raise HTTPException(404, "Case not found")

        weekly = await conn.fetch(
            """SELECT week_label, year, week_number, week_start_date, week_end_date,
                      owner, comments, category, availability,
                      is_reopened, is_duplicate, original_case_number
               FROM weekly_closed_cases
               WHERE case_number = $1
               ORDER BY year DESC, week_number DESC""",
            case_number,
        )

        work_items = await conn.fetch(
            "SELECT work_item, perf_type FROM cases WHERE case_number=$1 AND work_item IS NOT NULL",
            case_number,
        )

        ideas = await conn.fetch(
            """SELECT icl.idea_reference, ii.idea_name, ii.workflow_state,
                      ii.url, icl.source, icl.linked_by, icl.linked_date
               FROM idea_case_links icl
               LEFT JOIN ibm_ideas ii ON icl.idea_reference = ii.idea_reference
               WHERE icl.case_number = $1""",
            case_number,
        )

        duplicates = await conn.fetch(
            """SELECT original_case_number, detected_in_week, detected_by,
                      detected_date, reason
               FROM duplicate_references
               WHERE duplicate_case_number = $1""",
            case_number,
        )

    return {
        "case": dict(case),
        "weekly_history": [dict(w) for w in weekly],
        "work_items": [dict(wi) for wi in work_items],
        "idea_links": [dict(i) for i in ideas],
        "duplicate_references": [dict(d) for d in duplicates],
    }



# ── Performance Wednesday Comments ──────────────────────────────────────────

@router.get("/cases/{case_number}/wednesday-comments", summary="Get wednesday comments for a case")
async def get_wednesday_comments(
    case_number: str,
    pool: asyncpg.Pool = Depends(get_pool),
):
    async with pool.acquire() as conn:
        rows = await conn.fetch(
            """SELECT case_number, to_char(date_key, 'YYYY-MM-DD') as date_key, comment, updated_by, updated_at
               FROM performance_wednesday_comments
               WHERE case_number = $1
               ORDER BY date_key""",
            case_number,
        )
    return {"case_number": case_number, "comments": [dict(r) for r in rows]}


@router.patch("/cases/{case_number}/wednesday-comments", summary="Upsert a wednesday comment")
async def upsert_wednesday_comment(
    case_number: str,
    body: dict,
    x_iip_admin_token: str = Header(default=""),
    pool: asyncpg.Pool = Depends(get_pool),
):
    date_key   = (body.get("date_key") or "").strip()
    comment    = (body.get("comment") or "").strip()
    updated_by = (body.get("updated_by") or "User").strip()
    if not date_key:
        raise HTTPException(400, "date_key is required (YYYY-MM-DD)")
    from datetime import date as _date
    try:
        parsed_date = _date.fromisoformat(date_key)
    except ValueError:
        raise HTTPException(400, "date_key must be YYYY-MM-DD")
    async with pool.acquire() as conn:
        await _require_admin(conn, x_iip_admin_token)
        existing = await conn.fetchrow(
            "SELECT case_number FROM cases WHERE case_number=$1", case_number
        )
        if existing is None:
            raise HTTPException(404, "Case not found")
        await conn.execute(
            """INSERT INTO performance_wednesday_comments (case_number, date_key, comment, updated_by)
               VALUES ($1, $2, $3, $4)
               ON CONFLICT (case_number, date_key)
               DO UPDATE SET comment=$3, updated_by=$4, updated_at=CURRENT_TIMESTAMP""",
            case_number, parsed_date, comment, updated_by,
        )
    return {"status": "ok", "case_number": case_number, "date_key": date_key, "comment": comment}


# ── Performance Slot Days ─────────────────────────────────────────────────────

@router.get("/cases/{case_number}/slot-days", summary="Get slot day overrides for a case")
async def get_slot_days(
    case_number: str,
    pool: asyncpg.Pool = Depends(get_pool),
):
    async with pool.acquire() as conn:
        rows = await conn.fetch(
            """SELECT case_number, year, month, slot_index, day_of_week, updated_by
               FROM performance_slot_days
               WHERE case_number = $1
               ORDER BY year, month, slot_index""",
            case_number,
        )
    return {"case_number": case_number, "slots": [dict(r) for r in rows]}


@router.patch("/cases/{case_number}/slot-days", summary="Upsert a slot day override")
async def upsert_slot_day(
    case_number: str,
    body: dict,
    x_iip_admin_token: str = Header(default=""),
    pool: asyncpg.Pool = Depends(get_pool),
):
    year        = int(body.get("year") or 0)
    month       = int(body.get("month") or 0)
    slot_index  = int(body.get("slot_index") or 0)
    day_of_week = int(body.get("day_of_week") or 3)
    old_date    = (body.get("old_date") or "").strip()
    new_date    = (body.get("new_date") or "").strip()
    updated_by  = (body.get("updated_by") or "Admin").strip()
    if not year or month < 0:
        raise HTTPException(400, "year and month are required")
    from datetime import date as _date
    async with pool.acquire() as conn:
        await _require_admin(conn, x_iip_admin_token)
        existing = await conn.fetchrow(
            "SELECT case_number FROM cases WHERE case_number=$1", case_number
        )
        if existing is None:
            raise HTTPException(404, "Case not found")
        # Upsert slot day
        await conn.execute(
            """INSERT INTO performance_slot_days (case_number, year, month, slot_index, day_of_week, updated_by)
               VALUES ($1, $2, $3, $4, $5, $6)
               ON CONFLICT (case_number, year, month, slot_index)
               DO UPDATE SET day_of_week=$5, updated_by=$6, updated_at=CURRENT_TIMESTAMP""",
            case_number, year, month, slot_index, day_of_week, updated_by,
        )
        # Move comment from old date to new date if both provided
        if old_date and new_date and old_date != new_date:
            try:
                old_dt = _date.fromisoformat(old_date)
                new_dt = _date.fromisoformat(new_date)
                # Get existing comment on old date
                existing_comment = await conn.fetchrow(
                    "SELECT comment FROM performance_wednesday_comments WHERE case_number=$1 AND date_key=$2",
                    case_number, old_dt,
                )
                if existing_comment:
                    # Upsert on new date
                    await conn.execute(
                        """INSERT INTO performance_wednesday_comments (case_number, date_key, comment, updated_by)
                           VALUES ($1, $2, $3, $4)
                           ON CONFLICT (case_number, date_key)
                           DO UPDATE SET comment=$3, updated_by=$4, updated_at=CURRENT_TIMESTAMP""",
                        case_number, new_dt, existing_comment["comment"], updated_by,
                    )
                    # Delete old date entry
                    await conn.execute(
                        "DELETE FROM performance_wednesday_comments WHERE case_number=$1 AND date_key=$2",
                        case_number, old_dt,
                    )
            except Exception as e:
                print(f"[slot-days] comment move failed: {e}")
    return {"status": "ok", "case_number": case_number, "year": year, "month": month,
            "slot_index": slot_index, "day_of_week": day_of_week}

@router.patch("/cases/{case_number}/availability", summary="Set performance case availability")
async def set_perf_availability(
    case_number: str,
    body: dict,
    x_iip_admin_token: str = Header(default=""),
    pool: asyncpg.Pool = Depends(get_pool),
):
    val        = (body.get("availability") or "").strip()
    admin_user = (body.get("admin_user") or "User").strip()
    async with pool.acquire() as conn:
        await _require_admin(conn, x_iip_admin_token)
        existing = await conn.fetchrow(
            "SELECT case_number FROM cases WHERE case_number=$1", case_number
        )
        if existing is None:
            raise HTTPException(404, "Case not found")
        await conn.execute(
            "UPDATE cases SET availability=$1 WHERE case_number=$2",
            val, case_number,
        )
        await conn.execute(
            """INSERT INTO audit_log (action, entity_type, entity_id, old_value, new_value, admin_user)
               VALUES ('set_availability','case',$1,'',$2,$3)""",
            case_number, val, admin_user,
        )
    return {"status": "ok", "case_number": case_number, "availability": val}


# ─────────────────────────────────────────────────────────────────────────────
# PATCH /api/v2/cases/{case_number}/performance-tag
# Production-grade: single transaction for tag + work item + audit
# Replaces the two-call pattern (PATCH /performance + POST /work-item)
# ─────────────────────────────────────────────────────────────────────────────
class PerfTagBody(BaseModel):
    value:      bool
    work_item:  str  = ""
    perf_type:  str  = "Performance"
    admin_user: str  = "Admin"

@router.patch("/cases/{case_number}/performance-tag", summary="Admin: tag perf/non-perf + work item in one transaction")
async def set_performance_tag(
    case_number: str,
    body: PerfTagBody,
    x_iip_admin_token: str = Header(default=""),
    pool: asyncpg.Pool = Depends(get_pool),
):
    async with pool.acquire() as conn:
        await _require_admin(conn, x_iip_admin_token)
        existing = await conn.fetchrow(
            "SELECT is_performance_case FROM cases WHERE case_number=$1",
            case_number,
        )
        if existing is None:
            raise HTTPException(404, "Case not found")

        old_value = existing["is_performance_case"]

        # No-op guard
        if old_value == body.value and not body.work_item:
            return {"status": "no_change", "case_number": case_number}

        async with conn.transaction():
            # 1. Update tag only if it actually changed
            tag_changed = (old_value != body.value)
            if tag_changed:
                if body.value:
                    await conn.execute(
                        "UPDATE cases SET is_performance_case=$1, is_team_case=TRUE, updated_at=NOW() WHERE case_number=$2",
                        body.value, case_number,
                    )
                else:
                    await conn.execute(
                        "UPDATE cases SET is_performance_case=$1, updated_at=NOW() WHERE case_number=$2",
                        body.value, case_number,
                    )

            # 2. Replace work item if provided (single UPDATE on cases)
            if body.work_item:
                await conn.execute(
                    "UPDATE cases SET work_item=$1, perf_type=$2, updated_at=NOW() WHERE case_number=$3",
                    body.work_item, body.perf_type, case_number,
                )

            # 3. Single audit entry — notes captures what actually changed
            parts = []
            if tag_changed:
                parts.append(f"tag={'true' if body.value else 'false'}")
            if body.work_item:
                parts.append(f"work_item={body.work_item}")
            notes = ", ".join(parts) if parts else "no_change"
            await conn.execute(
                """INSERT INTO audit_log
                   (action, entity_type, entity_id, old_value, new_value, admin_user, notes)
                   VALUES ('set_performance', 'case', $1, $2, $3, $4, $5)""",
                case_number,
                "true" if old_value else "false",
                "true" if body.value else "false",
                body.admin_user,
                notes,
            )

    if _broadcast:
        await _broadcast("perf-tag-updated", {"case_number": case_number, "is_performance_case": body.value, "work_item": body.work_item or ""})

    return {
        "status":               "ok",
        "case_number":          case_number,
        "is_performance_case":  body.value,
        "work_item":            body.work_item or None,
    }



# ── (deprecated endpoints removed — use PATCH /cases/{id}/performance-tag) ──


# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€


# ─────────────────────────────────────────────────────────────────────────────
# OWNER REASSIGNMENT
# ─────────────────────────────────────────────────────────────────────────────

class OwnerReassignBody(BaseModel):
    owner: str
    admin_user: str = "Admin"

@router.patch("/cases/{case_number}/owner", summary="Admin: reassign case owner")
async def reassign_case_owner(
    case_number: str,
    body: OwnerReassignBody,
    x_iip_admin_token: str = Header(default=""),
    pool: asyncpg.Pool = Depends(get_pool),
):
    async with pool.acquire() as conn:
        await _require_admin(conn, x_iip_admin_token)

        existing = await conn.fetchrow(
            "SELECT owner_name, title FROM cases WHERE case_number=$1",
            case_number,
        )
        if existing is None:
            raise HTTPException(404, "Case not found")

        old_owner = existing["owner_name"]
        case_title = existing["title"] or ""
        new_owner = body.owner
        if old_owner == new_owner:
            return {"status": "no_change", "case_number": case_number, "owner": old_owner}
        admin_user = body.admin_user or "Admin"

        await conn.execute(
            "UPDATE cases SET owner_name=$1, updated_at=NOW() WHERE case_number=$2",
            new_owner, case_number,
        )
        await conn.execute(
            """INSERT INTO audit_log (action, entity_type, entity_id, old_value, new_value, admin_user, notes)
               VALUES ('reassign','case',$1,$2,$3,$4,$5)""",
            case_number, old_owner, new_owner, admin_user, case_title,
        )

    return {"status": "ok", "case_number": case_number, "old_owner": old_owner, "new_owner": new_owner}


@router.get("/admin/reassign-log", summary="Admin: get reassignment history from audit_log")
async def get_reassign_log(
    limit: int = 200,
    x_iip_admin_token: str = Header(default=""),
    pool: asyncpg.Pool = Depends(get_pool),
):
    async with pool.acquire() as conn:
        await _require_admin(conn, x_iip_admin_token)

        rows = await conn.fetch(
            """SELECT entity_id AS case_number, old_value AS old_owner, new_value AS new_owner,
                      notes AS title, admin_user, change_date
               FROM audit_log
               WHERE action = 'reassign'
               ORDER BY change_date DESC
               LIMIT $1""",
            limit,
        )
    return [dict(r) for r in rows]

# WEEKLY TRACKER
# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

@router.get("/weekly/{year}", summary="All week summaries for a year")
async def yearly_summary(year: int, pool: asyncpg.Pool = Depends(get_pool)):
    if year < 2020 or year > 2099:
        raise HTTPException(400, "year must be 2020â€“2099")
    async with pool.acquire() as conn:
        rows = await conn.fetch(
            """SELECT year, week_number, week_label, week_start_date, week_end_date,
                      total_cases_closed, reopened_count, duplicate_count,
                      rfe_count, performance_count, team_count
               FROM v_weekly_summary
               WHERE year=$1
               ORDER BY week_number""",
            year,
        )
    return {"year": year, "weeks": [dict(r) for r in rows]}


@router.get("/weekly/{year}/{week}", summary="Cases for a specific week (CW01â€¦CW53)")
async def weekly_cases(
    year: int,
    week: str,
    pool: asyncpg.Pool = Depends(get_pool),
):
    """week param: CW01, cw01, 1, or 01"""
    import re as _re
    m = _re.match(r'^[Cc][Ww]?(\d{1,2})$|^(\d{1,2})$', week.strip())
    if not m:
        raise HTTPException(400, "week must be CW01â€¦CW53 or a number 1â€“53")
    week_num = int(m.group(1) or m.group(2))
    if week_num < 1 or week_num > 53:
        raise HTTPException(400, "week must be 1â€“53")

    async with pool.acquire() as conn:
        summary = await conn.fetchrow(
            """SELECT year, week_number, week_label, week_start_date, week_end_date,
                      total_cases_closed, reopened_count, duplicate_count,
                      rfe_count, performance_count, team_count
               FROM v_weekly_summary WHERE year=$1 AND week_number=$2""",
            year, week_num,
        )

        rows = await conn.fetch(
            """SELECT w.case_number, c.title, w.owner, c.customer_number, c.product,
                      c.severity, c.status, c.closed_date,
                      w.comments, w.category, w.availability,
                      w.is_reopened, w.is_duplicate, w.original_case_number,
                      c.is_performance_case, c.is_team_case,
                      r.week_labels   AS reopen_week_labels,
                      r.week_years    AS reopen_week_years
               FROM weekly_closed_cases w
               JOIN cases c ON w.case_number = c.case_number
               LEFT JOIN mv_reopened_cases r ON r.case_number = w.case_number
               WHERE w.year=$1 AND w.week_number=$2
               ORDER BY c.closed_date DESC NULLS LAST, w.case_number""",
            year, week_num,
        )

    def _enrich_row(r, week_num):
        d = dict(r)
        # Compute later_week: find the next week label after current week_num
        labels = list(r["reopen_week_labels"] or [])
        years  = list(r["reopen_week_years"]  or [])
        later_week = None
        later_year = None
        if d["is_reopened"] and labels:
            import re as _re
            for i, lbl in enumerate(labels):
                m = _re.search(r"\d+", lbl)
                lbl_num = int(m.group()) if m else 0
                lbl_yr  = years[i] if i < len(years) else year
                if (lbl_yr > year) or (lbl_yr == year and lbl_num > week_num):
                    later_week = lbl
                    later_year = lbl_yr
                    break
        d["later_week"] = later_week
        d["later_year"] = later_year
        del d["reopen_week_labels"]
        del d["reopen_week_years"]
        return d

    return {
        "year": year,
        "week": f"CW{week_num:02d}",
        "summary": dict(summary) if summary else {},
        "cases": [_enrich_row(r, week_num) for r in rows],
    }


# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
# VIEWS â€” reopened / duplicates / summary
# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

@router.get("/reopened", summary="All reopened cases grouped by case")
async def reopened_cases(
    year: Optional[int] = None,
    pool: asyncpg.Pool = Depends(get_pool),
):
    CLOSED_STATUSES = ("Closed by IBM", "Closed by Client", "Closed - Archived", "Cancelled")

    # Build WHERE clause for year filter at SQL level (uses reopened_upload_date year)
    where_sql = ""
    params: list = []
    if year:
        params.append(year)
        where_sql = f"WHERE EXTRACT(YEAR FROM r.reopened_upload_date) = $1"

    async with pool.acquire() as conn:
        rows = await conn.fetch(
            f"""SELECT
                 r.case_number, r.title, r.owner_name, r.severity, r.customer_number, r.product,
                 r.current_status, r.first_closed_date, r.first_closed_status,
                 r.reopened_upload_date, r.final_closed_date, r.final_closed_status,
                 r.times_in_weekly, r.week_labels, r.week_years, r.week_comments,
                 r.has_overlap_duplicate,
                 c.is_team_case
               FROM mv_reopened_cases r
               JOIN cases c ON r.case_number = c.case_number
               {where_sql}
               ORDER BY r.final_closed_date DESC NULLS LAST""",
            *params
        )

    grouped: dict = {}
    for r in rows:
        cn = r["case_number"]
        if cn not in grouped:
            current_status = r["current_status"] or "Closed"
            is_currently_open = current_status not in CLOSED_STATUSES
            times_in_weekly = r["times_in_weekly"]
            missed_weekly = (
                (times_in_weekly is None or times_in_weekly == 0)
                and bool(r["is_team_case"])
                and not is_currently_open
            )
            grouped[cn] = {
                "caseNumber":           cn,
                "title":                r["title"],
                "owner":                r["owner_name"],
                "severity":             r["severity"],
                "product":              r["product"],
                "customerNumber":       r["customer_number"],
                "currentStatus":        current_status,
                "isCurrentlyOpen":      is_currently_open,
                "missedWeekly":         missed_weekly,
                "firstClosedDate":     str(r["first_closed_date"])    if r["first_closed_date"]    else None,
                "firstClosedStatus":   r["first_closed_status"]    or "",
                "reopenedUploadDate":  str(r["reopened_upload_date"]) if r["reopened_upload_date"] else None,
                "finalClosedDate":     str(r["final_closed_date"])   if r["final_closed_date"]    else None,
                "finalClosedStatus":   r["final_closed_status"]    or "",
                "timesInWeekly":       times_in_weekly,
                "weekLabels":          list(r["week_labels"])   if r["week_labels"]   else [],
                "weekYears":           list(r["week_years"])    if r["week_years"]    else [],
                "weekComments":        list(r["week_comments"]) if r["week_comments"] else [],
                "hasOverlapDuplicate": bool(r["has_overlap_duplicate"]),
            }

    result = list(grouped.values())
    result.sort(key=lambda g: (g["finalClosedDate"] or ""), reverse=True)
    return {"reopened": result, "total": len(result)}


@router.get("/ideas", summary="List IBM Ideas")
async def list_ideas(
    workflow_state: Optional[str] = None,
    limit: int = Query(100, ge=1, le=1000),
    pool: asyncpg.Pool = Depends(get_pool),
):
    where = "WHERE workflow_state ILIKE $1" if workflow_state else ""
    params = [f"%{workflow_state}%"] if workflow_state else []
    async with pool.acquire() as conn:
        rows = await conn.fetch(
            f"""SELECT idea_reference, idea_name, product, workflow_state,
                       is_complete, vote_count, comment_count, url,
                       idea_created_at, idea_updated_at
                FROM ibm_ideas {where}
                ORDER BY idea_reference
                LIMIT ${len(params)+1}""",
            *params, limit,
        )
    return [dict(r) for r in rows]


@router.get("/ideas/{idea_reference}", summary="Idea detail with linked cases")
async def get_idea(idea_reference: str, pool: asyncpg.Pool = Depends(get_pool)):
    async with pool.acquire() as conn:
        idea = await conn.fetchrow(
            "SELECT * FROM ibm_ideas WHERE idea_reference=$1", idea_reference
        )
        if not idea:
            raise HTTPException(404, "Idea not found")
        links = await conn.fetch(
            """SELECT icl.case_number, c.title, c.owner_name, c.status,
                      icl.source, icl.linked_by, icl.linked_date
               FROM idea_case_links icl
               LEFT JOIN cases c ON icl.case_number = c.case_number
               WHERE icl.idea_reference=$1""",
            idea_reference,
        )
    return {"idea": dict(idea), "linked_cases": [dict(l) for l in links]}


@router.get("/team", summary="Team members list")
async def list_team(pool: asyncpg.Pool = Depends(get_pool)):
    async with pool.acquire() as conn:
        rows = await conn.fetch(
            "SELECT id, name, display_name, email, team, status FROM team_members ORDER BY name"
        )
    return [dict(r) for r in rows]


@router.get("/alm-lines", summary="ALM lines with contacts")
async def list_alm_lines(pool: asyncpg.Pool = Depends(get_pool)):
    async with pool.acquire() as conn:
        rows = await conn.fetch(
            "SELECT * FROM alm_lines ORDER BY alm_line"
        )
    return [dict(r) for r in rows]


@router.get("/ibm-contacts", summary="IBM directory contacts")
async def list_ibm_contacts(pool: asyncpg.Pool = Depends(get_pool)):
    async with pool.acquire() as conn:
        rows = await conn.fetch(
            "SELECT id, group_name, name, email FROM ibm_contacts ORDER BY group_name, name"
        )
    return [dict(r) for r in rows]


@router.get("/escalation-contacts", summary="Escalation contacts")
async def list_escalation_contacts(pool: asyncpg.Pool = Depends(get_pool)):
    async with pool.acquire() as conn:
        rows = await conn.fetch(
            "SELECT id, group_name, name, email FROM escalation_contacts ORDER BY group_name, name"
        )
    return [dict(r) for r in rows]


# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
# AVAILABILITY ALERTS
# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

@router.get("/audit", summary="Recent audit log entries")
async def get_audit_log(
    entity_type: Optional[str] = None,
    entity_id: Optional[str] = None,
    limit: int = Query(500, ge=1, le=5000),
    pool: asyncpg.Pool = Depends(get_pool),
):
    where, params = [], []

    def _add(clause, val):
        params.append(val)
        where.append(clause.replace("?", f"${len(params)}"))

    if entity_type:
        _add("entity_type = ?", entity_type)
    if entity_id:
        _add("entity_id = ?", entity_id)

    where_sql = ("WHERE " + " AND ".join(where)) if where else ""
    async with pool.acquire() as conn:
        rows = await conn.fetch(
            f"""SELECT id, action, entity_type, entity_id,
                       old_value, new_value, admin_user, change_date, notes
                FROM audit_log {where_sql}
                ORDER BY change_date DESC
                LIMIT ${len(params)+1}""",
            *params, limit,
        )
    return [dict(r) for r in rows]



# ═══════════════════════════════════════════════════════════════════════════════
# ADMIN DASHBOARD STATS
# ═══════════════════════════════════════════════════════════════════════════════

@router.get("/admin/dashboard-stats", summary="Admin overview dashboard — all stats in one call")
async def admin_dashboard_stats(
    x_iip_admin_token: str = Header(default=""),
    pool: asyncpg.Pool = Depends(get_pool),
):
    """
    Returns all data needed for the admin overview dashboard in a single DB call:
    - Last upload (filename, date, status, record_count)
    - Performance case counts (perf + non-perf)
    - Reassignments this week (from audit_log)
    - Recent audit entries (last 10)
    - Total active cases
    - Change log count (last 7 days)
    """
    async with pool.acquire() as conn:
        await _require_admin(conn, x_iip_admin_token)

        # Last upload
        last_upload_row = await conn.fetchrow(
            """SELECT id, filename, upload_date, status, record_count
               FROM uploads
               ORDER BY upload_date DESC LIMIT 1"""
        )

        # Perf / non-perf counts
        perf_row = await conn.fetchrow(
            """SELECT
                 COUNT(*) FILTER (WHERE is_performance_case = TRUE) AS perf_count,
                 COUNT(*) FILTER (WHERE is_active = TRUE)           AS active_count
               FROM cases"""
        )
        nonperf_row = await conn.fetchrow(
            """SELECT COUNT(*) AS non_perf_count
               FROM cases c
               JOIN team_members tm ON LOWER(tm.name) = LOWER(c.owner_name)
               WHERE c.is_performance_case = FALSE
                 AND c.customer_number LIKE $1 || '%'""",
            PERF_CUSTOMER_PREFIX,
        )

        # Reassignments this week (audit_log action = 'reassign')
        reassign_row = await conn.fetchrow(
            """SELECT COUNT(*) AS count
               FROM audit_log
               WHERE action = 'reassign'
                 AND change_date >= NOW() - INTERVAL '7 days'"""
        )

        # Change log last 7 days
        changes_row = await conn.fetchrow(
            """SELECT COUNT(*) AS count
               FROM audit_log
               WHERE change_date >= NOW() - INTERVAL '7 days'"""
        )

        # Recent activity feed (last 10 entries)
        activity_rows = await conn.fetch(
            """SELECT id, action, entity_type, entity_id,
                      old_value, new_value, admin_user, change_date, notes
               FROM audit_log
               ORDER BY change_date DESC
               LIMIT 10"""
        )

        # Upload history (last 5)
        upload_rows = await conn.fetch(
            """SELECT id, filename, upload_date, status, record_count, error_message
               FROM uploads
               ORDER BY upload_date DESC LIMIT 5"""
        )

    last_upload = dict(last_upload_row) if last_upload_row else None
    if last_upload and last_upload.get("upload_date"):
        last_upload["upload_date"] = last_upload["upload_date"].isoformat()

    return {
        "last_upload": last_upload,
        "perf_count":       perf_row["perf_count"]     if perf_row else 0,
        "non_perf_count":   nonperf_row["non_perf_count"] if nonperf_row else 0,
        "active_cases":     perf_row["active_count"]   if perf_row else 0,
        "reassigns_week":   reassign_row["count"]      if reassign_row else 0,
        "changes_7d":       changes_row["count"]       if changes_row else 0,
        "recent_activity": [
            {
                **dict(r),
                "change_date": r["change_date"].isoformat() if r["change_date"] else None,
            }
            for r in activity_rows
        ],
        "recent_uploads": [
            {
                **dict(r),
                "upload_date": r["upload_date"].isoformat() if r["upload_date"] else None,
            }
            for r in upload_rows
        ],
    }

# ═══════════════════════════════════════════════════════════════════════════════
# ALL-CASES EXPORT
# ═══════════════════════════════════════════════════════════════════════════════

@router.get("/weekly-tracker", summary="All weekly closed cases grouped by year/week for frontend tracker")
async def get_weekly_tracker_data(pool: asyncpg.Pool = Depends(get_pool)):
    """
    Returns every row in weekly_closed_cases joined with cases, grouped as:
      { "2025": { "CW01": [row, ...], ... }, "2026": { ... } }
    This replaces the inline _WT_SEED blob and localStorage reads in the frontend.
    """
    cached = _cache_get("weekly_tracker_data")
    if cached is not None:
        return cached
    import re as _re2  # Fix E4: import once, not per-row
    async with pool.acquire() as conn:
        rows = await conn.fetch(
            """
            -- Fix C1: CTE replaces 2 correlated subqueries per row
            WITH last_closed AS (
                SELECT DISTINCT ON (case_number)
                    case_number,
                    status      AS last_closed_status,
                    closed_date AS last_closed_date
                FROM case_status_history
                WHERE status IN ('Closed by IBM','Closed by Client','Closed - Archived')
                ORDER BY case_number, upload_id DESC
            )
            SELECT
                w.year,
                w.week_number,
                w.week_label,
                w.case_number      AS case_number,
                COALESCE(w.owner, c.owner_name, '')          AS owner,
                COALESCE(NULLIF(tm.display_name, ''), w.owner, c.owner_name, '') AS display_name,
                COALESCE(c.title, '')                         AS title,
                COALESCE(c.customer_number, '')               AS customer_number,
                COALESCE(c.product, '')                       AS product,
                COALESCE(c.severity, '')                      AS severity,
                COALESCE(c.status, '')                        AS status,
                COALESCE(c.age_days::text, '')                AS age,
                COALESCE(c.closed_date::text, '')             AS closed_date,
                COALESCE(lc.last_closed_status, c.status, '') AS last_closed_status,
                COALESCE(lc.last_closed_date::text, c.closed_date::text, '') AS last_closed_date,
                COALESCE(w.comments, '')                      AS comments,
                COALESCE(w.category, '')                      AS category,
                COALESCE(w.availability, '')                  AS availability,
                COALESCE(c.created_date::text, '')            AS created,
                COALESCE(c.solution_date::text, '')           AS solution_date,
                w.is_reopened,
                w.is_duplicate,
                w.original_case_number,
                w.week_start_date,
                w.week_end_date,
                r.week_labels          AS reopen_week_labels,
                r.week_years           AS reopen_week_years,
                r.reopened_upload_date AS reopened_upload_date
            FROM weekly_closed_cases w
            LEFT JOIN cases c ON w.case_number = c.case_number
            LEFT JOIN mv_reopened_cases r ON r.case_number = w.case_number
            LEFT JOIN team_members tm ON (
                LOWER(COALESCE(w.owner, c.owner_name, '')) = LOWER(tm.name)
            )
            LEFT JOIN last_closed lc ON lc.case_number = w.case_number
            ORDER BY w.year, w.week_number, w.case_number
            """
        )

    # Group into { "year": { "CWNN": [rows] } }
    result: dict = {}
    for r in rows:
        yr  = str(r["year"])
        wk  = r["week_label"] or f"CW{r['week_number']:02d}"
        # Compute later_week for grayout badge
        _labels = list(r["reopen_week_labels"] or [])  # Fix E4: re imported at function scope
        _years  = list(r["reopen_week_years"]  or [])
        _later_week = None
        _later_year = None
        if r["is_reopened"] and _labels:
            for _i, _lbl in enumerate(_labels):
                _m = _re2.search(r"\d+", _lbl)
                _lbl_num = int(_m.group()) if _m else 0
                _lbl_yr  = _years[_i] if _i < len(_years) else yr
                if (_lbl_yr > int(yr)) or (_lbl_yr == int(yr) and _lbl_num > r["week_number"]):
                    _later_week = _lbl
                    _later_year = _lbl_yr
                    break
        row = {
            "id":             f"{r['case_number']}_{wk}",
            "caseNumber":     r["case_number"],
            "owner":          r["display_name"] or r["owner"],
            "title":          r["title"],
            "customerNumber": r["customer_number"],
            "product":        r["product"],
            "severity":       r["severity"],
            "status":         r["status"],
            "age":            r["age"],
            "closedDate":     r["closed_date"],
            "comments":       r["comments"],
            "category":       r["category"],
            "availability":   r["availability"],
            "created":        r["created"],
            "solutionDate":   r["solution_date"],
            "isReopened":        r["is_reopened"],
            "lastClosedStatus":  r["last_closed_status"],
            "lastClosedDate":    r["last_closed_date"],
            "weekStartDate":     str(r["week_start_date"]) if r["week_start_date"] else None,
            "weekEndDate":       str(r["week_end_date"])   if r["week_end_date"]   else None,
            "reopenedUploadDate": str(r["reopened_upload_date"]) if r["reopened_upload_date"] else None,
            "isDuplicate":       r["is_duplicate"],
            "originalCaseNumber": r["original_case_number"],
            "laterWeek":      _later_week,
            "laterYear":      _later_year,
        }
        result.setdefault(yr, {}).setdefault(wk, []).append(row)

    _cache_set("weekly_tracker_data", result, 60.0)
    return result

class _WTUpdateCase(BaseModel):
    comments: str = ""
    category: str = ""
    availability: str = ""

@router.patch("/weekly/{year}/{week}/{case_number}", summary="Sync comment+category and run duplicate detection")
async def update_weekly_case(
    year: int, week: str, case_number: str,
    body: _WTUpdateCase,
    pool: asyncpg.Pool = Depends(get_pool),
):
    import re as _re
    _TS_RE   = _re.compile(r'TS0\d{6,}', _re.IGNORECASE)
    _IDEA_URL_RE = _re.compile(r'https?://[^\s]*ideas\.aha\.io[^\s]*', _re.IGNORECASE)
    _IDEA_REF_RE = _re.compile(r'\b([A-Z]+-I-\d+)\b')
    comments     = (body.comments or "").strip()  # Fix D3: typed Pydantic model
    category     = (body.category or "").strip()
    availability = (body.availability or "").strip()

    async with pool.acquire() as conn:
        # Fix C6: Single UPDATE instead of two separate round-trips
        is_dup = category.lower() == "duplicate" and bool(_TS_RE.search(comments))
        orig_cn = None
        if is_dup:
            m = _TS_RE.search(comments)
            orig_cn = m.group(0).upper() if m else None
        await conn.execute(
            """UPDATE weekly_closed_cases
               SET comments = $1, category = $2, availability = $3,
                   is_duplicate = $4, original_case_number = $5
               WHERE case_number = $6 AND week_label = $7 AND year = $8""",
            comments, category, availability, is_dup, orig_cn,
            case_number, week, year,
        )
        if is_dup and orig_cn:
            await conn.execute(
                """INSERT INTO duplicate_references
                     (duplicate_case_number, original_case_number, detected_in_week, detected_by, reason)
                   VALUES ($1, $2, $3, 'ui', 'category=Duplicate + TS0* in comments')
                   ON CONFLICT (duplicate_case_number, original_case_number) DO NOTHING""",
                case_number, orig_cn, week,
            )
        # Auto-link idea_case_links when comment contains idea ref or Aha! URL
        idea_ref = None
        url_m = _IDEA_URL_RE.search(comments)
        ref_m = _IDEA_REF_RE.search(comments)
        if ref_m:
            idea_ref = ref_m.group(1).upper()
        elif url_m:
            rm = _re.search(r'/([A-Z]+-I-\d+)', url_m.group(0), _re.IGNORECASE)
            idea_ref = rm.group(1).upper() if rm else None
        if idea_ref:
            # Check idea exists in ibm_ideas
            exists = await conn.fetchval(
                "SELECT 1 FROM ibm_ideas WHERE idea_reference = $1", idea_ref
            )
            if exists:
                src = url_m.group(0) if url_m else f"comment ref: {idea_ref}"
                await conn.execute(
                    """INSERT INTO idea_case_links
                         (idea_reference, case_number, source, linked_by)
                       VALUES ($1, $2, $3, 'system')
                       ON CONFLICT (idea_reference, case_number) DO NOTHING""",
                    idea_ref, case_number, src,
                )
        # Remove idea_case_links if comment no longer has any idea ref
        if not idea_ref:
            await conn.execute(
                """DELETE FROM idea_case_links
                   WHERE case_number = $1 AND linked_by = 'system'
                   AND source LIKE 'comment ref:%'""",
                case_number,
            )
        # Re-sync is_reopened for this case against the view (single-case, fast)
        await conn.execute("""
            UPDATE weekly_closed_cases wcc
            SET is_reopened = TRUE
            WHERE wcc.case_number = $1
              AND EXISTS (SELECT 1 FROM mv_reopened_cases v WHERE v.case_number = $1)
        """, case_number)
    return {"status": "ok", "is_duplicate": is_dup, "original_case_number": orig_cn}

@router.get("/wt-categories", summary="Get weekly tracker categories from DB")
async def get_wt_categories(pool: asyncpg.Pool = Depends(get_pool)):
    cached = _cache_get("wt_categories")
    if cached is not None:
        return cached
    async with pool.acquire() as conn:
        row = await conn.fetchrow("SELECT value FROM app_settings WHERE key = 'wt_categories'")
    if row:
        import json as _json
        result = _json.loads(row["value"])
        _cache_set("wt_categories", result, 120.0)
        return result
    # Return default list if not yet seeded
    default = [
        {"name": "Issue Fixed in iFix",              "color": "var(--green)"},
        {"name": "LQE Validation / Reindexing",      "color": "var(--ibm-blue-60)"},
        {"name": "Export / Import Issues",           "color": "var(--yellow-text)"},
        {"name": "Known Defect",                     "color": "var(--red)"},
        {"name": "Out of Memory / Heap Issues",      "color": "#c00"},
        {"name": "TRS Feed Validation",              "color": "var(--ibm-blue-50)"},
        {"name": "Insufficient Information in Logs", "color": "#555"},
        {"name": "Single Occurrence Issue",          "color": "var(--purple)"},
        {"name": "DCM Connectivity Issues",          "color": "var(--orange)"},
        {"name": "Database Connectivity Issues",     "color": "var(--orange)"},
        {"name": "Backup & Restore",                 "color": "var(--red)"},
        {"name": "Duplicate",                        "color": "var(--red)"},
        {"name": "Reopened",                         "color": "var(--purple)"},
    ]
    _cache_set("wt_categories", default, 120.0)
    return default

@router.post("/wt-categories", summary="Save weekly tracker categories to DB (admin)")
async def save_wt_categories(
    body: dict,
    x_iip_admin_token: str = Header(default=""),
    pool: asyncpg.Pool = Depends(get_pool),
):
    async with pool.acquire() as _auth_conn:
        await _require_admin(_auth_conn, x_iip_admin_token)
    import json as _json
    categories = body.get("categories", [])
    value = _json.dumps(categories)
    async with pool.acquire() as conn:
        await conn.execute(
            """INSERT INTO app_settings (key, value, description)
               VALUES ('wt_categories', $1, 'Weekly Tracker category list with colors')
               ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value""",
            value,
        )
    return {"status": "ok", "count": len(categories)}


@router.get("/user-data/rfe-meta", summary="Load RFE tracking metadata (notes, tags, target release)")
async def get_rfe_meta(pool: asyncpg.Pool = Depends(get_pool)):
    async with pool.acquire() as conn:
        rows = await conn.fetch(
            "SELECT idea_reference, notes, tags, target_release FROM rfe_annotations"
        )
    result = {}
    for r in rows:
        result[r["idea_reference"]] = {
            "notes":          r["notes"]          or "",
            "tags":           r["tags"]            or "",
            "target_release": r["target_release"]  or "",
        }
    return result


@router.put("/user-data/rfe-meta", summary="Save RFE tracking metadata (notes, tags, target release)")
async def put_rfe_meta(request: Request, pool: asyncpg.Pool = Depends(get_pool)):
    try:
        import json as _json
        body = await request.json()
    except Exception:
        from fastapi import HTTPException
        raise HTTPException(status_code=400, detail="Invalid JSON")
    # body is { idea_reference: { notes, tags, target_release }, ... }
    async with pool.acquire() as conn:
        async with conn.transaction():
            for idea_ref, ann in body.items():
                if not isinstance(ann, dict):
                    continue
                await conn.execute("""
                    INSERT INTO rfe_annotations (idea_reference, notes, tags, target_release, updated_at)
                    VALUES ($1, $2, $3, $4, NOW())
                    ON CONFLICT (idea_reference) DO UPDATE
                      SET notes          = EXCLUDED.notes,
                          tags           = EXCLUDED.tags,
                          target_release = EXCLUDED.target_release,
                          updated_at     = NOW()
                """,
                    idea_ref,
                    str(ann.get("notes", "")),
                    str(ann.get("tags", "")),
                    str(ann.get("target_release", "")),
                )
    return {"status": "ok"}


@router.get("/user-data/tracker-meta", summary="Load performance tracker meta — built live from cases table (single source of truth)")
async def get_tracker_meta(pool: asyncpg.Pool = Depends(get_pool)):
    _cached_tm = _cache_get("tracker_meta")
    if _cached_tm is not None:
        return _cached_tm
    """
    Returns:
      - meta: per-case perf classification built live from the cases table (authoritative)
      - history/caseDetailLogs/ownerOverrides/reassignLog: UI-only state from tracker_ui_state
        (falls back to tracker_persist_meta for migration compatibility)
    """
    async with pool.acquire() as conn:
        # 1. Build perf meta from cases table (authoritative source of truth)
        rows = await conn.fetch(
            """
            SELECT
                c.case_number,
                c.is_performance_case,
                c.work_item,
                c.perf_type,
                c.availability
            FROM cases c
            JOIN team_members tm ON LOWER(tm.name) = LOWER(c.owner_name)
            WHERE c.is_performance_case = TRUE
               OR c.customer_number LIKE $1 || '%'
            ORDER BY c.case_number
            """,
            PERF_CUSTOMER_PREFIX,
        )
        meta = {}
        for r in rows:
            cn = r["case_number"]
            meta[cn] = {
                "category":    "performance" if r["is_performance_case"] else "non-performance",
                "workItem":    r["work_item"]    or "",
                "perf_type":   r["perf_type"]    or "",
                "availability": r["availability"] or "",
            }

        # 2. Load UI-only state — prefer tracker_ui_state, fall back to tracker_persist_meta
        ui_row = await conn.fetchrow(
            "SELECT value FROM app_settings WHERE key = 'tracker_ui_state'"
        )
        if not ui_row or not ui_row["value"]:
            ui_row = await conn.fetchrow(
                "SELECT value FROM app_settings WHERE key = 'tracker_persist_meta'"
            )

    ui_state = {}
    if ui_row and ui_row["value"]:
        try:
            import json as _json
            raw = _json.loads(ui_row["value"])
            # Only surface UI-only fields — never restore stale perf meta from blob
            ui_state = {
                "history":        raw.get("history", []),
                "caseDetailLogs": raw.get("caseDetailLogs", {}),
                "ownerOverrides": raw.get("ownerOverrides", {}),
                "reassignLog":    raw.get("reassignLog", []),
            }
        except Exception:
            pass

    _tm_result = {"meta": meta, **ui_state}
    _cache_set("tracker_meta", _tm_result, 30.0)
    return _tm_result


@router.put("/user-data/tracker-meta", summary="Save UI-only tracker state (history, logs, overrides) — NOT perf classification")
async def put_tracker_meta(request: Request, pool: asyncpg.Pool = Depends(get_pool)):
    """
    Persists UI-only state for the performance tracker: change history,
    case detail logs, owner overrides, reassign log.
    The `meta` field (perf category per case) is intentionally stripped —
    performance classification is the single responsibility of the cases table
    and is updated exclusively via PATCH /cases/{id}/performance-tag.
    """
    try:
        import json as _json
        body = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON")

    # Strip the perf-classification blob — it belongs in the cases table
    ui_state = {k: v for k, v in body.items() if k != "meta"}
    val = _json.dumps(ui_state, ensure_ascii=False)

    async with pool.acquire() as conn:
        await conn.execute("""
            INSERT INTO app_settings (key, value, description)
            VALUES ('tracker_ui_state', $1, 'Performance tracker UI state — history/logs/overrides only; NOT perf classification')
            ON CONFLICT (key) DO UPDATE SET value = $1, updated_at = NOW()
        """, val)
    return {"status": "ok"}


@router.get("/rfe-data", summary="RFE data from ibm_ideas table for frontend")
async def get_rfe_data(pool: asyncpg.Pool = Depends(get_pool)):
    async with pool.acquire() as conn:
        rows = await conn.fetch(
            """SELECT i.idea_reference, i.idea_name, i.product, i.product_reference,
                      i.product_categories, i.workflow_state, i.is_complete,
                      i.vote_count, i.comment_count, i.tags, i.description,
                      i.visibility, i.url, i.idea_created_at, i.idea_updated_at,
                      COALESCE(
                        array_agg(icl.case_number ORDER BY icl.linked_date)
                        FILTER (WHERE icl.case_number IS NOT NULL), ARRAY[]::text[]
                      ) AS linked_cases
               FROM ibm_ideas i
               LEFT JOIN idea_case_links icl ON icl.idea_reference = i.idea_reference
               GROUP BY i.idea_reference
               ORDER BY i.vote_count DESC NULLS LAST"""
        )
    return [
        {
            "Idea Reference":      r["idea_reference"],
            "Idea Name":           r["idea_name"],
            "Product":             r["product"],
            "Product Reference":   r["product_reference"],
            "Product Categories":  r["product_categories"],
            "Workflow State":      r["workflow_state"],
            "Is Complete":         r["is_complete"],
            "Vote Count":          r["vote_count"],
            "Comment Count":       r["comment_count"],
            "Tags":                r["tags"],
            "Description":         r["description"],
            "Visibility of Idea":  r["visibility"],
            "URL":                 r["url"],
            "Linked Cases":        list(r["linked_cases"]),
            "Created At":          r["idea_created_at"].isoformat() if r["idea_created_at"] else "",
            "Updated At":          r["idea_updated_at"].isoformat() if r["idea_updated_at"] else "",
        }
        for r in rows
    ]



# ─────────────────────────────────────────────────────────────────
# EXCEL WORK ITEMS UPLOAD — Import Work Item + Case Number + N/P
# ─────────────────────────────────────────────────────────────────

@router.get("/elm-upgrades", summary="List ELM upgrade entries (public read)")
async def list_elm_upgrades(pool: asyncpg.Pool = Depends(get_pool)):
    """
    Public (no auth) read of elm_upgrades table.
    Used by the Overview dashboard to populate the post-upgrade case tracking
    dropdown without requiring an admin session token.
    Returns entries ordered newest upgrade_date first.
    """
    async with pool.acquire() as conn:
        rows = await conn.fetch(
            """SELECT id, elm_version, ifix_version,
                      upgrade_date::text AS upgrade_date,
                      notes, created_by,
                      created_at::text  AS created_at
               FROM elm_upgrades
               ORDER BY upgrade_date DESC, id DESC"""
        )
    return [dict(r) for r in rows]


class _GrayoutCombo(BaseModel):
    caseNumber: str
    week: str
    year: int

class _GrayoutBulkRequest(BaseModel):
    combos: list[_GrayoutCombo]


@router.post("/grayout-bulk", summary="Bulk-fetch DB grayout states for a set of (case, week, year) combos")
async def grayout_bulk(
    body: _GrayoutBulkRequest,
    pool: asyncpg.Pool = Depends(get_pool),
):
    if not body.combos:
        return {"states": {}}

    async with pool.acquire() as conn:
        rows = await conn.fetch(
            """
            SELECT case_number, week, year,
                   is_grayed, later_week, later_year, metadata
            FROM   case_grayout_state
            WHERE  (case_number, week, year) = ANY(
                SELECT u.cn, u.wk, u.yr
                FROM   unnest($1::text[], $2::text[], $3::int[]) AS u(cn, wk, yr)
            )
            """,
            [c.caseNumber for c in body.combos],
            [c.week       for c in body.combos],
            [c.year       for c in body.combos],
        )

    states: dict = {}
    for r in rows:
        key = f"{r['case_number']}|{r['week']}|{r['year']}"
        states[key] = {
            "isGrayed":  r["is_grayed"],
            "laterWeek": r["later_week"],
            "laterYear": r["later_year"],
            "metadata":  r["metadata"] or {},
        }

    return {"states": states}


# ─────────────────────────────────────────────────────────────────────────────
# GET /api/grayout/{case_number}/{week}/{year}
# ─────────────────────────────────────────────────────────────────────────────

@router.get("/grayout/{case_number}/{week}/{year}", summary="Fetch DB grayout state for one (case, week, year)")
async def grayout_single(
    case_number: str,
    week: str,
    year: int,
    pool: asyncpg.Pool = Depends(get_pool),
):
    async with pool.acquire() as conn:
        row = await conn.fetchrow(
            """
            SELECT is_grayed, later_week, later_year, metadata
            FROM   case_grayout_state
            WHERE  case_number = $1 AND week = $2 AND year = $3
            """,
            case_number, week, year,
        )

    if row is None:
        return {"isGrayed": False}

    return {
        "isGrayed":  row["is_grayed"],
        "laterWeek": row["later_week"],
        "laterYear": row["later_year"],
        "metadata":  row["metadata"] or {},
    }


# ─────────────────────────────────────────────────────────────────────────────
# POST /api/reopened/sync
# ─────────────────────────────────────────────────────────────────────────────

class _Appearance(BaseModel):
    week: str
    year: int
    closedDate: str = ""
    status: str = ""
    owner: str = ""
    title: str = ""
    severity: str = ""

class _ReopenedCase(BaseModel):
    caseNumber: str
    appearances: list[_Appearance]

class _ReopenedSyncRequest(BaseModel):
    cases: list[_ReopenedCase]


@router.post("/reopened/sync", summary="Sync localStorage-detected cross-week reopened cases to DB")
async def reopened_sync(
    body: _ReopenedSyncRequest,
    pool: asyncpg.Pool = Depends(get_pool),
):
    if not body.cases:
        return {"status": "ok", "upserted": 0}

    upserted = 0
    async with pool.acquire() as conn:
        async with conn.transaction():
            for case in body.cases:
                appearances = sorted(case.appearances, key=lambda a: (a.year, a.week))
                n = len(appearances)

                for i, app in enumerate(appearances):
                    await conn.execute(
                        """
                        INSERT INTO weekly_reopened_sync
                            (case_number, week, year, closed_date, status, owner, title, severity)
                        VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
                        ON CONFLICT (case_number, week, year) DO UPDATE
                            SET closed_date = EXCLUDED.closed_date,
                                status      = EXCLUDED.status,
                                owner       = EXCLUDED.owner,
                                title       = EXCLUDED.title,
                                severity    = EXCLUDED.severity,
                                synced_at   = NOW()
                        """,
                        case.caseNumber, app.week, app.year,
                        app.closedDate, app.status, app.owner, app.title, app.severity,
                    )

                    if i < n - 1:
                        later = appearances[i + 1]
                        await conn.execute(
                            """
                            INSERT INTO case_grayout_state
                                (case_number, week, year, is_grayed, later_week, later_year, metadata)
                            VALUES ($1, $2, $3, TRUE, $4, $5, $6)
                            ON CONFLICT (case_number, week, year) DO UPDATE
                                SET is_grayed  = TRUE,
                                    later_week = EXCLUDED.later_week,
                                    later_year = EXCLUDED.later_year,
                                    metadata   = EXCLUDED.metadata,
                                    updated_at = NOW()
                            """,
                            case.caseNumber, app.week, app.year,
                            later.week, later.year, json.dumps({}),
                        )
                        upserted += 1

    return {"status": "ok", "upserted": upserted}


@router.delete("/weekly/{year}/{week}/{case_number}", summary="Remove a case from a specific tracker week")
async def delete_weekly_case(
    year: int, week: str, case_number: str,
    pool: asyncpg.Pool = Depends(get_pool),
):
    async with pool.acquire() as conn:
        deleted = await conn.fetchval(
            """DELETE FROM weekly_closed_cases
               WHERE case_number = $1 AND week_label = $2 AND year = $3
               RETURNING id""",
            case_number, week, year,
        )
    if deleted is None:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail="Record not found")
    return {"status": "deleted", "id": deleted}


class _WTAddCase(BaseModel):
    owner:           str
    case_number:     str
    title:           str
    product:         str = ""
    severity:        str = ""
    status:          str = "Closed by IBM"
    age:             str = ""
    closed_date:     str = ""
    category:        str = ""
    comments:        str = ""
    customer_number: str = ""


@router.post("/weekly/{year}/{week}", summary="Add a case to a tracker week")
async def add_weekly_case(
    year: int, week: str,
    body: _WTAddCase,
    pool: asyncpg.Pool = Depends(get_pool),
):
    import re as _re
    if not _re.match(r'^CW\d{1,2}$', week, _re.IGNORECASE):
        raise HTTPException(400, "week must be CW01…CW53")
    week = week.upper()
    m = _re.search(r'\d+', week)
    wk_num = int(m.group()) if m else 0

    async with pool.acquire() as conn:
        # Ensure case exists (upsert minimal row so FK is satisfied)
        await conn.execute("""
            INSERT INTO cases (case_number, title, owner_name, product, severity,
                               status, customer_number, is_team_case, is_active)
            VALUES ($1,$2,$3,$4,$5,$6,$7,TRUE,TRUE)
            ON CONFLICT (case_number) DO UPDATE SET
                title      = EXCLUDED.title,
                owner_name = EXCLUDED.owner_name,
                updated_at = NOW()
        """, body.case_number, body.title, body.owner,
             body.product, body.severity, body.status, body.customer_number)

        existing = await conn.fetchval(
            "SELECT id FROM weekly_closed_cases WHERE case_number=$1 AND week_number=$2 AND year=$3",
            body.case_number, wk_num, year
        )
        if existing:
            raise HTTPException(409, f"Case {body.case_number} already exists in {week} {year}")

        closed_dt = None
        if body.closed_date:
            try:
                from datetime import date as _d
                closed_dt = _d.fromisoformat(body.closed_date)
            except Exception:
                pass

        await conn.execute("""
            INSERT INTO weekly_closed_cases
              (case_number, year, week_number, week_label, owner,
               comments, category, availability)
            VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
        """, body.case_number, year, wk_num, week,
             body.owner, body.comments, body.category, "")

    return {"status": "ok", "case_number": body.case_number, "week": week, "year": year}


# ── WT Case History ──────────────────────────────────────────────────────────

class _WTHistoryEntry(BaseModel):
    case_number:    str
    owner:          str  = ""
    week:           str
    year:           int
    status_before:  str  = ""
    status_after:   str  = ""
    comment_before: str  = ""
    comment_after:  str  = ""
    availability:   str  = ""
    is_reopen:      bool = False
    prev_week:      str  = ""
    changed_by:     str  = "user"
    seed_id:        str  = ""


@router.get("/wt-history", summary="Load weekly tracker case history from DB")
async def get_wt_history(pool: asyncpg.Pool = Depends(get_pool)):
    cached = _cache_get("wt_history")
    if cached is not None:
        return cached
    async with pool.acquire() as conn:
        rows = await conn.fetch("""
            SELECT id, case_number, owner, week, year,
                   status_before, status_after, comment_before, comment_after,
                   availability, is_reopen, prev_week, changed_by, seed_id,
                   created_at
            FROM wt_case_history
            ORDER BY created_at DESC
            LIMIT 5000
        """)
    grouped: dict = {}
    for r in rows:
        cn = r["case_number"]
        if cn not in grouped:
            grouped[cn] = {"caseNumber": cn, "owner": r["owner"] or "", "entries": []}
        grouped[cn]["owner"] = r["owner"] or grouped[cn]["owner"]
        grouped[cn]["entries"].append({
            "_dbId":         r["id"],
            "ts":            r["created_at"].isoformat(),
            "week":          r["week"],
            "year":          r["year"],
            "statusBefore":  r["status_before"] or "",
            "statusAfter":   r["status_after"] or "",
            "commentBefore": r["comment_before"] or "",
            "commentAfter":  r["comment_after"] or "",
            "availability":  r["availability"] or "",
            "isReopen":      r["is_reopen"],
            "prevWeek":      r["prev_week"] or "",
            "changedBy":     r["changed_by"] or "user",
            "_seedId":       r["seed_id"] or "",
        })
    _cache_set("wt_history", grouped, 30.0)
    return grouped


@router.post("/wt-history", summary="Save a weekly tracker history entry to DB")
async def add_wt_history(body: _WTHistoryEntry, pool: asyncpg.Pool = Depends(get_pool)):
    async with pool.acquire() as conn:
        if body.seed_id:
            exists = await conn.fetchval(
                "SELECT 1 FROM wt_case_history WHERE seed_id=$1", body.seed_id
            )
            if exists:
                return {"status": "skipped", "reason": "duplicate seed_id"}
        await conn.execute("""
            INSERT INTO wt_case_history
              (case_number, owner, week, year, status_before, status_after,
               comment_before, comment_after, availability, is_reopen,
               prev_week, changed_by, seed_id)
            VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)
        """,
            body.case_number, body.owner, body.week, body.year,
            body.status_before, body.status_after,
            body.comment_before, body.comment_after,
            body.availability, body.is_reopen,
            body.prev_week, body.changed_by,
            body.seed_id or None,
        )
    return {"status": "ok"}


@router.delete("/wt-history/{entry_id}", summary="Delete a single history entry")
async def delete_wt_history_entry(entry_id: int, pool: asyncpg.Pool = Depends(get_pool)):
    async with pool.acquire() as conn:
        deleted = await conn.fetchval(
            "DELETE FROM wt_case_history WHERE id=$1 RETURNING id", entry_id
        )
    if not deleted:
        raise HTTPException(404, "Entry not found")
    return {"status": "deleted"}


@router.delete("/wt-history", summary="Delete ALL history (admin)")
async def delete_all_wt_history(
    x_iip_admin_token: str = Header(default=""),
    pool: asyncpg.Pool = Depends(get_pool),
):
    async with pool.acquire() as conn:
        await _require_admin(conn, x_iip_admin_token)
        count = await conn.fetchval("SELECT COUNT(*) FROM wt_case_history")
        await conn.execute("DELETE FROM wt_case_history")
    return {"status": "deleted", "count": count}


# ── Comments bulk fetch — single source of truth for frontend ────────────────

@router.get("/wt-comments", summary="All weekly tracker comments from DB (case→comment)")
async def get_wt_comments(pool: asyncpg.Pool = Depends(get_pool)):
    """Most recent comment per case from weekly_closed_cases."""
    async with pool.acquire() as conn:
        rows = await conn.fetch("""
            SELECT DISTINCT ON (case_number) case_number, comments
            FROM weekly_closed_cases
            WHERE comments IS NOT NULL AND comments <> ''
            ORDER BY case_number, year DESC, week_number DESC
        """)
    return {r["case_number"]: r["comments"] for r in rows}
