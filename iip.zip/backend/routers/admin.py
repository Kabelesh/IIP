"""
routers/admin.py — Production-grade Admin API
Provides protected CRUD endpoints for all admin-configurable data.
All endpoints require X-IIP-Admin-Token header.
All writes are audit-logged.
"""
import json
import time
from typing import List, Optional, Dict, Any
from datetime import datetime, date
from fastapi import APIRouter, Header, HTTPException, Response
from pydantic import BaseModel
import asyncpg

from ..database import get_pool
from ..auth import is_valid_session

router = APIRouter(prefix="/api/admin")

_broadcast = None

def set_broadcast(fn):
    global _broadcast
    _broadcast = fn


# ──────────────────────────────────────────────────────────────────
# PYDANTIC MODELS — Type safety for all responses
# ──────────────────────────────────────────────────────────────────

class TeamMember(BaseModel):
    id: Optional[int] = None
    name: str
    email: Optional[str] = None
    team: Optional[str] = None
    status: Optional[str] = "Active"
    display_name: Optional[str] = None

class TeamMemberUpdate(BaseModel):
    name: str
    email: Optional[str] = None
    team: Optional[str] = None
    status: Optional[str] = "Active"
    display_name: Optional[str] = None

class EscalationContact(BaseModel):
    id: Optional[int] = None
    group_name: Optional[str] = None
    name: str
    email: Optional[str] = None

class EscalationContactUpdate(BaseModel):
    group_name: Optional[str] = None
    name: str
    email: Optional[str] = None

class IBMContact(BaseModel):
    id: Optional[int] = None
    group_name: Optional[str] = None
    name: str
    email: Optional[str] = None

class IBMContactUpdate(BaseModel):
    group_name: Optional[str] = None
    name: str
    email: Optional[str] = None

class ALMLine(BaseModel):
    alm_line: str
    customer_contact: Optional[str] = None
    customer_email: Optional[str] = None
    line_manager: Optional[str] = None
    line_manager_email: Optional[str] = None
    case_responsible: Optional[str] = None
    case_responsible_email: Optional[str] = None
    case_responsible_proxy: Optional[str] = None
    case_responsible_proxy_email: Optional[str] = None

class ALMLineUpdate(BaseModel):
    customer_contact: Optional[str] = None
    customer_email: Optional[str] = None
    line_manager: Optional[str] = None
    line_manager_email: Optional[str] = None
    case_responsible: Optional[str] = None
    case_responsible_email: Optional[str] = None
    case_responsible_proxy: Optional[str] = None
    case_responsible_proxy_email: Optional[str] = None

class BootstrapData(BaseModel):
    team_members: List[TeamMember]
    escalation_contacts: List[EscalationContact]
    ibm_contacts: List[IBMContact]
    alm_lines: List[ALMLine]
    timestamp: str


# ──────────────────────────────────────────────────────────────────
# AUTH HELPER
# ──────────────────────────────────────────────────────────────────

async def _require_admin(conn, token: str) -> str:
    """Validate admin token and return admin username (or raise 403)."""
    if not await is_valid_session(conn, token):
        raise HTTPException(status_code=403, detail="Forbidden: invalid or expired session token.")
    return "admin"


async def _audit_log(
    conn,
    admin_user: str,
    action: str,
    resource_type: str,
    resource_id: Optional[str] = None,
    old_value: Optional[Dict] = None,
    new_value: Optional[Dict] = None,
):
    """Log admin action to audit_log table."""
    try:
        await conn.execute(
            """INSERT INTO audit_log 
               (admin_user, action, entity_type, entity_id, old_value, new_value)
               VALUES ($1, $2, $3, $4, $5, $6)""",
            admin_user,
            action,
            resource_type,
            resource_id,
            json.dumps(old_value) if old_value else None,
            json.dumps(new_value) if new_value else None,
        )
    except Exception as e:
        print(f"Audit log error: {e}")


async def _broadcast_admin_update(resource_type: str, action: str, data: Dict):
    """Send SSE broadcast for admin changes."""
    if _broadcast:
        payload = {
            "resource_type": resource_type,
            "action": action,
            "data": data,
            "timestamp": int(time.time() * 1000)
        }
        await _broadcast("admin-updated", payload)
        # Also broadcast config-updated so main dashboards refresh
        await _broadcast("config-updated", payload)


# ──────────────────────────────────────────────────────────────────
# BOOTSTRAP — Load all admin data in one call
# ──────────────────────────────────────────────────────────────────

@router.get("/bootstrap", response_model=BootstrapData)
async def bootstrap(
    x_iip_admin_token: str = Header(default=""),
    response: Response = None,
):
    """Load all admin dashboard data in one call (after login)."""
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate, max-age=0"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "0"

    pool = await get_pool()
    async with pool.acquire() as conn:
        admin_user = await _require_admin(conn, x_iip_admin_token)
        
        # Fetch all data
        team_rows = await conn.fetch(
            "SELECT id, name, email, team, status, display_name FROM team_members ORDER BY name"
        )
        escalation_rows = await conn.fetch(
            "SELECT id, group_name, name, email FROM escalation_contacts ORDER BY group_name, name"
        )
        ibm_rows = await conn.fetch(
            "SELECT id, group_name, name, email FROM ibm_contacts ORDER BY group_name, name"
        )
        alm_rows = await conn.fetch(
            "SELECT alm_line, customer_contact, customer_email, line_manager, line_manager_email, case_responsible, case_responsible_email, case_responsible_proxy, case_responsible_proxy_email FROM alm_lines ORDER BY alm_line"
        )
    
    return BootstrapData(
        team_members=[TeamMember(**dict(r)) for r in team_rows],
        escalation_contacts=[EscalationContact(**dict(r)) for r in escalation_rows],
        ibm_contacts=[IBMContact(**dict(r)) for r in ibm_rows],
        alm_lines=[ALMLine(**dict(r)) for r in alm_rows],
        timestamp=datetime.utcnow().isoformat() + "Z"
    )


# ──────────────────────────────────────────────────────────────────
# TEAM MEMBERS
# ──────────────────────────────────────────────────────────────────

@router.get("/team-members", response_model=List[TeamMember])
async def list_team_members(
    response: Response = None,
):
    """List all team members (read-only, no auth required)."""
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate, max-age=0"
    pool = await get_pool()
    async with pool.acquire() as conn:
        rows = await conn.fetch(
            "SELECT id, name, email, team, status, display_name FROM team_members ORDER BY name"
        )
    return [TeamMember(**dict(r)) for r in rows]


@router.post("/team-members", response_model=TeamMember)
async def create_team_member(
    body: TeamMemberUpdate,
    x_iip_admin_token: str = Header(default=""),
):
    """Create a new team member."""
    pool = await get_pool()
    async with pool.acquire() as conn:
        admin_user = await _require_admin(conn, x_iip_admin_token)
        
        try:
            row = await conn.fetchrow(
                """INSERT INTO team_members (name, email, team, status, display_name)
                   VALUES ($1, $2, $3, $4, $5)
                   RETURNING id, name, email, team, status, display_name""",
                body.name, body.email, body.team, body.status, body.display_name
            )
        except asyncpg.UniqueViolationError:
            raise HTTPException(status_code=409, detail=f"Team member '{body.name}' already exists")
        
        await _audit_log(conn, admin_user, "CREATE", "team_member", str(row["id"]), None, dict(row))
    
    await _broadcast_admin_update("team_member", "created", dict(row))
    return TeamMember(**dict(row))


@router.put("/team-members/{member_id}", response_model=TeamMember)
async def update_team_member(
    member_id: int,
    body: TeamMemberUpdate,
    x_iip_admin_token: str = Header(default=""),
):
    """Update a team member."""
    pool = await get_pool()
    async with pool.acquire() as conn:
        admin_user = await _require_admin(conn, x_iip_admin_token)
        
        old_row = await conn.fetchrow(
            "SELECT id, name, email, team, status, display_name FROM team_members WHERE id = $1",
            member_id
        )
        if not old_row:
            raise HTTPException(status_code=404, detail="Team member not found")
        
        row = await conn.fetchrow(
            """UPDATE team_members 
               SET name = $2, email = $3, team = $4, status = $5, display_name = $6
               WHERE id = $1
               RETURNING id, name, email, team, status, display_name""",
            member_id, body.name, body.email, body.team, body.status, body.display_name
        )
        
        await _audit_log(conn, admin_user, "UPDATE", "team_member", str(member_id), dict(old_row), dict(row))
    
    await _broadcast_admin_update("team_member", "updated", dict(row))
    return TeamMember(**dict(row))


@router.delete("/team-members/{member_id}")
async def delete_team_member(
    member_id: int,
    x_iip_admin_token: str = Header(default=""),
):
    """Delete a team member."""
    pool = await get_pool()
    async with pool.acquire() as conn:
        admin_user = await _require_admin(conn, x_iip_admin_token)
        
        old_row = await conn.fetchrow(
            "SELECT id, name, email, team, status, display_name FROM team_members WHERE id = $1",
            member_id
        )
        if not old_row:
            raise HTTPException(status_code=404, detail="Team member not found")
        
        await conn.execute("DELETE FROM team_members WHERE id = $1", member_id)
        await _audit_log(conn, admin_user, "DELETE", "team_member", str(member_id), dict(old_row), None)
    
    await _broadcast_admin_update("team_member", "deleted", {"id": member_id})
    return {"ok": True, "deleted": member_id}


# ──────────────────────────────────────────────────────────────────
# ESCALATION CONTACTS
# ──────────────────────────────────────────────────────────────────

@router.get("/escalation-contacts", response_model=List[EscalationContact])
async def list_escalation_contacts(
    x_iip_admin_token: str = Header(default=""),
    response: Response = None,
):
    """List all escalation contacts."""
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate, max-age=0"
    pool = await get_pool()
    async with pool.acquire() as conn:
        await _require_admin(conn, x_iip_admin_token)
        rows = await conn.fetch(
            "SELECT id, group_name, name, email FROM escalation_contacts ORDER BY group_name, name"
        )
    return [EscalationContact(**dict(r)) for r in rows]


@router.post("/escalation-contacts", response_model=EscalationContact)
async def create_escalation_contact(
    body: EscalationContactUpdate,
    x_iip_admin_token: str = Header(default=""),
):
    """Create a new escalation contact."""
    pool = await get_pool()
    async with pool.acquire() as conn:
        admin_user = await _require_admin(conn, x_iip_admin_token)
        
        row = await conn.fetchrow(
            """INSERT INTO escalation_contacts (group_name, name, email)
               VALUES ($1, $2, $3)
               RETURNING id, group_name, name, email""",
            body.group_name, body.name, body.email
        )
        
        await _audit_log(conn, admin_user, "CREATE", "escalation_contact", str(row["id"]), None, dict(row))
    
    await _broadcast_admin_update("escalation_contact", "created", dict(row))
    return EscalationContact(**dict(row))


@router.put("/escalation-contacts/{contact_id}", response_model=EscalationContact)
async def update_escalation_contact(
    contact_id: int,
    body: EscalationContactUpdate,
    x_iip_admin_token: str = Header(default=""),
):
    """Update an escalation contact."""
    pool = await get_pool()
    async with pool.acquire() as conn:
        admin_user = await _require_admin(conn, x_iip_admin_token)
        
        old_row = await conn.fetchrow(
            "SELECT id, group_name, name, email FROM escalation_contacts WHERE id = $1",
            contact_id
        )
        if not old_row:
            raise HTTPException(status_code=404, detail="Escalation contact not found")
        
        row = await conn.fetchrow(
            """UPDATE escalation_contacts 
               SET group_name = $2, name = $3, email = $4
               WHERE id = $1
               RETURNING id, group_name, name, email""",
            contact_id, body.group_name, body.name, body.email
        )
        
        await _audit_log(conn, admin_user, "UPDATE", "escalation_contact", str(contact_id), dict(old_row), dict(row))
    
    await _broadcast_admin_update("escalation_contact", "updated", dict(row))
    return EscalationContact(**dict(row))


@router.delete("/escalation-contacts/{contact_id}")
async def delete_escalation_contact(
    contact_id: int,
    x_iip_admin_token: str = Header(default=""),
):
    """Delete an escalation contact."""
    pool = await get_pool()
    async with pool.acquire() as conn:
        admin_user = await _require_admin(conn, x_iip_admin_token)
        
        old_row = await conn.fetchrow(
            "SELECT id, group_name, name, email FROM escalation_contacts WHERE id = $1",
            contact_id
        )
        if not old_row:
            raise HTTPException(status_code=404, detail="Escalation contact not found")
        
        await conn.execute("DELETE FROM escalation_contacts WHERE id = $1", contact_id)
        await _audit_log(conn, admin_user, "DELETE", "escalation_contact", str(contact_id), dict(old_row), None)
    
    await _broadcast_admin_update("escalation_contact", "deleted", {"id": contact_id})
    return {"ok": True, "deleted": contact_id}


# ──────────────────────────────────────────────────────────────────
# IBM CONTACTS
# ──────────────────────────────────────────────────────────────────

@router.get("/ibm-contacts", response_model=List[IBMContact])
async def list_ibm_contacts(
    x_iip_admin_token: str = Header(default=""),
    response: Response = None,
):
    """List all IBM contacts."""
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate, max-age=0"
    pool = await get_pool()
    async with pool.acquire() as conn:
        await _require_admin(conn, x_iip_admin_token)
        rows = await conn.fetch(
            "SELECT id, group_name, name, email FROM ibm_contacts ORDER BY group_name, name"
        )
    return [IBMContact(**dict(r)) for r in rows]


@router.post("/ibm-contacts", response_model=IBMContact)
async def create_ibm_contact(
    body: IBMContactUpdate,
    x_iip_admin_token: str = Header(default=""),
):
    """Create a new IBM contact."""
    pool = await get_pool()
    async with pool.acquire() as conn:
        admin_user = await _require_admin(conn, x_iip_admin_token)
        
        row = await conn.fetchrow(
            """INSERT INTO ibm_contacts (group_name, name, email)
               VALUES ($1, $2, $3)
               RETURNING id, group_name, name, email""",
            body.group_name, body.name, body.email
        )
        
        await _audit_log(conn, admin_user, "CREATE", "ibm_contact", str(row["id"]), None, dict(row))
    
    await _broadcast_admin_update("ibm_contact", "created", dict(row))
    return IBMContact(**dict(row))


@router.put("/ibm-contacts/{contact_id}", response_model=IBMContact)
async def update_ibm_contact(
    contact_id: int,
    body: IBMContactUpdate,
    x_iip_admin_token: str = Header(default=""),
):
    """Update an IBM contact."""
    pool = await get_pool()
    async with pool.acquire() as conn:
        admin_user = await _require_admin(conn, x_iip_admin_token)
        
        old_row = await conn.fetchrow(
            "SELECT id, group_name, name, email FROM ibm_contacts WHERE id = $1",
            contact_id
        )
        if not old_row:
            raise HTTPException(status_code=404, detail="IBM contact not found")
        
        row = await conn.fetchrow(
            """UPDATE ibm_contacts 
               SET group_name = $2, name = $3, email = $4
               WHERE id = $1
               RETURNING id, group_name, name, email""",
            contact_id, body.group_name, body.name, body.email
        )
        
        await _audit_log(conn, admin_user, "UPDATE", "ibm_contact", str(contact_id), dict(old_row), dict(row))
    
    await _broadcast_admin_update("ibm_contact", "updated", dict(row))
    return IBMContact(**dict(row))


@router.delete("/ibm-contacts/{contact_id}")
async def delete_ibm_contact(
    contact_id: int,
    x_iip_admin_token: str = Header(default=""),
):
    """Delete an IBM contact."""
    pool = await get_pool()
    async with pool.acquire() as conn:
        admin_user = await _require_admin(conn, x_iip_admin_token)
        
        old_row = await conn.fetchrow(
            "SELECT id, group_name, name, email FROM ibm_contacts WHERE id = $1",
            contact_id
        )
        if not old_row:
            raise HTTPException(status_code=404, detail="IBM contact not found")
        
        await conn.execute("DELETE FROM ibm_contacts WHERE id = $1", contact_id)
        await _audit_log(conn, admin_user, "DELETE", "ibm_contact", str(contact_id), dict(old_row), None)
    
    await _broadcast_admin_update("ibm_contact", "deleted", {"id": contact_id})
    return {"ok": True, "deleted": contact_id}


# ──────────────────────────────────────────────────────────────────
# ALM LINES
# ──────────────────────────────────────────────────────────────────

@router.get("/alm-lines", response_model=List[ALMLine])
async def list_alm_lines(
    x_iip_admin_token: str = Header(default=""),
    response: Response = None,
):
    """List all ALM lines."""
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate, max-age=0"
    pool = await get_pool()
    async with pool.acquire() as conn:
        await _require_admin(conn, x_iip_admin_token)
        rows = await conn.fetch(
            "SELECT alm_line, customer_contact, customer_email, line_manager, line_manager_email, case_responsible, case_responsible_email, case_responsible_proxy, case_responsible_proxy_email FROM alm_lines ORDER BY alm_line"
        )
    return [ALMLine(**dict(r)) for r in rows]


@router.post("/alm-lines", response_model=ALMLine)
async def create_alm_line(
    body: ALMLine,
    x_iip_admin_token: str = Header(default=""),
):
    """Create a new ALM line."""
    pool = await get_pool()
    async with pool.acquire() as conn:
        admin_user = await _require_admin(conn, x_iip_admin_token)
        
        try:
            row = await conn.fetchrow(
                """INSERT INTO alm_lines (alm_line, customer_contact, customer_email, line_manager, line_manager_email, case_responsible, case_responsible_email, case_responsible_proxy, case_responsible_proxy_email)
                   VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
                   RETURNING alm_line, customer_contact, customer_email, line_manager, line_manager_email, case_responsible, case_responsible_email, case_responsible_proxy, case_responsible_proxy_email""",
                body.alm_line, body.customer_contact, body.customer_email, body.line_manager, body.line_manager_email, body.case_responsible, body.case_responsible_email, body.case_responsible_proxy, body.case_responsible_proxy_email
            )
        except asyncpg.UniqueViolationError:
            raise HTTPException(status_code=409, detail=f"ALM line '{body.alm_line}' already exists")
        
        await _audit_log(conn, admin_user, "CREATE", "alm_line", body.alm_line, None, dict(row))
    
    await _broadcast_admin_update("alm_line", "created", dict(row))
    return ALMLine(**dict(row))


@router.put("/alm-lines/{alm_line}", response_model=ALMLine)
async def update_alm_line(
    alm_line: str,
    body: ALMLineUpdate,
    x_iip_admin_token: str = Header(default=""),
):
    """Update an ALM line."""
    pool = await get_pool()
    async with pool.acquire() as conn:
        admin_user = await _require_admin(conn, x_iip_admin_token)
        
        old_row = await conn.fetchrow(
            "SELECT alm_line, customer_contact, customer_email, line_manager, line_manager_email, case_responsible, case_responsible_email, case_responsible_proxy, case_responsible_proxy_email FROM alm_lines WHERE alm_line = $1",
            alm_line
        )
        if not old_row:
            raise HTTPException(status_code=404, detail="ALM line not found")
        
        row = await conn.fetchrow(
            """UPDATE alm_lines 
               SET customer_contact = $2, customer_email = $3, line_manager = $4, line_manager_email = $5, case_responsible = $6, case_responsible_email = $7, case_responsible_proxy = $8, case_responsible_proxy_email = $9
               WHERE alm_line = $1
               RETURNING alm_line, customer_contact, customer_email, line_manager, line_manager_email, case_responsible, case_responsible_email, case_responsible_proxy, case_responsible_proxy_email""",
            alm_line, body.customer_contact, body.customer_email, body.line_manager, body.line_manager_email, body.case_responsible, body.case_responsible_email, body.case_responsible_proxy, body.case_responsible_proxy_email
        )
        
        await _audit_log(conn, admin_user, "UPDATE", "alm_line", alm_line, dict(old_row), dict(row))
    
    await _broadcast_admin_update("alm_line", "updated", dict(row))
    return ALMLine(**dict(row))


@router.delete("/alm-lines/{alm_line}")
async def delete_alm_line(
    alm_line: str,
    x_iip_admin_token: str = Header(default=""),
):
    """Delete an ALM line."""
    pool = await get_pool()
    async with pool.acquire() as conn:
        admin_user = await _require_admin(conn, x_iip_admin_token)
        
        old_row = await conn.fetchrow(
            "SELECT alm_line, customer_contact, customer_email, line_manager, line_manager_email, case_responsible, case_responsible_email, case_responsible_proxy, case_responsible_proxy_email FROM alm_lines WHERE alm_line = $1",
            alm_line
        )
        if not old_row:
            raise HTTPException(status_code=404, detail="ALM line not found")
        
        await conn.execute("DELETE FROM alm_lines WHERE alm_line = $1", alm_line)
        await _audit_log(conn, admin_user, "DELETE", "alm_line", alm_line, dict(old_row), None)
    
    await _broadcast_admin_update("alm_line", "deleted", {"alm_line": alm_line})
    return {"ok": True, "deleted": alm_line}


# ──────────────────────────────────────────────────────────────────
# ELM UPGRADES — Track ELM version / iFix upgrade dates
# ──────────────────────────────────────────────────────────────────

class ELMUpgradeCreate(BaseModel):
    elm_version:  str
    ifix_version: str
    upgrade_date: str           # ISO date string e.g. "2024-03-15"
    notes:        Optional[str] = None

class ELMUpgrade(BaseModel):
    id:           int
    elm_version:  str
    ifix_version: str
    upgrade_date: str
    notes:        Optional[str] = None
    created_by:   Optional[str] = None
    created_at:   Optional[str] = None


@router.get("/elm-upgrades", response_model=List[ELMUpgrade])
async def list_elm_upgrades(x_iip_admin_token: str = Header(default="")):
    """Return all ELM upgrade records, newest first."""
    pool = await get_pool()
    async with pool.acquire() as conn:
        await _require_admin(conn, x_iip_admin_token)
        rows = await conn.fetch(
            """SELECT id, elm_version, ifix_version,
                      upgrade_date::text AS upgrade_date,
                      notes, created_by,
                      created_at::text   AS created_at
               FROM elm_upgrades
               ORDER BY upgrade_date DESC, id DESC"""
        )
        return [ELMUpgrade(**dict(r)) for r in rows]


@router.post("/elm-upgrades", response_model=ELMUpgrade)
async def create_elm_upgrade(
    body: ELMUpgradeCreate,
    x_iip_admin_token: str = Header(default=""),
):
    """Add a new ELM upgrade entry."""
    pool = await get_pool()
    async with pool.acquire() as conn:
        admin_user = await _require_admin(conn, x_iip_admin_token)
        try:
            row = await conn.fetchrow(
                """INSERT INTO elm_upgrades
                       (elm_version, ifix_version, upgrade_date, notes, created_by)
                   VALUES ($1, $2, $3::date, $4, $5)
                   RETURNING id, elm_version, ifix_version,
                             upgrade_date::text AS upgrade_date,
                             notes, created_by,
                             created_at::text   AS created_at""",
                body.elm_version.strip(),
                body.ifix_version.strip(),
                date.fromisoformat(body.upgrade_date),
                body.notes,
                admin_user,
            )
        except asyncpg.UniqueViolationError:
            raise HTTPException(
                status_code=409,
                detail=f"Upgrade entry for {body.elm_version} / {body.ifix_version} already exists",
            )
        await _audit_log(conn, admin_user, "CREATE", "elm_upgrade", str(row["id"]), None, dict(row))
    await _broadcast_admin_update("elm_upgrade", "created", dict(row))
    return ELMUpgrade(**dict(row))


@router.put("/elm-upgrades/{upgrade_id}", response_model=ELMUpgrade)
async def update_elm_upgrade(
    upgrade_id: int,
    body: ELMUpgradeCreate,
    x_iip_admin_token: str = Header(default=""),
):
    """Update an existing ELM upgrade entry."""
    pool = await get_pool()
    async with pool.acquire() as conn:
        admin_user = await _require_admin(conn, x_iip_admin_token)
        old = await conn.fetchrow(
            "SELECT * FROM elm_upgrades WHERE id = $1", upgrade_id
        )
        if not old:
            raise HTTPException(status_code=404, detail="ELM upgrade record not found")
        try:
            row = await conn.fetchrow(
                """UPDATE elm_upgrades
                   SET elm_version  = $2,
                       ifix_version = $3,
                       upgrade_date = $4::date,
                       notes        = $5
                   WHERE id = $1
                   RETURNING id, elm_version, ifix_version,
                             upgrade_date::text AS upgrade_date,
                             notes, created_by,
                             created_at::text   AS created_at""",
                upgrade_id,
                body.elm_version.strip(),
                body.ifix_version.strip(),
                date.fromisoformat(body.upgrade_date),
                body.notes,
            )
        except asyncpg.UniqueViolationError:
            raise HTTPException(
                status_code=409,
                detail=f"Upgrade entry for {body.elm_version} / {body.ifix_version} already exists",
            )
        await _audit_log(conn, admin_user, "UPDATE", "elm_upgrade", str(upgrade_id), dict(old), dict(row))
    await _broadcast_admin_update("elm_upgrade", "updated", dict(row))
    return ELMUpgrade(**dict(row))


@router.delete("/elm-upgrades/{upgrade_id}")
async def delete_elm_upgrade(
    upgrade_id: int,
    x_iip_admin_token: str = Header(default=""),
):
    """Delete an ELM upgrade entry."""
    pool = await get_pool()
    async with pool.acquire() as conn:
        admin_user = await _require_admin(conn, x_iip_admin_token)
        old = await conn.fetchrow(
            "SELECT * FROM elm_upgrades WHERE id = $1", upgrade_id
        )
        if not old:
            raise HTTPException(status_code=404, detail="ELM upgrade record not found")
        await conn.execute("DELETE FROM elm_upgrades WHERE id = $1", upgrade_id)
        await _audit_log(conn, admin_user, "DELETE", "elm_upgrade", str(upgrade_id), dict(old), None)
    await _broadcast_admin_update("elm_upgrade", "deleted", {"id": upgrade_id})
    return {"deleted": True, "id": upgrade_id}


# ── Audit Log: push from frontend ────────────────────────────────

class AuditEntryCreate(BaseModel):
    case_number: Optional[str] = ""
    field:       Optional[str] = ""
    old_value:   Optional[str] = ""
    new_value:   Optional[str] = ""
    updated_by:  Optional[str] = "Admin"
    is_bulk:     Optional[bool] = False
    bulk_count:  Optional[int]  = None
    client_ts:   Optional[str]  = ""

@router.post("/audit-log")
async def push_audit_entry(body: AuditEntryCreate, x_iip_admin_token: Optional[str] = Header(None)):
    pool = await get_pool()
    async with pool.acquire() as conn:
        await _require_admin(conn, x_iip_admin_token or "")
        action = body.field or "update"
        entity_type = "case" if (body.case_number and body.case_number != "CONFIG") else "config"
        entity_id   = body.case_number or ""
        notes       = f"bulk_count={body.bulk_count}" if body.is_bulk else body.client_ts
        await conn.execute(
            """INSERT INTO audit_log
               (admin_user, action, entity_type, entity_id, old_value, new_value, notes)
               VALUES ($1, $2, $3, $4, $5, $6, $7)""",
            body.updated_by or "Admin",
            action,
            entity_type,
            entity_id,
            body.old_value or None,
            body.new_value or None,
            notes or None,
        )
    return {"ok": True}


@router.get("/audit-log")
async def get_audit_log(limit: int = 500, action: Optional[str] = None, x_iip_admin_token: Optional[str] = Header(None)):
    pool = await get_pool()
    async with pool.acquire() as conn:
        await _require_admin(conn, x_iip_admin_token or "")
        rows = await conn.fetch(
            """SELECT id, admin_user, action, entity_type, entity_id,
                      old_value, new_value, notes,
                      change_date AT TIME ZONE 'UTC' AS change_date
               FROM audit_log
               WHERE ($2::text IS NULL OR action = $2)
               ORDER BY change_date DESC
               LIMIT $1""",
            limit, action,
        )
    return [dict(r) for r in rows]


# ── App Settings ──────────────────────────────────────────────────
@router.get("/app-settings")
async def get_app_settings(x_iip_admin_token: Optional[str] = Header(None)):
    pool = await get_pool()
    async with pool.acquire() as conn:
        await _require_admin(conn, x_iip_admin_token)
        rows = await conn.fetch("SELECT key, value, description, updated_at FROM app_settings ORDER BY key")
    return {"ok": True, "settings": {r["key"]: r["value"] for r in rows}}


@router.put("/app-settings")
async def update_app_settings(body: dict, x_iip_admin_token: Optional[str] = Header(None)):
    allowed = {
        "app_title", "app_subtitle", "team_name", "defect_base_url",
        "customer_account_id", "case_number_pattern", "sender_name",
        "sla_target_pct", "sla_closure_days", "idle_timeout_ms",
        "idle_warning_ms", "table_page_size", "closed_statuses",
        "customer_products", "wt_categories",
    }
    updates = {k: v for k, v in body.items() if k in allowed}
    if not updates:
        return {"ok": False, "error": "No valid keys provided"}
    pool = await get_pool()
    async with pool.acquire() as conn:
        await _require_admin(conn, x_iip_admin_token)
        for key, value in updates.items():
            val = value if isinstance(value, str) else __import__("json").dumps(value)
            await conn.execute(
                """INSERT INTO app_settings (key, value, updated_at)
                   VALUES ($1, $2, NOW())
                   ON CONFLICT (key) DO UPDATE SET value = $2, updated_at = NOW()""",
                key, val,
            )
    return {"ok": True, "updated": list(updates.keys())}
