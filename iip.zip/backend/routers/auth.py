"""
routers/auth.py — POST /api/auth, POST /api/auth/set-password,
                  POST /api/auth/logout,
                  POST /api/auth/security-questions,
                  POST /api/auth/reset-via-security

All auth state lives in proper tables:
  admin_credentials   — password hash
  admin_sessions      — session tokens
  security_questions  — password-reset Q&A
"""
from fastapi import APIRouter, Header, HTTPException
from ..database import get_pool
from ..auth import (
    hash_password, verify_password,
    create_session, revoke_session, is_valid_session,
)
from ..models import (
    AuthRequest, SetPasswordRequest,
    SecurityQuestionSetupRequest, SecurityQuestionResetRequest,
)

router = APIRouter(prefix="/api")


# ─────────────────────────────────────────────────────────────────
#  GET /api/auth/status  — Check if admin password is configured
# ─────────────────────────────────────────────────────────────────
@router.get("/auth/status")
async def auth_status():
    """Return whether an admin password has been configured."""
    pool = await get_pool()
    async with pool.acquire() as conn:
        row = await conn.fetchrow(
            "SELECT 1 FROM admin_credentials WHERE username = 'admin'"
        )
    return {"configured": row is not None}


# ─────────────────────────────────────────────────────────────────
#  POST /api/auth  — Login
# ─────────────────────────────────────────────────────────────────
@router.post("/auth")
async def login(body: AuthRequest):
    if not body.password:
        raise HTTPException(status_code=400, detail="Missing password.")

    pool = await get_pool()
    async with pool.acquire() as conn:
        row = await conn.fetchrow(
            "SELECT password_hash FROM admin_credentials WHERE username = 'admin'"
        )
        if not row:
            raise HTTPException(status_code=401, detail="No admin password configured.")
        if not verify_password(body.password, row["password_hash"]):
            raise HTTPException(status_code=401, detail="Incorrect password.")
        token = await create_session(conn)

    return {"ok": True, "token": token}


# ─────────────────────────────────────────────────────────────────
#  POST /api/auth/logout  — Revoke session
# ─────────────────────────────────────────────────────────────────
@router.post("/auth/logout")
async def logout(x_iip_admin_token: str = Header(default="")):
    if not x_iip_admin_token:
        return {"ok": True}
    pool = await get_pool()
    async with pool.acquire() as conn:
        await revoke_session(conn, x_iip_admin_token)
    return {"ok": True}




# ─────────────────────────────────────────────────────────────────
#  GET /api/auth/verify  — Validate session token
# ─────────────────────────────────────────────────────────────────
@router.get("/auth/verify")
async def verify_session(x_iip_admin_token: str = Header(default="")):
    """Return whether the provided session token is valid."""
    if not x_iip_admin_token:
        return {"authenticated": False}
    pool = await get_pool()
    async with pool.acquire() as conn:
        valid = await is_valid_session(conn, x_iip_admin_token)
    return {"authenticated": valid}
# ─────────────────────────────────────────────────────────────────
#  POST /api/auth/set-password  — Set or change admin password
# ─────────────────────────────────────────────────────────────────
@router.post("/auth/set-password")
async def set_password(
    body: SetPasswordRequest,
    x_iip_admin_token: str = Header(default=""),
):
    """
    First-time setup: no token required, currentPassword ignored.
    Password change:  valid session + correct currentPassword required.
    """
    if not body.newPassword or len(body.newPassword) < 8:
        raise HTTPException(status_code=400, detail="New password must be at least 8 characters.")

    pool = await get_pool()
    async with pool.acquire() as conn:
        row = await conn.fetchrow(
            "SELECT password_hash FROM admin_credentials WHERE username = 'admin'"
        )
        if row:
            if not await is_valid_session(conn, x_iip_admin_token):
                raise HTTPException(status_code=403, detail="Forbidden: must be logged in as admin to change password.")
            if not body.currentPassword:
                raise HTTPException(status_code=400, detail="Current password is required to change the password.")
            if not verify_password(body.currentPassword, row["password_hash"]):
                raise HTTPException(status_code=401, detail="Current password incorrect.")

        new_hash = hash_password(body.newPassword)
        await conn.execute(
            """INSERT INTO admin_credentials(username, password_hash, updated_at)
               VALUES('admin', $1, NOW())
               ON CONFLICT(username)
               DO UPDATE SET password_hash = EXCLUDED.password_hash, updated_at = NOW()""",
            new_hash,
        )

    return {"ok": True}


# ─────────────────────────────────────────────────────────────────
#  POST /api/auth/security-questions  — Save security questions
# ─────────────────────────────────────────────────────────────────
@router.post("/auth/security-questions")
async def save_security_questions(
    body: SecurityQuestionSetupRequest,
    x_iip_admin_token: str = Header(default=""),
):
    if not body.a1.strip() or not body.a2.strip():
        raise HTTPException(status_code=400, detail="Both answers are required.")
    if body.q1 == body.q2:
        raise HTTPException(status_code=400, detail="Please choose two different questions.")

    pool = await get_pool()
    async with pool.acquire() as conn:
        if not await is_valid_session(conn, x_iip_admin_token):
            raise HTTPException(status_code=403, detail="Forbidden: must be logged in as admin.")
        await conn.execute(
            """INSERT INTO security_questions(username, q1, a1, q2, a2, updated_at)
               VALUES('admin', $1, $2, $3, $4, NOW())
               ON CONFLICT(username)
               DO UPDATE SET q1 = EXCLUDED.q1, a1 = EXCLUDED.a1,
                             q2 = EXCLUDED.q2, a2 = EXCLUDED.a2,
                             updated_at = NOW()""",
            body.q1.strip(),
            body.a1.strip().lower(),
            body.q2.strip(),
            body.a2.strip().lower(),
        )
    return {"ok": True}


# ─────────────────────────────────────────────────────────────────
#  GET /api/auth/security-questions  — Get questions (not answers)
# ─────────────────────────────────────────────────────────────────
@router.get("/auth/security-questions")
async def get_security_questions():
    pool = await get_pool()
    async with pool.acquire() as conn:
        row = await conn.fetchrow(
            "SELECT q1, q2 FROM security_questions WHERE username = 'admin'"
        )
    if not row:
        return {"ok": True, "configured": False, "questions": None}
    return {
        "ok": True,
        "configured": True,
        "questions": {"q1": row["q1"], "q2": row["q2"]},
    }


# ─────────────────────────────────────────────────────────────────
#  POST /api/auth/reset-via-security  — Verify answers & reset password
# ─────────────────────────────────────────────────────────────────
@router.post("/auth/reset-via-security")
async def reset_via_security(body: SecurityQuestionResetRequest):
    if not body.newPassword or len(body.newPassword) < 8:
        raise HTTPException(status_code=400, detail="New password must be at least 8 characters.")

    pool = await get_pool()
    async with pool.acquire() as conn:
        row = await conn.fetchrow(
            "SELECT a1, a2 FROM security_questions WHERE username = 'admin'"
        )
        if not row:
            raise HTTPException(status_code=400, detail="Security questions have not been configured.")

        if (body.a1.strip().lower() != row["a1"] or
                body.a2.strip().lower() != row["a2"]):
            raise HTTPException(status_code=401, detail="One or both answers are incorrect.")

        new_hash = hash_password(body.newPassword)
        await conn.execute(
            """INSERT INTO admin_credentials(username, password_hash, updated_at)
               VALUES('admin', $1, NOW())
               ON CONFLICT(username)
               DO UPDATE SET password_hash = EXCLUDED.password_hash, updated_at = NOW()""",
            new_hash,
        )
        token = await create_session(conn)

    return {"ok": True, "token": token, "message": "Password reset successful."}

