"""
main.py — IIP FastAPI backend  v1.0
Replaces the Node.js/Express server.js with FastAPI + asyncpg + PostgreSQL.
"""
import asyncio
import json
import logging
import os
import time
import uuid
from contextlib import asynccontextmanager

from dotenv import load_dotenv
from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse, StreamingResponse
from starlette.exceptions import HTTPException as StarletteHTTPException
from .database import get_pool, close_pool
from .routers import auth, store, db_cases, admin, saved_searches
from .seed_data import auto_seed

load_dotenv()

# ── Logging ──────────────────────────────────────────────────────
LOG_LEVEL = os.getenv("IIP_LOG_LEVEL", "INFO").upper()
logging.basicConfig(
    level=LOG_LEVEL,
    format="%(asctime)s [%(levelname)s] %(name)s [%(request_id)s] %(message)s",
    datefmt="%Y-%m-%dT%H:%M:%S",
)


# Inject a default request_id=- into every log record that doesn't set one.
class _RequestIdFilter(logging.Filter):
    def filter(self, record):
        if not hasattr(record, "request_id"):
            record.request_id = "-"
        return True


for h in logging.getLogger().handlers:
    h.addFilter(_RequestIdFilter())

log = logging.getLogger("iip")
APP_VERSION = "1.0.0"

# ── SSE client registry ───────────────────────────────────────────
_sse_clients: set[asyncio.Queue] = set()


async def broadcast(event_name: str, data: dict):
    msg = f"event: {event_name}\ndata: {json.dumps(data)}\n\n"
    for q in list(_sse_clients):
        try:
            q.put_nowait(msg)
        except asyncio.QueueFull:
            pass


# Wire broadcast into routers
store.set_broadcast(broadcast)
admin.set_broadcast(broadcast)
db_cases.set_broadcast(broadcast)


# ── Lifespan (startup / shutdown) ─────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    # Try to warm up DB pool — but don't crash if DB isn't reachable yet
    try:
        pool = await get_pool()
        log.info("DB pool ready")
        try:
            await auto_seed(pool)
            log.info("auto_seed completed")
        except Exception as seed_err:
            log.error(f"auto_seed failed (startup continues): {seed_err}", exc_info=True)
    except Exception as e:
        log.warning(f"DB not reachable at startup ({e}) — will retry on first request")
    yield
    await close_pool()        # release pool on shutdown


# ── App ───────────────────────────────────────────────────────────
app = FastAPI(
    title="IIP API",
    version=APP_VERSION,
    lifespan=lifespan,
    root_path="/iip",
    docs_url="/api/docs",
    openapi_url="/api/openapi.json",
    redoc_url="/api/redoc",
)

ALLOWED_ORIGIN = os.getenv("CORS_ORIGIN", "https://rb-alm-01-d8.de.bosch.com")
# Support comma-separated list for multi-env deployments
_origins = [o.strip() for o in ALLOWED_ORIGIN.split(",") if o.strip()]
app.add_middleware(GZipMiddleware, minimum_size=1000)
app.add_middleware(
    CORSMiddleware,
    allow_origins=_origins,
    allow_credentials=False,
    allow_methods=["GET", "POST", "PUT", "DELETE", "PATCH"],
    allow_headers=["Content-Type", "X-IIP-Admin-Token"],
)


# ── Request ID + access log middleware ────────────────────────────
@app.middleware("http")
async def request_id_middleware(request: Request, call_next):
    rid = request.headers.get("X-Request-ID") or uuid.uuid4().hex[:12]
    request.state.request_id = rid
    t0 = time.monotonic()
    try:
        response = await call_next(request)
    except Exception as e:
        log.error(
            f"Unhandled exception on {request.method} {request.url.path}: {e}",
            extra={"request_id": rid},
            exc_info=True,
        )
        return JSONResponse(
            {"ok": False, "error": "Internal server error", "request_id": rid},
            status_code=500,
        )
    response.headers["X-Request-ID"] = rid
    dur_ms = int((time.monotonic() - t0) * 1000)
    # Skip noisy SSE heartbeats from access log
    if not request.url.path.endswith("/events"):
        log.info(
            f"{request.method} {request.url.path} -> {response.status_code} ({dur_ms}ms)",
            extra={"request_id": rid},
        )
    return response


# ── Unified error responses ───────────────────────────────────────
@app.exception_handler(StarletteHTTPException)
async def http_exc_handler(request: Request, exc: StarletteHTTPException):
    rid = getattr(request.state, "request_id", "-")
    return JSONResponse(
        {"ok": False, "error": exc.detail, "status": exc.status_code, "request_id": rid},
        status_code=exc.status_code,
    )


@app.exception_handler(RequestValidationError)
async def validation_exc_handler(request: Request, exc: RequestValidationError):
    rid = getattr(request.state, "request_id", "-")
    return JSONResponse(
        {"ok": False, "error": "Validation failed", "details": exc.errors(), "request_id": rid},
        status_code=422,
    )


# ── Routers ───────────────────────────────────────────────────────

app.include_router(auth.router)
app.include_router(store.router)
app.include_router(db_cases.router)
app.include_router(admin.router)
app.include_router(saved_searches.router)


# ── Health ────────────────────────────────────────────────────────
async def _health_handler():
    t0 = time.monotonic()
    try:
        pool = await get_pool()
        async with pool.acquire() as conn:
            # Deeper health: verify critical tables exist & are reachable
            await conn.fetchval("SELECT 1")
            cases_count = await conn.fetchval("SELECT COUNT(*) FROM cases")
        db_latency_ms = round((time.monotonic() - t0) * 1000)
        return {
            "ok": True,
            "version": APP_VERSION,
            "env": os.getenv("APP_ENV", os.getenv("NODE_ENV", "development")),
            "db": "connected",
            "db_latency_ms": db_latency_ms,
            "cases_count": cases_count,
            "sse_clients": len(_sse_clients),
        }
    except Exception as e:
        log.error(f"Health check failed: {e}")
        return JSONResponse({"ok": False, "error": str(e)}, status_code=503)


@app.get("/api/health")
async def health():
    return await _health_handler()



# ── SSE ───────────────────────────────────────────────────────────
async def _sse_auth_ok(token: str) -> bool:
    """Validate SSE token when SSE_REQUIRE_AUTH=true."""
    if os.getenv("SSE_REQUIRE_AUTH", "false").lower() != "true":
        return True
    if not token:
        return False
    try:
        from .auth import is_valid_session
        pool = await get_pool()
        async with pool.acquire() as conn:
            return await is_valid_session(conn, token)
    except Exception as e:
        log.warning(f"SSE auth check failed: {e}")
        return False


async def _make_sse_response(request: Request):
    token = request.query_params.get("token") or request.headers.get("X-IIP-Admin-Token", "")
    if not await _sse_auth_ok(token):
        return JSONResponse({"ok": False, "error": "Unauthorized"}, status_code=401)

    queue: asyncio.Queue = asyncio.Queue(maxsize=50)
    _sse_clients.add(queue)

    async def generator():
        try:
            yield f"event: connected\ndata: {json.dumps({'ts': int(time.time() * 1000)})}\n\n"
            while True:
                if await request.is_disconnected():
                    break
                try:
                    msg = await asyncio.wait_for(queue.get(), timeout=25)
                    yield msg
                except asyncio.TimeoutError:
                    yield ": heartbeat\n\n"
        finally:
            _sse_clients.discard(queue)

    return StreamingResponse(
        generator(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@app.get("/api/events")
async def events(request: Request):
    return await _make_sse_response(request)

