"""
backend/reset_admin.py — Manually seed / reset the admin password
Run from the IIP repo root:
    python -m backend.reset_admin
or with a custom password:
    python -m backend.reset_admin MyNewPass123
"""
import asyncio
import sys
import os
from dotenv import load_dotenv

load_dotenv()




async def seed_admin_password(new_password: str):
    import asyncpg
    from passlib.context import CryptContext

    pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

    ssl = os.getenv("DB_SSL", "false").lower() == "true"
    conn = await asyncpg.connect(
        host=os.getenv("DB_HOST", "localhost"),
        port=int(os.getenv("DB_PORT", "5432")),
        database=os.getenv("DB_NAME", "iip_db"),
        user=os.getenv("DB_USER", "iip_user"),
        password=os.getenv("DB_PASSWORD", ""),
        ssl="require" if ssl else None,
    )
    try:
        hashed = pwd_context.hash(new_password)
        await conn.execute(
            """INSERT INTO admin_credentials(username, password_hash, updated_at)
               VALUES('admin', $1, NOW())
               ON CONFLICT(username)
               DO UPDATE SET password_hash = EXCLUDED.password_hash, updated_at = NOW()""",
            hashed,
        )
        print(f"[OK] Admin password set to: {new_password}")
    finally:
        await conn.close()


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python reset_admin.py <new_password>")
        sys.exit(1)
    password = sys.argv[1]
    if len(password) < 8:
        print("Error: password must be at least 8 characters.")
        sys.exit(1)
    asyncio.run(seed_admin_password(password))
