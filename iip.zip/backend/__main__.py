"""
__main__.py — Entry point for running 'python3 -m backend'
Starts the FastAPI server with uvicorn on 0.0.0.0:8000
"""
import os
import uvicorn

if __name__ == "__main__":
    port = int(os.getenv("PORT", 8000))
    host = os.getenv("HOST", "0.0.0.0")
    
    uvicorn.run(
        "backend.main:app",
        host=host,
        port=port,
        reload=False,
        log_level="info"
    )
