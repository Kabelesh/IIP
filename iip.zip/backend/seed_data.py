"""
backend/seed_data.py — DB seed for IIP

On every startup:
  1. Seeds default admin password if no credentials exist
"""
import logging
import os

log = logging.getLogger(__name__)

_DEFAULT_ADMIN_PASSWORD = os.getenv("DEFAULT_ADMIN_PASSWORD", "Admin@1234")


async def auto_seed(pool) -> None:
    from .auth import hash_password

    async with pool.acquire() as conn:
        row = await conn.fetchrow(
            "SELECT 1 FROM admin_credentials WHERE username = 'admin'"
        )
        if row:
            log.info("seed check complete — admin credentials already set")
            return

        # Fresh install — seed default password
        default_hash = hash_password(_DEFAULT_ADMIN_PASSWORD)
        await conn.execute(
            "INSERT INTO admin_credentials(username, password_hash) VALUES('admin', $1) "
            "ON CONFLICT DO NOTHING",
            default_hash,
        )
        log.warning(
            "Default admin password seeded — login with '%s' and change immediately!",
            _DEFAULT_ADMIN_PASSWORD,
        )
    log.info("seed check complete")
