"""
auth.py — bcrypt password helpers + per-session token auth
Session tokens stored in admin_sessions table (proper indexed table).
Password stored in admin_credentials table.
"""
import datetime
import logging
import secrets
from passlib.context import CryptContext

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
log = logging.getLogger(__name__)

SESSION_TTL_HOURS = 12


def hash_password(plain: str) -> str:
    return pwd_context.hash(plain)


def verify_password(plain: str, hashed: str) -> bool:
    return pwd_context.verify(plain, hashed)


def generate_session_token() -> str:
    """Generate a cryptographically secure session token."""
    return secrets.token_hex(32)


async def create_session(conn) -> str:
    """Create a new session token valid for SESSION_TTL_HOURS hours."""
    token = generate_session_token()
    expires_at = (
        datetime.datetime.now(datetime.timezone.utc)
        + datetime.timedelta(hours=SESSION_TTL_HOURS)
    )
    # Purge expired sessions first (keep table lean)
    await conn.execute("DELETE FROM admin_sessions WHERE expires_at < NOW()")
    await conn.execute(
        "INSERT INTO admin_sessions(token, username, expires_at) VALUES($1, 'admin', $2)",
        token, expires_at,
    )
    return token


async def revoke_session(conn, token: str):
    """Revoke a specific session token."""
    await conn.execute("DELETE FROM admin_sessions WHERE token = $1", token)


async def is_valid_session(conn, token: str) -> bool:
    """Check if a session token is valid and not expired."""
    if not token:
        return False
    row = await conn.fetchrow(
        "SELECT 1 FROM admin_sessions WHERE token = $1 AND expires_at > NOW()",
        token,
    )
    return row is not None
