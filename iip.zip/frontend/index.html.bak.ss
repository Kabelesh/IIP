<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <meta name="description" content="IBM Case Intelligence Platform — AI-powered case tracking, knowledge base, and support analytics for IBM ELM teams."/>
  <title>IBM Case Intelligence Platform v1.0.0</title>
  <!-- ═══════════════════════════════════════════════════════════════
       AUTO BASE-PATH DETECTION — works both on server (/iip/) and
       locally (file:// or any path). No <base href> needed.
       ═══════════════════════════════════════════════════════════════ -->
  <script>
    (function () {
      // Derive the folder that contains index.html
      var loc = window.location.href;
      var base;
      if (loc.startsWith('file://')) {
        // Local file: strip "index.html" (or anything after last /)
        base = loc.substring(0, loc.lastIndexOf('/') + 1);
      } else {
        // Server: use the pathname up to the last slash
        var p = window.location.pathname;
        base = window.location.origin + p.substring(0, p.lastIndexOf('/') + 1);
      }
      window.__APP_BASE__ = base;
      window.API_BASE    = window.__APP_BASE__.replace(/\/$/, '') + '/api';
      window.API_BASE_V2 = window.API_BASE + '/v2';

      // Inject <base> tag so relative hrefs in CSS/HTML also resolve correctly
      var b = document.createElement('base');
      b.href = base;
      document.head.insertBefore(b, document.head.firstChild);
    })();
  </script>

  <!-- Offline / local font fallback — applies system IBM Plex Sans equivalents if Google Fonts unavailable -->
  <style>
    /* Fallback stack: system fonts that closely match IBM Plex Sans */
    :root {
      --font-sans: 'IBM Plex Sans', 'Helvetica Neue', 'Arial', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      --font-mono: 'IBM Plex Mono', 'Courier New', 'Consolas', 'Menlo', monospace;
    }
  </style>
  <link rel="stylesheet" href="/iip/fonts/ibm-plex-local.css">

  <!-- Vendor libraries — loaded locally, CDN as fallback if local is missing -->
  <script>
    // Local-first loader: serves from same origin to avoid Tracking Prevention blocks.
    // Falls back to CDN only if the local copy is unavailable.
    function loadScript(cdnUrl, localPath, cb) {
      var s = document.createElement('script');
      s.src = window.__APP_BASE__ + localPath;
      s.onload = cb || function(){};
      s.onerror = function () {
        console.warn('[IIP] Local file not found (' + localPath + '), falling back to CDN: ' + cdnUrl);
        var s2 = document.createElement('script');
        s2.src = cdnUrl;
        s2.onload = cb || function(){};
        s2.onerror = function(){ console.error('[IIP] CDN fallback also failed: ' + cdnUrl); if(cb) cb(); };
        document.head.appendChild(s2);
      };
      document.head.appendChild(s);
    }
  </script>
  <script>
    // Block until Chart.js is ready, then load XLSX
    // FIX: Load XLSX regardless of Chart.js success to prevent data import breakage
    var _xlsxLoaded = false;
    function _loadXLSX() {
      if (_xlsxLoaded) return;
      _xlsxLoaded = true;
      loadScript(
        'https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js',
        'js/vendor/xlsx.full.min.js'
      );
    }
    loadScript(
      'https://cdn.jsdelivr.net/npm/chart.js@4.4.2/dist/chart.umd.min.js',
      'js/vendor/chart.umd.min.js',
      function () {
        // Patch Chart.js 4.4.2: guard tooltip plugin's afterEvent against undefined tooltip
        // Root cause: chart.tooltip can be undefined during destroy/recreate cycle
        if (window.Chart) {
          try {
            var _tooltipPlugin = Chart.registry.plugins.get('tooltip');
            if (_tooltipPlugin && _tooltipPlugin.afterEvent) {
              var _origTooltipAfterEvent = _tooltipPlugin.afterEvent.bind(_tooltipPlugin);
              _tooltipPlugin.afterEvent = function(chart, args, options) {
                try {
                  if (!chart || !chart.tooltip) return;
                  _origTooltipAfterEvent(chart, args, options);
                } catch(e) { /* suppress handleEvent errors */ }
              };
            }
          } catch(e) {}
        }
        // Notify the app that Chart.js is now ready — active dashboard re-renders its charts
        window._chartJsReady = true;
        document.dispatchEvent(new CustomEvent('chartjs-ready'));
      }
    );
    // xlsx.full.min.js loaded on-demand when user triggers file upload (see DOMContentLoaded below)
      // Load xlsx only when user actually activates a file upload input
    document.addEventListener('DOMContentLoaded', function() {
      ['file-input','reload-input'].forEach(function(id) {
        var el = document.getElementById(id);
        if (el) el.addEventListener('mousedown', function(){ _loadXLSX(); }, { once: true });
      });
      var dz = document.getElementById('dropzone');
      if (dz) dz.addEventListener('dragenter', function(){ _loadXLSX(); }, { once: true });
    });
  </script>

  <!-- CSS load order: ui-system (tokens) → core → features → responsive -->
  <link rel="stylesheet" href="css/core/ui-system.css?v=1.0.0"/>
  <link rel="stylesheet" href="css/core/variables.css?v=1.0.0"/>
  <link rel="stylesheet" href="css/core/base.css?v=1.0.0"/>
  <link rel="stylesheet" href="css/core/layout.css?v=1.0.0"/>
  <link rel="stylesheet" href="css/core/components.css?v=1.0.0"/>
  <link rel="stylesheet" href="css/features/tables.css?v=1.0.0"/>
  <link rel="stylesheet" href="css/features/modals.css?v=1.0.0"/>
  <link rel="stylesheet" href="css/features/dashboards.css?v=1.0.0"/>
  <link rel="stylesheet" href="css/features/polish.css?v=1.0.0"/>
</head>
<body>
<!-- UPLOAD SCREEN -->
<div id="upload-screen" class="upload-screen initially-hidden">
  <div class="upload-card">
    <div class="upload-brand">
      <div class="upload-brand-alm">ALM</div>
      <div class="upload-brand-divider"></div>
      <span class="upload-brand-label">INTELLIGENCE PLATFORM</span>
    </div>
    <h1 class="upload-title" id="upload-app-title">IBM Case Intelligence Platform</h1>
    <p class="upload-sub">Upload your IBM Support export to analyse your team's cases</p>
    <div class="upload-dropzone" id="dropzone" tabindex="0" role="button" aria-label="Upload CSV file dropzone, press Enter or Space to choose file">
      <div class="upload-icon-wrap">
        <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#0f62fe" stroke-width="1.5"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="12" y1="18" x2="12" y2="12"/><polyline points="9 15 12 12 15 15"/></svg>
      </div>
      <p class="upload-hint">Drop your IBM Cases file here</p>
      <p class="upload-formats-text">Supports <strong>CSV</strong> · XLSX · XLS · XLSM</p>
      <label class="btn btn-primary upload-btn">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
        Choose File
        <input type="file" id="file-input" accept=".csv,.xlsx,.xls,.xlsm" hidden/>
      </label>
      <p class="upload-drag-hint">or drag &amp; drop here</p>
    </div>
    <div id="upload-status" class="upload-status hidden"></div>
    <!-- Validation summary renders here after parse — never touches upload-status -->
    <div id="upload-validation" class="upload-validation"></div>
    <!-- Export instructions — visible, actionable -->
    <div class="upload-export-info">
      <p class="upload-export-title">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>
        How to export from IBM Support
      </p>
      <p class="upload-export-body">
        Go to <strong>IBM Support → My Cases → Export</strong>, then save as <strong>CSV</strong> and upload it here.
        <a href="https://www.ibm.com/mysupport" target="_blank" rel="noopener noreferrer">Open IBM Support ↗</a>
      </p>
    </div>
  </div>
</div>

<!-- MAIN APP -->
<div id="app" class="app hidden">
  <!-- Skip to content link for accessibility -->
  <a href="#main-content" class="skip-to-content">Skip to main content</a>
  <aside class="sidebar" id="sidebar">
    <div class="sidebar-brand">
      <div class="sidebar-logo"><span class="sidebar-alm-badge">ALM</span></div>
      <div class="sidebar-brand-text">
        <div class="sidebar-title" id="sidebar-app-title">IBM Cases</div>
        <div class="sidebar-sub" id="sidebar-team-name">BD/TOA-ETS5</div>
      </div>
      <button class="sidebar-collapse-btn" id="sidebar-toggle" aria-label="Collapse sidebar" title="Collapse sidebar">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M11 17l-5-5 5-5"/><path d="M18 17l-5-5 5-5"/></svg>
      </button>
      <button class="sidebar-expand-btn" id="sidebar-expand" aria-label="Expand sidebar" title="Expand sidebar">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M13 17l5-5-5-5"/><path d="M6 17l5-5-5-5"/></svg>
      </button>
    </div>
    <div class="sidebar-search-wrap">
      <div class="sidebar-search">
        <svg class="sidebar-search-icon" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
        <input type="text" id="global-search" placeholder="Search cases, KB, owners…" autocomplete="off" role="combobox" aria-expanded="false" aria-haspopup="listbox" aria-controls="global-search-results" aria-autocomplete="list"/>
      </div>
      <div id="global-search-results" class="global-search-dropdown hidden" role="listbox" aria-label="Search results"></div>
    </div>
    <nav class="sidebar-nav" role="navigation" aria-label="Main navigation">

      <!-- ── Core ─────────────────────────────── -->
      <div class="nav-group">
        <button class="nav-item active" data-tab="overview" data-label="Overview" aria-label="Overview" title="Overview">
          <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></svg>
          <span>Overview</span>
        </button>

        <button class="nav-item" data-tab="members" data-label="Member Dashboard" aria-label="Member Dashboard" title="Member Dashboard">
          <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="19" y1="8" x2="19" y2="14"/><line x1="22" y1="11" x2="16" y2="11"/></svg>
          <span>Members</span>
        </button>

        <!-- Cases parent — expands sub-items -->
        <button class="nav-item nav-parent" id="nav-cases-parent" aria-expanded="false" aria-controls="nav-cases-children" title="Cases">
          <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>
          <span>Cases</span>
          <span class="nav-count" id="nav-cases-count"></span>
          <svg class="nav-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"/></svg>
        </button>

        <!-- Cases sub-items — hidden by default, toggled by parent -->
        <div class="nav-children" id="nav-cases-children" aria-hidden="true">
          <button class="nav-item nav-child" data-tab="team" data-label="Team Cases" aria-label="Team Cases" title="Team Cases">
            <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
            <span>Team Cases</span>
          </button>
          <button class="nav-item nav-child" data-tab="customer" data-label="Customer Cases" aria-label="Customer Cases" title="Customer Cases">
            <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
            <span>Customer Cases</span>
          </button>
          <button class="nav-item nav-child" data-tab="closed" data-label="Closed Cases" aria-label="Closed Cases" title="Closed Cases">
            <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
            <span>Closed Cases</span>
          </button>
          <button class="nav-item nav-child" data-tab="created" data-label="Created Cases" aria-label="Created Cases" title="Created Cases">
            <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg>
            <span>Created Cases</span>
          </button>
        </div>

        <button class="nav-item" data-tab="performance" data-label="Performance" aria-label="Performance" title="Performance">
          <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
          <span>Performance</span>
        </button>
        <button class="nav-item" data-tab="weekly-tracker" data-label="Weekly Tracker" aria-label="Weekly Closed Tracker" title="Weekly Closed Cases Tracker 2026">
          <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/><polyline points="9 16 11 18 15 14"/></svg>
          <span>Weekly Tracker</span>
        </button>
      </div>

      <!-- ── Tools ─────────────────────────────── -->
      <div class="nav-group">
        <div class="nav-group-label">Tools</div>
        <button class="nav-item" data-tab="investigate" data-label="Investigate" aria-label="Investigate" title="Investigate Cases">
          <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
          <span>Investigate</span>
        </button>
        <button class="nav-item" data-tab="rfe-tracking" data-label="RFE Tracking" aria-label="IBM RFE Tracking" title="IBM RFE Tracking">
          <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/><line x1="9" y1="13" x2="15" y2="13"/><line x1="9" y1="17" x2="15" y2="17"/></svg>
          <span>RFE Tracking</span>
        </button>
        <button class="nav-item" data-tab="documentation" data-label="Documentation" aria-label="Documentation" title="Documentation">
          <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 19.5h16M6 12.5h12M6 6.5h12"/></svg>
          <span>Documentation</span>
        </button>
        <button class="nav-item" data-tab="how-it-works" data-label="How It Works" aria-label="How It Works" title="How It Works — Interactive Guide">
          <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
          <span>How It Works</span>
        </button>
        <button class="nav-item tab-admin" data-tab="admin" data-label="Admin Portal" aria-label="Admin Portal" title="Admin Portal" id="nav-admin-portal">
          <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="3"/><path d="M19.07 4.93l-1.41 1.41M4.93 19.07l1.41-1.41M4.93 4.93l1.41 1.41M19.07 19.07l-1.41-1.41M12 2v2M12 20v2M2 12h2M20 12h2"/></svg>
          <span>Admin Portal</span>
        </button>
      </div>

      <!-- Information remains accessible via the ? help button in the footer -->
      <button class="nav-item initially-hidden" data-tab="info" data-label="Information" aria-hidden="true"></button>

    </nav>
    <div class="sidebar-footer">
      <div class="sidebar-stats" id="sidebar-stats"></div>

      <!-- Information button — opens info panel directly -->
      <div class="sidebar-help-wrap" id="sidebar-help-wrap">
        <button class="sidebar-help-btn nav-item" id="sidebar-help-btn" data-tab="info" title="Information" aria-label="Information">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>
          <span>Information</span>
        </button>
      </div>

      <div class="sidebar-footer-actions">
        <!-- Logout button — shown only when logged in as admin (visibility toggled by admin.js) -->
        <button type="button" id="admin-btn" class="btn btn-ghost btn-sm" title="Logout from admin">
          <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
          Logout
        </button>
        <label class="btn btn-ghost btn-sm" title="Upload a new cases file to refresh all dashboards">
          <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
          Re-upload Data<input type="file" id="reload-input" accept=".csv,.xlsx,.xls,.xlsm" hidden/>
        </label>
      </div>
      <a href="https://www.ibm.com/mysupport/s/createrecord/NewCase" target="_blank" rel="noopener noreferrer" class="btn btn-primary btn-sm">+ Open IBM Case</a>
    </div>
  </aside>

  <div class="main-area" id="main-content">
    <header class="top-header">
      <div class="top-header-left">
        <div id="page-title">Overview</div>
      </div>
      <div class="top-header-right">
        <span id="header-total"></span>
        <div id="kb-ingest-status" class="hidden"></div>
        <!-- Merged: Command Palette opens via Ctrl+K, ? shows shortcuts — same button triggers both via cmd palette -->
        <button id="header-cmd-hint" class="header-cmd-hint" title="Command Palette — search, navigate, actions (Ctrl+K)" aria-label="Open command palette (Ctrl+K)">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
          Search &amp; Commands
          <span class="cmd-hint-shortcut"><kbd>Ctrl</kbd><kbd>K</kbd></span>
        </button>
        <!-- Keep shortcut-hint hidden but in DOM so JS that references it doesn't break -->
        <button id="header-shortcut-hint" class="header-shortcut-hint initially-hidden" aria-hidden="true">
          <kbd>?</kbd>
        </button>
      </div>
    </header>
    <main class="main-content">
      <div id="tab-overview"         class="tab-page active"></div>
      <div id="tab-team"             class="tab-page"></div>
      <div id="tab-members"          class="tab-page"></div>
      <div id="tab-closed"           class="tab-page"></div>
      <div id="tab-created"          class="tab-page"></div>
      <div id="tab-performance"      class="tab-page"></div>
      <div id="tab-customer"         class="tab-page"></div>
      <div id="tab-investigate"  class="tab-page"></div>
      <div id="tab-rfe-tracking"   class="tab-page"></div>
      <div id="tab-documentation"  class="tab-page"></div>
      <div id="tab-how-it-works"  class="tab-page"></div>
      <div id="tab-info"         class="tab-page"></div>

      <div id="tab-admin"        class="tab-page"></div>
      <div id="tab-weekly-tracker" class="tab-page"></div>
    </main>
  </div>
</div>

<!-- TOAST NOTIFICATIONS -->
<div id="toast-container" class="toast-container" aria-live="assertive" aria-atomic="true"></div>

<!-- KEYBOARD SHORTCUTS MODAL -->
<div id="kb-shortcuts-overlay" class="kb-shortcuts-overlay hidden" role="dialog" aria-modal="true" aria-label="Keyboard Shortcuts">
  <div class="kb-shortcuts-box">
    <div class="kb-shortcuts-header">
      <h3>Keyboard Shortcuts</h3>
      <button class="modal-close" id="kb-shortcuts-close" aria-label="Close">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
      </button>
    </div>
    <div class="kb-shortcuts-body">
      <div class="kb-shortcut-group">
        <div class="kb-shortcut-group-title">Navigation</div>
        <div class="kb-shortcut-row"><span>Overview</span><span class="kb-shortcut-keys"><kbd>1</kbd></span></div>
        <div class="kb-shortcut-row"><span>Team Cases</span><span class="kb-shortcut-keys"><kbd>2</kbd></span></div>
        <div class="kb-shortcut-row"><span>Member Dashboard</span><span class="kb-shortcut-keys"><kbd>3</kbd></span></div>
        <div class="kb-shortcut-row"><span>Customer Cases</span><span class="kb-shortcut-keys"><kbd>4</kbd></span></div>
        <div class="kb-shortcut-row"><span>Closed Cases</span><span class="kb-shortcut-keys"><kbd>5</kbd></span></div>
        <div class="kb-shortcut-row"><span>Performance</span><span class="kb-shortcut-keys"><kbd>6</kbd></span></div>
        <div class="kb-shortcut-row"><span>Weekly Tracker</span><span class="kb-shortcut-keys"><kbd>7</kbd></span></div>
        <div class="kb-shortcut-row"><span>Created Cases</span><span class="kb-shortcut-keys"><kbd>8</kbd></span></div>
        <div class="kb-shortcut-row"><span>Case Investigation</span><span class="kb-shortcut-keys"><kbd>9</kbd></span></div>
      </div>
      <div class="kb-shortcut-group">
        <div class="kb-shortcut-group-title">Actions</div>
        <div class="kb-shortcut-row"><span>Command Palette</span><span class="kb-shortcut-keys"><kbd>Ctrl</kbd><kbd>K</kbd></span></div>
        <div class="kb-shortcut-row"><span>Focus Search</span><span class="kb-shortcut-keys"><kbd>/</kbd></span></div>
        <div class="kb-shortcut-row"><span>Open AI Assistant</span><span class="kb-shortcut-keys"><kbd>A</kbd></span></div>
        <div class="kb-shortcut-row"><span>Close / Dismiss</span><span class="kb-shortcut-keys"><kbd>Esc</kbd></span></div>
        <div class="kb-shortcut-row"><span>Show Shortcuts</span><span class="kb-shortcut-keys"><kbd>?</kbd></span></div>
      </div>
    </div>
  </div>
</div>

<!-- COMMAND PALETTE -->
<div id="cmd-palette-overlay" class="cmd-palette-overlay hidden" role="dialog" aria-modal="true" aria-label="Command Palette">
  <div class="cmd-palette-box">
    <div class="cmd-palette-input-wrap">
      <svg class="cmd-palette-search-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
      <input id="cmd-palette-input" type="text" placeholder="Search commands, navigate, actions…" autocomplete="off" spellcheck="false"/>
      <span class="cmd-palette-esc-hint"><kbd>Esc</kbd></span>
    </div>
    <div id="cmd-palette-list"></div>
    <div class="cmd-palette-footer">
      <span class="cmd-footer-hint"><kbd>↑</kbd><kbd>↓</kbd> Navigate</span>
      <span class="cmd-footer-hint"><kbd>↵</kbd> Select</span>
      <span class="cmd-footer-hint"><kbd>Esc</kbd> Close</span>
    </div>
  </div>
</div>

<!-- LOADING PROGRESS BAR -->
<div id="app-progress" class="app-progress-bar hidden">
  <div id="app-progress-fill" class="app-progress-fill"></div>
</div>

<!-- STATUS BAR -->
<div id="v6-status-bar" class="hidden" aria-live="polite" aria-atomic="true"></div>

<!-- BACK TO TOP -->
<button id="v6-back-to-top" aria-label="Back to top">
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="18 15 12 9 6 15"/></svg>
</button>

<!-- MODALS -->
<div id="modal-overlay" class="modal-overlay hidden" role="dialog" aria-modal="true" aria-labelledby="modal-title">
  <div id="modal-box" class="modal-box">
    <div class="modal-header"><h3 id="modal-title" class="modal-title"></h3><button class="modal-close modal-close-lg" id="modal-close" aria-label="Close dialog"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button></div>
    <div id="modal-body" class="modal-body"></div>
  </div>
</div>

<!-- ═══════════════════════════════════════════════════════════════════
     SCRIPTS — load order matters; organised by dependency layer
     ═══════════════════════════════════════════════════════════════════ -->

<!-- ── Layer 0: Core utilities (no dependencies) ──────────────────── -->
<!-- Phase 5: app-data.js deprecated — DynamicConfig now fetches from /api/team-config.
     Kept as offline fallback until migration is verified in production. -->
<script src="js/data/app-data.js?v=1.0.0"></script>
<script src="js/modules/data/utils.js?v=1.0.0"></script>

<!-- ── Layer 1: Configuration & data layer ────────────────────────── -->
<script src="js/modules/data/dynamic-config.js?v=1.0.0"></script>
<script src="js/modules/data/config.js?v=1.0.0"></script>
<script src="js/modules/data/storage.js?v=1.0.0"></script>
<script src="js/modules/data/data.js?v=1.0.0"></script>
<script src="js/modules/ui/charts.js?v=1.0.0"></script>
<script src="js/modules/ui/table.js?v=1.0.0"></script>

<!-- ── Layer 2: UI primitives ─────────────────────────────────────── -->

<!-- ── Layer 3: Authentication & persistence ──────────────────────── -->

<!-- ── Layer 4: Platform services ─────────────────────────────────── -->
<script src="js/modules/data/contacts.js?v=1.0.0"></script>
<script src="js/modules/platform/hash-router.js?v=1.0.0"></script>

<!-- ── Layer 5: Admin modules ─────────────────────────────────────── -->
<script src="js/modules/admin/admin-bootstrap-loader.js?v=1.0.0"></script>
<script src="js/modules/admin/admin-sse-listener.js?v=1.0.0"></script>

<!-- ── Layer 6: Tracker modules ───────────────────────────────────── -->

<!-- ── Layer 7: Dashboards ────────────────────────────────────────── -->


<!-- ── Layer 8: App bootstrap & UI chrome ─────────────────────────── -->
<script src="js/app.js?v=1.0.1"></script>
<script src="js/modules/ui/ui-chrome.js?v=1.0.0"></script>
  <script src="js/modules/ui/searchable-select.js?v=1.0.0"></script>

<!-- ── App version propagation ────────────────────────────────────── -->
<script>
  (function() {
    if (typeof AppVersion === 'undefined') return;
    const v = AppVersion.version;
    document.title = 'IBM Case Intelligence Platform ' + v;
    const badge = document.getElementById('upload-ver-badge');
    if (badge) badge.textContent = v;
  })();
</script>


<!-- ══════════════════════════════════════════════════════════════════
     IIP UX PATCHES — safe rewrite, no mutation loops, no polling
     ══════════════════════════════════════════════════════════════════ -->
<script>
/* ── 1. Cases sub-nav expand/collapse + Help flyout ── */
(function IIPNavPatch() {
  const CASES_CHILDREN = new Set(['team','customer','closed','created']);

  function setupCasesParent() {
    const parent   = document.getElementById('nav-cases-parent');
    const children = document.getElementById('nav-cases-children');
    if (!parent || !children) return;

    function open()   { children.classList.add('open'); parent.setAttribute('aria-expanded','true'); }
    function close()  { children.classList.remove('open'); parent.setAttribute('aria-expanded','false'); }
    function toggle() { children.classList.contains('open') ? close() : open(); }

    parent.addEventListener('click', toggle);
    parent.addEventListener('keydown', e => { if (e.key==='Enter'||e.key===' ') { e.preventDefault(); toggle(); } });

    // Restore if a child tab was active last session
    try {
      const sess = sessionStorage.getItem('ibm_session_v1');
      if (sess) { const {tab} = JSON.parse(sess); if (CASES_CHILDREN.has(tab)) open(); }
    } catch(e) {}

    return { open, close };
  }

  function setupActiveState(ctrl) {
    function sync() {
      const activeChild = document.querySelector('.nav-item.nav-child.active');
      const p = document.getElementById('nav-cases-parent');
      if (!p) return;
      if (activeChild) { p.classList.add('nav-child-active'); ctrl && ctrl.open(); }
      else p.classList.remove('nav-child-active');
    }
    // Watch for active class changes on nav items only (not subtree)
    document.querySelectorAll('.nav-item[data-tab]').forEach(btn => {
      btn.addEventListener('click', () => setTimeout(sync, 50));
    });
    sync();
  }

  function setupHelpFlyout() {
    // Information button is now a nav-item — handled by setupSidebarNav in app.js
  }

  function setupCaseBadge() {
    const badge = document.getElementById('nav-cases-count');
    if (!badge) return;
    function update() {
      try {
        if (typeof Data === 'undefined' || !Data.allCases) return;
        const n = Data.allCases().filter(r => !r._closed).length;
        badge.textContent = n; badge.style.display = n > 0 ? '' : 'none';
      } catch(e) {}
    }
    // Try once now, once after data likely loads
    setTimeout(update, 1500);
    document.querySelectorAll('.nav-item[data-tab]').forEach(b => b.addEventListener('click', () => setTimeout(update, 400)));
  }

  function init() {
    const ctrl = setupCasesParent();
    setupActiveState(ctrl);
    setupHelpFlyout();
    setupCaseBadge();
    // Alt+C = toggle cases, Alt+H = help
    document.addEventListener('keydown', e => {
      if (!['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName)) {
        if (e.altKey && e.key.toLowerCase()==='c') { e.preventDefault(); document.getElementById('nav-cases-parent')?.click(); }
        if (e.altKey && e.key.toLowerCase()==='h') { e.preventDefault(); document.getElementById('sidebar-help-btn')?.click(); }
      }
    });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
</script>

<script>
/* ── 2. Global Date Context — filters persist across tab switches ── */
(function IIPDateContext() {
  'use strict';
  const STORE_KEY = 'iip_date_ctx_v1';
  const DASHBOARDS = [
    { tab:'closed',   prefix:'cl', fields:['year','month','from','to','lastdays'], scope:'date-range-closed'   },
    { tab:'created',  prefix:'cr', fields:['year','month','from','to','lastdays'], scope:'date-range-created' },
    { tab:'customer', prefix:'cu', fields:['year','month','from','to','lastdays'], scope:'date-range-customer' },
  ];

  function load() { try { return JSON.parse(sessionStorage.getItem(STORE_KEY)||'{}'); } catch(e) { return {}; } }
  function save(ctx) { try { sessionStorage.setItem(STORE_KEY, JSON.stringify(ctx)); } catch(e) {} }

  function readInputs(dash) {
    const v = {};
    dash.fields.forEach(f => { const el = document.getElementById(`${dash.prefix}-${f}`); v[f] = el ? (el.value||'') : ''; });
    return v;
  }

  function applyInputs(dash, values) {
    const hasLastDays = values['lastdays'] && values['lastdays'].trim() !== '';
    ['year','month','from','to','lastdays'].forEach(field => {
      if (hasLastDays && ['year','month','from','to'].includes(field)) return;
      if (!hasLastDays && field === 'lastdays') return;
      const el = document.getElementById(`${dash.prefix}-${field}`);
      if (!el) return;
      const val = values[field]||'';
      if (el.value === val) return;
      el.value = val;
      el.dispatchEvent(new Event(el.tagName==='SELECT'?'change':el.type==='number'?'input':'change', {bubbles:true}));
    });
  }

  function watchDashboard(dash) {
    const tabEl = document.getElementById(`tab-${dash.tab}`);
    if (!tabEl) return;
    const handler = e => {
      if (!(e.target?.id||'').startsWith(dash.prefix+'-')) return;
      const ctx = load(); ctx[dash.scope] = readInputs(dash); save(ctx); updateBadge(ctx[dash.scope]);
    };
    tabEl.addEventListener('change', handler);
    tabEl.addEventListener('input', handler);
    tabEl.addEventListener('click', e => { if (e.target?.id === `${dash.prefix}-clear`) { setTimeout(() => { const ctx = load(); delete ctx[dash.scope]; save(ctx); updateBadge({}); }, 0); } });
  }

  function watchTabRender(dash) {
    const tabEl = document.getElementById(`tab-${dash.tab}`);
    if (!tabEl) return;
    const obs = new MutationObserver(() => {
      const bar = tabEl.querySelector('.filter-bar');
      if (!bar || bar.dataset.ctxApplied) return;
      bar.dataset.ctxApplied = '1';
      setTimeout(() => {
        const ctx = load(); const values = ctx[dash.scope];
        if (!values || !Object.values(values).some(v => v && v.trim())) return;
        applyInputs(dash, values);
      }, 60);
    });
    // Only watch direct children of tab — not subtree — to avoid triggering on inner DOM changes
    obs.observe(tabEl, { childList: true });
  }

  function updateBadge(values) {
    const hasActive = values && Object.values(values).some(v => v && v.trim());
    let badge = document.getElementById('iip-date-ctx-badge');
    if (!hasActive) { badge?.remove(); return; }
    if (!badge) {
      badge = document.createElement('div');
      badge.id = 'iip-date-ctx-badge';
      badge.title = 'Date filter active across all dashboards — click to clear (Alt+D)';
      badge.style.cssText = 'display:inline-flex;align-items:center;gap:5px;font-size:11px;font-weight:600;color:var(--ibm-blue-50);background:var(--ibm-blue-10);border:1px solid rgba(15,98,254,.25);padding:3px 9px;border-radius:99px;cursor:pointer;white-space:nowrap';
      badge.innerHTML = `<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg><span id="iip-date-ctx-label"></span><span style="opacity:.55;margin-left:1px">×</span>`;
      badge.addEventListener('click', clearAll);
      const headerRight = document.querySelector('.top-header-right');
      const cmdBtn = document.getElementById('header-cmd-hint');
      if (headerRight && cmdBtn) headerRight.insertBefore(badge, cmdBtn);
      else if (headerRight) headerRight.prepend(badge);
    }
    const label = document.getElementById('iip-date-ctx-label');
    if (!label) return;
    const months=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    if (values.from&&values.to)          label.textContent=`${values.from} → ${values.to}`;
    else if (values.from)                label.textContent=`From ${values.from}`;
    else if (values.to)                  label.textContent=`Until ${values.to}`;
    else if (values.lastdays)            label.textContent=`Last ${values.lastdays}d`;
    else if (values.year&&values.month)  label.textContent=`${months[+values.month-1]} ${values.year}`;
    else if (values.year)                label.textContent=values.year;
    else                                 label.textContent='Date filtered';
  }

  function clearAll() {
    save({});
    document.getElementById('iip-date-ctx-badge')?.remove();
    DASHBOARDS.forEach(dash => {
      const clearBtn = document.getElementById(`${dash.prefix}-clear`);
      if (clearBtn) { clearBtn.click(); return; }
      dash.fields.forEach(field => {
        const el = document.getElementById(`${dash.prefix}-${field}`);
        if (!el || !el.value) return;
        el.value = '';
        el.dispatchEvent(new Event(el.tagName==='SELECT'?'change':el.type==='number'?'input':'change',{bubbles:true}));
      });
    });
  }

  function init() {
    DASHBOARDS.forEach(dash => { watchDashboard(dash); watchTabRender(dash); });
    const ctx = load(); const first = Object.values(ctx)[0]; if (first) updateBadge(first);
    document.addEventListener('keydown', e => {
      if (e.altKey && e.key.toLowerCase()==='d' && !['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName))
        { e.preventDefault(); clearAll(); }
    });
  }

  window.IIPDateContext = { clear: clearAll, load };
  if (document.readyState==='loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
</script>


<script>
/* ── 4. Table keyboard navigation ── */
(function IIPTableKeyboard() {
  'use strict';
  const TABLE_SEL = '.data-table, .iip-created-table';
  const _patched  = new WeakSet();
  let   _applying = false; // re-entrance guard — prevents observer→patch→observer loop

  function cnFromRow(tr) {
    const span = tr.querySelector('[data-cn]');
    if (span) return span.dataset.cn;
    const td = tr.querySelector('td');
    if (td && /^TS\S+/i.test(td.textContent.trim())) return td.textContent.trim();
    return null;
  }

  function openRow(tr) {
    const span = tr.querySelector('[data-cn],.case-number-copy');
    if (span) { span.click(); return; }
    const cn = cnFromRow(tr);
    if (!cn) return;
    try {
      const inp = document.getElementById('global-search');
      if (inp) { inp.value = cn; inp.dispatchEvent(new Event('input',{bubbles:true}));
        setTimeout(() => { const item = document.querySelector(`.gs-item[data-cn="${cn}"]`); if (item) item.click(); }, 200); }
    } catch(e) {}
  }

  function applyRow(tr, i) {
    if (tr.dataset.kbPatched) return;
    const tds = tr.querySelectorAll('td');
    if (tds.length <= 1) return;
    tr.dataset.kbPatched = '1';
    tr.setAttribute('tabindex', '0');
    tr.setAttribute('role', 'row');
    tr.setAttribute('aria-rowindex', i + 2);
    const last = tr.querySelector('td:last-child');
    if (last) {
      const hint = document.createElement('span');
      hint.className = 'iip-row-view-hint';
      hint.setAttribute('aria-hidden','true');
      hint.textContent = 'View →';
      hint.style.cssText = 'float:right;margin-left:8px;font-size:10px;color:var(--ibm-blue-50);opacity:0;transition:opacity 0.12s;font-weight:600';
      last.appendChild(hint);
    }
  }

  function patchTable(table) {
    if (_patched.has(table)) return;
    _patched.add(table);
    if (!table.getAttribute('role')) table.setAttribute('role','grid');

    // Apply rows once on first patch
    _applying = true;
    [...table.querySelectorAll('tbody tr')].forEach((tr, i) => applyRow(tr, i));
    _applying = false;

    // Keyboard navigation
    table.addEventListener('keydown', e => {
      const focused = document.activeElement;
      if (!focused || focused.closest('table') !== table) return;
      const rows = [...table.querySelectorAll('tbody tr[tabindex="0"]')];
      const idx  = rows.indexOf(focused);
      if (idx === -1) return;
      switch(e.key) {
        case 'ArrowDown': e.preventDefault(); rows[idx+1]?.focus(); rows[idx+1]?.scrollIntoView({block:'nearest'}); break;
        case 'ArrowUp':   e.preventDefault(); rows[idx-1]?.focus(); rows[idx-1]?.scrollIntoView({block:'nearest'}); break;
        case 'Enter':     e.preventDefault(); openRow(focused); break;
        case 'Home':      e.preventDefault(); rows[0]?.focus(); break;
        case 'End':       e.preventDefault(); rows[rows.length-1]?.focus(); break;
        case 'Escape':    e.preventDefault(); focused.blur(); break;
      }
    });

    // Click to open (skip interactive cells)
    table.addEventListener('click', e => {
      const tr = e.target.closest('tbody tr');
      if (!tr || e.target.closest('button,a,select,input,.case-number-copy')) return;
      openRow(tr);
    });

    // Show/hide view hint on hover
    table.addEventListener('mouseover', e => {
      const tr = e.target.closest('tbody tr');
      if (tr) { const h = tr.querySelector('.iip-row-view-hint'); if (h) h.style.opacity='1'; }
    });
    table.addEventListener('mouseout', e => {
      const tr = e.target.closest('tbody tr');
      if (tr) { const h = tr.querySelector('.iip-row-view-hint'); if (h) h.style.opacity='0'; }
    });

    // Watch tbody for row replacements (Table.refresh()) — apply to new rows only
    const tbody = table.querySelector('tbody');
    if (tbody) {
      const rowObs = new MutationObserver(() => {
        if (_applying) return; // guard against our own DOM writes
        _applying = true;
        [...tbody.querySelectorAll('tr')].forEach((tr, i) => applyRow(tr, i));
        _applying = false;
      });
      rowObs.observe(tbody, { childList: true }); // childList only — NOT subtree/attributes
    }
  }

  function init() {
    // One-time scan of existing tables
    document.querySelectorAll(TABLE_SEL).forEach(t => patchTable(t));

    // Watch main-content direct children only for new tab panels
    const main = document.querySelector('.main-content');
    if (main) {
      const obs = new MutationObserver(() => {
        if (_applying) return;
        document.querySelectorAll(TABLE_SEL).forEach(t => { if (!_patched.has(t)) patchTable(t); });
      });
      obs.observe(main, { childList: true }); // childList only — NOT subtree
    }

    setTimeout(() => document.querySelectorAll(TABLE_SEL).forEach(t => { if (!_patched.has(t)) patchTable(t); }), 1500);
  }

  if (document.readyState==='loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
</script>


<!-- ── Deferred & lazy resource loader ───────────────────────────────────────
     JS  EAGER  = loads for every page at idle (needed by all tabs)
     JS  LAZY   = loads only when the user first visits the tab that needs it
     CSS EAGER  = injected at idle (used by tabs with case tables)
     CSS LAZY   = injected only when the relevant tab is first visited
     contacts.js is synchronous so _TEAM_LOWER is built before App.init().
──────────────────────────────────────────────────────────────────────────── -->
<script>
(function() {
  'use strict';

  // ── JS Eager: needed on all pages ──────────────────────────────────────
  var JS_EAGER = [
    'js/modules/ui/modal.js?v=1.0.0',
    'js/modules/ui/progressive-disclosure.js?v=1.0.0',
    'js/modules/ui/onboarding.js?v=1.0.0',
    'js/modules/ui/polish.js?v=1.0.0',
    'js/modules/ui/ui-components.js?v=1.0.0',
    'js/modules/ui/state-manager.js?v=1.0.0',
    'js/modules/platform/mail.js?v=1.0.0',
    'js/modules/platform/patches.js?v=1.0.0',
    'js/modules/ui/whats-new.js?v=1.0.0',
  ];

  // ── JS Lazy: only when the user first visits that tab ──────────────────
  var JS_LAZY = {
    'team':           ['js/modules/ui/column-manager.js?v=1.0.0', 'js/modules/platform/reopen-workflow.js?v=1.0.0'],
    'members':        ['js/modules/ui/column-manager.js?v=1.0.0', 'js/modules/platform/reopen-workflow.js?v=1.0.0'],
    'closed':         ['js/modules/ui/column-manager.js?v=1.0.0'],
    'created':        ['js/modules/ui/column-manager.js?v=1.0.0'],
    'customer':       ['js/modules/ui/column-manager.js?v=1.0.0'],
    'performance':    ['js/modules/ui/perf-utils.js?v=1.0.0'],
    'investigate':    ['js/modules/ui/custom-select.js?v=1.0.0', 'js/modules/platform/saved-search.js?v=1.0.0'],
    'admin':          [], // handled by app.js _LAZY_SCRIPTS (avoids duplicate load on nav click)
  };

  // ── CSS Eager: used by any tab that shows case tables ──────────────────
  var CSS_EAGER = [
    'css/features/atlassian.css?v=1.0.0',
    'css/features/enhancements.css?v=1.0.0',
  ];

  // ── CSS Lazy: only inject when the relevant tab is first visited ────────
  var CSS_LAZY = {
    'investigate':    ['css/features/investigate.css?v=1.0.0', 'css/features/custom-select.css?v=1.0.0'],
    'rfe-tracking':   ['css/features/rfe-tracking.css?v=1.0.0'],
    'how-it-works':   ['css/features/how-it-works.css?v=1.0.0'],
    'weekly-tracker': ['css/features/weekly-tracker.css?v=1.0.0'],
    'performance':    ['css/features/performance.css?v=1.0.0'],
    'admin':          ['css/features/admin-portal-v3.css', 'css/features/custom-select.css?v=1.0.0'],
    // onboarding CSS covers the onboarding overlay shown on any tab on first visit
    '_eager':         ['css/features/onboarding.css?v=1.0.0'],
  };

  var _jsLoaded  = new Set();
  var _cssLoaded = new Set();

  function _injectJS(src) {
    if (_jsLoaded.has(src)) return;
    _jsLoaded.add(src);
    var base = (typeof window.__APP_BASE__ === 'string') ? window.__APP_BASE__ : '';
    var s = document.createElement('script');
    s.src = base + src;
    document.head.appendChild(s);
  }

  function _injectCSS(href) {
    if (_cssLoaded.has(href)) return;
    _cssLoaded.add(href);
    var base = (typeof window.__APP_BASE__ === 'string') ? window.__APP_BASE__ : '';
    var l = document.createElement('link');
    l.rel  = 'stylesheet';
    l.href = base + href;
    document.head.appendChild(l);
  }

  function loadEager() {
    // Inject eager JS
    JS_EAGER.forEach(_injectJS);
    // Inject eager CSS (used by case tables on most tabs + onboarding overlay)
    CSS_EAGER.forEach(_injectCSS);
    (CSS_LAZY['_eager'] || []).forEach(_injectCSS);

    // Re-run inits skipped at boot because modules weren't ready yet.
    // Also rebuild _TEAM_LOWER from the now-loaded contacts.js.
    setTimeout(function() {
      try { Modal.init(); }             catch(e) {}
      try { Admin.init(); }             catch(e) {}
      try { Contacts.refresh(); }       catch(e) {}
      try { Data.refreshTeamIndex(); }  catch(e) {}   // ← fixes TEAM CASES = 0
      // Re-render overview so team KPIs and charts use the correct team index
      setTimeout(function() {
        try { if (typeof DashOverview !== 'undefined') DashOverview.render(); } catch(e) {}
      }, 150);
    }, 600);
  }

  // ── Route-based lazy loader ─────────────────────────────────────────────
  function lazyLoadTab(tab) {
    (JS_LAZY[tab]  || []).forEach(_injectJS);
    (CSS_LAZY[tab] || []).forEach(_injectCSS);
  }

  function setupLazyLoader() {
    document.querySelectorAll('.nav-item[data-tab]').forEach(function(btn) {
      btn.addEventListener('click', function() { lazyLoadTab(btn.dataset.tab); });
    });
    // Handle the initial active tab if it's not overview
    try {
      var active = document.querySelector('.nav-item.active[data-tab]');
      if (active && active.dataset.tab !== 'overview') lazyLoadTab(active.dataset.tab);
    } catch(e) {}
  }

  function init() {
    loadEager();
    setupLazyLoader();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function() {
      if (window.requestIdleCallback) requestIdleCallback(init, { timeout: 2000 });
      else setTimeout(init, 100);
    });
  } else {
    if (window.requestIdleCallback) requestIdleCallback(init, { timeout: 2000 });
    else setTimeout(init, 100);
  }
})();
</script>

</body>
</html>
