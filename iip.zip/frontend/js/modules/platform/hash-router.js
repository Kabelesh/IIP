const HashRouter = (() => {
  /* Derive the pathname base, e.g. '/iip/' → '/iip' */
  function _basePath() {
    try {
      const b = document.querySelector('base');
      if (b && b.href) return new URL(b.href).pathname.replace(/\/$/, '');
    } catch(e) {}
    if (typeof window.__APP_BASE__ !== 'undefined') {
      try { return new URL(window.__APP_BASE__).pathname.replace(/\/$/, ''); } catch(e) {}
    }
    return '';
  }

  function _activate(tabKey) {
    if (!tabKey) return;
    const btn = document.querySelector('[data-tab="' + tabKey + '"]');
    if (btn && typeof btn.click === 'function') btn.click();
  }

  function _tabFromPath() {
    const base = _basePath();
    const rel   = location.pathname.startsWith(base)
      ? location.pathname.slice(base.length)
      : location.pathname;
    return rel.replace(/^\//, '').split('/')[0].trim();
  }

  /* Public: programmatically navigate to a tab */
  function navigate(tabKey) {
    if (!tabKey) return;
    history.pushState({ tab: tabKey }, '', _basePath() + '/' + tabKey);
    _activate(tabKey);
  }

  function _onPopState() {
    const tab = _tabFromPath();
    if (tab) _activate(tab);
  }

  function init() {
    window.addEventListener('popstate', _onPopState);
    document.addEventListener('click', e => {
      const btn = e.target.closest('[data-tab]');
      if (btn) {
        const k = btn.getAttribute('data-tab');
        const _target = _basePath() + '/' + k;
        if (location.pathname !== _target) history.pushState({ tab: k }, '', _target);
      }
    });
    setTimeout(() => {
      const tab = _tabFromPath();
      if (tab) history.replaceState({ tab }, '', location.pathname);
      _onPopState();
    }, 200);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
  return { init, activate: _activate, navigate };
})();
