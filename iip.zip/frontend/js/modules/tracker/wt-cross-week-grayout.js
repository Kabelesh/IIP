// =============================================================================
// frontend/js/modules/tracker/wt-cross-week-grayout.js
// IIP Fix 2.6 — Cross-Week Duplicate Case Grayout
//
// When the same case number appears in multiple weeks (e.g. TS021336609 in
// W07 AND W13), this module:
//
//   1. SCANS all weeks (localStorage + seed) for every year to build a map of
//      caseNumber → [{ week, year, closedDate, … }, …]
//
//   2. For any case with 2+ appearances:
//      - The EARLIEST week(s) get grayed out  (wt-row-grayed class)
//      - The LATEST week remains active (no grayout)
//
//   3. Records a HISTORY entry in the localStorage history store for each
//      cross-week case (shown in the Reopened tab and History tab).
//
//   4. Fetches DB-side grayout states in ONE bulk call (no per-row requests)
//      and merges them with the localStorage-derived set.
//
// Integration:
//   • Called by DashWeeklyTracker after _renderTable() to apply styling.
//   • Exposes window.WTCrossWeekGrayout.* for direct calls.
//   • Also hooks into enrichFromCases() to update records when new CSV loaded.
//
// Performance:
//   • The scan result is cached in memory and invalidated only when the
//     localStorage tracker data changes (checked via a lightweight version key).
//   • Row styling is applied synchronously (no awaits in the hot path).
//   • DB grayout states are fetched once per render cycle (async, then applied).
// =============================================================================

'use strict';

(function (window) {

  // ── Constants ────────────────────────────────────────────────────────────────
  const STORE_PREFIX   = 'ibm_wtracker_';
  const HISTORY_KEY    = 'ibm_wtracker_history';
  const CACHE_VER_KEY  = 'ibm_wtracker_cwg_version'; // lightweight change-detection key
  const GRAYOUT_ATTR   = 'data-cwg-applied';          // sentinel attribute on <tr>

  // Week comparison key: zero-pad CW so CW07 < CW13 lexicographically
  const _cwKey = (week, year) => `${year}|${week}`;  // e.g. "2026|CW07"

  // ── Cached scan result ───────────────────────────────────────────────────────
  // caseAppearances: Map<caseNumber, Array<{week, year, closedDate, owner, title, status}>>
  // Sorted by _cwKey ascending (earliest first).
  let _cachedAppearances = null;  // null = stale / not yet computed
  let _cachedVersion     = null;

  // ── Grayout state set (built from cache) ─────────────────────────────────────
  // Keys: `${caseNumber}|${week}|${year}`  → metadata { laterWeek, laterYear }
  let _grayoutSet = new Map();

  // ── DB grayout state (fetched async) ─────────────────────────────────────────
  // Keys: `${caseNumber}|${week}|${year}`  → { reason, metadata }
  let _dbGrayoutMap = new Map();
  let _dbFetchPending = false;
  let _dbSyncDone     = false;  // push to /api/reopened/sync once per page load

  // ── Helpers ──────────────────────────────────────────────────────────────────

  function _ldy(yr) {
    try { return JSON.parse(localStorage.getItem(STORE_PREFIX + yr) || '{}'); } catch(e) { return {}; }
  }

  function _loadHistory() {
    try { return JSON.parse(localStorage.getItem(HISTORY_KEY) || '{}'); } catch(e) { return {}; }
  }

  function _saveHistory(h) {
    try { localStorage.setItem(HISTORY_KEY, JSON.stringify(h)); } catch(e) {}
  }

  // Compute a lightweight version fingerprint (total byte length of all wtracker_ keys).
  // Cheap to compute, detects any localStorage change without full rescan.
  function _computeVersion() {
    let v = 0;
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.startsWith(STORE_PREFIX)) {
        try { v += (localStorage.getItem(k) || '').length; } catch(e) {}
      }
    }
    return v;
  }

  // ── Main scan ─────────────────────────────────────────────────────────────────
  // Returns Map<caseNumber, Array<appearance>> — sorted earliest-first per case.

  function _scanAllWeeks() {
    const byCase = new Map(); // caseNumber → Set of unique week|year combos to avoid duplicates

    function _addRow(r, yr, wk) {
      const cn = (r.caseNumber || '').replace(/<[^>]*>/g, '').trim();
      if (!cn) return;
      if (!byCase.has(cn)) byCase.set(cn, []);
      const arr = byCase.get(cn);
      // Dedup: one entry per case+week+year combo
      const key = _cwKey(wk, yr);
      if (!arr.some(a => _cwKey(a.week, a.year) === key)) {
        arr.push({
          week:       wk,
          year:       yr,
          closedDate: r.closedDate || r.closed_date || '',
          owner:      r.owner || '',
          title:      r.title || '',
          status:     r.status || '',
          severity:   r.severity || '',
        });
      }
    }

    // 1. Seed data (if accessible via DashWeeklyTracker._seed or window._WT_SEED)
    const seed = (typeof window._WT_SEED !== 'undefined' && window._WT_SEED)
              || (typeof DashWeeklyTracker !== 'undefined' && DashWeeklyTracker._seed);
    if (seed && typeof seed === 'object') {
      Object.entries(seed).forEach(([yr, weeks]) => {
        if (!weeks || typeof weeks !== 'object') return;
        Object.entries(weeks).forEach(([wk, rows]) => {
          (Array.isArray(rows) ? rows : []).forEach(r => _addRow(r, parseInt(yr), wk));
        });
      });
    }

    // 2. localStorage tracker data
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (!k || !k.startsWith(STORE_PREFIX)) continue;
      const yr = parseInt(k.replace(STORE_PREFIX, ''), 10);
      if (isNaN(yr)) continue;
      const yearData = _ldy(yr);
      Object.entries(yearData).forEach(([wk, rows]) => {
        (Array.isArray(rows) ? rows : []).forEach(r => _addRow(r, yr, wk));
      });
    }

    // Sort each case's appearances chronologically (earliest first)
    byCase.forEach((appearances, cn) => {
      appearances.sort((a, b) => {
        const ka = _cwKey(a.week, a.year);
        const kb = _cwKey(b.week, b.year);
        return ka < kb ? -1 : ka > kb ? 1 : 0;
      });
    });

    return byCase;
  }

  // ── Build grayout set from appearances map ────────────────────────────────────

  function _buildGrayoutSet(byCase) {
    const grayoutSet = new Map();
    byCase.forEach((appearances, cn) => {
      if (appearances.length < 2) return; // only one week — nothing to gray out
      // The last entry is the "active" (latest) week — all earlier ones get grayed
      const latestApp = appearances[appearances.length - 1];
      for (let i = 0; i < appearances.length - 1; i++) {
        const app = appearances[i];
        const key = `${cn}|${app.week}|${app.year}`;
        grayoutSet.set(key, {
          caseNumber: cn,
          week:       app.week,
          year:       app.year,
          laterWeek:  latestApp.week,
          laterYear:  latestApp.year,
          owner:      app.owner || latestApp.owner,
          title:      app.title || latestApp.title,
        });
      }
    });
    return grayoutSet;
  }

  // ── Ensure cache is fresh ─────────────────────────────────────────────────────

  function _ensureCache() {
    const ver = _computeVersion();
    if (_cachedAppearances && _cachedVersion === ver) return; // still fresh

    _cachedAppearances = _scanAllWeeks();
    _cachedVersion     = ver;
    _grayoutSet        = _buildGrayoutSet(_cachedAppearances);

    // Also update the localStorage history for all newly-detected cross-week cases
    _syncHistoryRecords(_cachedAppearances);
  }

  // ── Sync history records ──────────────────────────────────────────────────────
  // Adds a history entry for each case that appears in 2+ weeks, so it shows
  // in the History tab and the Reopened tab's computed list.

  function _syncHistoryRecords(byCase) {
    const h    = _loadHistory();
    let changed = false;

    byCase.forEach((appearances, cn) => {
      if (appearances.length < 2) return;

      if (!h[cn]) {
        h[cn] = { caseNumber: cn, owner: appearances[0].owner, entries: [] };
        changed = true;
      }

      // Record history for every reopening (2nd+ appearance)
      for (let i = 1; i < appearances.length; i++) {
        const prev = appearances[i - 1];
        const curr = appearances[i];
        const seedId = `cwg_reopen_${cn}_${curr.year}_${curr.week}`;

        // Skip if already recorded
        if (h[cn].entries.some(e => e._seedId === seedId)) continue;

        h[cn].owner = curr.owner || prev.owner || h[cn].owner;
        h[cn].entries.unshift({
          _seedId:      seedId,
          ts:           (() => {
            try {
              const d = curr.closedDate ? new Date(curr.closedDate) : new Date();
              return isNaN(d) ? new Date().toISOString() : d.toISOString();
            } catch(e) { return new Date().toISOString(); }
          })(),
          week:         curr.week,
          year:         curr.year,
          statusBefore: prev.status || 'Closed by IBM',
          statusAfter:  curr.status || 'Reopened',
          commentBefore:'',
          commentAfter: `Case appeared again in ${curr.week} ${curr.year} (was grayed out from ${prev.week} ${prev.year})`,
          changedBy:    'cross-week-detection',
          isReopen:     true,
          prevWeek:     prev.week,
          prevYear:     prev.year,
        });
        // Cap entries per case
        if (h[cn].entries.length > 50) h[cn].entries = h[cn].entries.slice(0, 50);
        changed = true;
      }
    });

    if (changed) _saveHistory(h);
  }

  // ── DB grayout fetch ──────────────────────────────────────────────────────────
  // Fetches all grayout states in ONE bulk call from the backend.

  async function _fetchDbGrayouts() {
    if (_dbFetchPending) return;
    _dbFetchPending = true;
    try {
      // Collect all case+week+year combos currently visible on screen
      const rows = document.querySelectorAll('tr[data-case-number][data-week][data-year]');
      if (!rows.length) { _dbFetchPending = false; return; }

      const combos = [];
      const seen = new Set();
      rows.forEach(tr => {
        const cn   = tr.dataset.caseNumber;
        const week = tr.dataset.week;
        const year = tr.dataset.year;
        const k = `${cn}|${week}|${year}`;
        if (cn && week && year && !seen.has(k)) {
          seen.add(k);
          combos.push({ caseNumber: cn, week, year: parseInt(year) });
        }
      });

      if (!combos.length) { _dbFetchPending = false; return; }

      // Try the bulk endpoint first (new); fall back to individual calls
      let usedBulk = false;
      try {
        const resp = await fetch((window.API_BASE_V2 || '/iip/api/v2') + '/grayout-bulk', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ combos }),
        });
        if (resp.ok) {
          const data = await resp.json();
          const states = data.states || {};
          _dbGrayoutMap = new Map();
          Object.entries(states).forEach(([k, v]) => {
            if (v && v.isGrayed) _dbGrayoutMap.set(k, v);
          });
          usedBulk = true;
        }
      } catch(e) {}

      // Fallback: individual per-row calls (existing behaviour)
      if (!usedBulk) {
        _dbGrayoutMap = new Map();
        await Promise.all(combos.map(async ({ caseNumber, week, year }) => {
          try {
            const resp = await fetch(`${window.API_BASE_V2 || "/iip/api/v2"}/grayout/${encodeURIComponent(caseNumber)}/${encodeURIComponent(week)}/${year}`);
            if (!resp.ok) return;
            const state = await resp.json();
            if (state && state.isGrayed) {
              _dbGrayoutMap.set(`${caseNumber}|${week}|${year}`, state);
            }
          } catch(e) {}
        }));
      }

      // Re-apply after DB data arrives
      _applyToVisibleRows(true);
    } finally {
      _dbFetchPending = false;
    }
  }

  // ── Row styling ───────────────────────────────────────────────────────────────

  /**
   * Apply (or refresh) grayout styling to all <tr> rows currently in the DOM.
   * @param {boolean} [force] - if true, re-process even rows already marked.
   */
  function _applyToVisibleRows(force) {
    _ensureCache(); // make sure scan is up-to-date

    const rows = document.querySelectorAll(
      '#wt-table-wrap tr[data-case-number][data-week][data-year]'
    );

    rows.forEach(tr => {
      if (!force && tr.hasAttribute(GRAYOUT_ATTR)) return; // already processed

      const cn   = tr.dataset.caseNumber;
      const week = tr.dataset.week;
      const year = tr.dataset.year;
      if (!cn || !week || !year) return;

      const rowKey = `${cn}|${week}|${year}`;

      // Determine if this row should be grayed — either from localStorage scan or DB
      const lsGrayout = _grayoutSet.get(rowKey);
      const dbGrayout = _dbGrayoutMap.get(rowKey);
      const rowLaterWeek = tr.dataset.laterWeek || '';
      const rowLaterYear = parseInt(tr.dataset.laterYear || year);
      const rowGrayout = rowLaterWeek ? { caseNumber: cn, week, year: parseInt(year), laterWeek: rowLaterWeek, laterYear: rowLaterYear } : null;
      const grayout   = lsGrayout || rowGrayout || (dbGrayout ? { ...dbGrayout, caseNumber: cn, week, year: parseInt(year), laterWeek: dbGrayout.metadata?.closedAgainIn || '?' } : null);

      // Remove any previous grayout styling before (re-)applying
      _clearRowGrayout(tr);

      if (grayout) {
        _applyRowGrayout(tr, grayout);
      }

      tr.setAttribute(GRAYOUT_ATTR, grayout ? '1' : '0');
    });
  }

  function _clearRowGrayout(tr) {
    tr.classList.remove('wt-row-grayed');
    tr.removeAttribute(GRAYOUT_ATTR);
    // Remove any injected badge elements
    tr.querySelectorAll('.wt-cwg-badge').forEach(el => el.remove());
  }

  function _applyRowGrayout(tr, grayout) {
    tr.classList.add('wt-row-grayed');

    // Inject a small "moved to Wxx" badge into the case number cell (3rd column = td:nth-child(4))
    const cnCell = tr.querySelector('td:nth-child(4)');
    if (cnCell && !cnCell.querySelector('.wt-cwg-badge')) {
      const badge = document.createElement('div');
      badge.className = 'wt-cwg-badge';
      const laterLabel = grayout.laterYear && grayout.laterYear !== parseInt(grayout.year)
        ? `${grayout.laterWeek} ${grayout.laterYear}`
        : grayout.laterWeek || '?';
      badge.innerHTML = `
        <span class="wt-cwg-badge-inner" title="This case also appears in ${laterLabel}. The earlier week is grayed out — only the latest week (${laterLabel}) is considered active."
          onclick="event.stopPropagation(); if(typeof DashWeeklyTracker!=='undefined'){DashWeeklyTracker._setYear(${grayout.laterYear||grayout.year}); DashWeeklyTracker._navClick('${grayout.laterWeek||''}')}"
          style="cursor:${grayout.laterWeek ? 'pointer' : 'default'}">
          ↺ moved → ${laterLabel}
        </span>`;
      cnCell.appendChild(badge);
    }
  }


  // ── Push localStorage-detected reopenings to backend ─────────────────────────
  // Called once per page load from applyGrayout(). Sends all cross-week cases
  // to POST /api/reopened/sync so the DB tables stay in sync with localStorage.
  // Idempotent on the backend (ON CONFLICT DO UPDATE). No-op if already done.

  async function _pushToBackend() {
    if (_dbSyncDone) return;
    _dbSyncDone = true;           // optimistic — prevent double-fire

    _ensureCache();
    const crossWeek = getCrossWeekCases();
    if (!crossWeek.size) return;

    const payload = [];
    crossWeek.forEach((appearances, cn) => {
      payload.push({
        caseNumber:  cn,
        appearances: appearances.map(a => ({
          week:       a.week,
          year:       a.year,
          closedDate: a.closedDate || '',
          status:     a.status     || '',
          owner:      a.owner      || '',
          title:      a.title      || '',
          severity:   a.severity   || '',
        })),
      });
    });

    try {
      const resp = await fetch((window.API_BASE_V2 || '/iip/api/v2') + '/reopened/sync', {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ cases: payload }),
      });
      if (!resp.ok) {
        _dbSyncDone = false;   // allow retry next render if transient error
        console.warn('[WTCrossWeekGrayout] /api/reopened/sync failed:', resp.status);
      }
    } catch(e) {
      _dbSyncDone = false;     // allow retry
      console.warn('[WTCrossWeekGrayout] /api/reopened/sync error:', e);
    }
  }

  // ── Public API ────────────────────────────────────────────────────────────────

  /**
   * Main entry point. Call this after every _renderTable() call.
   * Applies grayout synchronously from cache, then fetches DB states async.
   */
  let _applyGrayoutTimer = null;
  function applyGrayout() {
    _ensureCache();
    _applyToVisibleRows(false);
    // Debounce: if multiple renders fire in quick succession (e.g. startup),
    // only fire one grayout-bulk request after the dust settles (150ms).
    clearTimeout(_applyGrayoutTimer);
    _applyGrayoutTimer = setTimeout(() => {
      _fetchDbGrayouts().catch(() => {});
      // Push localStorage-detected reopenings to DB (once per page load)
      _pushToBackend().catch(() => {});
    }, 150);
  }

  /**
   * Invalidate cache (call when new data is uploaded or localStorage changes).
   */
  function invalidate() {
    _cachedAppearances = null;
    _cachedVersion     = null;
    _grayoutSet        = new Map();
    _dbGrayoutMap      = new Map();
    _dbSyncDone        = false;   // re-push after data changes
  }

  /**
   * Returns the full appearances map (for use by Reopened tab renderer).
   * Map<caseNumber, Array<appearance>>  — only cases with 2+ appearances.
   */
  function getCrossWeekCases() {
    _ensureCache();
    const result = new Map();
    _cachedAppearances.forEach((appearances, cn) => {
      if (appearances.length >= 2) result.set(cn, appearances);
    });
    return result;
  }

  /**
   * Check if a specific case+week+year combo is grayed out.
   */
  function isGrayed(caseNumber, week, year) {
    _ensureCache();
    return _grayoutSet.has(`${caseNumber}|${week}|${year}`)
        || _dbGrayoutMap.has(`${caseNumber}|${week}|${year}`);
  }

  // ── Init ──────────────────────────────────────────────────────────────────────
  // CSS is in css/features/weekly-tracker.css — no inline injection needed.

  // Expose public API
  window.WTCrossWeekGrayout = {
    applyGrayout,
    invalidate,
    getCrossWeekCases,
    isGrayed,
    // Internal helpers exposed for testing
    _scanAllWeeks,
    _buildGrayoutSet,
    _syncHistoryRecords,
    _pushToBackend,
  };

}(window));