const AdminBootstrapLoader = (() => {
  let _data = null;
  let _loading = false;
  
  async function load() {
    if (_data) return _data;
    if (_loading) return null;
    
    _loading = true;
    try {
      const raw = await AdminAPIClient.bootstrap();
      
      _data = {
        team_members: raw.team_members || [],
        escalation_contacts: {
          bd: (raw.escalation_contacts || []).filter(c => c.group_name === 'BD Escalation'),
          ec: (raw.escalation_contacts || []).filter(c => c.group_name === 'IBM Escalation'),
          tl: (raw.escalation_contacts || []).filter(c => c.group_name === 'Team Lead')
        },
        ibm_contacts: (raw.ibm_contacts || []).reduce((acc, c) => {
          if (!acc[c.group_name]) acc[c.group_name] = [];
          acc[c.group_name].push(c);
          return acc;
        }, {}),
        alm_lines: raw.alm_lines || [],
        timestamp: raw.timestamp
      };
      
      if (typeof DynamicConfig !== 'undefined') { DynamicConfig._injectAlmLines(_data.alm_lines || []); }
      console.log('✓ Bootstrap loaded:', _data);
      window.AdminAppData = _data;
      return _data;
    } catch (err) {
      console.error('Bootstrap failed:', err);
      throw err;
    } finally {
      _loading = false;
    }
  }
  
  function clear() {
    _data = null;
    delete window.AdminAppData;
  }
  
  return { load, clear, get data() { return _data; } };
})();
