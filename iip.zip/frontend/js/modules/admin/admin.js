/* ============================================================
   js/modules/admin/admin.js  —  Admin Module  v2.0.0
   ────────────────────────────────────────────────────────────
   v2.0.0 changes:
   • Removed static API Admin Token — sessions are now issued
     by the server at login and stored in sessionStorage only.
   • Added Forgot Password flow: security questions → reset.
   • Logout now calls POST /api/auth/logout to revoke the token.
   ============================================================ */
const Admin = (() => {
  'use strict';

  // Derive API base — try origin-level /api first (works when reverse proxy strips the
  // app subfolder prefix, e.g. nginx maps /iip/api/ → localhost:8000/api/).
  // Falls back to __APP_BASE__+/api for fully-qualified proxy setups.

  const ADMIN_TOKEN_KEY = 'ibm_admin_token_v1';
  const SESSION_KEY     = 'ibm_admin_session_v1';

  let _role  = 'write';
  let _actor = 'Admin';

  // ── Token helpers (sessionStorage only) ──────────────────────
  function _getSessionToken() {
    try { return sessionStorage.getItem(ADMIN_TOKEN_KEY) || ''; }
    catch(e) { return ''; }
  }
  function _setSessionToken(token) {
    try {
      sessionStorage.setItem(ADMIN_TOKEN_KEY, token);
      try { localStorage.removeItem(ADMIN_TOKEN_KEY); } catch(e) {}
      try { localStorage.removeItem('ibm_admin_token_v1'); } catch(e) {}
    } catch(e) {}
  }
  function _clearSessionToken() {
    try { sessionStorage.removeItem(ADMIN_TOKEN_KEY); } catch(e) {}
    try { sessionStorage.removeItem(SESSION_KEY); } catch(e) {}
  }

  async function _isFirstTimeSetup() {
    try {
      const r = await fetch(API_BASE + '/auth/status');
      if (!r.ok) return true;
      const data = await r.json();
      return !data.configured;
    } catch(e) {
      return true;
    }
  }

  function updateHeader() {
    const adminBtn = document.getElementById('admin-btn');
    const isAdmin  = (typeof Data !== 'undefined') ? Data.isAdmin() : false;
    if (adminBtn) adminBtn.style.display = isAdmin ? 'flex' : 'none';
  }

  // ── Shared modal scaffold ─────────────────────────────────────
  function _makeModal(innerHtml) {
    const existing = document.getElementById('admin-login-modal');
    if (existing) existing.remove();
    const modal = document.createElement('div');
    modal.id = 'admin-login-modal';
    modal.style.cssText = [
      'position:fixed;inset:0;z-index:var(--z-modal)',
      'display:flex;align-items:center;justify-content:center;padding-bottom:5vh',
      'background:var(--bg-page,#f0f2f5)'
    ].join(';');
    modal.innerHTML = innerHtml;
    document.body.appendChild(modal);
    modal.addEventListener('click', e => { if (e.target === modal) modal.remove(); });
    return modal;
  }

  function _showErr(el, msg) {
    el.textContent = msg;
    el.style.display = '';
  }
  function _hideErr(el) { el.style.display = 'none'; }

  // ── INPUT STYLE (reused) ──────────────────────────────────────
  const INP = 'width:100%;padding:9px 12px;border:1px solid var(--border-mid);border-radius:var(--radius-sm);font-size:14px;margin-bottom:10px;box-sizing:border-box;background:var(--bg-input);color:var(--text-primary)';
  const BOX = 'background:var(--bg-ui);border-radius:var(--radius-lg);padding:32px 36px;box-shadow:var(--shadow-xl)';

  // ── Main login modal ──────────────────────────────────────────
  async function showLoginModal() {
    // Redirect to standalone admin login page
    try { var _b=(typeof window.__APP_BASE__==="string")?window.__APP_BASE__:"/"; var _bp; try{_bp=new URL(_b).pathname.replace(/\/$/,"");}catch(e){_bp="";} window.location.href=_bp+"/admin/"; } catch(e){} return;
    const isSetup = await _isFirstTimeSetup();

    if (isSetup) {
      _showSetupModal();
    } else {
      _showLoginForm();
    }
  }

  // First-time setup (no password yet) — no token field
  function _showSetupModal() {
    const modal = _makeModal(`
      <div style="${BOX};width:380px">
        <h3 style="margin:0 0 6px;font-size:16px;font-weight:700;color:var(--text-primary)">Admin Setup</h3>
        <p style="margin:0 0 18px;font-size:13px;color:var(--text-secondary);line-height:1.5">
          No admin password has been configured. Set one now to secure the Admin Portal.
        </p>
        <input id="admin-pwd-new" aria-label="New password" type="password" placeholder="New password (min 8 characters)" style="${INP}"/>
        <input id="admin-pwd-confirm" aria-label="Confirm password" type="password" placeholder="Confirm password"                style="${INP}"/>
        <div id="admin-login-err" style="color:var(--red);font-size:12px;margin-bottom:10px;display:none"></div>
        <div style="display:flex;gap:8px;justify-content:flex-end">
          <button id="admin-login-cancel" class="btn btn-ghost btn-sm">Cancel</button>
          <button id="admin-login-submit" class="btn btn-primary btn-sm">Set Password</button>
        </div>
      </div>`);

    const errEl  = modal.querySelector('#admin-login-err');
    const submit = modal.querySelector('#admin-login-submit');
    const newPwd = modal.querySelector('#admin-pwd-new');
    const confPwd = modal.querySelector('#admin-pwd-confirm');

    modal.querySelector('#admin-login-cancel').addEventListener('click', () => modal.remove());

    const _attempt = async () => {
      const np = newPwd.value, cp = confPwd.value;
      if (np.length < 8) { _showErr(errEl, 'Password must be at least 8 characters.'); return; }
      if (np !== cp)     { _showErr(errEl, 'Passwords do not match.'); return; }
      submit.disabled = true; submit.textContent = 'Setting…';
      try {
        const r = await fetch(API_BASE + '/auth/set-password', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ currentPassword: '', newPassword: np })
        });
        const data = await r.json();
        if (!r.ok) { _showErr(errEl, data.detail || data.error || 'Failed to set password.'); submit.disabled = false; submit.textContent = 'Set Password'; return; }

        // Auto-login after setup
        const lr = await fetch(API_BASE + '/auth', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ password: np })
        });
        const ldata = await lr.json();
        if (lr.ok && ldata.token) {
          _setSessionToken(ldata.token);
          _onLoginSuccess(ldata.token);
          modal.remove();
        } else {
          _showErr(errEl, ldata.detail || ldata.error || 'Setup succeeded but login failed. Reload and try.');
        }
      } catch(e) {
        _showErr(errEl, 'Network error. API: ' + API_BASE);
      }
      submit.disabled = false; submit.textContent = 'Set Password';
    };

    submit.addEventListener('click', _attempt);
    confPwd.addEventListener('keydown', e => { if (e.key === 'Enter') _attempt(); });
    setTimeout(() => newPwd.focus(), 50);
  }

  // Normal login form
  function _showLoginForm() {
    const modal = _makeModal(`
      <div style="${BOX};width:340px">
        <h3 style="margin:0 0 20px;font-size:16px;font-weight:700;color:var(--text-primary)">Admin Login</h3>
        <input id="admin-pwd-input" aria-label="Password" type="password" placeholder="Password" style="${INP}"/>
        <div id="admin-login-err" style="color:var(--red);font-size:12px;margin-bottom:10px;display:none">Incorrect password</div>
        <div style="display:flex;gap:8px;justify-content:flex-end;align-items:center">
          <button id="admin-forgot-btn" class="btn btn-ghost btn-sm" style="margin-right:auto;font-size:12px;color:var(--text-secondary)">Reset via Security Question</button>
          <button id="admin-login-cancel" class="btn btn-ghost btn-sm">Cancel</button>
          <button id="admin-login-submit" class="btn btn-primary btn-sm">Login</button>
        </div>
      </div>`);

    const errEl  = modal.querySelector('#admin-login-err');
    const submit = modal.querySelector('#admin-login-submit');
    const input  = modal.querySelector('#admin-pwd-input');

    modal.querySelector('#admin-login-cancel').addEventListener('click', () => modal.remove());
    modal.querySelector('#admin-forgot-btn').addEventListener('click', () => {
      modal.remove();
      _showForgotPasswordModal();
    });

    const _attempt = async () => {
      const pwd = input.value;
      if (!pwd) return;
      submit.disabled = true; submit.textContent = 'Checking…';
      try {
        const r = await fetch(API_BASE + '/auth', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ password: pwd })
        });
        const data = await r.json();
        if (r.ok && data.token) {
          _setSessionToken(data.token);
          modal.remove();
          _onLoginSuccess(data.token);
        } else {
          _showErr(errEl, data.detail || data.error || 'Incorrect password.');
          input.value = ''; input.focus();
        }
      } catch(e) {
        _showErr(errEl, 'Server unreachable. API: ' + API_BASE);
      }
      submit.disabled = false; submit.textContent = 'Login';
    };

    submit.addEventListener('click', _attempt);
    input.addEventListener('keydown', e => { if (e.key === 'Enter') _attempt(); });
    setTimeout(() => input.focus(), 50);
  }

  // ── Forgot Password — Security Questions reset ────────────────
  async function _showForgotPasswordModal() {
    // Fetch configured questions from the server
    let q1 = '', q2 = '', configured = false;
    try {
      const r = await fetch(API_BASE + '/auth/security-questions');
      const data = await r.json();
      if (data.configured && data.questions) {
        q1 = data.questions.q1 || '';
        q2 = data.questions.q2 || '';
        configured = true;
      }
    } catch(e) {}

    if (!configured) {
      const modal = _makeModal(`
        <div style="${BOX};width:360px">
          <h3 style="margin:0 0 12px;font-size:16px;font-weight:700;color:var(--text-primary)">Security Questions Not Set</h3>
          <p style="margin:0 0 16px;font-size:13px;color:var(--text-secondary);line-height:1.5">
            Security questions have not been configured yet. Please log in and set them up from the Admin Portal.
          </p>
          <div style="display:flex;gap:8px;justify-content:flex-end">
            <button id="admin-sq-back" class="btn btn-primary btn-sm">Back to Login</button>
          </div>
        </div>`);
      modal.querySelector('#admin-sq-back').addEventListener('click', () => {
        modal.remove();
        _showLoginForm();
      });
      return;
    }

    const modal = _makeModal(`
      <div style="${BOX};width:400px">
        <h3 style="margin:0 0 6px;font-size:16px;font-weight:700;color:var(--text-primary)">Reset Password</h3>
        <p style="margin:0 0 16px;font-size:13px;color:var(--text-secondary);line-height:1.5">
          Answer the security questions below to reset your admin password.
        </p>
        <div style="margin-bottom:12px">
          <label style="font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:0.5px;color:var(--text-tertiary);display:block;margin-bottom:5px">Question 1</label>
          <div style="font-size:13px;font-weight:500;color:var(--text-primary);margin-bottom:6px">${_escHtml(q1)}</div>
          <input id="admin-sq-a1" aria-label="Security answer 1" type="text" placeholder="Your answer" style="${INP}" autocomplete="off"/>
        </div>
        <div style="margin-bottom:12px">
          <label style="font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:0.5px;color:var(--text-tertiary);display:block;margin-bottom:5px">Question 2</label>
          <div style="font-size:13px;font-weight:500;color:var(--text-primary);margin-bottom:6px">${_escHtml(q2)}</div>
          <input id="admin-sq-a2" aria-label="Security answer 2" type="text" placeholder="Your answer" style="${INP}" autocomplete="off"/>
        </div>
        <input id="admin-sq-newpwd" aria-label="New password" type="password" placeholder="New password (min 8 characters)" style="${INP}"/>
        <input id="admin-sq-confpwd" aria-label="Confirm new password" type="password" placeholder="Confirm new password" style="${INP}"/>
        <div id="admin-sq-err" style="color:var(--red);font-size:12px;margin-bottom:10px;display:none"></div>
        <div style="display:flex;gap:8px;justify-content:flex-end;align-items:center">
          <button id="admin-sq-back" class="btn btn-ghost btn-sm" style="margin-right:auto">Back to Login</button>
          <button id="admin-sq-submit" class="btn btn-primary btn-sm">Reset Password</button>
        </div>
      </div>`);

    const errEl   = modal.querySelector('#admin-sq-err');
    const submit  = modal.querySelector('#admin-sq-submit');
    const a1Inp   = modal.querySelector('#admin-sq-a1');
    const a2Inp   = modal.querySelector('#admin-sq-a2');
    const newPwd  = modal.querySelector('#admin-sq-newpwd');
    const confPwd = modal.querySelector('#admin-sq-confpwd');

    modal.querySelector('#admin-sq-back').addEventListener('click', () => {
      modal.remove();
      _showLoginForm();
    });

    const _attempt = async () => {
      const ans1 = a1Inp.value.trim();
      const ans2 = a2Inp.value.trim();
      const np   = newPwd.value;
      const cp   = confPwd.value;
      if (!ans1 || !ans2)  { _showErr(errEl, 'Please answer both security questions.'); return; }
      if (np.length < 8)   { _showErr(errEl, 'New password must be at least 8 characters.'); return; }
      if (np !== cp)       { _showErr(errEl, 'Passwords do not match.'); return; }

      submit.disabled = true; submit.textContent = 'Verifying…';
      try {
        const r = await fetch(API_BASE + '/auth/reset-via-security', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ q1, a1: ans1, q2, a2: ans2, newPassword: np })
        });
        const data = await r.json();
        if (r.ok && data.token) {
          _setSessionToken(data.token);
          modal.remove();
          _onLoginSuccess(data.token);
          try {
            if (typeof Toast !== 'undefined') Toast.success('Password reset successfully. You are now logged in.');
          } catch(e) {}
        } else {
          _showErr(errEl, data.detail || data.error || 'Incorrect answers. Try again.');
          a1Inp.value = ''; a2Inp.value = ''; a1Inp.focus();
        }
      } catch(e) {
        _showErr(errEl, 'Network error. Check server connection.');
      }
      submit.disabled = false; submit.textContent = 'Reset Password';
    };

    submit.addEventListener('click', _attempt);
    confPwd.addEventListener('keydown', e => { if (e.key === 'Enter') _attempt(); });
    setTimeout(() => a1Inp.focus(), 50);
  }

  function _escHtml(s) {
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  }

  // ── Post-login ────────────────────────────────────────────────
  function _onLoginSuccess(token) {
    if (typeof Data !== 'undefined') Data.setAdminMode(true);
    try { sessionStorage.setItem(SESSION_KEY, '1'); } catch(e) {}
    if (token) _setSessionToken(token);
    updateHeader();
    try { if (typeof App !== 'undefined') App.renderTab('admin'); } catch(e) {}
  }

  // ── Logout — also revokes server-side session ─────────────────
  async function logout() {
    const token = _getSessionToken();
    if (typeof Data !== 'undefined') Data.setAdminMode(false);
    _clearSessionToken();
    updateHeader();
    try { if (typeof App !== 'undefined') App.renderTab('overview'); } catch(e) {}
    // Fire-and-forget server-side revoke
    if (token) {
      try {
        await fetch(API_BASE + '/auth/logout', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'X-IIP-Admin-Token': token }
        });
      } catch(e) { /* ignore — local session already cleared */ }
    }
  }

  // ── Change password ───────────────────────────────────────────
  async function changePassword(currentPwd, newPwd) {
    if (newPwd.length < 8) return { ok: false, error: 'New password must be at least 8 characters' };
    try {
      const token = _getSessionToken();
      const r = await fetch(API_BASE + '/auth/set-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-IIP-Admin-Token': token },
        body: JSON.stringify({ currentPassword: currentPwd, newPassword: newPwd })
      });
      const data = await r.json();
      if (r.ok) { return { ok: true }; }
      return { ok: false, error: data.detail || data.error || 'Failed to change password.' };
    } catch(e) {
      return { ok: false, error: 'Server unreachable. Password change requires a server connection.' };
    }
  }

  // ── Wire up nav buttons ───────────────────────────────────────
  function _wireAdminBtn() {
    const btn = document.getElementById('admin-btn');
    if (!btn) return;
    btn.addEventListener('click', () => {
      if (typeof Data !== 'undefined' && Data.isAdmin()) logout();
      else showLoginModal();
    });
  }

  function _wireAdminNavItem() {
    const navBtn = document.getElementById('nav-admin-portal');
    if (!navBtn) return;
    navBtn.addEventListener('click', e => {
      if (typeof Data !== 'undefined' && !Data.isAdmin()) {
        e.stopImmediatePropagation();
        showLoginModal();
      }
    }, true);
  }

  function setDirtyGuard() {}
  async function checkSession() { return false; }

  let _initialized = false;
  async function init() {
    if (_initialized) { updateHeader(); return; }  // idempotent — safe to call multiple times
    _initialized = true;
    updateHeader();
    _wireAdminBtn();
    _wireAdminNavItem();
    // Restore admin session from sessionStorage (survives F5, not tab close)
    try {
      if (sessionStorage.getItem(SESSION_KEY) === '1') {
        // Validate token with backend before restoring session (prevents stale-session ghost login)
        const _tok = _getSessionToken();
        let _verified = false;
        try {
          const _vr = await fetch(API_BASE + '/auth/verify', {
            headers: _tok ? { 'X-IIP-Admin-Token': _tok } : {}
          });
          const _vd = _vr.ok ? await _vr.json() : {};
          _verified = !!_vd.authenticated;
        } catch(e) { _verified = false; }
        if (!_verified) {
          sessionStorage.removeItem(SESSION_KEY);
          sessionStorage.removeItem(ADMIN_TOKEN_KEY);
          updateHeader();
          return;
        }
        if (typeof Data !== 'undefined') Data.setAdminMode(true);
        updateHeader();
      }
    } catch(e) {}
  }

  return { init, updateHeader, showLoginModal, logout, checkSession, changePassword, getActor: () => _actor, getRole: () => _role, isWriter: () => true, setDirtyGuard, getToken: _getSessionToken };
})();

// Auto-initialize when this module is lazy-loaded (e.g. on first Admin Portal visit).
// Without this, Admin.init() would never run after a page refresh while already logged in,
// leaving the logout button hidden (CSS: #admin-btn { display: none }).
Admin.init().catch(() => {});
