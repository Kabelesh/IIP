const AdminSSEListener = (() => {
  let _eventSource = null;
  
  function connect() {
    if (_eventSource) return;
    try {
      _eventSource = new EventSource((window.__APP_BASE__ || '/iip').replace(/\/$/, '') + '/api/events');
      _eventSource.addEventListener('data-updated', () => {
        document.dispatchEvent(new CustomEvent('iip-data-updated'));
        // Store reference so dashboards can attach directly
        window._iipSSE = _eventSource;
      });
      _eventSource.addEventListener('admin-updated', () => {
        document.dispatchEvent(new CustomEvent('iip-admin-updated'));
        delete window.AdminAppData;
        if (typeof DashAdmin !== 'undefined' && DashAdmin.render) {
          DashAdmin.render();
        }
      });
      _eventSource.onerror = () => {
        disconnect();
        setTimeout(connect, 3000);
      };
      console.log('✓ SSE connected');
    } catch (err) {
      console.error('SSE error:', err);
      setTimeout(connect, 3000);
    }
  }
  
  function disconnect() {
    if (_eventSource) {
      _eventSource.close();
      _eventSource = null;
    }
  }
  
  return { connect, disconnect };
})();
