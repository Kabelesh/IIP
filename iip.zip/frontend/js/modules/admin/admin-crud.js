const AdminCRUD = (() => {
  
  async function createTeamMember(name, email, team, status = 'Active') {
    return AdminAPIClient.createTeamMember({ name, email, team, status });
  }
  
  async function updateTeamMember(id, updates) {
    return AdminAPIClient.updateTeamMember(id, updates);
  }
  
  async function deleteTeamMember(id) {
    return AdminAPIClient.deleteTeamMember(id);
  }
  
  async function createEscalationContact(group_name, name, email) {
    return AdminAPIClient.createEscalationContact({ group_name, name, email });
  }
  
  async function updateEscalationContact(id, updates) {
    return AdminAPIClient.updateEscalationContact(id, updates);
  }
  
  async function deleteEscalationContact(id) {
    return AdminAPIClient.deleteEscalationContact(id);
  }
  
  async function createIBMContact(group_name, name, email) {
    return AdminAPIClient.createIBMContact({ group_name, name, email });
  }
  
  async function updateIBMContact(id, updates) {
    return AdminAPIClient.updateIBMContact(id, updates);
  }
  
  async function deleteIBMContact(id) {
    return AdminAPIClient.deleteIBMContact(id);
  }
  
  async function createALMLine(alm_line, customer_contact, customer_email, line_manager, line_manager_email) {
    return AdminAPIClient.createALMLine({
      alm_line, customer_contact, customer_email, line_manager, line_manager_email
    });
  }
  
  async function updateALMLine(alm_line, updates) {
    return AdminAPIClient.updateALMLine(alm_line, updates);
  }
  
  async function deleteALMLine(alm_line) {
    return AdminAPIClient.deleteALMLine(alm_line);
  }

  async function createELMUpgrade(elm_version, ifix_version, upgrade_date, notes) {
    return AdminAPIClient.createELMUpgrade({ elm_version, ifix_version, upgrade_date, notes });
  }

  async function updateELMUpgrade(id, updates) {
    return AdminAPIClient.updateELMUpgrade(id, updates);
  }

  async function deleteELMUpgrade(id) {
    return AdminAPIClient.deleteELMUpgrade(id);
  }

  return {
    createTeamMember, updateTeamMember, deleteTeamMember,
    createEscalationContact, updateEscalationContact, deleteEscalationContact,
    createIBMContact, updateIBMContact, deleteIBMContact,
    createALMLine, updateALMLine, deleteALMLine,
    createELMUpgrade, updateELMUpgrade, deleteELMUpgrade
  };
})();
