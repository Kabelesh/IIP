/* ============================================================
   js/modules/dynamic-config.js  —  Dynamic Configuration Layer
   Phase 5: fetches from /api/team-config on startup, caches in
   localStorage. Falls back to cache → AppData when offline.
   ============================================================ */

const DynamicConfig = (() => {
  const STORAGE_KEY = 'ibm_team_config_v1_cache';
  let _cfg = null;

  // ── Load: API → localStorage cache ───────────────────────
  async function load() {
    // 1. Try API
    try {
      const resp = await fetch(`${API_BASE}/team-config`);
      if (resp.ok) {
        const json = await resp.json();
        if (json.ok && json.data) {
          const teamCfg = json.data['ibm_team_config_v1'] || {};
          const adminCfg = json.data['admin-cfg'] || {};
          _cfg = { ...teamCfg, config: { ...(teamCfg.config || {}), ...adminCfg } };
          try { localStorage.setItem(STORAGE_KEY, JSON.stringify(_cfg)); } catch(e) {}
          return;
        }
      }
    } catch(e) { /* network error — fall through to cache */ }

    // 2. Fall back to localStorage cache
    try {
      const cached = localStorage.getItem(STORAGE_KEY);
      if (cached) { _cfg = JSON.parse(cached); return; }
    } catch(e) {}
  }

  // ── Save — merge patch and persist ───────────────────────
  async function save(patch) {
    _cfg = Object.assign(_cfg || {}, patch);
    // Cache key (local only — fast access)
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(_cfg)); } catch(e) {}
    // ibm_team_config_v1 is SHARED — storage.js interceptor syncs this to PostgreSQL
    try { localStorage.setItem('ibm_team_config_v1', JSON.stringify(_cfg)); } catch(e) {}
    // If config fields changed — persist to app_settings table via API
    if (patch.config) {
      try {
        const tok = sessionStorage.getItem('ibm_admin_token_v1') || '';
        const cfg = patch.config;
        await fetch(API_BASE + '/admin/app-settings', {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json', 'x-iip-admin-token': tok },
          body: JSON.stringify({
            app_title:            cfg.appTitle        || '',
            app_subtitle:         cfg.appSubtitle     || '',
            team_name:            cfg.teamName        || '',
            defect_base_url:      cfg.defectBaseUrl   || '',
            customer_account_id:  cfg.customerAccountId || '',
            case_number_pattern:  cfg.caseNumberPattern || '',
            sender_name:          cfg.senderName      || '',
            sla_target_pct:       String(cfg.slaTargetPct  || '80'),
            sla_closure_days:     String(cfg.slaClosureDays || '30'),
          })
        });
      } catch(e) { console.warn('[DynamicConfig] app-settings sync failed:', e); throw e; }
    }
  }

  function _injectAlmLines(rows) {
    _cfg = _cfg || {};
    _cfg.alm_lines = rows;
  }

  async function clear() {
    _cfg = null;
    try { localStorage.removeItem(STORAGE_KEY); } catch(e) {}
  }

  // ── Raw config access ─────────────────────────────────────
  function getRaw()   { return _cfg ? JSON.parse(JSON.stringify(_cfg)) : {}; }
  function isLoaded() { return _cfg !== null; }

  async function exportConfig() { return getRaw(); }

  // ── Team data getters ──────────────────────────────────────
  function teamMembers() {
    return (_cfg && Array.isArray(_cfg.teamMembers) && _cfg.teamMembers.length > 0)
      ? _cfg.teamMembers.map(m => m.name || m) : [];
  }

  function departedMembers() {
    return (_cfg && Array.isArray(_cfg.departedMembers) && _cfg.departedMembers.length > 0)
      ? _cfg.departedMembers.map(m => m.name || m) : [];
  }

  function teamEmails() {
    if (!_cfg || !_cfg.teamEmails) return {};
    return { ..._cfg.teamEmails };
  }

  function almResponsible() {
    if (_cfg && Array.isArray(_cfg.alm_lines) && _cfg.alm_lines.length > 0) {
      return _cfg.alm_lines.map(r => ({
        alm:        r.alm_line                     || "",
        bd:         r.line_manager                 || "",
        bdEmail:    r.line_manager_email           || "",
        ibm:        r.case_responsible             || "",
        ibmEmail:   r.case_responsible_email       || "",
        proxy:      r.case_responsible_proxy       || "",
        proxyEmail: r.case_responsible_proxy_email || "",
      }));
    }
    return (_cfg && Array.isArray(_cfg.almResponsible) && _cfg.almResponsible.length > 0)
      ? _cfg.almResponsible : [];
  }

  function customerContacts() {
    // Derive from almResponsible — team-config maps customer_contact/email into names/emails
    if (_cfg && Array.isArray(_cfg.almResponsible) && _cfg.almResponsible.length > 0) {
      return _cfg.almResponsible.map(r => ({
        line:   r.alm    || "",
        alm:    r.alm    || "",
        names:  r.names  || "",
        emails: r.emails || "",
      }));
    }
    return (_cfg && Array.isArray(_cfg.customerContacts) && _cfg.customerContacts.length > 0)
      ? _cfg.customerContacts : [];
  }

  function expertiseConnect() {
    return (_cfg && Array.isArray(_cfg.expertiseConnect) && _cfg.expertiseConnect.length > 0)
      ? _cfg.expertiseConnect : [];
  }

  function bdEscalation() {
    return (_cfg && Array.isArray(_cfg.bdEscalation) && _cfg.bdEscalation.length > 0)
      ? _cfg.bdEscalation : [];
  }

  function teamLead() {
    return (_cfg && Array.isArray(_cfg.teamLead) && _cfg.teamLead.length > 0)
      ? _cfg.teamLead : [];
  }

  function ibmDirectory() {
    if (_cfg && _cfg.ibmDirectory && Object.keys(_cfg.ibmDirectory).length > 0)
      return _cfg.ibmDirectory;
    return {};
  }

  function appConfig() {
    if (!_cfg || !_cfg.config) return {};
    return { ..._cfg.config };
  }

  // ── Case / product getters ────────────────────────────────
  function customerProducts() {
    if (_cfg && Array.isArray(_cfg.customerProducts) && _cfg.customerProducts.length > 0)
      return new Set(_cfg.customerProducts);
    return new Set([
      "Engineering Lifecycle Management Base",
      "Engineering Lifecycle Management Suite",
      "Engineering Requirements Management DOORS Next",
      "Engineering Test Management",
      "Engineering Workflow Management"
    ]);
  }

  function customerAccountId() {
    return (_cfg && _cfg.customerAccountId) || "881812";
  }

  function caseNumberPattern() {
    if (_cfg && _cfg.caseNumberPattern) {
      try { return new RegExp(_cfg.caseNumberPattern, 'i'); } catch(e) {}
    }
    return /^TS\d{8,}/i;
  }

  function teamGroups() {
    if (!_cfg || !_cfg.teamGroups) return {};
    return { ..._cfg.teamGroups };
  }

  function nameAliases() {
    const out = {};
    [...(_cfg && _cfg.teamMembers || []), ...(_cfg && _cfg.departedMembers || [])].forEach(m => {
      if (m && m.name && m.display_name) out[m.name.toLowerCase()] = m.display_name;
    });
    return out;
  }

  function csvFieldMap() {
    return (_cfg && _cfg.csvFieldMap) ? _cfg.csvFieldMap : null;
  }

  // ── Auto-detect helpers ───────────────────────────────────
  function detectNewOwners(rows) {
    const knownLower = new Set([
      ...teamMembers().map(n => n.toLowerCase()),
      ...Object.keys(nameAliases()),
    ]);
    const seen = new Set();
    const newOwners = [];
    rows.forEach(r => {
      const o = (r.Owner || '').trim();
      if (!o) return;
      const ol = o.toLowerCase();
      if (!knownLower.has(ol) && !seen.has(ol)) { seen.add(ol); newOwners.push(o); }
    });
    return newOwners;
  }

  function detectProducts(rows) {
    return [...new Set(rows.map(r => (r.Product || '').trim()).filter(Boolean))];
  }

  async function approveNewOwners(names) {
    const existing = teamMembers();
    const merged = [...new Set([...existing, ...names])];
    await save({ teamMembers: merged, teamEmails: teamEmails() });
    if (typeof Data !== 'undefined' && typeof Data.refreshTeamIndex === 'function') {
      Data.refreshTeamIndex();
    }
  }

  async function saveProducts(products) {
    await save({ customerProducts: products });
  }

  return {
    load, save, clear, exportConfig, getRaw, isLoaded, _injectAlmLines,
    teamMembers, departedMembers, teamEmails, almResponsible, customerContacts,
    expertiseConnect, bdEscalation, teamLead, ibmDirectory,
    appConfig, customerProducts, customerAccountId,
    caseNumberPattern, nameAliases, teamGroups, csvFieldMap,
    detectNewOwners, detectProducts, approveNewOwners, saveProducts,
  };
})();
