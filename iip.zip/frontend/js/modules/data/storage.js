/*  storage.js — IIPStore v3.0
 *  Lightweight localStorage wrapper.
 *  DB sync layer removed — all data served via /api/v2/* endpoints.
 */
(function () {
  'use strict';

  const _isFileMode = window.location.protocol === 'file:';

  /* ── Admin token ──────────────────────────────────────────────── */
  let _adminToken = '';
  function setAdminToken(token) { _adminToken = token || ''; }
  function getAdminToken()      { return _adminToken; }

  /* ── localStorage helpers ─────────────────────────────────────── */
  function _lsGet(key) {
    try {
      const r = localStorage.getItem(key);
      return r === null ? null : JSON.parse(r);
    } catch (_) { return null; }
  }
  function _lsSet(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (e) {
      console.warn('[IIPStore] localStorage write failed:', e.message);
      return false;
    }
  }
  function _lsSetRaw(key, rawStr) {
    try { localStorage.setItem(key, rawStr); } catch (e) {
      console.warn('[IIPStore] localStorage raw write failed:', key, e.message);
    }
  }
  function _lsDel(key) {
    try { localStorage.removeItem(key); } catch (_) {}
  }

  /* ── Boot hydration (no-op — all data via /api/v2/* endpoints) ── */
  async function hydrateFromDB() {}

  /* ── Public API ───────────────────────────────────────────────── */
  async function set(key, value) { _lsSet(key, value); return true; }
  async function get(key)        { return _lsGet(key); }
  function  getSync(key)         { return _lsGet(key); }
  async function remove(key)     { _lsDel(key); }

  const KEYS = {
    CASES_RAW:        'ibm_cases_raw_v1',
    CASES_OVERRIDES:  'ibm_cases_overrides_v1',
    REOPENED_CASES:   'ibm_reopened_cases_v1',
    TRACKER_PERSIST:  'ibm_tracker_persist_v1',
    TEAM_CONFIG:      'ibm_team_config_v1',
    TRACKER_COMMENTS: 'ibm_wtracker_comments_v1',
    IMPORT_LOG:       'ibm_import_log_v1',
    RFE_DATA:         'ibm_rfe_tracking_v1',
    RFE_META:         'ibm_rfe_tracking_metadata_v1',
    INVESTIGATE:      'ibm_investigate_archive_v1',
    PERF_COMMENTS:    'ibm_perf_comments_v1',
    DATA_VERSION:     'ibm_data_version_v1',
  };

  const setCases     = rows => set(KEYS.CASES_RAW, rows);
  const getCases     = ()   => get(KEYS.CASES_RAW).then(d => Array.isArray(d) ? d : null);
  const setOverrides = ov   => set(KEYS.CASES_OVERRIDES, ov);
  const getOverrides = ()   => get(KEYS.CASES_OVERRIDES).then(d => (d && typeof d === 'object') ? d : {});
  const setReopened  = arr  => set(KEYS.REOPENED_CASES, arr);
  const getReopened  = ()   => get(KEYS.REOPENED_CASES).then(d => Array.isArray(d) ? d : []);

  const setDataVersion = (ts) => set(KEYS.DATA_VERSION, ts || Date.now());
  const getDataVersion = () => {
    const base = typeof window.__APP_BASE__ !== 'undefined' ? window.__APP_BASE__.replace(/\/$/, '') : '';
    return fetch(base + '/api/v2/data-version', { cache: 'no-store' })
      .then(r => r.ok ? r.json() : null)
      .then(d => (d && d.versionTs) ? d.versionTs : null)
      .catch(() => null);
  };
  const getDataVersionSync = () => _lsGet(KEYS.DATA_VERSION);

  window.IIPStore = {
    set, get, getSync, remove,
    hydrateFromDB,
    setCases, getCases,
    setOverrides, getOverrides,
    setReopened, getReopened,
    setDataVersion, getDataVersion, getDataVersionSync,
    setAdminToken, getAdminToken,
    KEYS,
    mode:         _isFileMode ? 'local' : 'server',
    isFileMode:   () => _isFileMode,
    isServerMode: () => !_isFileMode,
    isShared:     () => false,
  };

}());
