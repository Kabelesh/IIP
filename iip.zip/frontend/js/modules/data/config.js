/* ================================================================
   js/modules/config.js  —  Application Config (startup defaults)
   ----------------------------------------------------------------
   Provides non-crashing defaults at initial load.
   DynamicConfig.appConfig() supersedes these after async DB load.
   ================================================================ */

const Config = (() => {

  return Object.freeze({
    TEAM_NAME:           "",
    APP_TITLE:           "IBM Cases",
    APP_SUBTITLE:        "IBM Case Intelligence Platform",
    DEFECT_BASE_URL:     "",
    IDLE_TIMEOUT_MS:     30 * 60 * 1000,
    IDLE_WARNING_MS:     27 * 60 * 1000,
    SESSION_MAX_AGE_MS:  30 * 60 * 1000,
    TABLE_PAGE_SIZE:     50,
    PERSIST_KEY_TRACKER: "ibm_tracker_persist_v1",
    PERSIST_KEY_KB:      "ibm_knowledge_base_v2",
    PERSIST_KEY_CASES:   "ibm_cases_raw_v1",
  });

})();
