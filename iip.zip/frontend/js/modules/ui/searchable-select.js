/* ================================================================
   searchable-select.js — IBM Case Intelligence Platform
   Unified searchable dropdown reusing .cs-* CSS classes so all
   dropdowns (plain + searchable) share the same look and feel.
================================================================ */

const SearchableSelect = (() => {

  let _openInstance = null;

  function _portal() {
    let p = document.getElementById('cs-portal');
    if (!p) {
      p = document.createElement('div');
      p.id = 'cs-portal';
      p.style.cssText = 'position:fixed;top:0;left:0;width:0;height:0;z-index:9999;pointer-events:none';
      document.body.appendChild(p);
    }
    return p;
  }

  function _position(triggerEl, panel) {
    const r     = triggerEl.getBoundingClientRect();
    const panH  = Math.min(300, panel.scrollHeight || 260);
    const below = window.innerHeight - r.bottom;
    const above = r.top;
    const openUp = below < panH + 8 && above > below;
    panel.style.left  = r.left + 'px';
    panel.style.width = Math.max(r.width, 240) + 'px';
    panel.style.pointerEvents = 'auto';
    if (openUp) {
      panel.style.top    = '';
      panel.style.bottom = (window.innerHeight - r.top) + 'px';
      panel.classList.add('cs-up');
    } else {
      panel.style.top    = (r.bottom + 2) + 'px';
      panel.style.bottom = '';
      panel.classList.remove('cs-up');
    }
  }

  function _closeOpen() {
    if (_openInstance) { _openInstance.close(); _openInstance = null; }
  }

  function create({ trigger, valueEl, members, onSelect, placeholder }) {
    placeholder = placeholder || '\u2014 Select \u2014';

    let wrapper = trigger.closest('.cs-wrapper');
    if (!wrapper) {
      wrapper = document.createElement('div');
      wrapper.className = 'cs-wrapper';
      trigger.parentNode.insertBefore(wrapper, trigger);
      wrapper.appendChild(trigger);
    }

    trigger.classList.add('cs-trigger');

    let chev = wrapper.querySelector('.cs-trigger-chev');
    if (!chev) {
      chev = document.createElement('span');
      chev.className = 'cs-trigger-chev';
      chev.innerHTML = '<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>';
      trigger.appendChild(chev);
    }

    const panel = document.createElement('div');
    panel.className = 'cs-drop';
    panel.style.cssText = [
      'display:none', 'position:fixed',
      'background:var(--bg-ui,#fff)',
      'border:1px solid var(--border-mid,#c6c6c6)',
      'border-radius:var(--radius-md,4px)',
      'box-shadow:0 4px 20px rgba(0,0,0,0.13),0 1px 4px rgba(0,0,0,0.06)',
      'z-index:9999', 'overflow:hidden', 'flex-direction:column',
      'max-height:300px', 'padding:0'
    ].join(';');

    const searchWrap = document.createElement('div');
    searchWrap.className = 'cs-search-wrap';
    const searchInput = document.createElement('input');
    searchInput.type = 'text';
    searchInput.className = 'form-input form-input-sm';
    searchInput.placeholder = 'Search\u2026';
    searchInput.autocomplete = 'off';
    searchInput.style.cssText = 'width:100%;box-sizing:border-box;';
    searchWrap.appendChild(searchInput);
    panel.appendChild(searchWrap);

    const listEl = document.createElement('div');
    listEl.style.cssText = 'overflow-y:auto;flex:1;padding:5px 0;scrollbar-width:thin;scrollbar-color:var(--border-mid) transparent;';
    panel.appendChild(listEl);

    _portal().appendChild(panel);

    function _renderList(q) {
      q = (q || '').toLowerCase();
      listEl.innerHTML = '';
      const groups = {};
      members.forEach(function(m) {
        const g = m.group || '';
        if (!groups[g]) groups[g] = [];
        groups[g].push(m);
      });
      let any = false;
      Object.entries(groups).forEach(function(entry) {
        const groupName = entry[0], items = entry[1];
        const filtered = items.filter(function(m) {
          return !q || m.label.toLowerCase().includes(q) || m.value.toLowerCase().includes(q);
        });
        if (!filtered.length) return;
        any = true;
        if (groupName) {
          const hdr = document.createElement('div');
          hdr.textContent = groupName;
          hdr.style.cssText = 'display:block;padding:4px 12px;font-size:10px;font-weight:700;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:.05em;border-top:1px solid var(--border-subtle);margin-top:2px;background:var(--bg-ui)';
          listEl.appendChild(hdr);
        }
        filtered.forEach(function(m) {
          const btn = document.createElement('button');
          btn.type = 'button';
          btn.className = 'cs-opt' + (valueEl && valueEl.value === m.value ? ' cs-opt-active' : '');
          btn.style.cssText = 'display:block;width:100%;padding:8px 16px;background:none;border:none;text-align:left;font-family:var(--font-sans,IBM Plex Sans,sans-serif);font-size:13px;font-weight:400;color:var(--text-primary,#161616);cursor:pointer;white-space:nowrap;box-sizing:border-box;outline:none;line-height:1.3;';
          btn.addEventListener('mouseenter', function() { btn.style.background='var(--ibm-blue-10,#edf5ff)'; btn.style.color='var(--ibm-blue-60,#0043ce)'; });
          btn.addEventListener('mouseleave', function() { btn.style.background=''; btn.style.color='var(--text-primary,#161616)'; });
          btn.textContent = m.label;
          btn.dataset.value = m.value;
          btn.dataset.label = m.label;
          btn.addEventListener('mousedown', function(e) {
            e.preventDefault();
            _select(m.value, m.label);
          });
          listEl.appendChild(btn);
        });
      });
      if (!any) {
        const empty = document.createElement('div');
        empty.style.cssText = 'padding:10px 14px;font-size:12px;color:var(--text-disabled);font-style:italic';
        empty.textContent = 'No results';
        listEl.appendChild(empty);
      }
    }

    function _select(value, label) {
      if (valueEl) valueEl.value = value;
      _setTriggerText(label);
      close();
      if (onSelect) onSelect(value, label);
    }

    function _setTriggerText(text) {
      let span = wrapper.querySelector('.cs-trigger-text');
      if (!span) {
        span = document.createElement('span');
        span.className = 'cs-trigger-text';
        trigger.insertBefore(span, chev);
      }
      if (text) {
        span.textContent = text;
        span.classList.remove('cs-placeholder');
      } else {
        span.textContent = placeholder;
        span.classList.add('cs-placeholder');
      }
    }

    function open() {
      if (_openInstance && _openInstance !== inst) _closeOpen();
      _openInstance = inst;
      panel.style.display = 'flex'; panel.style.flexDirection = 'column';
      wrapper.classList.add('cs-open');
      chev.style.transform = 'rotate(180deg)';
      _position(trigger, panel);
      searchInput.value = '';
      _renderList('');
      setTimeout(function() { searchInput.focus(); }, 20);
      const _repos = function() { if (panel.style.display !== 'none') _position(trigger, panel); };
      window.addEventListener('scroll', _repos, { passive: true, capture: true });
      window.addEventListener('resize', _repos, { passive: true });
      panel._cleanup = function() {
        window.removeEventListener('scroll', _repos, { capture: true });
        window.removeEventListener('resize', _repos);
      };
    }

    function close() {
      if (panel._cleanup) { panel._cleanup(); panel._cleanup = null; }
      panel.style.display = 'none';
      wrapper.classList.remove('cs-open');
      chev.style.transform = '';
      if (_openInstance === inst) _openInstance = null;
    }

    trigger.addEventListener('click', function(e) {
      e.stopPropagation();
      panel.style.display !== 'none' ? close() : open();
    });
    searchInput.addEventListener('input', function(e) { _renderList(e.target.value); });
    searchInput.addEventListener('keydown', function(e) {
      if (e.key === 'Escape') { close(); trigger.focus(); }
      if (e.key === 'Enter') {
        const first = listEl.querySelector('.cs-opt:not([disabled])');
        if (first) _select(first.dataset.value, first.dataset.label);
      }
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        listEl.querySelector('.cs-opt:not([disabled])')?.focus();
      }
    });
    listEl.addEventListener('keydown', function(e) {
      if (e.key === 'Escape') { close(); trigger.focus(); }
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        const opts = [...listEl.querySelectorAll('.cs-opt:not([disabled])')];
        const idx  = opts.indexOf(document.activeElement);
        const next = e.key === 'ArrowDown' ? Math.min(idx + 1, opts.length - 1) : Math.max(idx - 1, 0);
        opts[next]?.focus();
      }
    });

    _setTriggerText(valueEl && valueEl.value ? valueEl.value : '');

    function setMembers(newMembers) {
      members = newMembers;
      if (panel.style.display !== 'none') _renderList(searchInput.value);
    }

    const inst = { open, close, setMembers, _setTriggerText, _select };
    return inst;
  }

  document.addEventListener('click', function(e) {
    if (!e.target.closest('.cs-wrapper') && !e.target.closest('.cs-drop')) _closeOpen();
  });

  return { create };
})();
