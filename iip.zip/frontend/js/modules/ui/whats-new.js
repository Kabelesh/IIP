/* ================================================================
   js/modules/ui/whats-new.js  —  "What's New" changelog modal
   (Phase 5: absorbed from legacy/whats-new.js)
   ----------------------------------------------------------------
   Shows a modal on first visit after a new version is deployed.
   Uses localStorage key  "iip_seen_whats_new_v{MAJOR}.{MINOR}.{PATCH}"
   to ensure it only shows ONCE per version per browser.

   To add entries for a future release:
     1. Update AppVersion (version.js)
     2. Add a new entry to CHANGELOG array below
   ================================================================ */

const WhatsNew = (() => {

  /* ── Change log entries ───────────────────────────────────────
     type: "new" | "fix" | "improvement" | "removed"
     phase: optional label shown as a badge
  ─────────────────────────────────────────────────────────────── */
  const CHANGELOG =   [
    {
      "version": "1.0.0",
      "date": "2026-03-28",
      "title": "Security Questions, Developer Docs & Cleanup",
      "subtitle": "Password Reset via Security Questions · In-App Developer Documentation · Project Cleanup",
      "entries": [
        {
          "type": "new",
          "phase": "Backend",
          "title": "Security question-based password reset",
          "detail": "Replaced the old Forgot Password (phone + OTP) flow with security questions. Admin configures 2 questions via Admin Portal. Users can reset password by answering them correctly. Answers stored case-insensitively in PostgreSQL.",
          "tags": ["Security", "Auth", "Password Reset"]
        },
        {
          "type": "new",
          "phase": "Frontend",
          "title": "In-app developer documentation (admin-only)",
          "detail": "Added 6 new admin-only documentation pages: Security Questions & Password Reset, Developer Setup & Workflow, Authentication Architecture, Database Schema Reference, Deployment & Server Ops, Debugging & Troubleshooting Guide.",
          "tags": ["Documentation", "Admin"]
        },
        {
          "type": "improvement",
          "phase": "Frontend",
          "title": "Custom dropdown for security questions modal",
          "detail": "Replaced native <select> with custom div-based dropdown in the security questions setup modal. Native selects were trapped behind the modal's backdrop-filter stacking context.",
          "tags": ["UI", "Modal", "z-index"]
        },
        {
          "type": "improvement",
          "phase": "Project",
          "title": "Project cleanup — 21 files removed",
          "detail": "Removed 5 obsolete shell scripts, 14 redundant markdown files, a 4MB data export, and an unused GitLab CI config. All documentation content is now in the in-app Documentation dashboard. Added a proper README.md.",
          "tags": ["Cleanup", "Organization"]
        },
        {
          "type": "fix",
          "phase": "Backend",
          "title": "API version updated to 1.0.0",
          "detail": "FastAPI app version and /api/health endpoint now correctly report v1.0.0.",
          "tags": ["API", "Version"]
        }
      ]
    },
    {
      "version": "2.0.3",
      "date": "2026-03-24",
      "title": "Server Recovery & Full-Stack Stability",
      "subtitle": "Backend Recovery · API Path Fix · Admin Login Fix · IIPStore Fix · CSP Fix",
      "entries": [
        {
          "type": "fix",
          "phase": "Backend",
          "title": "Full server recovery after crash",
          "detail": "Recovered from a complete backend crash: missing npm modules reinstalled, PostgreSQL database and iip_admin user recreated, schema reloaded, Apache proxy path corrected from /api/ to /iip/api/, SELinux permissions fixed, and PM2 restarted. Backend API is fully operational.",
          "tags": [
            "Recovery",
            "PostgreSQL",
            "Apache",
            "PM2"
          ]
        },
        {
          "type": "fix",
          "phase": "Frontend",
          "title": "API path mismatch fixed across all modules",
          "detail": "Frontend JS files were calling hardcoded /api/ endpoints instead of /iip/api/. Fixed storage.js, admin.js, app.js, and dynamic-config.js to use a dynamic API_BASE constant derived from window.__APP_BASE__ — the app now works correctly when served from any sub-path.",
          "tags": [
            "API_BASE",
            "storage.js",
            "admin.js",
            "dynamic-config.js"
          ]
        },
        {
          "type": "fix",
          "phase": "Frontend",
          "title": "Admin Portal login prompt restored",
          "detail": "A SyntaxError in admin.js caused the Admin module to fail silently, allowing the Admin Portal to open without a password prompt. Fixed: admin.js now declares its own API_BASE safely, and the login guard in app.js is hardened to always require authentication.",
          "tags": [
            "Admin",
            "Login",
            "Security"
          ]
        },
        {
          "type": "fix",
          "phase": "Frontend",
          "title": "IIPStore undefined error resolved",
          "detail": "storage.js had orphaned ternary lines and a double-paren IIFE that caused a SyntaxError preventing IIPStore from registering on window. Fixed by removing orphan lines, correcting the IIFE structure, and ensuring one clean API_BASE declaration. IIPStore now initialises correctly.",
          "tags": [
            "IIPStore",
            "storage.js",
            "DB Sync"
          ]
        },
        {
          "type": "improvement",
          "phase": "Ops",
          "title": "CSP updated and console noise eliminated",
          "detail": "Content Security Policy connect-src was blocking Chart.js source map connections. Added cdn.jsdelivr.net to connect-src in .htaccess. Added favicon.ico to eliminate 404 console noise.",
          "tags": [
            "CSP",
            "Chart.js",
            "favicon"
          ]
        }
      ]
    },
    {
      "version": "2.0.0",
      "date": "2026-03-23",
      "title": "Production Release — Phases 1–5 Complete",
      "subtitle": "Security Hardening · bcrypt Auth · Observability · 47 Tests · Desktop-Only · Accessibility",
      "entries": [
        {
          "type": "new",
          "phase": "Security",
          "title": "Server-side bcrypt authentication",
          "detail": "Admin password verification moved from client-side to server-side bcrypt. Admin tokens now stored in sessionStorage only (not localStorage) — cleared on tab close, invisible to XSS attacks. Rate limiting on auth: 10 attempts per minute per IP.",
          "tags": [
            "bcrypt",
            "sessionStorage",
            "Rate Limiting"
          ]
        },
        {
          "type": "new",
          "phase": "Security",
          "title": "Helmet.js + hardened API security",
          "detail": "Added HSTS, X-DNS-Prefetch-Control, Cross-Origin policies via Helmet.js. API endpoints require X-IIP-Admin-Token header for writes. Key allowlist enforced — unknown keys rejected with HTTP 400. Password whitespace bypass closed (discovered by test suite).",
          "tags": [
            "Helmet",
            "HSTS",
            "API Auth"
          ]
        },
        {
          "type": "new",
          "phase": "Backend",
          "title": "Structured logging + health check",
          "detail": "All console.log replaced with pino — JSON logs in production, colorized in dev. Every HTTP request logged with duration. GET /api/health returns uptime, db_latency_ms, sse_clients, version. Kubernetes-ready readiness probe.",
          "tags": [
            "pino",
            "Health Check",
            "Observability"
          ]
        },
        {
          "type": "new",
          "phase": "Backend",
          "title": "Graceful shutdown + DB connection pool",
          "detail": "SIGTERM/SIGINT handlers now drain SSE clients and release the DB pool cleanly before exit. DB pool capped at 5 connections with 30s idle timeout — prevents connection exhaustion under load.",
          "tags": [
            "Graceful Shutdown",
            "DB Pool",
            "SSE"
          ]
        },
        {
          "type": "new",
          "phase": "Backend",
          "title": "Dynamic team config API",
          "detail": "New GET /api/team-config endpoint serves team configuration from PostgreSQL. DynamicConfig.js fetches this at startup and falls back to localStorage cache then AppData. The 3.6MB app-data.js is no longer blocking page load.",
          "tags": [
            "team-config",
            "DynamicConfig",
            "Performance"
          ]
        },
        {
          "type": "new",
          "phase": "Quality",
          "title": "47 Jest tests + ESLint v9 + Prettier",
          "detail": "Full backend test suite: isKeyAllowed(), safeParseValue(), rateLimit(), auth middleware, all HTTP endpoints. Coverage thresholds enforced (Lines ≥60%, Functions ≥70%). ESLint v9 flat config + Prettier + Husky pre-commit hooks prevent bad code from reaching production.",
          "tags": [
            "Jest",
            "ESLint",
            "Coverage"
          ]
        },
        {
          "type": "improvement",
          "phase": "UX",
          "title": "Desktop-only — mobile code removed",
          "detail": "Removed mobile.css, viewport meta tag, sidebar toggle, touch event listeners, haptic feedback, and 24 CSS media query blocks. Application is now 100% desktop-optimised with no responsive layout overhead.",
          "tags": [
            "Desktop",
            "Performance",
            "Cleanup"
          ]
        },
        {
          "type": "improvement",
          "phase": "Accessibility",
          "title": "WCAG 2.1 Level AA focus indicators + ARIA",
          "detail": "Added *:focus-visible outlines (2px blue) for full keyboard navigation. Reassign modal dropdown now has aria-haspopup, aria-expanded, role=listbox/option. Keyboard navigation (arrows, Enter, Escape) added to all dropdowns.",
          "tags": [
            "WCAG",
            "ARIA",
            "Keyboard Nav"
          ]
        },
        {
          "type": "improvement",
          "phase": "UX",
          "title": "Reassign modal loading states",
          "detail": "The reassign confirm button now shows a spinner during API call, disables itself to prevent duplicate submissions, shows a success toast on completion, and displays a clear error message on failure.",
          "tags": [
            "Reassign",
            "Loading State",
            "UX"
          ]
        },
        {
          "type": "new",
          "phase": "DevOps",
          "title": "pm2 ecosystem config + migration system",
          "detail": "Included ecosystem.config.js for pm2 with memory guards and exponential backoff. Database migrations now tracked in a migrations table — know exactly which schema versions have been applied. .gitlab-ci.yml ready for CI/CD pipeline.",
          "tags": [
            "pm2",
            "Migrations",
            "CI/CD"
          ]
        }
      ]
    },
    {
      "version": "1.0.3",
      "date": "2026-03-23",
      "title": "Data Sync & Stability — Multi-User Re-upload",
      "subtitle": "Live Data Sync · Refresh Banner · Merge Upload · Documentation Fix · Bug Fixes",
      "entries": [
        {
          "type": "new",
          "phase": "Sync",
          "title": "Re-upload data syncs to all users instantly",
          "detail": "When any user re-uploads a new Excel/CSV file, the data is now saved to the shared server for everyone. Other users see a 'New data available — Refresh now' banner at the bottom of the screen within 30 seconds. No more stale data for teammates.",
          "tags": [
            "Re-upload",
            "Multi-user",
            "Live Sync"
          ]
        },
        {
          "type": "improvement",
          "phase": "Data",
          "title": "Smart merge — re-upload keeps all history",
          "detail": "Re-uploading a file no longer loses old cases. New cases are added, existing cases are updated, and cases from previous uploads are retained. Your full case history accumulates over time.",
          "tags": [
            "Merge",
            "Re-upload",
            "History"
          ]
        },
        {
          "type": "fix",
          "phase": "UI",
          "title": "Documentation page now renders correctly",
          "detail": "The Documentation tab was showing a blank page due to a CSS layout issue where height:100% collapsed to zero inside a block-level container. Fixed with a proper absolute-fill layout that works regardless of parent display type.",
          "tags": [
            "Documentation",
            "CSS",
            "Layout"
          ]
        },
        {
          "type": "fix",
          "phase": "UI",
          "title": "Progress bar clears after re-upload",
          "detail": "The blue loading bar at the top of the upload screen was getting stuck after a re-upload completed. It now finishes, shows 100% briefly, then disappears — and shows a green 'Data uploaded successfully' toast.",
          "tags": [
            "Progress Bar",
            "Re-upload",
            "UX"
          ]
        }
      ]
    },
    {
      "version": "1.0.2",
      "date": "2026-03-20",
      "title": "10/10 UX Excellence — Major Release",
      "subtitle": "Progressive Disclosure · Guided Tour · Smart Errors · Celebrations · Proficiency Tracking",
      "entries": [
        {
          "type": "new",
          "phase": "Tier 1",
          "title": "Progressive Disclosure — Overview dashboard now breathes",
          "detail": "The Overview no longer dumps everything at once. KPI cards are always visible as your primary focus. Detailed Analysis (charts, workload, alerts), Performance Cases, and the Cases Table each collapse/expand with a smooth animation. Your layout preference is remembered across sessions — collapse what you don't need today, it stays that way tomorrow.",
          "tags": [
            "Overview",
            "Progressive Disclosure",
            "localStorage"
          ]
        },
        {
          "type": "new",
          "phase": "Tier 1",
          "title": "Smart Table Defaults — Team Cases shows 6 columns by default",
          "detail": "Instead of showing all columns at once, Team Cases now defaults to the 6 most useful: Case #, Title, Status, Owner, Updated, Last Updated (Days). A pill bar above the table lets you toggle any column on or off with a single click. Your column choice is saved — next visit, the table looks exactly as you left it.",
          "tags": [
            "Team Cases",
            "Column Manager",
            "Cognitive Load"
          ]
        },
        {
          "type": "new",
          "phase": "Tier 2",
          "title": "Guided Onboarding Tour — learn the platform in 60 seconds",
          "detail": "New users now see a welcome modal on first visit with a Quick Tour option. The tour uses a spotlight overlay to highlight 5 key areas: sidebar navigation (keys 1–9), KPI strip, global search (/), command palette (Ctrl+K), and the shortcuts help panel (?). The tour can be restarted any time from the Command Palette → 'Start Guided Tour'.",
          "tags": [
            "Onboarding",
            "Tour",
            "New Users"
          ]
        },
        {
          "type": "new",
          "phase": "Tier 2",
          "title": "\"Did You Know?\" contextual tips — surfaces features you haven't tried",
          "detail": "After your second visit to any dashboard, a tip card slides in from the bottom-right with a useful hint about that section. 10 tips cover keyboard shortcuts, chart drill-downs, column manager, the Weekly Tracker drag-and-drop, performance Work Items, and more. 'Got it' dismisses permanently; 'Remind me later' snoozes. Auto-dismisses after 12 seconds.",
          "tags": [
            "Tips",
            "Contextual Help",
            "Feature Discovery"
          ]
        },
        {
          "type": "new",
          "phase": "Tier 2",
          "title": "Proficiency badge — tracks how power-user you are",
          "detail": "Your sidebar footer now shows a Beginner / Intermediate / Advanced badge computed from how you use the app. Keyboard shortcuts (1–9, /, Ctrl+K, ?), filter usage, and column toggles all count toward your level. The badge updates in real time — hit Advanced to unlock the full power-user experience.",
          "tags": [
            "Proficiency",
            "Gamification",
            "Sidebar"
          ]
        },
        {
          "type": "improvement",
          "phase": "Tier 3",
          "title": "Smart empty states — helpful, not just a blank message",
          "detail": "When a search returns no results, you now see a contextual icon, a description of what happened, smart suggestions (try shorter term, search by owner, etc.), and a Clear Search button. No more 'No cases found' dead ends.",
          "tags": [
            "Empty States",
            "UX",
            "Search"
          ]
        },
        {
          "type": "improvement",
          "phase": "Tier 3",
          "title": "Micro-interactions — the app feels alive",
          "detail": "Every button click now produces a ripple effect. Buttons press down slightly when clicked (scale 0.97). KPI cards lift on hover. Table rows and sort headers have smooth transitions. All animations respect your OS's prefers-reduced-motion setting — if you prefer stillness, everything is instant.",
          "tags": [
            "Micro-interactions",
            "Ripple",
            "Animations"
          ]
        },
        {
          "type": "new",
          "phase": "Tier 4",
          "title": "Undo / Redo — Ctrl+Z to reverse case reassignments",
          "detail": "Reassigned a case to the wrong person? Press Ctrl+Z immediately to reverse it. A progress-bar toast appears after every reassignment showing the undo window (6 seconds). Ctrl+Y redoes. The undo system is open — future actions (bulk status changes, etc.) can plug in via PerfUtils.pushAction().",
          "tags": [
            "Undo",
            "Reassign",
            "Error Recovery"
          ]
        },
        {
          "type": "new",
          "phase": "Tier 4",
          "title": "Smart error toasts & network monitor",
          "detail": "Errors are no longer generic. Network offline? A red banner slides in from the top: '📡 No internet connection — working offline.' Back online? A green bar confirms sync. Other errors (timeouts, permission denials) get the right icon, a clear message, and actionable buttons (Retry / Continue / Dismiss). Nothing auto-dismisses for critical errors.",
          "tags": [
            "Error Handling",
            "Network",
            "Recovery"
          ]
        },
        {
          "type": "new",
          "phase": "Tier 5",
          "title": "Success celebrations — delight when it matters",
          "detail": "Bulk actions now feel satisfying. Sending reminders for 10+ cases? Confetti falls. Every reassignment triggers a bouncing success toast. Individual row bounces after reassign. These moments are brief and purposeful — enough to feel good, not enough to slow you down.",
          "tags": [
            "Celebrations",
            "Confetti"
          ]
        },
        {
          "type": "new",
          "phase": "Tier 5",
          "title": "Preventive design — stops mistakes before they happen",
          "detail": "The Send Reminder Mail button now shows a cooldown badge ('⏱ 23h cooldown') after sending — no accidental double-sends. Destructive actions require two clicks: first click shows 'Are you sure? Click again to confirm', auto-resets after 3.5 seconds. Save buttons pulse when they have pending changes and are disabled with a helpful tooltip when they don't.",
          "tags": [
            "Preventive Design",
            "Error Prevention",
            "Safety"
          ]
        }
      ]
    },
    {
      "version": "8.5.7",
      "date": "2026-03-18",
      "title": "UI Consistency Overhaul",
      "subtitle": "Phases 1–5 complete — search bars, buttons, form wrappers, and documentation",
      "entries": [
        {
          "type": "new",
          "phase": "Phase 5",
          "title": "COMPONENTS.md — full UI component library reference",
          "detail": "A comprehensive developer reference covering every component: buttons (all types and sizes), search input, form input group, status badges, severity badges, notify bars, icons, typography scale, color tokens, spacing, border radius, transitions, and z-index stack. Lives at frontend/COMPONENTS.md.",
          "tags": [
            "Documentation",
            "Developer reference"
          ]
        },
        {
          "type": "new",
          "phase": "Phase 5",
          "title": "CONSISTENCY.md — development rules and code review checklist",
          "detail": "A rules document with the five golden rules, a complete PR checklist, a common-mistakes table with fixes, guidance on adding new components, and a full dashboard inventory. Lives at frontend/CONSISTENCY.md.",
          "tags": [
            "Documentation",
            "Code review",
            "Standards"
          ]
        },
        {
          "type": "improvement",
          "phase": "Phase 4",
          "title": "form-input-group component — eliminates all ad-hoc icon wrappers",
          "detail": "A new .form-input-group CSS component replaces every instance of position:relative wrapper + position:absolute icon span + manual padding-left across the codebase. Icon offset is standardized at 10px left; input padding-left is 32px automatically. Works with .form-input and .search-input.",
          "tags": [
            ".form-input-group",
            ".input-icon",
            "components.css"
          ]
        },
        {
          "type": "fix",
          "phase": "Phase 4",
          "title": "All inline padding-left and absolute icon spans eliminated",
          "detail": "Six icon+input wrappers across admin-dash.js, changelog.js, info.js (×2), and rfe-tracking-advanced.js were migrated to .form-input-group. Zero inline padding-left values remain on search or form inputs.",
          "tags": [
            "Admin",
            "Changelog",
            "Info",
            "RFE Advanced",
            "Code cleanup"
          ]
        },
        {
          "type": "improvement",
          "phase": "Phase 4",
          "title": "rfe-tracking-advanced search upgraded to .search-input",
          "detail": "The RFE Tracking Advanced search input was using form-input form-input-sm with an inline padding-left. It is now a .search-input inside a .form-input-group, consistent with every other dashboard.",
          "tags": [
            "RFE Advanced",
            "search-input"
          ]
        },
        {
          "type": "new",
          "phase": "Phase 3",
          "title": "Archive Search tab in Investigate dashboard",
          "detail": "A new third tab — Archive Search — lets you search all permanently archived cases by case #, title, owner, product, or status. Results update in real-time with keyword highlighting, open cases floated to the top, and case number click-to-copy support.",
          "tags": [
            "Investigate",
            "Archive",
            "Search"
          ]
        },
        {
          "type": "new",
          "phase": "Phase 3",
          "title": "ALM Lines search in Info dashboard",
          "detail": "A search input has been added to the ALM Lines table header. Typing filters rows instantly by ALM line code, customer name, line responsible, case responsible, or proxy — without re-rendering the full page.",
          "tags": [
            "Info",
            "ALM Lines",
            "Search"
          ]
        },
        {
          "type": "improvement",
          "phase": "Phase 3",
          "title": "IBM Contacts Directory search upgraded to .search-input",
          "detail": "The existing contact directory search input (which already had filter logic) was upgraded from .form-input to the standardized .search-input class, giving it consistent focus states and placeholder styling.",
          "tags": [
            "Info",
            "Directory",
            "Consistency"
          ]
        },
        {
          "type": "improvement",
          "phase": "Phase 2",
          "title": "Custom button classes formalized in components.css",
          "detail": "Four custom button variants were scattered or undocumented. All are now in one place with documentation comments, :hover and :focus-visible states: .btn-overlay, .btn-danger-filled, .btn-warning, and .btn-micro.",
          "tags": [
            ".btn-overlay",
            ".btn-danger-filled",
            ".btn-warning",
            ".btn-micro"
          ]
        },
        {
          "type": "improvement",
          "phase": "Phase 1",
          "title": "Unified search bar styling across all dashboards",
          "detail": "All search inputs across every dashboard now use a single .search-input CSS class — consistent padding, border, focus ring, and placeholder colour. Previously each dashboard had its own class or no class at all.",
          "tags": [
            "All dashboards",
            "search-input",
            "Consistency"
          ]
        }
      ]
    }
  ];



  /* ── Helpers ─────────────────────────────────────────────────── */
  const _storageKey = v => `iip_seen_whats_new_v${v}_p45_900`;

  const _hasBeenSeen = version => {
    try { return localStorage.getItem(_storageKey(version)) === "1"; } catch(e) { return true; }
  };

  const _markSeen = version => {
    try { localStorage.setItem(_storageKey(version), "1"); } catch(e) {}
  };

  /* ── Badge colour map ─────────────────────────────────────────── */
  const TYPE_CONFIG = {
    new:         { label: "New",         bg: "var(--ibm-blue-10)",  color: "var(--ibm-blue-50)",  border: "rgba(15,98,254,.25)"   },
    improvement: { label: "Improved",    bg: "rgba(25,128,56,.08)", color: "var(--green)",         border: "rgba(25,128,56,.25)"   },
    fix:         { label: "Fix",         bg: "var(--yellow-bg)",    color: "var(--yellow-text)",   border: "rgba(166,120,0,.25)"   },
    removed:     { label: "Deprecated",  bg: "var(--bg-layer)",     color: "var(--text-tertiary)", border: "var(--border-subtle)"  }
  };

  /* ── Render ───────────────────────────────────────────────────── */
  function _render(release) {
    const cfg = t => TYPE_CONFIG[t] || TYPE_CONFIG.improvement;

    // Escape HTML to prevent <select> and other tags in detail text from rendering as elements
    const escapeHtml = s => String(s || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");

    const entriesHTML = release.entries.map(e => {
      const c = cfg(e.type);
      const typeBadge = `<span style="
        display:inline-block;padding:1px 7px;border-radius:999px;
        font-size:10px;font-weight:700;letter-spacing:.04em;text-transform:uppercase;
        background:${c.bg};color:${c.color};border:1px solid ${c.border};
        flex-shrink:0;line-height:1.6;
      ">${c.label}</span>`;

      const phaseBadge = e.phase ? `<span style="
        display:inline-block;padding:1px 7px;border-radius:999px;
        font-size:10px;font-weight:600;letter-spacing:.04em;
        background:var(--purple-bg);color:var(--purple);border:1px solid rgba(105,41,196,.2);
        flex-shrink:0;line-height:1.6;
      ">${e.phase}</span>` : "";

      const tagsHTML = (e.tags||[]).map(t =>
        `<span style="
          display:inline-block;padding:1px 6px;border-radius:var(--radius-sm);
          font-size:10px;font-family:var(--font-mono);
          background:var(--bg-layer);color:var(--text-tertiary);
          border:1px solid var(--border-subtle);
        ">${t}</span>`
      ).join(" ");

      return `
        <div style="
          padding:12px 0;
          border-bottom:1px solid var(--border-subtle);
          display:flex;flex-direction:column;gap:5px;
        ">
          <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;">
            ${typeBadge}${phaseBadge}
            <span style="font-size:13px;font-weight:600;color:var(--text-primary);">${e.title}</span>
          </div>
          <p style="margin:0;font-size:11px;color:var(--text-secondary);line-height:1.55;">${escapeHtml(e.detail)}</p>
          <div style="display:flex;gap:4px;flex-wrap:wrap;">${tagsHTML}</div>
        </div>`;
    }).join("");

    return `
      <div id="whats-new-overlay" role="dialog" aria-modal="true" aria-label="What's new in ${release.version}" style="
        position:fixed;inset:0;z-index:1050;
        background:rgba(0,0,0,.55);
        backdrop-filter:blur(3px);
        display:flex;align-items:center;justify-content:center;
        padding:16px;
        animation:wn-fadein .18s ease;
      ">
        <style>
          @keyframes wn-fadein  { from { opacity:0; } to { opacity:1; } }
          @keyframes wn-slidein { from { opacity:0; transform:translateY(14px); } to { opacity:1; transform:none; } }
          #whats-new-box { animation: wn-slidein .22s ease; }
          #whats-new-box:focus { outline:none; }
        </style>

        <div id="whats-new-box" tabindex="-1" style="
          background:var(--bg-ui);
          border:1px solid var(--border-mid);
          border-radius:var(--radius-md);
          width:100%;max-width:720px;
          max-height:98vh;
          display:flex;flex-direction:column;
          box-shadow:0 20px 60px rgba(0,0,0,.35);
          overflow:hidden;
        ">

          <!-- Header -->
          <div style="
            padding:14px 22px 10px;
            border-bottom:1px solid var(--border-subtle);
            display:flex;align-items:flex-start;gap:12px;
            background:var(--bg-ui);
            flex-shrink:0;
          ">
            <div style="
              width:38px;height:38px;border-radius:var(--radius-sm);
              background:var(--ibm-blue-10);border:1px solid rgba(15,98,254,.2);
              display:flex;align-items:center;justify-content:center;flex-shrink:0;
            ">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--ibm-blue-50)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/>
              </svg>
            </div>
            <div style="flex:1;min-width:0;">
              <div style="display:flex;align-items:center;gap:8px;margin-bottom:2px;">
                <span style="font-size:16px;font-weight:700;color:var(--text-primary);">What's New</span>
                <span style="
                  font-size:11px;font-weight:600;padding:1px 8px;
                  border-radius:999px;font-family:var(--font-mono);
                  background:var(--ibm-blue-10);color:var(--ibm-blue-50);
                  border:1px solid rgba(15,98,254,.2);
                ">v${release.version}</span>
              </div>
              <p style="margin:0;font-size:12px;color:var(--text-secondary);">${release.subtitle}</p>
            </div>
            <button id="whats-new-close" aria-label="Close what's new" style="
              width:28px;height:28px;border-radius:var(--radius-sm);
              border:1px solid var(--border-mid);background:transparent;
              color:var(--text-tertiary);cursor:pointer;
              display:flex;align-items:center;justify-content:center;
              flex-shrink:0;transition:all var(--t-fast);
            " onmouseover="this.style.background='var(--red)';this.style.color='#fff';this.style.borderColor='var(--red)'"
               onmouseout="this.style.background='transparent';this.style.color='var(--text-tertiary)';this.style.borderColor='var(--border-mid)'">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            </button>
          </div>

          <!-- Scrollable body -->
          <div style="overflow-y:auto;padding:12px 22px;flex:1;min-height:0;">
            ${entriesHTML}
            <!-- bottom padding spacer -->
            <div style="height:8px;"></div>
          </div>

          <!-- Footer -->
          <div style="
            padding:12px 22px;
            border-top:1px solid var(--border-subtle);
            display:flex;align-items:center;justify-content:space-between;
            background:var(--bg-layer);
            flex-shrink:0;
            gap:10px;flex-wrap:wrap;
          ">
            <span style="font-size:10px;color:var(--text-tertiary);">
              Released ${release.date} · ${release.entries.length} changes
            </span>
            <div style="display:flex;gap:8px;">
              <button id="whats-new-changelog" class="btn btn-secondary btn-sm" style="font-size:12px;">
                View full changelog
              </button>
              <button id="whats-new-dismiss" class="btn btn-primary btn-sm" style="font-size:12px;">
                Got it
              </button>
            </div>
          </div>

        </div>
      </div>`;
  }

  /* ── Public: show ─────────────────────────────────────────────── */
  function show(forceVersion) {
    // Find the most recent unseen release, or the forced version
    const release = forceVersion
      ? CHANGELOG.find(r => r.version === forceVersion)
      : CHANGELOG.find(r => !_hasBeenSeen(r.version));

    if (!release) return;

    // Mark as seen immediately — so a refresh or tab close won't re-show it
    if (!forceVersion) _markSeen(release.version);

    // Inject HTML
    const container = document.createElement("div");
    container.innerHTML = _render(release);
    document.body.appendChild(container);

    const overlay = document.getElementById("whats-new-overlay");
    const box     = document.getElementById("whats-new-box");

    // Focus trap
    setTimeout(() => box && box.focus(), 50);

    function dismiss() {
      overlay && overlay.remove();
      container.remove();
    }

    document.getElementById("whats-new-dismiss")?.addEventListener("click", dismiss);
    document.getElementById("whats-new-close")?.addEventListener("click", dismiss);

    document.getElementById("whats-new-changelog")?.addEventListener("click", () => {
      dismiss();
      // Navigate to documentation tab (contains the full changelog)
      setTimeout(() => {
        if (typeof App !== "undefined" && typeof App.renderTab === "function") {
          App.renderTab("documentation");
        } else {
          window.location.hash = "documentation";
        }
      }, 120);
    });

    // Dismiss on backdrop click
    overlay?.addEventListener("click", e => { if (e.target === overlay) dismiss(); });

    // Dismiss on Escape
    function onKey(e) {
      if (e.key === "Escape") { dismiss(); document.removeEventListener("keydown", onKey); }
    }
    document.addEventListener("keydown", onKey);
  }

  /* ── Detect browser reload (F5 / Ctrl+R) ─────────────────────── */
  function _isPageReload() {
    try {
      const nav = performance.getEntriesByType("navigation")[0];
      if (nav) return nav.type === "reload";
    } catch(e) {}
    try { return performance.navigation.type === 1; } catch(e) {}
    return false;
  }

  /* ── Auto-init: fire after app is ready ──────────────────────── */
  function _autoInit() {
    // Never show the popup on a browser refresh (F5 / Ctrl+R).
    // Only show on a genuine new session/tab or when a new version is deployed.
    if (_isPageReload()) return;

    // Clean up stale seen-keys for old versions so a new version always shows once.
    if (typeof AppVersion !== "undefined" && AppVersion.version) {
      const currentVersionKey = _storageKey(AppVersion.version);
      try {
        for (let i = localStorage.length - 1; i >= 0; i--) {
          const key = localStorage.key(i);
          if (key && key.startsWith("iip_seen_whats_new_v") && key !== currentVersionKey) {
            localStorage.removeItem(key);
          }
        }
      } catch(e) {}
    }

    // Wait for the app ready flag (set in app.js after data loads)
    const MAX_WAIT = 15000;
    const TICK     = 300;
    let   waited   = 0;

    function tryShow() {
      if (window._iipAppReady) {
        // Small delay so the UI settles before the modal appears
        setTimeout(() => show(), 600);
      } else if (waited < MAX_WAIT) {
        waited += TICK;
        setTimeout(tryShow, TICK);
      }
    }

    tryShow();
  }

  /* ── Expose ───────────────────────────────────────────────────── */
  return Object.freeze({ show, init: _autoInit });

})();

// Boot
document.addEventListener("DOMContentLoaded", () => WhatsNew.init());
