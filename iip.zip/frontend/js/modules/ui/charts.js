/* ============================================================
   js/modules/ui/charts.js
   Chart.js wrapper helpers
   (Phase 6: absorbed from legacy/charts.js)
   Each function creates/updates a Chart instance.
   ============================================================ */

const Charts = (() => {

  // Keep references to destroy before re-render
  const _instances = {};

  // Debounce clicks to prevent re-entrance issues
  const _clickDebounce = {};

  // Resolve CSS custom property to a concrete color value for Canvas API.
  // Canvas 2D context cannot use var(--token) strings directly.
  function _cssColor(varName) {
    try {
      const v = getComputedStyle(document.documentElement).getPropertyValue(varName).trim();
      return v || varName;
    } catch(e) { return varName; }
  }

  // Resolve a color that may be "var(--token)", "--token", or a raw hex/rgb value
  function _resolveColor(val, fallbackVar) {
    if (!val) return _cssColor(fallbackVar);
    if (val.startsWith("var(")) return _cssColor(val.slice(4, -1));
    if (val.startsWith("--"))  return _cssColor(val);
    return val;  // already a concrete color (hex, rgb, etc.)
  }

  // Chart palette — resolved at render time from CSS tokens
  function _chartColors(n) {
    const vars = [
      "--chart-1","--chart-2","--chart-3","--chart-4",
      "--chart-5","--chart-6","--chart-7","--chart-8",
      "--ibm-blue-50","--teal","--red","--teal"
    ];
    return vars.slice(0, n).map(v => _cssColor(v));
  }

  // CHART_COLORS resolved lazily at render time so CSS vars are applied.
  // Using a plain function — Proxy was broken because .slice() on Proxy([])
  // returns [] (backing array length=0), making all bar colors default to black.
  let _CHART_COLORS_CACHE = null;
  function _getChartColors() {
    if (_CHART_COLORS_CACHE) return _CHART_COLORS_CACHE;
    _CHART_COLORS_CACHE = [
      "--chart-1","--chart-2","--chart-3","--chart-4",
      "--chart-5","--chart-6","--chart-7","--chart-8",
      "--ibm-blue-50","--teal","--red","--teal"
    ].map(v => _cssColor(v));
    return _CHART_COLORS_CACHE;
  }
  // Alias — always call _getChartColors() instead of CHART_COLORS for array ops
  const CHART_COLORS = { slice: (a, b) => _getChartColors().slice(a, b) };

  const GRID_COLOR  = "rgba(0,0,0,0.05)";

  // Generate a blue→teal gradient palette across n bars
  function _barGradient(n) {
    if (n === 0) return [];
    return Array.from({ length: n }, (_, i) => {
      const t = n > 1 ? i / (n - 1) : 0;
      const r = Math.round(0x45 + (0x00 - 0x45) * t);
      const g = Math.round(0x89 + (0xBE - 0x89) * t);
      const b = Math.round(0xFF + (0x65 - 0xFF) * t);
      return `rgba(${r},${g},${b},0.85)`;
    });
  }
  // TICK_COLOR resolved lazily at render time (CSS may not be applied at parse time)
  function _tickColor() { return _cssColor("--text-tertiary") || "#6f6f6f"; }
  const TICK_COLOR  = "#6f6f6f"; // safe fallback used only if _tickColor() isn't called
  const FONT_FAMILY = "'IBM Plex Sans','Helvetica Neue',Arial,sans-serif";

  function _destroy(id) {
    if (_instances[id]) {
      try {
        const chart = _instances[id];
        // Remove event listeners before destroying
        if (chart.canvas) {
          chart.canvas.removeEventListener('click', chart._onclick);
          chart.canvas.style.cursor = '';
        }
        chart.destroy();
      } catch(e) {}
      delete _instances[id];
    }
  }

  // Guard: returns true if Chart.js is ready.
  // If not ready yet, schedules a re-render once Chart.js loads — no permanent error shown.
  function _chartAvailable(canvasId) {
    if (typeof Chart !== "undefined") return true;
    if (!window._chartRetryQueued) console.debug("[Charts] Chart.js not loaded yet — will retry on chartjs-ready");
    // Blank the canvas container quietly — no error message yet
    const el = document.getElementById(canvasId);
    if (el && el.parentElement && !el.parentElement.dataset.chartPending) {
      el.parentElement.dataset.chartPending = "1";
    }
    // When Chart.js loads, re-render the active dashboard so charts appear
    if (!window._chartRetryQueued) {
      window._chartRetryQueued = true;
      document.addEventListener('chartjs-ready', function _onChartReady() {
        window._chartRetryQueued = false;
        document.removeEventListener('chartjs-ready', _onChartReady);
        // Reset pending markers so charts re-render cleanly
        document.querySelectorAll('[data-chart-pending]').forEach(el => {
          delete el.dataset.chartPending;
          // Restore canvas if it was hidden
          const canvas = el.querySelector('canvas');
          if (canvas) canvas.style.display = '';
        });
        // Re-render the active tab's dashboard to redraw all charts
        setTimeout(function() {
          try {
            if (typeof App !== 'undefined' && App.renderActive) {
              App.renderActive();
            }
          } catch(e) {}
        }, 100);
      });
    }
    return false;
  }

  // FIX: Ensure canvas container has a non-zero height before Chart.js reads dimensions.
  // If the inline height style is missing or the container reports 0, apply a default.
  function _ensureContainerHeight(canvasId, defaultHeight) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;
    const wrap = canvas.parentElement;
    if (!wrap) return;
    const h = wrap.offsetHeight || parseInt(wrap.style.height) || 0;
    if (h === 0) {
      wrap.style.height = (defaultHeight || 200) + "px";
      console.info("[Charts] Applied fallback height to #" + canvasId + " container");
    }
  }

  // FIX: Empty-data guard — logs a console warning and shows a placeholder instead of
  // letting Chart.js create a broken empty chart.
  function _hasData(canvasId, data, label) {
    if (!data || data.length === 0) {
      console.warn("[Charts] No data for chart #" + canvasId + (label ? " (" + label + ")" : "") + " — skipping render.");
      const canvas = document.getElementById(canvasId);
      if (canvas && canvas.parentElement) {
        if (!canvas.parentElement.querySelector(".chart-no-data")) {
          const msg = document.createElement("div");
          msg.className = "chart-no-data";
          msg.style.cssText = "display:flex;align-items:center;justify-content:center;height:100%;min-height:80px;color:var(--text-disabled);font-size:12px;font-family:'IBM Plex Mono',monospace";
          msg.textContent = "No data available";
          canvas.parentElement.appendChild(msg);
          canvas.style.display = "none";
        }
      }
      return false;
    }
    // Remove any prior no-data placeholder
    const canvas = document.getElementById(canvasId);
    if (canvas) {
      canvas.style.display = "";
      canvas.parentElement?.querySelector(".chart-no-data")?.remove();
    }
    return true;
  }

  /* ── Bar Chart: owner vs count ─────────────────────────── */
  function ownerBar(canvasId, data, opts = {}) {
    const ctx = document.getElementById(canvasId);
    if (!ctx) return;
    if (!_chartAvailable(canvasId)) return;
    if (!_hasData(canvasId, data, "ownerBar")) return;
    _ensureContainerHeight(canvasId, 200);

    _destroy(canvasId);

    const hasSecondary = opts.secondaryKey && data.some(d => d[opts.secondaryKey] !== undefined);

    // Single-dataset: gradient palette. Dual: keep distinct brand colours.
    const primaryColors = hasSecondary
      ? data.map(() => _resolveColor(opts.color, "--ibm-blue-30"))
      : _barGradient(data.length);
    const primaryBg = hasSecondary
      ? primaryColors.map(c => c + "cc")
      : primaryColors;

    const datasets = [{
      label: opts.label || "Cases",
      data: data.map(d => d.count),
      backgroundColor: primaryBg,
      borderColor: primaryColors.map(c => c.replace("0.85)", "1)")),
      borderWidth: 0,
      borderRadius: 7,
      borderSkipped: false,
    }];

    if (hasSecondary) {
      const secColor = _resolveColor(opts.secondaryColor, "--red");
      datasets.push({
        label: opts.secondaryLabel || "Secondary",
        data: data.map(d => d[opts.secondaryKey] || 0),
        backgroundColor: secColor + "99",
        borderColor: secColor,
        borderWidth: 0,
        borderRadius: 7,
        borderSkipped: false,
      });
    }

    _instances[canvasId] = new Chart(ctx, {
      type: "bar",
      data: { labels: data.map(d => d.name), datasets },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        onClick: opts.onClick ? (evt, elements) => {
          if (elements.length && !_clickDebounce[canvasId]) {
            _clickDebounce[canvasId] = true;
            const fullName = data[elements[0].index].fullName;
            const dsIdx    = elements[0].datasetIndex;
            setTimeout(() => {
              try { opts.onClick(fullName, dsIdx); } catch(e) { console.warn("[Charts] ownerBar onClick:", e); }
              delete _clickDebounce[canvasId];
            }, 0);
          }
        } : undefined,
        plugins: {
          legend: { display: false, labels: { color: _tickColor(), font: { family: FONT_FAMILY, size: 11 } } },
          tooltip: {
            backgroundColor: _cssColor("--bg-ui"),
            borderColor: _cssColor("--border-subtle"),
            borderWidth: 1,
            titleColor: _cssColor("--text-primary"),
            bodyColor: _cssColor("--text-secondary"),
            titleFont: { family: FONT_FAMILY, size: 11 },
            bodyFont:  { family: FONT_FAMILY, size: 13 },
            padding: 10,
            cornerRadius: 8,
            callbacks: {
              title: items => items[0].label,
              label:  item  => ` ${item.dataset.label}: ${item.raw}`
            }
          }
        },
        scales: {
          x: {
            grid: { display: false },
            border: { display: false },
            ticks: {
              color:       _tickColor(),
              font:        { family: FONT_FAMILY, size: 10 },
              maxRotation: 45,
              minRotation: 0,
              autoSkip:    true,
              maxTicksLimit: 30
            }
          },
          y: {
            grid:  { color: GRID_COLOR, drawTicks: false },
            border: { display: false },
            ticks: { color: _tickColor(), font: { family: FONT_FAMILY, size: 11 }, padding: 6, precision: 0, callback: v => Number.isInteger(v) ? v : null },
            beginAtZero: true
          }
        }
      }
    });
  }

  /* ── Line Chart: monthly trend ─────────────────────────── */
  function trendLine(canvasId, trend, opts = {}) {
    const ctx = document.getElementById(canvasId);
    if (!ctx) return;
    if (!_chartAvailable(canvasId)) return;
    if (!_hasData(canvasId, trend, "trendLine")) return;
    _ensureContainerHeight(canvasId, 195);

    _destroy(canvasId);

    _instances[canvasId] = new Chart(ctx, {
      type: "line",
      data: {
        labels: trend.map(d => d.label),
        datasets: [
          {
            label: "Created",
            data: trend.map(d => d.created),
            borderColor: _cssColor("--ibm-blue-30"),
            backgroundColor: "#4589ff22",
            borderWidth: 2,
            pointRadius: 3,
            pointBackgroundColor: _cssColor("--ibm-blue-30"),
            tension: 0.3,
            fill: true
          },
          {
            label: "Closed",
            data: trend.map(d => d.closed),
            borderColor: _cssColor("--green"),
            backgroundColor: "#42be6522",
            borderWidth: 2,
            pointRadius: 3,
            pointBackgroundColor: _cssColor("--green"),
            tension: 0.3,
            fill: true
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: { mode: "index", intersect: false },
        plugins: {
          legend: {
            labels: {
              color: _tickColor(),
              font: { family: FONT_FAMILY, size: 11 },
              boxWidth: 10
            }
          },
          tooltip: {
            backgroundColor: _cssColor("--bg-ui"),
            borderColor: _cssColor("--border-subtle"),
            borderWidth: 1,
            titleColor: _cssColor("--text-primary"),
            bodyColor: _cssColor("--text-secondary"),
            titleFont: { family: FONT_FAMILY, size: 11 },
            bodyFont:  { family: FONT_FAMILY, size: 12 }
          }
        },
        onClick: opts.onClick ? (evt, elements) => {
          if (elements.length > 0 && !_clickDebounce[canvasId]) {
            _clickDebounce[canvasId] = true;
            const label = trend[elements[0].index]?.label;
            setTimeout(() => {
              try { if (label) opts.onClick(label); } catch(e) { console.warn("[Charts] trendLine onClick:", e); }
              delete _clickDebounce[canvasId];
            }, 0);
          }
        } : undefined,
        scales: {
          x: {
            grid: { color: GRID_COLOR },
            ticks: { color: _tickColor(), font: { family: FONT_FAMILY, size: 10 }, maxRotation: 0, minRotation: 0 }
          },
          y: {
            grid: { color: GRID_COLOR },
            ticks: { color: _tickColor(), font: { family: FONT_FAMILY, size: 11 }, precision: 0, callback: v => Number.isInteger(v) ? v : null },
            beginAtZero: true
          }
        }
      }
    });
  }

  /* ── Doughnut: status distribution (modern) ────────────── */
  const STATUS_COLORS_BORDER = {
    "Awaiting your feedback": "#D4920A",
    "IBM is working":         "#0F62FE",
    "Waiting for IBM":        "#6929C4",
    "Closed by IBM":          "#198038",
    "Closed by Client":       "#6F6F6F",
    "Closed - Archived":      "#A8A8A8"
  };
  const STATUS_COLORS_FILL = {
    "Awaiting your feedback": "#F5A800",
    "IBM is working":         "#4589FF",
    "Waiting for IBM":        "#8A3FFC",
    "Closed by IBM":          "#24A148",
    "Closed by Client":       "#8D8D8D",
    "Closed - Archived":      "#C6C6C6"
  };

  function statusDonut(canvasId, data, opts = {}) {
    _destroy(canvasId);
    const ctx = document.getElementById(canvasId);
    if (!ctx) return;
    if (!_chartAvailable(canvasId)) return;
    if (!_hasData(canvasId, data, "statusDonut")) return;

    // IBM Design palette — matches Yearly Closed donut in Closed Cases page
    const _palette     = ["#4589FF","#42BE65","#8A3FFC","#F1C21B","#FF832B","#33B1FF","#FA4D56","#08BDBA"];
    const fillColors   = data.map((_, i) => _palette[i % _palette.length] + "dd");
    const borderColors = data.map((_, i) => _palette[i % _palette.length]);
    const total        = data.reduce((s, d) => s + d.value, 0);
    const visible      = data.map(() => true);

    // Centre-text plugin — visibleTotal updates when legend items are toggled
    let visibleTotal = total;
    const centerPlugin = {
      id: "statusDonutCenter",
      afterDraw(chart) {
        const { ctx: c, chartArea: { left, right, top, bottom } } = chart;
        const cx = (left + right) / 2, cy = (top + bottom) / 2;
        c.save();
        c.textAlign = "center"; c.textBaseline = "middle";
        c.font = `700 ${Math.max(16, Math.min(24, (right - left) * 0.13))}px ${FONT_FAMILY}`;
        c.fillStyle = _cssColor("--text-primary") || "#161616";
        c.fillText(visibleTotal.toLocaleString(), cx, cy - 8);
        c.font = `400 11px ${FONT_FAMILY}`;
        c.fillStyle = _cssColor("--text-tertiary") || "#6f6f6f";
        c.fillText(opts.centerLabel || "Total Cases", cx, cy + 11);
        c.restore();
      }
    };

    _instances[canvasId] = new Chart(ctx, {
      type: "doughnut",
      data: {
        labels: data.map(d => d.name),
        datasets: [{
          data: data.map(d => d.value),
          backgroundColor: fillColors,
          borderColor: borderColors,
          borderWidth: 2.5,
          borderRadius: 0,
          spacing: 0,
          hoverOffset: 8,
          hoverBorderWidth: 0,
        }]
      },
      plugins: [centerPlugin],
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: "62%",
        animation: { animateRotate: true, animateScale: false, duration: 600, easing: "easeOutCubic" },
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: "#fff",
            borderColor: _cssColor("--border-subtle"),
            borderWidth: 1,
            titleColor: _cssColor("--text-primary"),
            bodyColor: _cssColor("--text-secondary"),
            titleFont: { family: FONT_FAMILY, size: 12, weight: "600" },
            bodyFont:  { family: FONT_FAMILY, size: 13 },
            padding: 12,
            cornerRadius: 8,
            displayColors: true,
            boxWidth: 10,
            boxHeight: 10,
            callbacks: {
              title: (items) => items[0]?.label || "",
              label: (item) => {
                const pct = total > 0 ? Math.round(item.raw / total * 100) : 0;
                return `  ${item.raw} cases  (${pct}%)`;
              }
            }
          }
        },
        onClick: opts.onClick ? (evt, elements) => {
          if (elements.length > 0 && !_clickDebounce[canvasId]) {
            _clickDebounce[canvasId] = true;
            const name = data[elements[0].index].name;
            setTimeout(() => {
              try { opts.onClick(name); } catch(e) { console.warn("[Charts] statusDonut onClick:", e); }
              delete _clickDebounce[canvasId];
            }, 0);
          }
        } : undefined
      }
    });
    if (opts.onClick) ctx.style.cursor = "pointer";

    // ── Custom stable HTML legend ──
    const legendEl = document.getElementById(opts.legendId || "chart-status-legend");
    if (legendEl && _instances[canvasId]) {
      legendEl.innerHTML = data.map((d, i) => {
        const fill   = fillColors[i];
        const border = borderColors[i];
        const pct    = total > 0 ? Math.round(d.value / total * 100) : 0;
        return `<span data-sidx="${i}" style="display:inline-flex;align-items:center;gap:5px;cursor:pointer;user-select:none;white-space:nowrap;">
          <span class="sl-swatch" style="display:inline-block;width:10px;height:10px;border-radius:2px;background:${fill};flex-shrink:0;"></span>
          <span class="sl-text" style="color:${_cssColor("--text-primary")||"#161616"};font-size:12px;">${d.name} <strong>${d.value}</strong> (${pct}%)</span>
        </span>`;
      }).join("");

      legendEl.querySelectorAll("span[data-sidx]").forEach(item => {
        item.addEventListener("click", () => {
          const i      = parseInt(item.dataset.sidx);
          const chart  = _instances[canvasId];
          if (!chart) return;
          visible[i] = !visible[i];
          chart.toggleDataVisibility(i);
          visibleTotal = data.reduce((s, d, idx) => s + (visible[idx] ? d.value : 0), 0);
          chart.update();
          const swatch = item.querySelector(".sl-swatch");
          const text   = item.querySelector(".sl-text");
          swatch.style.background   = visible[i] ? fillColors[i]   : "transparent";
          swatch.style.border       = visible[i] ? "none"           : `1.5px solid ${borderColors[i]}`;
          text.style.color          = visible[i] ? (_cssColor("--text-primary")||"#161616") : (_cssColor("--text-tertiary")||"#6f6f6f");
          text.style.textDecoration = visible[i] ? "none"           : "line-through";
        });
      });
    }
  }

  /* ── Horizontal bar: product distribution ──────────────── */
  function productBar(canvasId, data, opts = {}) {
    _destroy(canvasId);
    const ctx = document.getElementById(canvasId);
    if (!ctx) return;
    if (!_chartAvailable(canvasId)) return;
    if (!_hasData(canvasId, data, "productBar")) return;
    _ensureContainerHeight(canvasId, 210);

    // Smart abbreviation: strip common prefixes, keep meaningful part
    const abbrevLabel = (name) => {
      let s = name
        .replace(/^IBM Engineering /, "")
        .replace(/^IBM Rational /, "")
        .replace(/^IBM /, "")
        .replace(" Management", " Mgmt")
        .replace(" Requirements", " Req.")
        .replace(" Workflow", " WF")
        .replace(" Lifecycle", " LC");
      return s.length > 28 ? s.slice(0, 26) + "…" : s;
    };
    const shortLabels = data.map(d => abbrevLabel(d.name));
    const fullLabels  = data.map(d => d.name);
    const gradColors = _barGradient(data.length);

    _instances[canvasId] = new Chart(ctx, {
      type: "bar",
      data: {
        labels: shortLabels,
        datasets: [{
          data: data.map(d => d.value),
          backgroundColor: gradColors,
          borderColor: gradColors.map(c => c.replace("0.85)", "1)")),
          borderWidth: 0,
          borderRadius: 6,
          borderSkipped: false
        }]
      },
      options: {
        indexAxis: "y",
        responsive: true,
        maintainAspectRatio: false,
        layout: { padding: { left: 0 } },
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: _cssColor("--bg-ui"), borderColor: _cssColor("--border-subtle"), borderWidth: 1,
            titleColor: _cssColor("--text-primary"), bodyColor: _cssColor("--text-secondary"),
            bodyFont: { family: FONT_FAMILY, size: 12 },
            padding: 10, cornerRadius: 8,
            callbacks: {
              title: (items) => fullLabels[items[0].dataIndex] || items[0].label
            }
          }
        },
        scales: {
          x: {
            grid: { color: GRID_COLOR, drawTicks: false },
            border: { display: false },
            ticks: { color: _tickColor(), font: { family: FONT_FAMILY, size: 10 }, padding: 6, maxRotation: 0, minRotation: 0 },
            beginAtZero: true
          },
          y: {
            grid: { display: false },
            border: { display: false },
            ticks: {
              color: _tickColor(),
              font: { family: FONT_FAMILY, size: 10.5 },
              maxRotation: 0,
              minRotation: 0,
              autoSkip: false
            },
            afterFit: (axis) => { axis.width = Math.max(axis.width, 160); }
          }
        },
        onClick: opts.onClick ? (evt, elements) => {
          if (elements.length > 0 && !_clickDebounce[canvasId]) {
            _clickDebounce[canvasId] = true;
            const name = data[elements[0].index].name;
            setTimeout(() => {
              try { opts.onClick(name); } catch(e) { console.warn("[Charts] productBar onClick:", e); }
              delete _clickDebounce[canvasId];
            }, 0);
          }
        } : undefined
      }
    });
    if (opts.onClick) ctx.style.cursor = "pointer";
    // Fix 6: Attach native title attrs to y-axis tick elements for truncated label tooltip
    ctx.setAttribute("aria-label", data.map(d => d.name).join(", "));
    ctx.title = ""; // prevent default canvas title
  }

  /* ── Destroy all chart instances (cleanup helper) ──── */
  function destroyAll() {
    Object.keys(_instances).forEach(id => _destroy(id));
  }

  return { ownerBar, trendLine, statusDonut, productBar, destroyAll, cssColor: _cssColor };
})();
