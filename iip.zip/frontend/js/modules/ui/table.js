/* ============================================================
   js/modules/ui/table.js — Reusable table with search, sort, pagination
   (Phase 6: absorbed from legacy/table.js)
   ============================================================ */
const Table = (() => {
  const PAGE_SIZE = 50;

  function render(container, cases, opts = {}) {
    if (!container) return;

    const {
      columns, extraCols = [],
      onRemind, onReassign, onClear,
      showRemind   = false,
      showReassign = false,
      showActions  = true,
      showClearBtn = false,
      extraActions,
      tableId,
      defaultSortKey = null,
      defaultSortDir = 1
    } = opts;

    const cols = columns || [...defaultColumns(), ...extraCols];
    let page    = 1;
    let sortKey = defaultSortKey;
    let sortDir = defaultSortDir;
    let data    = [...cases];
    let search  = "";

    // Stable uid — fixed once, never regenerated across redraws
    const uid = tableId || ("tbl_" + Math.random().toString(36).slice(2,7));
    const hasActions = showActions && (showRemind || showReassign || extraActions);

    function filteredData() {
      if (!search.trim()) return data;
      const q = search.toLowerCase();
      return data.filter(r =>
        (r["Case Number"]||"").toLowerCase().includes(q) ||
        (r.Title||"").toLowerCase().includes(q) ||
        (r.Owner||"").toLowerCase().includes(q) ||
        (typeof Data !== "undefined" && Data.displayName ? (Data.displayName(r.Owner)||"") : "").toLowerCase().includes(q) ||
        (r.Product||"").toLowerCase().includes(q)
      );
    }

    function sortedData() {
      const fd = filteredData();
      if (!sortKey) return fd;
      const col = cols.find(c => c.key === sortKey);
      return [...fd].sort((a, b) => {
        const av = col?.sortValue ? col.sortValue(a) : (a[sortKey]||"");
        const bv = col?.sortValue ? col.sortValue(b) : (b[sortKey]||"");
        if (typeof av === "number") return (av - bv) * sortDir;
        return String(av).localeCompare(String(bv)) * sortDir;
      });
    }

    // ── Build stable DOM shell (called once) ─────────────────
    function _buildShell() {
      // Topbar — created once, never replaced
      const topbar = document.createElement("div");
      topbar.className = "table-topbar";
      topbar.id = "tbl-topbar-" + uid;
      const titleHtml = container.dataset.title ? '<span class="section-title mb-0" style="font-size:13px;flex-shrink:0">' + container.dataset.title + '</span>' : '';
      topbar.innerHTML =
        titleHtml +
        '<div style="display:flex;align-items:center;gap:8px">' +
          '<span class="table-record-count" id="tbl-count-' + uid + '"></span>' +
          '<button id="tbl-clear-' + uid + '" class="btn btn-ghost btn-sm" style="font-size:11px;padding:3px 8px;display:none" title="Clear filter and scroll to chart"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right:4px"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>Clear</button>' +
        '</div>' +
        '<div class="row-8">' +
          '<input type="text" placeholder="Search case #, title, owner\u2026"' +
            ' id="tbl-search-' + uid + '" value=""' +
            ' class="form-input form-input-sm" style="width:260px"/>' +
          '<button class="export-btn" id="tbl-export-' + uid + '"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg> Export Excel</button>' +
        '</div>';

      // Table wrapper — created once
      const tableWrap = document.createElement("div");
      tableWrap.className = "data-table-wrap";
      tableWrap.id = "tbl-wrap-" + uid;
      tableWrap.innerHTML =
        '<div class="table-scroll" id="tbl-scroll-' + uid + '">' +
          '<table class="data-table" id="tbl-table-' + uid + '" role="grid" aria-label="Cases table">' +
            '<thead><tr id="tbl-thead-' + uid + '"></tr></thead>' +
            '<tbody id="tbl-tbody-' + uid + '"></tbody>' +
          '</table>' +
        '</div>';

      // Pagination container
      const pagination = document.createElement("div");
      pagination.id = "tbl-pagination-" + uid;

      container.appendChild(topbar);
      container.appendChild(tableWrap);
      container.appendChild(pagination);

      // Wire search ONCE to stable input element
      var si = topbar.querySelector("#tbl-search-" + uid);
      if (si) {
        var _dbt = null;
        si.addEventListener("input", function(e) {
          clearTimeout(_dbt);
          var val = e.target.value;
          _dbt = setTimeout(function() {
            search = val; page = 1;
            _updateCount(); _updateThead(); _updateTbody(); _updatePagination();
          }, 150);
        });
      }

      // Wire export ONCE
      var expBtn = topbar.querySelector("#tbl-export-" + uid);
      if (expBtn) expBtn.addEventListener("click", function() {
        exportToExcel(sortedData(), cols, "cases");
      });

      // Wire clear button ONCE
      var clrBtn = topbar.querySelector("#tbl-clear-" + uid);
      if (clrBtn && onClear) {
        clrBtn.addEventListener("click", function() {
          onClear();
        });
      }

      // Wire overflow scroll shadow ONCE.
      // Track the resize listener by uid so it can be removed if this table is
      // ever re-rendered (prevents accumulating ghost listeners on window).
      var scroll = tableWrap.querySelector("#tbl-scroll-" + uid);
      if (scroll) {
        var checkOverflow = function() {
          tableWrap.classList.toggle("has-overflow", scroll.scrollWidth > scroll.clientWidth);
        };
        checkOverflow();
        scroll.addEventListener("scroll", function() {
          var atEnd = scroll.scrollLeft + scroll.clientWidth >= scroll.scrollWidth - 4;
          tableWrap.classList.toggle("has-overflow", !atEnd);
        });
        // Remove any prior listener registered for this uid before adding a new one
        var _resizeKey = "_tbl_resize_" + uid;
        if (window[_resizeKey]) window.removeEventListener("resize", window[_resizeKey]);
        window[_resizeKey] = checkOverflow;
        window.addEventListener("resize", checkOverflow);
      }
    }

    // ── Update record count text only ────────────────────────
    function _updateCount() {
      var sorted = sortedData(), total = sorted.length;
      var pages = Math.max(1, Math.ceil(total / PAGE_SIZE));
      if (page > pages) page = pages;
      var from = total === 0 ? 0 : (page - 1) * PAGE_SIZE + 1;
      var to   = Math.min(page * PAGE_SIZE, total);
      var el   = container.querySelector("#tbl-count-" + uid);
      if (el) {
        el.innerHTML = "Showing " + from + "\u2013" + to + " of <strong>" + total + "</strong> cases";
        // F26: Flash count on filter change
        el.style.transition = "opacity .15s"; el.style.opacity = "0";
        setTimeout(function() { el.style.opacity = "1"; }, 160);
      }
      // Show/hide clear button if onClear callback is provided (showClearBtn flag gets stale on refresh, so use onClear existence as the indicator)
      var clrBtn = container.querySelector("#tbl-clear-" + uid);
      if (clrBtn) {
        clrBtn.style.display = onClear ? "inline-flex" : "none";
      }
    }

    // ── Rebuild thead only (on sort change) ──────────────────
    function _updateThead() {
      var tr = container.querySelector("#tbl-thead-" + uid);
      if (!tr) return;
      var html = "";
      cols.forEach(function(col) {
        var isCur    = sortKey === col.key;
        var arrow    = isCur ? (sortDir === 1 ? " \u2191" : " \u2193") : "";
        var sortAttr = col.sortable !== false ? 'data-sort="' + col.key + '"' : "";
        var cls      = (col.sortable !== false ? "sort-th " : "") + (isCur ? "sort-active" : "");
        html += '<th scope="col" class="' + cls + '" ' + sortAttr + '>' + col.label +
          (isCur ? '<span class="sort-arrow" aria-hidden="true">' + arrow + '</span>' : '') + '</th>';
      });
      if (hasActions) html += '<th scope="col" class="w-100">Actions</th>';
      tr.innerHTML = html;

      tr.querySelectorAll(".sort-th[data-sort]").forEach(function(th) {
        th.addEventListener("click", function() {
          var key = th.dataset.sort;
          if (sortKey === key) sortDir *= -1; else { sortKey = key; sortDir = 1; }
          page = 1; _updateCount(); _updateThead(); _updateTbody(); _updatePagination();
        });
      });
    }

    // ── Rebuild tbody rows only ──────────────────────────────
    function _updateTbody() {
      var tbody = container.querySelector("#tbl-tbody-" + uid);
      if (!tbody) return;

      var sorted = sortedData(), total = sorted.length;
      var pages  = Math.max(1, Math.ceil(total / PAGE_SIZE));
      if (page > pages) page = pages;
      var slice  = sorted.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

      if (!slice.length) {
        var isFiltered = search.trim().length > 0;
        var emptyHtml  = (typeof PerfUtils !== "undefined")
          ? PerfUtils.emptyStateHTML(search, uid)
          : '<div style="padding:32px 16px;text-align:center;color:var(--text-tertiary)">' +
              (isFiltered ? "No matches found" : "No cases found") + '</div>';
        tbody.innerHTML = '<tr><td colspan="' + (cols.length + (hasActions ? 1 : 0)) + '" style="padding:0">' + emptyHtml + '</td></tr>';
        return;
      }

      var html = "";
      slice.forEach(function(row, idx) {
        var staleDays = Utils.daysDiff(Utils.parseDate(row.Updated) || Utils.parseDate(row.Created));
        var sev = String(row.Severity || "").trim();
        var sevStyle = "";
        if (sev.startsWith("1"))      sevStyle = "border-left:3px solid var(--red,#da1e28)";
        else if (sev.startsWith("2")) sevStyle = "border-left:3px solid var(--orange,#ff832b)";
        else if (sev.startsWith("3")) sevStyle = "border-left:3px solid var(--yellow,#f1c21b)";
        html += '<tr class="' + (staleDays >= 5 ? "stale-row" : "") + '" style="' + sevStyle + '">';
        cols.forEach(function(col) {
          var val = col.render ? col.render(row, idx) : Utils.escHtml(row[col.key] || "\u2014");
          html += '<td class="' + (col.class || "") + '">' + val + '</td>';
        });
        if (hasActions) {
          html += '<td><div class="col-actions">';
          if (showRemind && onRemind)
            html += '<button class="action-btn-remind" data-case="' + Utils.escHtml(row["Case Number"]) + '">\u2709 Remind</button>';
          if (showReassign && onReassign)
            html += '<button class="action-btn-reassign" data-case="' + Utils.escHtml(row["Case Number"]) + '">\u21bb Reassign</button>';
          if (extraActions) html += extraActions(row);
          html += '</div></td>';
        }
        html += '</tr>';
      });
      tbody.innerHTML = html;

      // Wire action buttons on fresh tbody rows
      tbody.querySelectorAll(".action-btn-remind[data-case]").forEach(function(btn) {
        btn.addEventListener("click", function(e) {
          e.stopPropagation();
          var caseNum = btn.dataset.case;
          var row = data.find(function(r) { return r["Case Number"] === caseNum; });
          if (!row || !onRemind) return;
          onRemind(row);
        });
      });
      tbody.querySelectorAll(".action-btn-reassign[data-case]").forEach(function(btn) {
        btn.addEventListener("click", function(e) {
          e.stopPropagation();
          var row = Data.allCases().find(function(r) { return r["Case Number"] === btn.dataset.case; });
          if (row && onReassign) onReassign(row);
        });
      });
    }

    // ── Rebuild pagination only ──────────────────────────────
    function _updatePagination() {
      var sorted = sortedData(), total = sorted.length;
      var pages  = Math.max(1, Math.ceil(total / PAGE_SIZE));
      var pEl    = container.querySelector("#tbl-pagination-" + uid);
      if (!pEl) return;
      pEl.innerHTML = renderPagination(total, page, pages);
      pEl.querySelectorAll(".page-btn[data-page]").forEach(function(btn) {
        btn.addEventListener("click", function() {
          page = parseInt(btn.dataset.page);
          _updateCount(); _updateTbody(); _updatePagination();
        });
      });
      var prevBtn = pEl.querySelector(".page-prev");
      if (prevBtn) prevBtn.addEventListener("click", function() {
        if (page > 1) { page--; _updateCount(); _updateTbody(); _updatePagination(); }
      });
      var nextBtn = pEl.querySelector(".page-next");
      if (nextBtn) nextBtn.addEventListener("click", function() {
        if (page < pages) { page++; _updateCount(); _updateTbody(); _updatePagination(); }
      });
    }

    // ── Full redraw (used by refresh / setSearch) ────────────
    function draw() {
      _updateCount(); _updateThead(); _updateTbody(); _updatePagination();
    }

    // Initial build
    _buildShell();
    draw();

    return {
      refresh: function(newCases) { data = [...newCases]; page = 1; draw(); },
      getSearch: function() { return search; },
      // F24: Stable method to programmatically set search value
      setSearch: function(val) {
        search = val; page = 1;
        var si = container.querySelector("#tbl-search-" + uid);
        if (si) si.value = val;
        draw();
      }
    };
  }


  /* ── Pagination ── */
  function renderPagination(total, page, pages) {
    if (pages <= 1) return "";
    var from  = total === 0 ? 0 : (page - 1) * PAGE_SIZE + 1;
    var to    = Math.min(page * PAGE_SIZE, total);
    var start = Math.max(1, page - 2);
    var end   = Math.min(pages, page + 2);
    var btns  = "";
    for (var p = start; p <= end; p++)
      btns += '<button class="page-btn ' + (p === page ? "active" : "") + '" data-page="' + p + '">' + p + '</button>';
    return '<div class="table-pagination">' +
      '<span>Showing ' + from + '\u2013' + to + ' of ' + total + '</span>' +
      '<div class="page-btns">' +
        '<button class="page-btn page-prev" ' + (page===1?"disabled":"") + '>\u2039 Prev</button>' +
        btns +
        '<button class="page-btn page-next" ' + (page===pages?"disabled":"") + '>Next \u203a</button>' +
      '</div></div>';
  }

  /* ── Export ── */
  function exportToExcel(rows, cols, suffix) {
    var headers = cols.map(function(c) { return c.label; }).join(",");
    var dataRows = rows.map(function(row) {
      return cols.map(function(col) {
        var val = col.key ? (row[col.key] || "") : "";
        val = String(val).replace(/<[^>]*>/g, "").replace(/"/g, '""');
        return '"' + val + '"';
      }).join(",");
    });
    var csv  = [headers].concat(dataRows).join("\n");
    var blob = new Blob(["\uFEFF" + csv], { type:"text/csv;charset=utf-8;" });
    var url  = URL.createObjectURL(blob);
    var a    = document.createElement("a");
    a.href = url; a.download = "cases_" + suffix + "_" + new Date().toISOString().slice(0,10) + ".csv";
    document.body.appendChild(a); a.click();
    setTimeout(function() { URL.revokeObjectURL(url); a.remove(); }, 1000);
  }

  /* ── Default columns ── */
  function defaultColumns() {
    return [
      { key:"Case Number", label:"Case Number", class:"col-case-num",
        render: function(row) {
          var perfIcon = (typeof Data !== "undefined" && Data.isMarkedPerformance && Data.isMarkedPerformance(row["Case Number"]))
            ? '<span title="Performance Case" style="color:var(--red);margin-right:4px;display:inline-flex;align-items:center;vertical-align:middle"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg></span>'
            : "";
          return perfIcon + '<span class="text-mono c-blue">' + Utils.escHtml(row["Case Number"]) + '</span>';
        }},
      { key:"Owner", label:"Owner", class:"col-owner",
        render: function(row) {
          var displayOwner = Utils.escHtml(Utils.shortName(row.Owner));
          if (row._ownerOverride) {
            var origOwner = row._originalOwner ? Utils.escHtml(Utils.shortName(row._originalOwner)) : "";
            var ts = row._overrideTs ? new Date(row._overrideTs).toLocaleDateString("en-GB", { day:"numeric", month:"short", year:"numeric" }) : "";
            var tooltip = origOwner ? "Reassigned from " + origOwner + (ts ? " on " + ts : "") : "Reassigned via Admin Portal";
            return '<div style="display:flex;flex-direction:column;gap:2px;align-items:flex-start">' +
              '<span>' + displayOwner + '</span>' +
              '<span title="' + tooltip + '" style="display:inline-flex;align-items:center;gap:3px;background:rgba(224,112,0,.12);color:var(--orange,#ff832b);font-size:10px;font-weight:700;padding:1px 6px;border-radius:var(--radius-xs,3px);border:1px solid rgba(224,112,0,.25);white-space:nowrap;cursor:default;">' +
                '<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 014-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 01-4 4H3"/></svg>' +
                'Reassigned</span>' +
              (origOwner ? '<span style="font-size:10px;color:var(--text-tertiary);font-style:italic">was: ' + origOwner + '</span>' : "") +
              '</div>';
          }
          return displayOwner;
        }},
      { key:"Status", label:"Status",
        render: function(row) { return Utils.statusBadge(row.Status); }},
      { key:"Product", label:"Product", class:"col-product",
        render: function(row) { return '<span title="' + Utils.escHtml(row.Product) + '">' + Utils.escHtml(row.Product) + '</span>'; }},
      { key:"Customer number", label:"Customer #", class:"col-date text-mono",
        render: function(row) { return Utils.escHtml(row["Customer number"] || "\u2014"); }},
      { key:"Created", label:"Created", class:"col-date",
        render: function(row) { return Utils.fmtDateShort(row.Created); }},
      { key:"Updated", label:"Updated", class:"col-stale",
        render: function(row) {
          var d    = Utils.parseDate(row.Updated);
          var days = Utils.daysDiff(d);
          return '<span style="color:' + (days>=5?"var(--red)":"var(--text-tertiary)") + '">' + Utils.fmtDateShort(row.Updated) + '</span>' +
            (days >= 5 ? ' <span class="stale-days">(+' + days + 'd)</span>' : "");
        }},
      { key:"Severity", label:"Severity", class:"col-sev",
        render: function(row) {
          var s = String(row.Severity||"").trim();
          var col = s.startsWith("1") ? "var(--red)" : s.startsWith("2") ? "var(--orange)" : s.startsWith("3") ? "var(--yellow)" : "var(--text-tertiary)";
          return '<span style="font-weight:700;color:' + col + ';font-family:var(--font-mono)">' + Utils.escHtml(s||"\u2014") + '</span>';
        }},
      { key:"Age", label:"Age (days)", class:"col-age text-mono",
        render: function(row) {
          var a = parseInt(row.Age||"0", 10);
          return '<span style="font-family:var(--font-mono);color:' + (a>30?"var(--red)":a>14?"var(--orange)":"var(--text-tertiary)") + '">' + (a > 0 ? a + "d" : "\u2014") + '</span>';
        }},
      { key:"Title", label:"Title", class:"col-title", sortable:false,
        render: function(row) { return '<span title="' + Utils.escHtml(row.Title) + '">' + Utils.escHtml(row.Title) + '</span>'; }}
    ];
  }

  return { render, defaultColumns, exportToExcel, renderPagination };
})();

