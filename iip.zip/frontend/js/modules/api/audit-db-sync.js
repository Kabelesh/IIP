/* audit-db-sync.js — patches Data.pushChange so every admin change is also
 * persisted to the DB audit_log table.
 *
 * The history panel in admin-dash.js fetches directly from the DB via
 * AdminAPIClient.getAuditLog() — no local hydration needed.
 */
(function () {

  // ── Guard: only run when an admin session token exists ──────────
  function _hasToken() {
    try {
      return typeof Admin !== 'undefined' && Admin.getToken && !!Admin.getToken();
    } catch (e) {
      return false;
    }
  }

  function _init() {
    if (typeof Data === 'undefined' || !Data.pushChange) {
      setTimeout(_init, 300);
      return;
    }

    var _orig = Data.pushChange.bind(Data);
    Data.pushChange = function (entry) {
      _orig(entry);

      // Only persist to DB when an admin token is present
      if (!_hasToken()) return;

      AdminAPIClient.pushAuditEntry({
        case_number: entry.caseNumber || '',
        field:       entry.field      || '',
        old_value:   entry.oldValue   || '',
        new_value:   entry.newValue   || '',
        updated_by:  entry.updatedBy  || 'Admin',
        is_bulk:     !!entry.isBulk,
        bulk_count:  entry.bulkCount  || null,
        client_ts:   entry.timestamp  || new Date().toLocaleString()
      }).catch(function (e) { console.warn('[AuditSync] DB write failed:', e); });
    };

    console.info('[AuditSync] patched — audit entries now persist to DB.');
  }

  _init();
})();
