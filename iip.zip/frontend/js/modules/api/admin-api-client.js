const AdminAPIClient = (() => {
  const BASE = window.API_BASE_ADMIN || (window.API_BASE ? window.API_BASE + '/admin' : '/iip/api/admin');
  function _token() {
    try { return (typeof Admin !== 'undefined' && Admin.getToken) ? Admin.getToken() : ''; } catch(e) { return ''; }
  }
  function _headers() { const h = {'Content-Type':'application/json'}; const tok=_token(); if(tok) h['X-IIP-Admin-Token']=tok; return h; }
  async function _req(method, path, body) {
    const opts = {method, headers: _headers()};
    if (body !== undefined) opts.body = JSON.stringify(body);
    const r = await fetch(BASE + path, opts);
    if (!r.ok) {
      if (r.status === 403 && typeof Admin !== 'undefined' && Admin.showLoginModal) Admin.showLoginModal();
      const e = await r.json().catch(()=>({detail:r.statusText})); throw new Error(e.detail||'HTTP '+r.status);
    }
    return r.json();
  }
  function bootstrap()                       { return _req('GET',    '/bootstrap'); }
  function getTeamMembers()                  { return _req('GET',    '/team-members'); }
  function createTeamMember(d)               { return _req('POST',   '/team-members', d); }
  function updateTeamMember(id, d)           { return _req('PUT',    '/team-members/'+id, d); }
  function deleteTeamMember(id)              { return _req('DELETE', '/team-members/'+id); }
  function getEscalationContacts()           { return _req('GET',    '/escalation-contacts'); }
  function createEscalationContact(d)        { return _req('POST',   '/escalation-contacts', d); }
  function updateEscalationContact(id, d)    { return _req('PUT',    '/escalation-contacts/'+id, d); }
  function deleteEscalationContact(id)       { return _req('DELETE', '/escalation-contacts/'+id); }
  function getIBMContacts()                  { return _req('GET',    '/ibm-contacts'); }
  function createIBMContact(d)               { return _req('POST',   '/ibm-contacts', d); }
  function updateIBMContact(id, d)           { return _req('PUT',    '/ibm-contacts/'+id, d); }
  function deleteIBMContact(id)              { return _req('DELETE', '/ibm-contacts/'+id); }
  function getALMLines()                     { return _req('GET',    '/alm-lines'); }
  function createALMLine(d)                  { return _req('POST',   '/alm-lines', d); }
  function updateALMLine(line, d)            { return _req('PUT',    '/alm-lines/'+line, d); }
  function deleteALMLine(line)               { return _req('DELETE', '/alm-lines/'+line); }
  function pushAuditEntry(d)                 { return _req('POST',   '/audit-log', d); }
  function getAuditLog(limit)                { return _req('GET',    '/audit-log'+(limit?'?limit='+limit:'?limit=2000')); }
  function getELMUpgrades()                  { return _req('GET',    '/elm-upgrades'); }
  function createELMUpgrade(d)               { return _req('POST',   '/elm-upgrades', d); }
  function updateELMUpgrade(id, d)           { return _req('PUT',    '/elm-upgrades/'+id, d); }
  function deleteELMUpgrade(id)              { return _req('DELETE', '/elm-upgrades/'+id); }
  return { bootstrap, getTeamMembers, createTeamMember, updateTeamMember, deleteTeamMember,
    getEscalationContacts, createEscalationContact, updateEscalationContact, deleteEscalationContact,
    getIBMContacts, createIBMContact, updateIBMContact, deleteIBMContact,
    getALMLines, createALMLine, updateALMLine, deleteALMLine, pushAuditEntry, getAuditLog,
    getELMUpgrades, createELMUpgrade, updateELMUpgrade, deleteELMUpgrade };
})();
