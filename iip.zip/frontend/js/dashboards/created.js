/* ============================================================
   js/dashboards/created.js  —  Created Cases tab
   Identical layout to Closed Cases but filters on Created date
   and uses all team cases (not just closed ones).
   ============================================================ */

function _cssClrCr(v) {
  try { return getComputedStyle(document.documentElement).getPropertyValue(v).trim() || v; }
  catch(e) { return v; }
}

const DashCreated = (() => {

  let _year = "", _month = "", _fromDate = "", _toDate = "", _lastDays = "";
  let _ownerFilter = "";
  let _customerFilter = "";
  let _tableRef = null;

  function _yearSelect(id, selected) {
    const yearsFromData = (() => {
      try {
        const all = Data.teamCases();
        const ySet = new Set();
        all.forEach(r => {
          const v = (r["Created"] || "").trim();
          if (!v) return;
          const d = Utils.parseDate(v);
          if (d && !isNaN(d)) ySet.add(d.getFullYear());
        });
        return [...ySet].sort();
      } catch(e) { return [2023, 2024, 2025, 2026]; }
    })();
    const opts = yearsFromData.map(y =>
      `<option value="${y}" ${String(y)===String(selected)?"selected":""}>${y}</option>`).join("");
    return `<div class="filter-group"><span class="filter-label">Year</span>
      <select id="${id}" class="form-select"><option value="">All</option>${opts}</select></div>`;
  }

  function _monthSelect(id, selected) {
    const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    const opts = months.map((m,i) => {
      const v = String(i+1).padStart(2,"0");
      return `<option value="${v}" ${v===selected?"selected":""}>${m}</option>`;
    }).join("");
    return `<div class="filter-group"><span class="filter-label">Month</span>
      <select id="${id}" class="form-select"><option value="">All</option>${opts}</select></div>`;
  }

  function render() {
    const el = document.getElementById("tab-created");
    if (!el) return;
    // Reset filter state on every navigation
    _year = ""; _month = ""; _fromDate = ""; _toDate = ""; _lastDays = "";
    _ownerFilter = ""; _customerFilter = "";
    _tableRef = null; // reset so _drawAll creates a fresh table instance
    el.innerHTML = `
      <div class="kpi-row" id="cr-kpi-row"></div>
      <div class="filter-bar mt-5">
        ${_yearSelect("cr-year",_year)} ${_monthSelect("cr-month",_month)}
        <div class="filter-group">
          <span class="filter-label">From</span>
          <input id="cr-from" aria-label="From date" type="date" class="form-input form-input-sm w-140" value="${_fromDate}"/>
        </div>
        <div class="filter-group">
          <span class="filter-label">To</span>
          <input id="cr-to" aria-label="To date" type="date" class="form-input form-input-sm w-140" value="${_toDate}"/>
        </div>
        <div class="filter-group">
          <span class="filter-label">Last N Days</span>
          <input id="cr-lastdays" aria-label="Last N days" type="number" class="form-input form-input-sm w-80" placeholder="e.g. 30" value="${_lastDays}"/>
        </div>
        <div class="filter-group">
          <span class="filter-label">Customer Number</span>
          <select id="cr-customer" class="form-select" style="min-width:140px">
            <option value="">All</option>
            ${[...new Set(Data.teamCases().map(r => r["Customer number"] || "").filter(Boolean))].sort()
              .map(cn => `<option value="${cn}" ${_customerFilter===cn?"selected":""}>${cn}</option>`).join("")}
          </select>
        </div>
        <button id="cr-clear" class="btn btn-ghost btn-sm">Clear</button>
      </div>
      <div class="grid-3 mt-5" id="cr-charts-grid">
        <div class="tile">
          <div class="section-title">Monthly Created</div>
          <div class="chart-canvas-wrap" style="height:220px"><canvas id="chart-created-monthly"></canvas></div>
        </div>
        <div class="tile">
          <div class="section-title">Weekly Created (Last 12w)</div>
          <div class="chart-canvas-wrap" style="height:220px"><canvas id="chart-created-weekly"></canvas></div>
        </div>
        <div class="tile">
          <div class="section-title">Yearly Created</div>
          <div class="chart-canvas-wrap" style="height:220px"><canvas id="chart-created-yearly"></canvas></div>
          <div id="chart-created-yearly-legend" style="display:flex;flex-wrap:wrap;gap:4px 12px;justify-content:center;padding:6px 4px 0;font-size:11px;font-family:'IBM Plex Sans',sans-serif;"></div>
        </div>
      </div>
      <div class="tile mt-5">
        <div class="section-title">Owner vs Created Cases Count</div>
        <div class="chart-canvas-wrap" style="height:350px"><canvas id="chart-created-owners"></canvas></div>
      </div>
      <div class="tile mt-5">
        <div id="tbl-created" data-title="Created Cases"></div>
      </div>
    `;
    _bindFilters();
    try { _drawAll(); } catch(e) {
      console.warn("[DashCreated] render error:", e);
      try {
        const tblEl = document.getElementById("tbl-created");
        const cases = Data.teamCases();
        if (tblEl && cases.length) Table.render(tblEl, cases, { showActions: false });
        else if (tblEl) tblEl.innerHTML = '<div style="padding:40px;text-align:center;color:var(--text-tertiary)">No cases found.</div>';
      } catch(e2) {}
    }
  }

  function _filtered() {
    const today = new Date();
    return Data.teamCases().filter(r => {
      const d = Utils.parseDate(r.Created);
      if (_year  && (!d || String(d.getFullYear()) !== _year)) return false;
      if (_month && (!d || String(d.getMonth()+1).padStart(2,"0") !== _month)) return false;
      if (_fromDate && (!d || d < new Date(_fromDate))) return false;
      if (_toDate   && (!d || d > new Date(_toDate + "T23:59:59"))) return false;
      if (_lastDays && _lastDays > 0) {
        const cutoff = new Date(today); cutoff.setDate(today.getDate() - parseInt(_lastDays, 10));
        if (!d || d < cutoff) return false;
      }
      if (_customerFilter) {
        const cf = _customerFilter.trim().toLowerCase();
        const cn = (r["Customer number"] || "").toLowerCase();
        if (!cn.includes(cf)) return false;
      }
      return true;
    });
  }

  function _setEls(map) {
    Object.entries(map).forEach(([id, val]) => { const el = document.getElementById(id); if (el) el.value = val; });
  }

  function _drawAll(ownerFilter) {
    if (ownerFilter !== undefined) _ownerFilter = ownerFilter;
    const cases     = _filtered();
    const tableData = _ownerFilter ? cases.filter(r => r.Owner === _ownerFilter) : cases;

    _renderKPIs(cases);

    const lastDaysMode = !!(_lastDays && parseInt(_lastDays,10) > 0);
    const grid = document.getElementById("cr-charts-grid");
    if (grid) grid.style.display = lastDaysMode ? "none" : "";

    if (lastDaysMode) {
      const n = parseInt(_lastDays, 10);
      const toD = new Date(), fromD = new Date();
      fromD.setDate(toD.getDate() - n);
      const pad = v => String(v).padStart(2,"0");
      _setEls({
        "cr-from":  fromD.getFullYear()+"-"+pad(fromD.getMonth()+1)+"-"+pad(fromD.getDate()),
        "cr-to":    toD.getFullYear()+"-"+pad(toD.getMonth()+1)+"-"+pad(toD.getDate()),
        "cr-year":  String(fromD.getFullYear()),
        "cr-month": pad(fromD.getMonth()+1)
      });
    }

    if (!lastDaysMode) { _drawMonthly(cases); _drawWeekly(cases); _drawYearly(cases); }

    try { Charts.ownerBar("chart-created-owners", Utils.ownerCounts(cases), {
      color: _cssClrCr("--chart-1"),
      onClick: name => {
        _drawAll(name === _ownerFilter ? "" : name);
        document.getElementById("tbl-created")?.scrollIntoView({ behavior:"smooth", block:"start" });
      }
    }); } catch(e) { console.warn("[DashCreated] ownerBar:", e); }

    const tblEl = document.getElementById("tbl-created");
    if (_tableRef) {
      _tableRef.refresh(tableData);
    } else {
      _tableRef = Table.render(tblEl, tableData, {
      showActions: false,
      defaultSortKey: "Created",
      defaultSortDir: 1,
      columns: [
        { key:"Case Number", label:"Case Number", class:"col-case-num",
          render: row => {
            const perfIcon = (typeof Data!=="undefined" && Data.isMarkedPerformance && Data.isMarkedPerformance(row["Case Number"]))
              ? `<span title="Performance Case" style="color:var(--red);margin-right:4px;display:inline-flex;align-items:center;vertical-align:middle"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg></span>` : "";
            const cn = Utils.escHtml(row["Case Number"]);
            return `${perfIcon}<span class="case-number-copy" data-cn="${cn}" title="Click to copy" style="cursor:pointer;color:#2563eb;font-weight:600;font-family:var(--font-mono)">${cn}</span>`;
          }},
        { key:"Owner",  label:"Owner",  class:"col-owner",   render: row => Utils.escHtml(Utils.shortName(row.Owner)) },
        { key:"Status", label:"Status",                      render: row => Utils.statusBadge(row.Status) },
        { key:"Product",label:"Product",class:"col-product", render: row => `<span title="${Utils.escHtml(row.Product)}">${Utils.escHtml(row.Product)}</span>` },
        { key:"Customer number", label:"Customer #", class:"col-date text-mono", render: row => Utils.escHtml(row["Customer number"]||"—") },
        { key:"Created", label:"Created", class:"col-date",
          sortValue: row => { const d=Utils.parseDate(row.Created); return d?d.getTime():0; },
          render: row => Utils.fmtDateShort(row.Created) },
        { key:"Updated", label:"Updated", class:"col-stale",
          render: row => {
            const d=Utils.parseDate(row.Updated), days=Utils.daysDiff(d);
            return `<span style="color:${days>=5?_cssClrCr("--red"):_cssClrCr("--text-tertiary")}">${Utils.fmtDateShort(row.Updated)}</span>`
                 + (days>=5?` <span class="stale-days">(+${days}d)</span>`:"");
          }},
        { key:"Severity", label:"Severity", class:"col-sev",
          render: row => {
            const s=String(row.Severity||"").trim();
            const col=s.startsWith("1")?_cssClrCr("--red"):s.startsWith("2")?_cssClrCr("--orange"):s.startsWith("3")?_cssClrCr("--yellow"):_cssClrCr("--text-tertiary");
            return `<span style="font-weight:700;color:${col};font-family:var(--font-mono)">${Utils.escHtml(s||"—")}</span>`;
          }},
        { key:"Age", label:"Age (days)", class:"col-age text-mono",
          render: row => {
            const a=parseInt(row.Age||"0",10);
            return `<span style="font-family:var(--font-mono);color:${a>30?_cssClrCr("--red"):a>14?_cssClrCr("--orange"):_cssClrCr("--text-tertiary")}">${a>0?a+"d":"—"}</span>`;
          }},
        { key:"Title", label:"Title", class:"col-title", sortable:false,
          render: row => `<span title="${Utils.escHtml(row.Title)}">${Utils.escHtml(row.Title)}</span>` }
      ]
    });
    }
  }

  function _renderKPIs(cases) {
    const row = document.getElementById("cr-kpi-row");
    if (!row) return;
    const today = new Date();
    const acc02 = cases.filter(r => (r["Customer number"]||"").replace(/^0+/,"").startsWith("2"));
    const acc08 = cases.filter(r => (r["Customer number"]||"").includes(Data.customerAccountId()));
    const created7d = cases.filter(r => {
      const d = Utils.parseDate(r.Created);
      return d && (today - d) / 86400000 <= 7;
    });
    const avgAge = cases.length > 0
      ? Math.round(cases.reduce((sum, r) => sum + (parseInt(r.Age || "0", 10)), 0) / cases.length)
      : 0;
    const kpi = (label, value, cls) => `<div class="kpi-card ${cls}"><div class="kpi-label">${label}</div><div class="kpi-value">${value}</div></div>`;
    row.innerHTML = [
      kpi("Total Created",cases.length,""),
      kpi("Created (Last 7d)",created7d.length,"kpi-green"),
      kpi("02 Account",acc02.length,"kpi-blue"),
      kpi("08 Account",acc08.length,"kpi-purple"),
      kpi("Avg Days",avgAge+"d","kpi-yellow")
    ].join("");
  }

  function _isoWeekKey(d) {
    const jan1 = new Date(d.getFullYear(), 0, 1);
    const week = Math.ceil(((d - jan1) / 86400000 + jan1.getDay() + 1) / 7);
    return d.getFullYear() + "-W" + String(week).padStart(2,"0");
  }

  function _drawMonthly(cases) {
    const counts={};
    cases.forEach(r=>{const d=Utils.parseDate(r.Created);if(!d)return;const k=d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0");counts[k]=(counts[k]||0)+1;});
    const sorted=Object.keys(counts).sort().slice(-18);
    const labels=sorted.map(k=>{const[y,m]=k.split("-");return["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"][parseInt(m)-1]+" "+y.slice(2);});
    const data=sorted.map(k=>counts[k]);
    const canvas=document.getElementById("chart-created-monthly"); if(!canvas) return;
    if(typeof Chart==="undefined"){setTimeout(()=>_drawMonthly(cases),200);return;}
    try{const ex=Chart.getChart?.(canvas);if(ex)ex.destroy();}catch(e){}
    const ctx2d=canvas.getContext("2d");
    const grad=ctx2d.createLinearGradient(0,0,0,canvas.offsetHeight||220);
    grad.addColorStop(0,"rgba(69,137,255,0.38)");grad.addColorStop(0.6,"rgba(69,137,255,0.10)");grad.addColorStop(1,"rgba(69,137,255,0.00)");
    const onPointClick=label=>{
      const mos=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
      const[mon,yy]=label.split(" "),mm=String(mos.indexOf(mon)+1).padStart(2,"0"),yyyy=(parseInt(yy)<50?"20":"19")+yy;
      _fromDate=yyyy+"-"+mm+"-01";_toDate=yyyy+"-"+mm+"-"+String(new Date(parseInt(yyyy),parseInt(mm),0).getDate()).padStart(2,"0");
      _year=yyyy;_month=mm;_lastDays="";
      _setEls({"cr-year":yyyy,"cr-month":mm,"cr-from":_fromDate,"cr-to":_toDate,"cr-lastdays":""});
      _ownerFilter="";_drawAll();
      document.getElementById("tbl-created")?.scrollIntoView({behavior:"smooth",block:"start"});
    };
    try{new Chart(canvas,{type:"line",data:{labels,datasets:[{data,borderColor:"#4589FF",backgroundColor:grad,borderWidth:2.5,
      pointRadius:data.length>12?2:4,pointHoverRadius:6,pointBackgroundColor:"#4589FF",pointBorderColor:"#fff",pointBorderWidth:2,tension:0.4,fill:true}]},
      options:{responsive:true,maintainAspectRatio:false,
        plugins:{legend:{display:false},tooltip:{backgroundColor:"#fff",borderColor:_cssClrCr("--border-subtle"),borderWidth:1,
          titleColor:_cssClrCr("--text-primary"),bodyColor:_cssClrCr("--text-secondary"),
          callbacks:{label:item=>" "+item.raw+" cases \u2014 click to filter"}}},
        scales:{x:{grid:{display:false},border:{display:false},ticks:{color:_cssClrCr("--text-tertiary"),font:{size:10},maxRotation:45}},
                y:{grid:{color:"rgba(0,0,0,0.05)",drawTicks:false},border:{display:false},ticks:{color:_cssClrCr("--text-tertiary"),font:{size:11},padding:8},beginAtZero:true}},
        onClick:(evt,els)=>{if(els.length){const lbl=labels[els[0].index];setTimeout(()=>{try{onPointClick(lbl);}catch(e){console.warn("[DashCreated] monthly onClick:",e);}},0);}}
      }})}catch(e){console.warn("[DashCreated] Monthly area chart:",e);}
    canvas.style.cursor="pointer";
  }

  function _drawWeekly(cases) {
    const now=new Date(), weekBuckets={};
    for(let i=11;i>=0;i--){const d=new Date(now);d.setDate(d.getDate()-i*7);weekBuckets[_isoWeekKey(d)]=0;}
    cases.forEach(r=>{
      const d=Utils.parseDate(r.Created);if(!d)return;
      const diff=Math.floor((now-d)/(7*24*3600*1000));
      if(diff>=0&&diff<12){const k=_isoWeekKey(new Date(now.getTime()-diff*7*24*3600*1000));if(k in weekBuckets)weekBuckets[k]++;}
    });
    const keys=Object.keys(weekBuckets).sort();
    const labels=keys.map(k=>k.replace(/-W/,"-W"));
    const data=keys.map(k=>weekBuckets[k]);
    const canvas=document.getElementById("chart-created-weekly"); if(!canvas) return;
    if(typeof Chart==="undefined"){setTimeout(()=>_drawWeekly(cases),200);return;}
    try{const ex=Chart.getChart?.(canvas);if(ex)ex.destroy();}catch(e){}
    const n=keys.length;
    const colors=keys.map((_,i)=>{const t=n>1?i/(n-1):0;const r=Math.round(0x45+(0x00-0x45)*t);const g=Math.round(0x89+(0xBE-0x89)*t);const b=Math.round(0xFF+(0x65-0xFF)*t);return"rgba("+r+","+g+","+b+",0.85)";});
    const onBarClick=label=>{
      const wkKey=keys.find(k=>k===label||k.endsWith("-W"+label.replace(/.*-W/,""))); if(!wkKey) return;
      const[yr,wn]=wkKey.split("-W"),jan1=new Date(parseInt(yr),0,1),startOfWk=new Date(jan1);
      startOfWk.setDate(jan1.getDate()+(parseInt(wn)-1)*7-jan1.getDay());
      const endOfWk=new Date(startOfWk);endOfWk.setDate(startOfWk.getDate()+6);
      const fmt=d=>d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0");
      _fromDate=fmt(startOfWk);_toDate=fmt(endOfWk);_year="";_month="";_lastDays="";
      _setEls({"cr-year":"","cr-month":"","cr-lastdays":"","cr-from":_fromDate,"cr-to":_toDate});
      _ownerFilter="";_drawAll();
      document.getElementById("tbl-created")?.scrollIntoView({behavior:"smooth",block:"start"});
    };
    try{new Chart(canvas,{type:"bar",data:{labels,datasets:[{data,backgroundColor:colors,
        hoverBackgroundColor:colors.map(c=>c.replace("0.85","1")),borderRadius:7,borderSkipped:false}]},
      options:{responsive:true,maintainAspectRatio:false,
        plugins:{legend:{display:false},tooltip:{backgroundColor:"#fff",borderColor:_cssClrCr("--border-subtle"),borderWidth:1,
          titleColor:_cssClrCr("--text-primary"),bodyColor:_cssClrCr("--text-secondary"),
          callbacks:{label:item=>" "+item.raw+" cases \u2014 click to filter"}}},
        scales:{x:{grid:{display:false},border:{display:false},ticks:{color:_cssClrCr("--text-tertiary"),font:{size:10},maxRotation:0}},
                y:{grid:{color:"rgba(0,0,0,0.05)",drawTicks:false},border:{display:false},ticks:{color:_cssClrCr("--text-tertiary"),font:{size:11},padding:8},beginAtZero:true}},
        onClick:(evt,els)=>{if(els.length){const key=keys[els[0].index];setTimeout(()=>{try{onBarClick(key);}catch(e){console.warn("[DashCreated] weekly onClick:",e);}},0);}}
      }})}catch(e){console.warn("[DashCreated] Weekly gradient bars:",e);}
    canvas.style.cursor="pointer";
  }

  function _drawYearly(cases) {
    const counts = {};
    cases.forEach(r => {
      const d = Utils.parseDate(r.Created);
      if (!d) return;
      const y = String(d.getFullYear());
      counts[y] = (counts[y]||0) + 1;
    });
    const sorted = Object.keys(counts).sort();
    const data   = sorted.map(k => counts[k]);
    _drawYearlyDonut("chart-created-yearly", sorted, data, label => {
      _year = label; _month = ""; _fromDate = ""; _toDate = ""; _lastDays = "";
      _setEls({"cr-year":label,"cr-month":"","cr-from":"","cr-to":"","cr-lastdays":""});
      _ownerFilter = ""; _drawAll();
      document.getElementById("tbl-created")?.scrollIntoView({behavior:"smooth",block:"start"});
    });
  }

  function _drawYearlyDonut(canvasId, labels, data, onYearClick) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;
    if (typeof Chart === "undefined") { setTimeout(() => _drawYearlyDonut(canvasId,labels,data,onYearClick), 200); return; }
    try { const ex = Chart.getChart?.(canvas); if (ex) ex.destroy(); } catch(e) {}

    const palette  = ["#4589FF","#42BE65","#8A3FFC","#F1C21B","#FF832B","#33B1FF","#FA4D56","#08BDBA"];
    const total    = data.reduce((s,v) => s+v, 0);
    const visible  = labels.map(() => true);
    let visibleTotal = total;

    const centerPlugin = {
      id: "crYearlyCenter",
      afterDraw(chart) {
        const { ctx, chartArea: { left, right, top, bottom } } = chart;
        const cx = (left+right)/2, cy = (top+bottom)/2;
        ctx.save();
        ctx.textAlign = "center"; ctx.textBaseline = "middle";
        ctx.font = `700 ${Math.max(18,Math.min(26,(right-left)*0.13))}px 'IBM Plex Sans',sans-serif`;
        ctx.fillStyle = _cssClrCr("--text-primary") || "#161616";
        ctx.fillText(visibleTotal.toLocaleString(), cx, cy - 8);
        ctx.font = `400 11px 'IBM Plex Sans',sans-serif`;
        ctx.fillStyle = _cssClrCr("--text-tertiary") || "#6f6f6f";
        ctx.fillText("Total Cases", cx, cy + 12);
        ctx.restore();
      }
    };

    let chartInst;
    try {
      chartInst = new Chart(canvas, {
        type: "doughnut",
        data: {
          labels,
          datasets: [{
            data,
            backgroundColor: labels.map((_,i) => palette[i%palette.length]+"dd"),
            borderColor:      labels.map((_,i) => palette[i%palette.length]),
            borderWidth: 2.5,
            hoverBackgroundColor: labels.map((_,i) => palette[i%palette.length]),
            hoverBorderWidth: 0,
            hoverOffset: 8
          }]
        },
        plugins: [centerPlugin],
        options: {
          responsive: true, maintainAspectRatio: false,
          cutout: "62%",
          animation: { animateRotate:true, animateScale:false, duration:700, easing:"easeOutQuart" },
          plugins: {
            legend: { display: false },
            tooltip: {
              backgroundColor:"#fff", borderColor:_cssClrCr("--border-subtle"), borderWidth:1,
              titleColor:_cssClrCr("--text-primary"), bodyColor:_cssClrCr("--text-secondary"),
              padding:10, cornerRadius:8,
              callbacks: {
                label: item => {
                  const pct = total ? ((item.raw/total)*100).toFixed(1) : 0;
                  return `  ${item.raw} cases (${pct}%) — click to filter`;
                }
              }
            }
          },
          onClick: (evt, elements) => {
            if (elements.length && onYearClick) {
              setTimeout(() => { try { onYearClick(labels[elements[0].index]); } catch(e){} }, 0);
            }
          }
        }
      });
    } catch(e) { console.warn("[DashCreated] yearly donut:", e); }

    // ── Legend with toggle + click-to-filter ──────────────────────────────────
    const legendEl = document.getElementById("chart-created-yearly-legend");
    if (legendEl && chartInst) {
      legendEl.innerHTML = labels.map((lbl, i) => {
        const color = palette[i%palette.length];
        return `<span data-cidx="${i}" style="display:inline-flex;align-items:center;gap:4px;cursor:pointer;user-select:none;white-space:nowrap;">
          <span class="cyl-swatch" style="display:inline-block;width:10px;height:10px;border-radius:2px;background:${color};flex-shrink:0;"></span>
          <span class="cyl-text" style="color:${_cssClrCr("--text-primary")||"#161616"};">${lbl} (${data[i].toLocaleString()})</span>
        </span>`;
      }).join("");

      legendEl.querySelectorAll("span[data-cidx]").forEach(item => {
        item.addEventListener("click", () => {
          const i      = parseInt(item.dataset.cidx);
          const color  = palette[i%palette.length];
          const swatch = item.querySelector(".cyl-swatch");
          const text   = item.querySelector(".cyl-text");

          // Toggle visibility in donut
          visible[i] = !visible[i];
          chartInst.toggleDataVisibility(i);
          visibleTotal = data.reduce((s,v,idx) => s+(visible[idx]?v:0), 0);
          chartInst.update();

          // Visual feedback
          swatch.style.background   = visible[i] ? color : "transparent";
          swatch.style.border       = visible[i] ? "none" : `1.5px solid ${color}`;
          text.style.color          = visible[i] ? (_cssClrCr("--text-primary")||"#161616") : (_cssClrCr("--text-tertiary")||"#6f6f6f");
          text.style.textDecoration = visible[i] ? "none" : "line-through";

          // Also filter the table by this year
          if (onYearClick) setTimeout(() => { try { onYearClick(labels[i]); } catch(e){} }, 0);
        });
      });
    }

    if (onYearClick) canvas.style.cursor = "pointer";
  }

  let _chartClickDebounce = {};
  function _drawBarChart(canvasId, labels, data, color, onBarClick) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;
    if (typeof Chart === "undefined") { setTimeout(()=>_drawBarChart(canvasId,labels,data,color,onBarClick),200); return; }
    try { const ex=Chart.getChart?.(canvas); if(ex) ex.destroy(); } catch(e) {}
    try { new Chart(canvas, {
      type: "bar",
      data: { labels, datasets:[{ data, backgroundColor:color, hoverBackgroundColor:color, borderRadius:3 }] },
      options: {
        responsive:true, maintainAspectRatio:false,
        plugins:{ legend:{display:false}, tooltip:{
          backgroundColor:"#fff", borderColor:_cssClrCr("--border-subtle"), borderWidth:1,
          titleColor:_cssClrCr("--text-primary"), bodyColor:_cssClrCr("--text-secondary"),
          callbacks:{ label: item => ` ${item.raw} cases — click to filter` }
        }},
        scales:{
          x:{ grid:{display:false}, ticks:{color:_cssClrCr("--text-tertiary"),font:{size:10},maxRotation:45} },
          y:{ grid:{color:"rgba(0,0,0,0.06)"}, ticks:{color:_cssClrCr("--text-tertiary"),font:{size:11},precision:0,callback:v=>Number.isInteger(v)?v:null}, beginAtZero:true }
        },
        onClick: onBarClick?(evt,els)=>{if(els.length&&!_chartClickDebounce[canvasId]){_chartClickDebounce[canvasId]=true;const lbl=labels[els[0].index];setTimeout(()=>{try{onBarClick(lbl);}catch(e){console.warn("[DashCreated] chart click:",e);}delete _chartClickDebounce[canvasId];},0);}}:undefined
      }
    }); } catch(e) { console.warn("[DashCreated] chart:", e); }
    if (onBarClick) canvas.style.cursor="pointer";
  }

  function _bindFilters() {
    document.getElementById("cr-year")?.addEventListener("change",    e=>{_year=e.target.value;_ownerFilter="";_drawAll();});
    document.getElementById("cr-month")?.addEventListener("change",   e=>{_month=e.target.value;_ownerFilter="";_drawAll();});
    document.getElementById("cr-from")?.addEventListener("change",    e=>{_fromDate=e.target.value;_year="";_month="";_setEls({"cr-year":"","cr-month":""});_ownerFilter="";_drawAll();});
    document.getElementById("cr-to")?.addEventListener("change",      e=>{_toDate=e.target.value;_year="";_month="";_setEls({"cr-year":"","cr-month":""});_ownerFilter="";_drawAll();});
    document.getElementById("cr-lastdays")?.addEventListener("input", e=>{_lastDays=e.target.value;_year="";_month="";_fromDate="";_toDate="";_setEls({"cr-year":"","cr-month":"","cr-from":"","cr-to":""});_ownerFilter="";_drawAll();});
    document.getElementById("cr-customer")?.addEventListener("change", e=>{_customerFilter=e.target.value;_ownerFilter="";_drawAll();});
    document.getElementById("cr-clear")?.addEventListener("click", ()=>{
      _year="";_month="";_fromDate="";_toDate="";_lastDays="";_ownerFilter="";_customerFilter="";
      _setEls({"cr-year":"","cr-month":"","cr-from":"","cr-to":"","cr-lastdays":"","cr-customer":""});
      StateManager.clearFiltersForDashboard("created");
      _drawAll();
    });
  }

  return { render };
})();
