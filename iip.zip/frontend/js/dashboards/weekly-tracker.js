/* ================================================================
   weekly-tracker.js  —  IBM Weekly Closed Cases Tracker  v2.2
   2025: 237 cases / 27 weeks  |  2026: 48 cases / 8 weeks
   2025 rows with comments: 199
   v2.2: Reopened availability category, history export/import/reset,
         dedup guard, auto-history for alert categories, seed history
   ================================================================ */

// _WT_SEED removed — data now loaded from DB via /api/v2/weekly-tracker
let _wtDbCache = null;
let _wtDbLoaded = false;

let _wtDbLoadPromise = null;  // in-flight guard — prevents duplicate fetches
async function _loadWTFromDB(forceRefresh = false) {
  if (_wtDbLoaded && !forceRefresh) return _wtDbCache || {};
  // If a fetch is already in flight, return the same promise (no double request)
  if (_wtDbLoadPromise && !forceRefresh) return _wtDbLoadPromise;
  _wtDbLoadPromise = (async () => {
    try {
      const base = (window.API_BASE_V2 || '/iip/api/v2');
      const resp = await fetch(base + '/weekly-tracker', { cache: 'no-store' });
      if (resp.ok) {
        _wtDbCache = await resp.json();
        _wtDbLoaded = true;
        return _wtDbCache;
      }
    } catch(e) {
      console.warn('[WT] DB load failed:', e);
    }
    _wtDbLoaded = true;
    _wtDbCache = {};
    return {};
  })().finally(() => { _wtDbLoadPromise = null; });
  return _wtDbLoadPromise;
}


/* ================================================================
   CATEGORY NORMALISATION MAP
   Maps legacy/inconsistent category values → canonical names.
   Any value not in this map is left as-is (or treated as blank).
   ================================================================ */
const _WT_CAT_NORM = {
  // New canonical names (self-mapping)
  "Duplicate":                     "Duplicate",
  "Reopened":                      "Reopened",
  "Issue Fixed in iFix":           "Issue Fixed in iFix",
  "LQE Validation / Reindexing":   "LQE Validation / Reindexing",
  "Export / Import Issues":        "Export / Import Issues",
  "Known Defect":                  "Known Defect",
  "Out of Memory / Heap Issues":   "Out of Memory / Heap Issues",
  "TRS Feed Validation":           "TRS Feed Validation",
  "Insufficient Information in Logs": "Insufficient Information in Logs",
  "Single Occurrence Issue":       "Single Occurrence Issue",
  "DCM Connectivity Issues":       "DCM Connectivity Issues",
  "Database Connectivity Issues":  "Database Connectivity Issues",
  "Backup & Restore":             "Backup & Restore",
  // Legacy → new mapping
  "Application Bug":              "Known Defect",
  "Defect / iFix":                "Issue Fixed in iFix",
  "Defect":                       "Known Defect",
  "TestFix":                      "Issue Fixed in iFix",
  "Known Defect":                 "Known Defect",
  "OOM / App Down":               "Out of Memory / Heap Issues",
  "OutOfMemory / JVM":            "Out of Memory / Heap Issues",
  "LQE / TRS Issue":              "LQE Validation / Reindexing",
  "LQE / LDX":                    "LQE Validation / Reindexing",
  "TRS Validation":               "TRS Feed Validation",
  "LQE Validation":               "LQE Validation / Reindexing",
  "LQE Validation ":              "LQE Validation / Reindexing",
  "Export / Import Issue":        "Export / Import Issues",
  "Database Issue":               "Database Connectivity Issues",
  "Database Connectivity Issues": "Database Connectivity Issues",
  "DCM Connectivity Issues":      "DCM Connectivity Issues",
  "CCM / Work Item":              "Known Defect",
  "DNG / RM":                     "Known Defect",
  "ETM / QM":                     "Known Defect",
  "JRS / Reports":                "Known Defect",
  "Performance / Slow":           "Known Defect",
  "CDCM":                         "DCM Connectivity Issues",
  "Configuration Issue":          "Known Defect",
  "Permission Issue":             "Single Occurrence Issue",
  "Authentication Issue":         "Single Occurrence Issue",
  "Liberty / IHS":                "Known Defect",
  "Upgrade / Rollout":            "Known Defect",
  "7.0.3":                        "Known Defect",
  "Query / General":              "Insufficient Information in Logs",
  "Reopen / No Response":         "Insufficient Information in Logs",
  "Reopen":                       "Reopened",
  "Reopened":                     "Reopened",
  "Query":                        "Insufficient Information in Logs",
  "Artifact":                     "Insufficient Information in Logs",
  "License":                      "Insufficient Information in Logs",
  "L3 Tool":                      "Insufficient Information in Logs",
  "Lack of logs":                 "Insufficient Information in Logs",
  "Standby":                      "Single Occurrence Issue",
  "Customer":                     "Insufficient Information in Logs",
  "Duplicate":                    "Duplicate",
  // Numeric / garbage — map to blank so user is prompted
  "109": "", "130": "", "135": "", "145": "", "149": "", "154": "",
  "163": "", "168": "", "171": "", "175": "", "179": "",
  "184": "", "192": "",
};

/* ================================================================
   WT_CATEGORIES — built dynamically from seed data + canonical list
   Always sorted; new categories added via data appear automatically.
   ================================================================ */
// WT_CATEGORIES — loaded from DB via /api/v2/wt-categories, falls back to defaults
let WT_CATEGORIES = [
  "Backup & Restore",
  "Database Connectivity Issues",
  "DCM Connectivity Issues",
  "Duplicate",
  "Export / Import Issues",
  "Insufficient Information in Logs",
  "Issue Fixed in iFix",
  "Known Defect",
  "LQE Validation / Reindexing",
  "Out of Memory / Heap Issues",
  "Reopened",
  "Single Occurrence Issue",
  "TRS Feed Validation",
];
let WT_CATEGORY_COLORS = {};
(async function _loadWtCategories() {
  try {
    const base = (window.API_BASE_V2 || '/iip/api/v2');
    const resp = await fetch(base + "/wt-categories", { cache: "no-store" });
    if (resp.ok) {
      const data = await resp.json();
      if (Array.isArray(data) && data.length) {
        WT_CATEGORIES = data.map(c => c.name).filter(Boolean).sort();
        data.forEach(c => { if (c.name && c.color) WT_CATEGORY_COLORS[c.name] = c.color; });
      }
    }
  } catch(e) { console.warn("[IIP] wt-categories load failed:", e.message); }
})();

/* ================================================================
   wtSuggestCategory — keyword-based auto-suggest
   Returns best matching category string or "" if no match.
   ================================================================ */
function wtSuggestCategory(title, comments) {
  const txt = ((title || "") + " " + (comments || "")).toLowerCase();
  const rules = [
    [/\boom|out.?of.?memory|heap|oome|garbage.collec|app.down|application.down|went.down|down.due/i, "Out of Memory / Heap Issues"],
    [/\blqe|ldx|compaction|reindex|lqers|datasource|data.source/i,                                   "LQE Validation / Reindexing"],
    [/\btrs.feed|trs.valid|skipped.resource/i,                                                       "TRS Feed Validation"],
    [/\bupgrad|rollout|migrat|7\.0\.3|7\.1|7\.2|repotools|jvm.*creat|jvmj9/i,                        "Known Defect"],
    [/\bliberty|ihs|httpd|websphere|wlp|ssl|certificate|config/i,                                    "Known Defect"],
    [/\bbackup|restore|recover/i,                                                                    "Backup & Restore"],
    [/\bexport|import|reqif|csv|xlsx|download|upload/i,                                              "Export / Import Issues"],
    [/\bdatabase|db|oracle|sql|jdbc|connection|dcm|connectivity/i,                                   "Database Connectivity Issues"],
    [/\bifix|testfix|dt\d{6}|known.issue|ki.dt|fixed|issue.fixed/i,                                  "Issue Fixed in iFix"],
    [/\bdefect|bug|error|exception|crash|slow|timeout|known.defect/i,                               "Known Defect"],
    [/\bquery|clarif|question|how.to|what.is|best.practic|reopen|no.response|no.reply/i,            "Insufficient Information in Logs"],
    [/\bpermission|access.denied|unauthorized|403|401|privilege|role/i,                             "Single Occurrence Issue"],
    [/\bauth|oauth|token|ldap|saml|login|sso|kerberos/i,                                            "Single Occurrence Issue"],
  ];
  for (const [re, cat] of rules) { if (re.test(txt)) return cat; }
  return "";
}

const DashWeeklyTracker = (() => {

  // On file://, use sessionStorage to avoid the empty-namespace isolation issue.

  // STORE_PREFIX removed — no longer writing to localStorage year keys
  const HISTORY_KEY   = "ibm_wtracker_history";
  const WTC_SERVER_KEY = "ibm_wtracker_comments_v1"; // server-side comments store key

  let _year        = new Date().getFullYear();
  let _currentWeek = null;
  let _editComment = null;
  let _activeTab   = "tracker"; // "tracker" | "history" | "reopened"
  let _sortCol     = "closedDate"; // FIX: default sort by Closed Date
  let _sortDir     = 1;            // 1 = asc, -1 = desc
  // Bulk selection state (#7)
  let _selectedRows = new Set();
  // Filter chip state — owner and category quick-filters
  let _filterOwner    = "";        // "" = no filter
  let _filterCategory = "";        // "" = no filter

  // ── Server-side comments store ────────────────────────────────────────────
  // Shape: { [caseNumber]: "comment text" }
  // This is the single source of truth for comments — never stored in localStorage.
  // Loaded once at render() time, saved back to server on every comment edit or import.
  let _serverComments = {};      // in-memory cache

  // Refresh _serverComments when poll brings in updated comments from DB
  window.addEventListener('iip:comments-updated', function(e) {
    if (e.detail && typeof e.detail === 'object') {
      Object.assign(_serverComments, e.detail);
      _serverCommentsLoaded = true;
      _renderKPI();
      _renderFollowUp();
      _renderWeekNav(_buildWeeks(_year));
    }
  });
  let _serverCommentsLoaded = false;

  const LS_CMT_KEY = "ibm_wtracker_comments_v1";

  // Public helper: populates _serverComments from _wtDbCache (Fix B1)
  // Comments are already in the /weekly-tracker response — no separate fetch needed.
  async function _ensureServerCommentsLoaded() {
    if (_serverCommentsLoaded) return;
    // Extract comments from DB cache (already loaded by _loadWTFromDB)
    if (_wtDbCache) {
      Object.values(_wtDbCache).forEach(weeks => {
        if (!weeks || typeof weeks !== 'object') return;
        Object.values(weeks).forEach(rows => {
          if (!Array.isArray(rows)) return;
          rows.forEach(r => {
            const cn = r.caseNumber || r.case_number || '';
            const cmt = r.comments || '';
            if (cn && cmt.trim()) _serverComments[cn] = cmt;
          });
        });
      });
    }
    _serverCommentsLoaded = true;
  }

  async function _loadServerComments() {
    await _ensureServerCommentsLoaded();
  }

  async function _syncWeeklyCase(caseNumber, weekLabel, year, comments, category, availability) {
    // Sync comment + category back to weekly_closed_cases in DB for duplicate detection
    try {
      const base = window.API_BASE_V2 || '/iip/api/v2';
      await fetch(`${base}/weekly/${year}/${weekLabel}/${caseNumber}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ comments, category, availability })
      });
    } catch(e) { console.warn("[IIP] weekly sync failed:", e.message); }
  }

  async function _saveServerComments() {
    // Use IIPStore.set so comments are written to both localStorage AND the DB
    // (IIPStore uses _origSetItem internally, bypassing the interceptor, then
    //  calls _apiSet directly — reliable even during hydration guard windows).
    if (typeof IIPStore !== 'undefined' && IIPStore.set) {
      IIPStore.set(LS_CMT_KEY, _serverComments).catch(() => {});
    } else {
      try { localStorage.setItem(LS_CMT_KEY, JSON.stringify(_serverComments)); } catch(e) {}
    }
  }

  // Merge an imported map (caseNumber → comment) into the server store.
  // Imported comments OVERWRITE existing ones for matching case numbers.
  // Used by legacy paths only — Admin Portal import now uses _mergeServerCommentsNoOverwrite.
  async function _mergeServerComments(importedMap) {
    let added = 0, updated = 0, unchanged = 0;
    Object.entries(importedMap).forEach(([cn, cmt]) => {
      if (_serverComments[cn] === undefined) { added++; }
      else if (_serverComments[cn] !== cmt)   { updated++; }
      else                                     { unchanged++; }
    });
    Object.assign(_serverComments, importedMap);
    await _saveServerComments();
    return { added, updated, unchanged };
  }

  // Safe merge: only fills in comments for cases that have NO existing comment.
  // Never overwrites. Used by the Admin Portal Excel import.
  async function _mergeServerCommentsNoOverwrite(newEntriesMap) {
    let added = 0;
    Object.entries(newEntriesMap).forEach(([cn, cmt]) => {
      const existing = _serverComments[cn];
      if (!existing || !existing.trim()) {
        _serverComments[cn] = cmt;
        added++;
      }
    });
    if (added > 0) await _saveServerComments();
    return { added };
  }

  // ── Reopened Cases Management (Real-time sync from PostgreSQL) ────────────────────
  // Cache reopened cases in memory — fetched on each render from backend
  let _reopenedCasesCache = null;
  let _grayoutStateCache = {};

  // Fetch reopened cases from backend (GET /api/v2/reopened?year=YYYY)
  let _fetchReopenedPromise = null;  // in-flight guard
  async function _fetchReopenedCases() {
    if (_fetchReopenedPromise) return _fetchReopenedPromise;
    _fetchReopenedPromise = (async () => {
      try {
        const url = _year ? `/iip/api/v2/reopened?year=${_year}` : '/api/v2/reopened';
        const resp = await fetch(url);
        if (!resp.ok) return [];
        const data = await resp.json();
        _reopenedCasesCache = data.reopened || [];
        return _reopenedCasesCache;
      } catch(e) {
        console.warn('[WT] Failed to fetch reopened cases:', e);
        return _reopenedCasesCache || [];
      }
    })().finally(() => { _fetchReopenedPromise = null; });
    return _fetchReopenedPromise;
  }

  // Fetch gray-out state for a specific case/week
  async function _fetchGrayoutState(caseNumber, week, year) {
    const cacheKey = `${caseNumber}|${week}|${year}`;
    if (_grayoutStateCache[cacheKey] !== undefined) {
      return _grayoutStateCache[cacheKey];
    }
    try {
      const resp = await fetch(`/iip/api/v2/grayout/${encodeURIComponent(caseNumber)}/${encodeURIComponent(week)}/${year}`);
      if (!resp.ok) return null;
      const state = await resp.json();
      _grayoutStateCache[cacheKey] = state;
      return state;
    } catch(e) {
      return null;
    }
  }

  // Apply gray-out styling to a row element based on reopened status
  function _applyGrayoutToRow(rowEl, caseNumber, week, year, isGrayed, metadata) {
    if (!isGrayed) return;

    // Add gray-out class
    rowEl.classList.add('wt-row-grayed');

    // Add border indicator (already in CSS via wt-row-grayed)
    // Add metadata badge showing reopening info
    if (metadata && (metadata.reopenedOn || metadata.closedAgainIn)) {
      const badge = document.createElement('div');
      badge.className = 'wt-reopened-badge';
      badge.innerHTML = `↺ Reopened ${metadata.reopenedOn ? new Date(metadata.reopenedOn).toLocaleDateString() : ''}`;
      if (metadata.closedAgainIn) {
        badge.innerHTML += ` | Closed again ${metadata.closedAgainIn}`;
      }
      rowEl.appendChild(badge);
    }
  }

  // Rebuild gray-out state for all visible rows (called during render)
  // Delegated to WTCrossWeekGrayout module which handles both localStorage
  // cross-week detection and DB-side grayout states in one efficient pass.
  function _applyGrayoutToVisibleRows() {
    if (typeof WTCrossWeekGrayout !== 'undefined') {
      WTCrossWeekGrayout.applyGrayout();
    } else {
      // Fallback: legacy per-row async fetch (original behaviour)
      _applyGrayoutToVisibleRowsLegacy();
    }
  }

  // Legacy fallback (kept for environments where the module hasn't loaded yet)
  async function _applyGrayoutToVisibleRowsLegacy() {
    const rows = document.querySelectorAll('[data-case-number][data-week][data-year]');
    for (const row of rows) {
      const caseNumber = row.dataset.caseNumber;
      const week = row.dataset.week;
      const year = parseInt(row.dataset.year);
      const state = await _fetchGrayoutState(caseNumber, week, year);
      if (state && state.isGrayed) {
        _applyGrayoutToRow(row, caseNumber, week, year, true, state.metadata);
      }
    }
  }

  /* ── Storage helpers (case/week data — not comments) ── */
  const _ldy = yr => (_wtDbCache && _wtDbCache[String(yr)]) ? _wtDbCache[String(yr)] : {};
  // _svy removed — weekly data is DB-only (Fix A1)

  // _wr: read rows for a week, overlaying server-side comments onto each row
  const _cleanCaseNum = s => (s || "").replace(/<[^>]*>/g, "").replace(/[⏱⚡]/g, "").trim();

  /* _buildUrlPreview: extract URLs and hyperlinks from text,
     render as a clickable links list for the popover "Links" panel.
     Detects three sources generically:
       1. Bare http/https URLs in plain text
       2. Any hyperlinked text captured via paste (stored in _pastedLinkMap)
       3. Bare TS/DT/PMR-style identifiers not already in _pastedLinkMap */
  function _buildUrlPreview(text) {
    if (!text) return "";
    const textLower = text.toLowerCase();

    // Source 1: bare URLs in plain text
    const rawUrls = [...new Set((text.match(/https?:\/\/[^\s<>"')\]]+/g) || []))];

    // Source 2: pasted hyperlinks whose label text appears in the textarea
    // _pastedLinkMap keys are lowercased label text → { label, href }
    const pastedItems = [];
    const pastedHrefs = new Set(); // track hrefs already added from paste map
    for (const [key, entry] of Object.entries(_pastedLinkMap)) {
      if (textLower.includes(key)) {
        pastedItems.push(entry);
        pastedHrefs.add(entry.href);
      }
    }

    // Source 3: bare identifier patterns not already covered by paste map
    // Generic pattern: 2+ uppercase letters followed by 5+ digits (e.g. TS019458021, DT445785, PMR12345)
    const identRe = /(?<![A-Za-z0-9])([A-Z]{2,}[\d]+)(?![A-Za-z0-9])/g;
    const bareIdents = [];
    let m;
    while ((m = identRe.exec(text)) !== null) {
      const token = m[1];
      // Only surface if NOT already in pasted map (pasted map is more precise — has the real URL)
      if (!_pastedLinkMap[token.toLowerCase()]) {
        bareIdents.push(token);
      }
    }
    const uniqueIdents = [...new Set(bareIdents)];

    // Filter bare URLs: skip any whose full URL is already in pastedHrefs
    const filteredUrls = rawUrls.filter(u => !pastedHrefs.has(u));

    if (!filteredUrls.length && !pastedItems.length && !uniqueIdents.length) return "";

    // Render pasted hyperlinks (most informative — real URLs known)
    const pastedHtml = pastedItems.map(({ label, href }) => {
      const display = label.length > 70 ? label.slice(0, 67) + "\u2026" : label;
      return `<a href="${Utils.escHtml(href)}" target="_blank" rel="noopener noreferrer"
        onclick="event.stopPropagation()"
        style="color:var(--ibm-blue-50);font-weight:600;text-decoration:underline;text-decoration-style:dotted;
          text-underline-offset:2px;word-break:break-all;transition:opacity var(--t-fast);display:block"
        onmouseover="this.style.opacity='.7'" onmouseout="this.style.opacity='1'"
        title="${Utils.escHtml(href)}">${Utils.escHtml(display)}</a>`;
    });

    // Render bare identifiers (no known URL — show as monospaced label only)
    const identHtml = uniqueIdents.map(token => {
      // Try to auto-resolve known IBM patterns to a URL
      let href = null;
      if (/^TS\d{8,}$/.test(token)) href = _IBM_CASE_BASE + token;
      const display = Utils.escHtml(token);
      if (href) {
        return `<a href="${Utils.escHtml(href)}" target="_blank" rel="noopener noreferrer"
          onclick="event.stopPropagation()"
          style="color:var(--ibm-blue-50);font-weight:600;text-decoration:underline;text-decoration-style:dotted;
            text-underline-offset:2px;font-family:var(--font-mono);transition:opacity var(--t-fast);display:block"
          onmouseover="this.style.opacity='.7'" onmouseout="this.style.opacity='1'"
          title="Open IBM Case ${display}">${display}</a>`;
      }
      // Unknown identifier — show as plain monospaced badge (dim; user knows it was linked)
      return `<span style="color:var(--ibm-blue-50);font-family:var(--font-mono);font-size:11px;
        opacity:.75;display:block" title="Linked identifier (URL not captured)">${display}</span>`;
    });

    // Render bare URLs
    const urlHtml = filteredUrls.map(u => {
      const display = u.length > 60 ? u.slice(0, 57) + "\u2026" : u;
      return `<a href="${Utils.escHtml(u)}" target="_blank" rel="noopener noreferrer"
        onclick="event.stopPropagation()"
        style="color:var(--ibm-blue-50);text-decoration:underline;text-decoration-style:dotted;
          text-underline-offset:2px;word-break:break-all;transition:opacity var(--t-fast);display:block"
        onmouseover="this.style.opacity='.7'" onmouseout="this.style.opacity='1'"
        title="${Utils.escHtml(u)}">${Utils.escHtml(display)}</a>`;
    });

    return [...pastedHtml, ...identHtml, ...urlHtml].join("");
  }


  /* _linkify: convert plain text to HTML with:
     1. http/https URLs → clickable links
     2. Bare TS case numbers (e.g. TS021544897) → IBM mysupport links
     Safe: escapes all non-link text via Utils.escHtml, never double-escapes. */
  const _IBM_CASE_BASE = "https://www.ibm.com/mysupport/s/case/";

  function _linkify(text) {
    if (!text) return "";
    // Combined regex: capture either a full URL or a bare TS case number
    const COMBINED_RE = /(https?:\/\/[^\s<>"')\]]+)|((?<![A-Za-z0-9])TS\d{8,}(?![A-Za-z0-9]))/g;
    let result = "";
    let lastIdx = 0;
    let match;
    while ((match = COMBINED_RE.exec(text)) !== null) {
      result += Utils.escHtml(text.slice(lastIdx, match.index));
      lastIdx = match.index + match[0].length;
      if (match[1]) {
        // Full URL
        const url = match[1];
        const display = url.length > 55 ? url.slice(0, 52) + "\u2026" : url;
        result += `<a href="${Utils.escHtml(url)}" target="_blank" rel="noopener noreferrer"
          onclick="event.stopPropagation()"
          style="color:var(--ibm-blue-50);text-decoration:underline;text-decoration-style:dotted;
            text-underline-offset:2px;word-break:break-all;transition:opacity var(--t-fast)"
          onmouseover="this.style.opacity='.7'" onmouseout="this.style.opacity='1'"
          title="${Utils.escHtml(url)}">${Utils.escHtml(display)}</a>`;
      } else if (match[2]) {
        // Bare TS case number → IBM mysupport link
        const cn = match[2];
        const url = _IBM_CASE_BASE + cn;
        result += `<a href="${Utils.escHtml(url)}" target="_blank" rel="noopener noreferrer"
          onclick="event.stopPropagation()"
          style="color:var(--ibm-blue-50);font-weight:600;text-decoration:underline;text-decoration-style:dotted;
            text-underline-offset:2px;font-family:var(--font-mono);transition:opacity var(--t-fast)"
          onmouseover="this.style.opacity='.7'" onmouseout="this.style.opacity='1'"
          title="Open IBM Case ${Utils.escHtml(cn)}">${Utils.escHtml(cn)}</a>`;
      }
    }
    result += Utils.escHtml(text.slice(lastIdx));
    return result;
  }


  const _wr  = (yr, wk) => {
    const rows = _ldy(yr)[wk] || [];
    // Build Map lookup once instead of .find() per row (Fix C3)
    const liveCases = (typeof Data !== 'undefined' && Data.allCases) ? Data.allCases() : [];
    const liveMap = new Map();
    liveCases.forEach(c => { const cn = c["Case Number"] || ""; if (cn) liveMap.set(cn, c); });
    return rows.map(r => {
      const cleanCN = _cleanCaseNum(r.caseNumber);
      const sc = _serverComments[cleanCN] ?? _serverComments[r.caseNumber];
      const base = cleanCN !== r.caseNumber ? { ...r, caseNumber: cleanCN } : r;
      const withComments = (sc !== undefined) ? { ...base, comments: sc } : base;
      const liveCase = liveMap.get(cleanCN) || liveMap.get(r.caseNumber);
      if (liveCase && liveCase._ownerOverride) {
        return { ...withComments, owner: Data.displayName(liveCase.Owner) };
      }
      return withComments;
    });
  };

  // _swk removed — DB is single source of truth, no localStorage writes (Fix A2)
  const _swk = () => {};

  /* ── History storage ── */
  let _histCache = {};
  let _histCacheReady = false;

  async function _loadHistoryFromDB() {
    if (_histCacheReady) return;
    try {
      const base = window.API_BASE_V2 || '/iip/api/v2';
      const resp = await fetch(base + '/wt-history', { cache: 'no-store' });
      if (resp.ok) { _histCache = await resp.json(); }
    } catch(e) {
      try { _histCache = JSON.parse(localStorage.getItem(HISTORY_KEY) || '{}'); } catch(_) {}
    }
    _histCacheReady = true;
  }

  function _loadHistory() { return _histCache; }

  function _saveHistory(h) {
    _histCache = h;
    try { localStorage.setItem(HISTORY_KEY, JSON.stringify(h)); } catch(e) {}
  }

  function _recordHistory(caseNumber, owner, statusBefore, statusAfter, commentBefore, commentAfter, week, year, availabilityFlag) {
    const h = _loadHistory();
    if (!h[caseNumber]) h[caseNumber] = { caseNumber, owner, entries: [] };
    h[caseNumber].owner = owner; // keep latest
    const entry = {
      ts: new Date().toISOString(),
      week, year,
      statusBefore, statusAfter,
      commentBefore, commentAfter,
      changedBy: "user"
    };
    if (availabilityFlag) entry.availability = availabilityFlag;
    h[caseNumber].entries.unshift(entry);
    // Cap at 50 entries per case
    if (h[caseNumber].entries.length > 50) h[caseNumber].entries = h[caseNumber].entries.slice(0, 50);
    _saveHistory(h);
    // Also persist to DB
    try {
      const _base = window.API_BASE_V2 || '/iip/api/v2';
      fetch(_base + '/wt-history', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          case_number: caseNumber, owner: owner || '',
          week: week || '', year: year || new Date().getFullYear(),
          status_before: statusBefore || '', status_after: statusAfter || '',
          comment_before: commentBefore || '', comment_after: commentAfter || '',
          availability: availabilityFlag || '', is_reopen: false,
          prev_week: '', changed_by: 'user'
        })
      }).catch(function(e) { console.warn('[WT] history DB save:', e.message); });
    } catch(e) {}
  }

  /* ── Normalise a category value using the map ── */
  function _normCat(raw) {
    if (!raw) return "";
    const trimmed = raw.trim();
    if (trimmed in _WT_CAT_NORM) return _WT_CAT_NORM[trimmed];
    return WT_CATEGORIES.includes(trimmed) ? trimmed : trimmed;
  }

  /* _deduplicateAllWeeks removed — DB handles dedup (Fix A4) */
  function _deduplicateAllWeeks() { return 0; }

  /* ── Seed reopened-case history from cross-week seed data ── */
  function _seedReopenedHistory() {
    const h = _loadHistory();
    let changed = false;
    // Scan seed data for cases appearing in multiple weeks (reopened cases)
    if (!_wtDbCache) return; // no-op without DB data
    Object.entries(_wtDbCache).forEach(([yr, weeks]) => {
      const caseWeeks = {};
      Object.entries(weeks).forEach(([wk, rows]) => {
        rows.forEach(row => {
          if (!caseWeeks[row.caseNumber]) caseWeeks[row.caseNumber] = [];
          caseWeeks[row.caseNumber].push({ wk, row });
        });
      });
      Object.entries(caseWeeks).forEach(([cn, appearances]) => {
        if (appearances.length < 2) return; // not reopened
        // Sort by week to process in order
        appearances.sort((a, b) => a.wk.localeCompare(b.wk));
        if (!h[cn]) { h[cn] = { caseNumber: cn, owner: appearances[0].row.owner, entries: [] }; changed = true; }
        // Add a history entry for each reopening (2nd+ appearance)
        for (let i = 1; i < appearances.length; i++) {
          const prev = appearances[i - 1];
          const curr = appearances[i];
          const entryId = `seed_reopen_${cn}_${curr.wk}`;
          // Don't add duplicates if already seeded
          if (h[cn].entries.some(e => e._seedId === entryId)) continue;
          h[cn].owner = curr.row.owner;
          h[cn].entries.push({
            _seedId: entryId,
            ts: (() => { try { const d = new Date(curr.row.closedDate || Date.now()); return isNaN(d) ? new Date().toISOString() : d.toISOString(); } catch(e) { return new Date().toISOString(); } })(),
            week: curr.wk,
            year: parseInt(yr),
            statusBefore: prev.row.status,
            statusAfter: curr.row.status,
            commentBefore: prev.row.comments || "",
            commentAfter: curr.row.comments || "",
            changedBy: "reopened",
            isReopen: true,
            prevWeek: prev.wk
          });
          changed = true;
        }
        if (h[cn].entries.length > 50) h[cn].entries = h[cn].entries.slice(0, 50);
      });
    });
    if (changed) _saveHistory(h);
  }

  /* _applySeed removed — DB is single source of truth; _svy removed (Fix A1/A3) */
  function _applySeed() {}

  /* ── Enrich from main IBM cases CSV ── */
  function enrichFromCases(allCases) {
    if (!allCases || !allCases.length) return;
    const byYW = {};
    allCases.forEach(r => {
      if (!Data.isTeamOwner(r.Owner)) return;
      const closedStr = (r["Closed Date"] || "").trim();
      if (!closedStr) return;
      const d = Utils.parseDate(closedStr);
      if (!d) return;

      // CRITICAL: Only include CLOSED cases in the tracker
      const status = (r["Status"] || "").toLowerCase();
      const isClosed = status.includes('closed') || status.includes('cancel');
      if (!isClosed) return; // Skip active cases

      const yr = d.getFullYear();
      const wk = _isoWeek(d);
      const key = yr + "_" + wk;
      if (!byYW[key]) byYW[key] = { yr, wk, rows: [] };
      // Check if this case has been reassigned via Admin Portal (_ownerOverride)
      const _caseNum = _cleanCaseNum(r["Case Number"] || "");
      const _liveCase = (Data.allCases ? Data.allCases() : []).find(c => c["Case Number"] === r["Case Number"] || c["Case Number"] === _caseNum);
      const _effectiveOwner = (_liveCase && _liveCase._ownerOverride) ? _liveCase.Owner : r.Owner;
      byYW[key].rows.push({
        id: _caseNum + "_" + wk,
        caseNumber: _caseNum,
        owner: Data.displayName(_effectiveOwner || ""),
        title: r.Title || "",
        customerNumber: (r["Customer number"] || "").replace(/^0+/,""),
        product: r.Product || "",
        severity: r.Severity || "",
        status: r.Status || "",
        age: r.Age || "",
        closedDate: closedStr,
        created: r.Created || "",
        solutionDate: r["Solution date"] || "",
        comments: "", category: "",
        _fromCSV: true
      });
    });

    // ── Cross-week cleanup: Excel is the authoritative source of truth ──────────────────
    // For every case in this upload, its ONLY valid week is the one from its Closed Date.
    // Any other stored week containing this case number is stale (from a previous upload
    // or a DB restore with old data) and must be removed immediately.
    // This prevents ghost-week: uploading file-1 (case in W07) showing case in W13
    // from the previous session's DB-restored data.
    // Cross-week ghost-case cleanup is now handled server-side during CSV upload.
    // The DB stores canonical week per case; no localStorage scan needed.

    // Build previous state snapshot before merging (for reopened detection)
    const prevState = {};
    Object.entries(_ldy(2025)).forEach(([wk, rows]) => {
      rows.forEach(r => {
        if (r && r.caseNumber && !prevState[r.caseNumber]) {
          prevState[r.caseNumber] = { status: r.status, owner: r.owner, week: wk };
        }
      });
    });
    Object.entries(_ldy(2026)).forEach(([wk, rows]) => {
      rows.forEach(r => {
        if (r && r.caseNumber && !prevState[r.caseNumber]) {
          prevState[r.caseNumber] = { status: r.status, owner: r.owner, week: wk };
        }
      });
    });

    let _commentsMigrated = false;
    const reopened = [];
    Object.values(byYW).forEach(({ yr, wk, rows }) => {
      const stored = _wr(yr, wk);
      const byCase = {};
      stored.forEach(r => { byCase[r.caseNumber] = r; });
      const merged = rows.map(r => {
        const s = byCase[r.caseNumber] || {};
        // Server-side comments take priority; fall back to any stored comment
        const serverCmt = _serverComments[r.caseNumber];
        const comment   = (serverCmt !== undefined) ? serverCmt : (s.comments || "");
        // Migrate seed/stored comments into _serverComments so _swk stripping doesn't erase them
        if (serverCmt === undefined && comment) {
          _serverComments[r.caseNumber] = comment;
          _commentsMigrated = true;
        }
        // Track reopened cases: if status was "Closed" and now active
        const prev = prevState[r.caseNumber];
        if (prev && Utils.isClosed(prev.status) && !Utils.isClosed(r.status)) {
          reopened.push({ caseNumber: r.caseNumber, owner: r.owner, statusBefore: prev.status, statusAfter: r.status, previousWeek: prev.week, currentWeek: wk });
        }
        return { ...r, comments: comment, category: s.category||"", owner: r.owner||s.owner, availability: s.availability||"" };
      });
      stored.forEach(s => { if (!merged.find(m => m.caseNumber === s.caseNumber)) merged.push(s); });
      // Dedup guard: keep only first occurrence of each caseNumber in this week
      const seenCases = new Set();
      const deduped = merged.filter(r => {
        if (seenCases.has(r.caseNumber)) return false;
        seenCases.add(r.caseNumber);
        return true;
      });
      _swk(yr, wk, deduped);
    });
    // Persist any comments rescued from seed data before _swk could strip them
    if (_commentsMigrated) _saveServerComments();

    // Add reopened cases to history
    if (reopened.length > 0) {
      const h = _loadHistory();
      reopened.forEach(r => {
        if (!h[r.caseNumber]) h[r.caseNumber] = { caseNumber: r.caseNumber, owner: r.owner, entries: [] };
        h[r.caseNumber].entries.push({
          ts: new Date().toISOString(),
          week: r.currentWeek,
          statusBefore: r.statusBefore,
          statusAfter: r.statusAfter,
          changedBy: "csv-upload",
          isReopen: true,
          prevWeek: r.previousWeek
        });
      });
      _saveHistory(h);
    }

    try { const el=document.getElementById("tab-weekly-tracker"); if(el&&el.classList.contains("active")) render(); } catch(e) {}

    // Invalidate cross-week grayout cache so it rescans with fresh data
    try { if (typeof WTCrossWeekGrayout !== 'undefined') WTCrossWeekGrayout.invalidate(); } catch(e) {}
  }

  function _isoWeek(d) {
    // Sunday-based week numbering, W01 = week containing Jan 1
    const yr = d.getFullYear();
    const jan1 = new Date(yr, 0, 1);
    const jan1Day = jan1.getDay(); // 0=Sun
    // Sunday on or before Jan 1 = start of W01
    const w1Sun = new Date(jan1);
    w1Sun.setDate(jan1.getDate() - jan1Day);
    const target = new Date(yr, d.getMonth(), d.getDate());
    if (target < w1Sun) {
      // Before W01 of this year — belongs to last week of previous year
      return _isoWeek(new Date(yr - 1, 11, 31));
    }
    const wk = Math.floor((target - w1Sun) / (7 * 86400000)) + 1;
    return "CW" + String(wk).padStart(2, "0");
  }

  /* ── Collect ALL cases from ALL years (DB-driven) ── */
  function _getAllWTCases() {
    const seen = new Set();
    const all  = [];

    function addRows(yearData, yr) {
      Object.keys(yearData).forEach(wk => {
        const rows = yearData[wk];
        if (!Array.isArray(rows)) return;
        rows.forEach(r => {
          const cn = _cleanCaseNum(r.caseNumber);
          if (!cn) return;
          const key = cn + '|' + wk;
          if (!seen.has(key)) {
            seen.add(key);
            all.push({ ...r, caseNumber: cn, _year: yr, _week: wk });
          }
        });
      });
    }

    // DB cache is the single source of truth
    if (_wtDbCache) {
      Object.keys(_wtDbCache).forEach(yr => addRows(_wtDbCache[yr], parseInt(yr)));
    }

    return all;
  }

  /* ── Wire WT Global Case Search ── */
  function _setupGlobalSearch() {
    const inp     = document.getElementById('wt-global-search');
    const results = document.getElementById('wt-global-search-results');
    const countEl = document.getElementById('wt-gs-count');
    const clearBtn= document.getElementById('wt-gs-clear');
    if (!inp || !results) return;

    let _dbt = null;

    function _hide() {
      results.style.display = 'none';
      if (countEl) countEl.textContent = '';
      if (clearBtn) clearBtn.style.display = 'none';
      inp.value = '';
    }

    function _search(q) {
      const ql = q.toLowerCase().trim();
      if (!ql) { results.style.display = 'none'; if(countEl) countEl.textContent=''; return; }

      const cases = _getAllWTCases().filter(r =>
        (r.caseNumber  || '').toLowerCase().includes(ql) ||
        (r.title       || '').toLowerCase().includes(ql) ||
        (r.owner       || '').toLowerCase().includes(ql) ||
        (r.category    || '').toLowerCase().includes(ql) ||
        (r.comments    || '').toLowerCase().includes(ql) ||
        (r.product     || '').toLowerCase().includes(ql) ||
        (r.status      || '').toLowerCase().includes(ql)
      );

      if (countEl) countEl.textContent = cases.length + ' result' + (cases.length !== 1 ? 's' : '');
      if (clearBtn) clearBtn.style.display = 'block';

      if (!cases.length) {
        results.innerHTML = `<div style="padding:14px 16px;font-size:12px;color:var(--text-tertiary);text-align:center">
          No results found for "<strong>${Utils.escHtml(q)}</strong>"
        </div>`;
        results.style.display = 'block';
        return;
      }

      // Deduplicate by case number — show the most recent week's entry
      const byCase = new Map();
      cases.forEach(r => {
        const existing = byCase.get(r.caseNumber);
        if (!existing || r._year > existing._year ||
            (r._year === existing._year && r._week > existing._week)) {
          byCase.set(r.caseNumber, r);
        }
      });
      const unique = [...byCase.values()].slice(0, 15);

      results.innerHTML = unique.map(r => {
        const sev = String(r.severity || '').trim();
        const sevCol = sev === '1' ? 'var(--red)' : sev === '2' ? 'var(--orange)' : sev === '3' ? 'var(--yellow)' : 'var(--text-disabled)';
        const isClosed = (r.status || '').toLowerCase().includes('closed') || (r.status || '').toLowerCase().includes('cancel');
        const cnColor  = isClosed ? 'var(--text-tertiary)' : 'var(--ibm-blue-50)';
        const comments = (r.comments || '').slice(0, 80);
        const cat = r.category || '';
        return `<div class="wt-gs-item" data-cn="${Utils.escHtml(r.caseNumber)}" data-year="${r._year}" data-week="${Utils.escHtml(r._week)}"
          style="padding:10px 14px;cursor:pointer;border-bottom:1px solid var(--border-subtle);display:flex;gap:10px;align-items:flex-start;transition:background var(--t-fast)"
          tabindex="0" role="option">
          <div style="flex:1;min-width:0">
            <div style="display:flex;align-items:center;gap:6px;margin-bottom:3px;flex-wrap:wrap">
              <span style="font-family:var(--font-mono);font-size:12px;font-weight:700;color:${cnColor}">${Utils.escHtml(r.caseNumber)}</span>
              ${sev ? `<span style="font-size:10px;font-weight:700;color:${sevCol};font-family:var(--font-mono)">S${sev}</span>` : ''}
              <span style="font-size:10px;color:var(--text-tertiary);background:var(--bg-layer);padding:1px 6px;border-radius:var(--radius-xs);border:1px solid var(--border-subtle)">${Utils.escHtml(r._year + ' · ' + r._week)}</span>
              ${cat ? `<span style="font-size:10px;color:var(--ibm-blue-50);background:rgba(15,98,254,.08);padding:1px 6px;border-radius:var(--radius-xs)">${Utils.escHtml(cat)}</span>` : ''}
            </div>
            <div style="font-size:12px;color:var(--text-primary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-bottom:2px">${Utils.escHtml((r.title || '—').slice(0, 80))}</div>
            <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
              <span style="font-size:11px;color:var(--text-tertiary)">${Utils.escHtml(r.owner || '—')}</span>
              ${r.status ? `<span style="font-size:11px;color:var(--text-disabled)">·</span><span style="font-size:11px;color:var(--text-tertiary)">${Utils.escHtml(r.status)}</span>` : ''}
              ${comments ? `<span style="font-size:11px;color:var(--text-disabled)">·</span><span style="font-size:11px;color:var(--text-tertiary);font-style:italic;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:200px">${Utils.escHtml(comments)}${r.comments.length > 80 ? '…' : ''}</span>` : ''}
            </div>
          </div>
          <span style="font-size:10px;color:var(--ibm-blue-50);opacity:.7;flex-shrink:0;align-self:center;white-space:nowrap">Go to week →</span>
        </div>`;
      }).join('') + (byCase.size > 15 ? `<div style="padding:8px 14px;font-size:11px;color:var(--text-tertiary);text-align:center">Showing top 15 of ${byCase.size} unique cases</div>` : '');

      results.style.display = 'block';

      // Wire each result item
      results.querySelectorAll('.wt-gs-item').forEach(item => {
        const activate = () => {
          const cn   = item.dataset.cn;
          const yr   = parseInt(item.dataset.year);
          const wk   = item.dataset.week;
          results.style.display = 'none';
          inp.value = '';
          if (countEl) countEl.textContent = '';
          if (clearBtn) clearBtn.style.display = 'none';

          // Step 1: Navigate to the correct year + week
          const doNav = () => {
            _navClick(wk);
            // Step 2: After nav renders, highlight the case row in the table
            setTimeout(() => {
              const trs = document.querySelectorAll('#wt-table-wrap tr');
              let found = null;
              trs.forEach(r => { if ((r.textContent || '').includes(cn)) found = r; });
              if (found) {
                found.scrollIntoView({ behavior: 'smooth', block: 'center' });
                found.style.transition = 'box-shadow .15s';
                found.style.boxShadow  = 'inset 0 0 0 2px var(--ibm-blue-50)';
                setTimeout(() => { found.style.boxShadow = ''; }, 2200);
              }
            }, 150);
          };

          // If different year, set year first then navigate
          if (_year !== yr) {
            _setYear(yr);
            setTimeout(doNav, 350);
          } else {
            doNav();
          }
        };
        item.addEventListener('click', activate);
        item.addEventListener('keydown', e => { if (e.key === 'Enter') activate(); });
        item.addEventListener('mouseover', () => item.style.background = 'var(--ibm-blue-10)');
        item.addEventListener('mouseout',  () => item.style.background = '');
      });
    }

    inp.addEventListener('input', e => {
      clearTimeout(_dbt);
      const val = e.target.value;
      if (!val.trim()) { results.style.display='none'; if(countEl)countEl.textContent=''; if(clearBtn)clearBtn.style.display='none'; return; }
      _dbt = setTimeout(() => _search(val), 180);
    });

    inp.addEventListener('keydown', e => {
      if (e.key === 'Escape') { _hide(); inp.blur(); }
      if (e.key === 'ArrowDown') { e.preventDefault(); results.querySelector('.wt-gs-item')?.focus(); }
    });

    results.addEventListener('keydown', e => {
      if (e.key === 'ArrowDown') { e.preventDefault(); e.target.nextElementSibling?.focus(); }
      if (e.key === 'ArrowUp')   { e.preventDefault(); (e.target.previousElementSibling || inp).focus(); }
      if (e.key === 'Escape')    { _hide(); inp.focus(); }
    });

    clearBtn?.addEventListener('click', _hide);

    document.addEventListener('click', e => {
      const wrap = document.getElementById('wt-global-search-wrap');
      if (wrap && !wrap.contains(e.target)) results.style.display = 'none';
    });
  }

  /* ── WT Case Detail Modal ── */
  function _showWTCaseModal(row) {
    const cn     = row.caseNumber || '';
    const sev    = String(row.severity || '').trim();
    const sevCol = sev === '1' ? 'var(--red)' : sev === '2' ? 'var(--orange)' : sev === '3' ? 'var(--yellow)' : 'var(--text-disabled)';
    const isClosed = (row.status||'').toLowerCase().includes('closed')||(row.status||'').toLowerCase().includes('cancel');
    const cnColor  = isClosed ? 'var(--text-tertiary)' : 'var(--ibm-blue-50)';

    const html = `
      <div style="display:flex;flex-direction:column;gap:14px">
        <!-- Header -->
        <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:10px;flex-wrap:wrap">
          <div>
            <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:6px">
              <span style="font-family:var(--font-mono);font-size:15px;font-weight:700;color:${cnColor}">${Utils.escHtml(cn)}</span>
              ${sev ? `<span style="background:${sevCol}22;color:${sevCol};border:1px solid ${sevCol}44;font-size:11px;font-weight:700;padding:2px 8px;border-radius:var(--radius-sm);font-family:var(--font-mono)">Sev ${sev}</span>` : ''}
              <span style="background:var(--bg-layer);color:var(--text-tertiary);border:1px solid var(--border-subtle);font-size:10px;font-weight:600;padding:2px 8px;border-radius:var(--radius-sm);font-family:var(--font-mono)">${Utils.escHtml(row._year + ' · ' + row._week)}</span>
            </div>
            <div style="font-size:12px;color:var(--text-secondary)">${Utils.statusBadge ? Utils.statusBadge(row.status) : Utils.escHtml(row.status||'')}</div>
          </div>
          <a href="https://www.ibm.com/support/pages/node/${encodeURIComponent(cn)}" target="_blank" rel="noopener"
            style="display:inline-flex;align-items:center;gap:5px;font-size:12px;font-weight:600;color:var(--ibm-blue-50);text-decoration:none;padding:6px 12px;border:1px solid rgba(15,98,254,.3);border-radius:var(--radius-sm);background:rgba(15,98,254,.05);flex-shrink:0">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
            Open in IBM
          </a>
        </div>

        <!-- Title -->
        <div>
          <div style="font-size:10px;font-weight:600;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px">Title</div>
          <div style="font-size:13px;color:var(--text-primary);line-height:1.5">${Utils.escHtml(row.title || '—')}</div>
        </div>

        <!-- Key fields grid -->
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
          <div style="background:var(--bg-layer);border:1px solid var(--border-subtle);border-radius:var(--radius-sm);padding:9px 12px">
            <div style="font-size:10px;font-weight:600;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:.5px;margin-bottom:3px">Owner</div>
            <div style="font-size:13px;font-weight:600;color:var(--text-primary)">${Utils.escHtml(row.owner || '—')}</div>
          </div>
          <div style="background:var(--bg-layer);border:1px solid var(--border-subtle);border-radius:var(--radius-sm);padding:9px 12px">
            <div style="font-size:10px;font-weight:600;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:.5px;margin-bottom:3px">Category</div>
            <div style="font-size:13px;color:var(--text-primary)">${Utils.escHtml(row.category || '—')}</div>
          </div>
          <div style="background:var(--bg-layer);border:1px solid var(--border-subtle);border-radius:var(--radius-sm);padding:9px 12px">
            <div style="font-size:10px;font-weight:600;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:.5px;margin-bottom:3px">Product</div>
            <div style="font-size:13px;color:var(--text-primary)">${Utils.escHtml(row.product || '—')}</div>
          </div>
          <div style="background:var(--bg-layer);border:1px solid var(--border-subtle);border-radius:var(--radius-sm);padding:9px 12px">
            <div style="font-size:10px;font-weight:600;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:.5px;margin-bottom:3px">Closed Date</div>
            <div style="font-size:13px;font-family:var(--font-mono);color:var(--text-primary)">${Utils.escHtml(row.closedDate || '—')}</div>
          </div>
          <div style="background:var(--bg-layer);border:1px solid var(--border-subtle);border-radius:var(--radius-sm);padding:9px 12px">
            <div style="font-size:10px;font-weight:600;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:.5px;margin-bottom:3px">Age</div>
            <div style="font-size:13px;font-family:var(--font-mono);color:var(--text-primary)">${Utils.escHtml(row.age || '—')}</div>
          </div>
          <div style="background:var(--bg-layer);border:1px solid var(--border-subtle);border-radius:var(--radius-sm);padding:9px 12px">
            <div style="font-size:10px;font-weight:600;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:.5px;margin-bottom:3px">Customer #</div>
            <div style="font-size:13px;font-family:var(--font-mono);color:var(--text-primary)">${Utils.escHtml(row.customerNumber || '—')}</div>
          </div>
        </div>

        ${row.comments ? `
        <div style="background:var(--bg-layer);border:1px solid var(--border-subtle);border-radius:var(--radius-sm);padding:10px 12px">
          <div style="font-size:10px;font-weight:600;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:.5px;margin-bottom:5px">Comments / Resolution</div>
          <div style="font-size:12px;color:var(--text-secondary);line-height:1.6;white-space:pre-wrap">${Utils.escHtml(row.comments)}</div>
        </div>` : ''}

        <!-- Actions -->
        <div style="display:flex;gap:8px;flex-wrap:wrap;padding-top:4px;border-top:1px solid var(--border-subtle)">
          <button onclick="
            if(typeof Modal!=='undefined')Modal.close();
            if(typeof DashWeeklyTracker!=='undefined'){
              const wt = DashWeeklyTracker;
              const targetYear = ${row._year};
              const targetWeek = '${Utils.escHtml(row._week)}';
              const targetCN   = '${Utils.escHtml(cn)}';
              if(wt._setYear && wt._navClick){
                // If same year already loaded, just navClick; otherwise setYear then navClick after render
                const yearSelect = document.querySelector('#tab-weekly-tracker select, #wt-year-select');
                const currentYear = yearSelect ? parseInt(yearSelect.value) : null;
                const doNav = () => {
                  wt._navClick(targetWeek);
                  // After nav, highlight the matching row
                  setTimeout(() => {
                    const rows = document.querySelectorAll('#wt-table-wrap tr[data-case-id], #wt-table-wrap tr');
                    let found = null;
                    rows.forEach(r => {
                      if ((r.textContent||'').includes(targetCN)) found = r;
                    });
                    if(found){
                      found.scrollIntoView({behavior:'smooth',block:'center'});
                      found.style.transition='box-shadow .15s';
                      found.style.boxShadow='inset 0 0 0 2px var(--ibm-blue-50)';
                      setTimeout(()=>found.style.boxShadow='',2000);
                    }
                  }, 150);
                };
                if(currentYear === targetYear){
                  doNav();
                } else {
                  wt._setYear(targetYear);
                  setTimeout(doNav, 350);
                }
              }
            }
          " class="btn btn-primary btn-sm" style="flex:1">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
            Go to ${row._year} · ${Utils.escHtml(row._week)}
          </button>
          <button onclick="navigator.clipboard?.writeText('${Utils.escHtml(cn)}').then(()=>{this.textContent='✓ Copied!';setTimeout(()=>this.textContent='Copy Case #',1500)})"
            class="btn btn-ghost btn-sm">Copy Case #</button>
        </div>
      </div>`;

    if (typeof Modal !== 'undefined') Modal.open(cn + ' — Weekly Tracker', html);
  }

  function _buildWeeks(yr) {
    const weeks = [];
    const MN = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    const pad = n => String(n).padStart(2, "0");
    // Use local date string (avoids UTC-offset shifting dates across year boundaries)
    const localIso = d => `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
    const jan1 = new Date(yr, 0, 1);
    const jan1Day = jan1.getDay(); // 0=Sun
    const sun = new Date(yr, 0, 1 - jan1Day); // Sunday on or before Jan 1
    // Year boundaries — weeks are clipped to these so no week spans into an adjacent year
    const yearStart = new Date(yr, 0, 1);   // Jan 1
    const yearEnd   = new Date(yr, 11, 31); // Dec 31
    let cw = 1;
    for (let i = 0; i < 54; i++) {
      const s = new Date(sun), e = new Date(sun);
      e.setDate(sun.getDate() + 6);
      // Stop if week starts after Dec 31 of this year
      if (s.getFullYear() > yr) break;
      // Include if the week overlaps with this year at all
      if (s.getFullYear() === yr || e.getFullYear() === yr) {
        // Clip to year boundaries: Jan W01 starts Jan 1 (not Dec 28), Dec W53 ends Dec 31 (not Jan 3)
        const sc = s < yearStart ? new Date(yearStart) : s;
        const ec = e > yearEnd   ? new Date(yearEnd)   : e;
        weeks.push({
          key:      "CW" + pad(cw),
          label:    MN[sc.getMonth()] + " W" + pad(cw) + " (" + sc.getDate() + "-" + ec.getDate() + ")",
          range:    sc.getDate() + " " + MN[sc.getMonth()] + " \u2013 " + ec.getDate() + " " + MN[ec.getMonth()] + " " + ec.getFullYear(),
          isoStart: localIso(sc),
          isoEnd:   localIso(ec),
          month:    sc.getMonth(),
          sortDate: s.getTime(),  // sort by real week start (not clipped)
        });
        cw++;
      }
      sun.setDate(sun.getDate() + 7);
    }
    weeks.sort((a, b) => a.sortDate - b.sortDate);
    return weeks;
  }

  function _curCW(weeks) {
    const n = new Date();
    const today = `${n.getFullYear()}-${String(n.getMonth()+1).padStart(2,"0")}-${String(n.getDate()).padStart(2,"0")}`;
    return (weeks.find(w => today >= w.isoStart && today <= w.isoEnd) || weeks[0]).key;
  }

  function _yearsAvail() {
    // Use ONLY DB cache years — source of truth is the backend API
    // Do NOT use Data.allCases() as it contains legacy years from old CSV blob
    const s = new Set();
    if (_wtDbCache && Object.keys(_wtDbCache).length) {
      Object.keys(_wtDbCache).forEach(y => s.add(parseInt(y, 10)));
    } else {
      // Fallback: current year only until DB loads
      s.add(new Date().getFullYear());
    }
    return [...s].sort().reverse(); // newest first
  }

  /* ════════════════════════════════════════════════════
     RENDER
  ════════════════════════════════════════════════════ */
  function render() {
    const el = document.getElementById("tab-weekly-tracker");
    if (!el) return;
    // Ensure DB data is loaded before rendering
    if (!_wtDbLoaded) {
      el.innerHTML = `<div style="padding:24px 20px;color:var(--color-text-secondary);font-size:14px">
        <span style="opacity:.6">Loading weekly tracker data from server…</span></div>`;
      _loadWTFromDB().then(() => render()).catch(() => { _wtDbLoaded = true; render(); });
      return;
    }
    // Load server-side comments + reopened cases first (async), then paint.
    // On subsequent renders the in-memory cache is used instantly.
    if (!_serverCommentsLoaded) {
      // Show skeleton immediately so the panel feels responsive
      el.innerHTML = `<div style="padding:24px 20px">
        <div style="display:flex;gap:12px;margin-bottom:16px">
          ${[120,80,100,60].map(w=>`<div style="height:28px;width:${w}px;border-radius:var(--radius-sm);background:var(--border-subtle);animation:wt-pulse 1.2s ease-in-out infinite"></div>`).join('')}
        </div>
        ${[1,2,3,4,5,6].map(()=>`<div style="display:flex;gap:12px;align-items:center;margin-bottom:10px">
          <div style="height:18px;width:110px;border-radius:var(--radius-xs);background:var(--border-subtle);animation:wt-pulse 1.2s ease-in-out infinite"></div>
          <div style="height:18px;flex:1;border-radius:var(--radius-xs);background:var(--border-subtle);animation:wt-pulse 1.2s ease-in-out infinite;opacity:.7"></div>
          <div style="height:18px;width:70px;border-radius:var(--radius-xs);background:var(--border-subtle);animation:wt-pulse 1.2s ease-in-out infinite;opacity:.5"></div>
        </div>`).join('')}
        <style>@keyframes wt-pulse{0%,100%{opacity:.4}50%{opacity:1}}</style>
      </div>`;
      Promise.all([
        _loadServerComments(),
        _fetchReopenedCases(),
        typeof _loadHistoryFromDB === 'function' ? _loadHistoryFromDB() : Promise.resolve()
      ]).then(() => _renderInner(el)).catch(() => _renderInner(el));
    } else {
      // Refresh reopened cases even if comments are cached
      _fetchReopenedCases().then(() => _renderInner(el)).catch(() => _renderInner(el));
    }
  }

  function _renderInner(el) {
    // _applySeed() removed — DB is single source of truth (Fix A3)
    const weeks = _buildWeeks(_year);
    if (!_currentWeek || !weeks.find(w => w.key === _currentWeek)) _currentWeek = _curCW(weeks);
    const years = _yearsAvail();

    el.innerHTML = `
      <div style="display:flex;flex-direction:column;height:calc(100vh - 112px);overflow:hidden">

        <!-- TOP: Tab bar + Year selector + compact nav strip -->
        <div style="flex-shrink:0;background:var(--bg-layer);border-bottom:1px solid var(--border-subtle)">

          <!-- Row 1: Tabs + Year -->
          <div style="display:flex;align-items:center;padding:0 16px;gap:0;border-bottom:1px solid var(--border-subtle)">
            <div style="display:flex;align-items:center;gap:6px;padding:6px 12px 6px 0;border-right:1px solid var(--border-subtle);margin-right:10px">
              <label for="wt-year-sel" style="font-size:10px;font-weight:600;text-transform:none;letter-spacing:var(--tracking-wide);color:var(--text-tertiary);white-space:nowrap">Year</label>
              <select id="wt-year-sel" aria-label="Select year" class="form-input form-input-sm" style="width:76px;font-family:var(--font-mono);font-weight:600;font-size:12px;height:26px"
                onchange="DashWeeklyTracker._setYear(parseInt(this.value))">
                ${years.map(y => `<option value="${y}" ${y===_year?"selected":""}>${y}</option>`).join("")}
              </select>
            </div>
            ${["tracker","reopened","history"].filter(t => t==="tracker" || Data.isAdmin()).map(t => {
              const label = t==="history"?"⏱ History":t==="reopened"?"↺ Reopened":"📋 Tracker";
              const isActive = _activeTab===t;
              return `<button onclick="DashWeeklyTracker._switchTab('${t}')" style="
                padding:10px 14px;font-size:12px;font-weight:${isActive?700:500};
                border:none;border-bottom:2px solid ${isActive?"var(--blue)":"transparent"};
                background:none;color:${isActive?"var(--blue)":"var(--text-secondary)"};
                cursor:pointer;white-space:nowrap;font-family:inherit;margin-bottom:-1px
              ">${label}</button>`;
            }).join("")}
          </div>

          <!-- Row 2: Compact month+week strip (tracker only) -->
          <div id="wt-nav-strip" style="display:${_activeTab==="tracker"?"flex":"none"};align-items:center;gap:0;overflow-x:auto;padding:0;background:var(--bg-layer);border-bottom:1px solid var(--border-subtle);min-height:36px">
            <div id="wt-week-list" style="display:flex;flex-direction:row;align-items:stretch;gap:0;white-space:nowrap;padding:0 8px;flex:1"></div>
            <div style="flex-shrink:0;padding:0 10px;border-left:1px solid var(--border-subtle);display:flex;align-items:center;height:36px">
              <button id="wt-today-btn" onclick="DashWeeklyTracker._jumpToToday()" title="Jump to current week"
                style="font-size:10px;font-weight:600;padding:4px 10px;border-radius:var(--radius-sm);border:1.5px solid var(--ibm-blue-50);background:rgba(15,98,254,.09);color:var(--ibm-blue-50);cursor:pointer;white-space:nowrap;transition:all var(--t-fast);letter-spacing:.03em;line-height:1.4"
                onmouseover="this.style.background='rgba(15,98,254,.2)'" onmouseout="this.style.background='rgba(15,98,254,.09)'">⟲ Today</button>
            </div>
          </div>

          <!-- Row 2 history search -->
          <div id="wt-hist-strip" style="display:${_activeTab==="history"?"flex":"none"};align-items:center;gap:8px;padding:6px 14px;background:var(--surface-1)">
            <input type="text" id="wt-hist-search" aria-label="Search history" class="search-input" placeholder="Search case, owner…" class="w-220"/>
            <label style="display:flex;align-items:center;gap:4px;cursor:pointer;user-select:none;font-size:11px;color:var(--text-secondary)">
              <input type="checkbox" id="wt-hist-hide-empty" aria-label="Hide empty entries" onchange="DashWeeklyTracker._renderHistoryFiltered()" class="cursor-p" width="14" height="14">
              Hide empty entries
            </label>
            <div class="flex-1"></div>
            <button class="btn btn-primary btn-sm" id="wt-hist-export-csv-btn" title="Export history as CSV spreadsheet" class="row-4-fs11"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg> Export Excel</button>
            
            <button class="btn btn-secondary btn-sm" id="wt-hist-import-btn" title="Import history from JSON file" class="row-4-fs11">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
              Import
            </button>
            <button class="btn btn-danger btn-sm" id="wt-hist-reset-btn" title="Clear all history permanently" class="row-4-fs11">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6M14 11v6"/><path d="M9 6V4h6v2"/></svg>
              Reset
            </button>
          </div>
        </div>

        <!-- MAIN: full-width content -->
        <div style="flex:1;overflow-y:auto;padding:14px 18px;min-width:0">
          <div id="wt-tracker-panel" style="display:${_activeTab==="tracker"?"block":"none"}">
            <!-- Week title + actions -->
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;gap:10px;flex-wrap:wrap">
              <div>
                <div id="wt-week-title" style="font-size:15px;font-weight:700;color:var(--text-primary);letter-spacing:-.2px"></div>
                <div id="wt-week-range" style="font-size:11px;color:var(--text-tertiary);margin-top:1px;font-family:var(--font-mono)"></div>
              </div>
              <div class="d-flex gap-8 flex-wrap">
                <button class="btn btn-primary btn-sm" id="wt-export-year-btn" title="Export all cases for the entire year — one sheet per week"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg> Export Excel</button>
              </div>
            </div>

            <!-- WT Global Case Search — searches ALL years -->
            <div id="wt-global-search-wrap" style="position:relative;margin-bottom:10px">
              <div style="display:flex;align-items:center;gap:8px;padding:8px 12px;background:var(--bg-layer);border:1px solid var(--border-subtle);border-radius:var(--radius-md)">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="color:var(--text-tertiary);flex-shrink:0"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>
                <input type="text" id="wt-global-search" aria-label="Search all cases" class="form-input form-input-sm"
                  placeholder="Search all cases across all years — case #, title, owner, category, comments…"
                  style="border:none;box-shadow:none;background:transparent;padding:0;flex:1;font-size:13px"
                  autocomplete="off"/>
                <span id="wt-gs-count" style="font-size:11px;color:var(--text-tertiary);font-family:var(--font-mono);flex-shrink:0;white-space:nowrap"></span>
                <button id="wt-gs-clear" style="display:none;background:none;border:none;cursor:pointer;color:var(--text-tertiary);padding:0;line-height:0" title="Clear search">
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                </button>
              </div>
              <div id="wt-global-search-results" style="display:none;position:absolute;top:calc(100% + 4px);left:0;right:0;background:var(--bg-ui);border:1px solid var(--border-mid);border-radius:var(--radius-md);box-shadow:var(--shadow-lg);z-index:500;max-height:420px;overflow-y:auto"></div>
            </div>

            <div id="wt-kpi" style="display:flex;gap:8px;margin-bottom:10px;flex-wrap:wrap"></div>
            <div id="wt-followup-panel" class="mb-10"></div>
            <div id="wt-bulk-bar" style="display:none;align-items:center;gap:8px;padding:7px 12px;background:rgba(15,98,254,.06);border:1px solid rgba(15,98,254,.2);border-radius:var(--radius-md);margin-bottom:8px;flex-wrap:wrap">
              ${Data.isAdmin() ? `<span id="wt-bulk-count" style="font-size:11px;font-weight:600;color:var(--ibm-blue-50);min-width:70px"></span>
              <span class="text-10 text-muted">Set for all selected:</span>
              <select id="wt-bulk-cat" aria-label="Bulk set category" class="form-input form-input-sm" style="font-size:11px;width:170px" onchange="DashWeeklyTracker._bulkSetCat(this.value);this.value=''">
                <option value="">Category…</option>
                ${WT_CATEGORIES.map(cat=>`<option value="${cat}">${cat}</option>`).join("")}
              </select>
              <select id="wt-bulk-av" aria-label="Bulk set availability" class="form-input form-input-sm" style="font-size:11px;width:140px" onchange="DashWeeklyTracker._bulkSetAv(this.value);this.value=''">
                <option value="">Availability…</option>
                <option value="Attended">✓ Attended</option>
                <option value="Not Joined">✗ Not Joined</option>
                <option value="On Leave">◌ On Leave</option>
                <option value="Follow Up">→ Follow Up</option>
                <option value="Reopen">↻ Reopen</option>
                <option value="Reopened">↺ Reopen</option>
              </select>
              <button class="btn btn-ghost btn-sm" onclick="DashWeeklyTracker._clearBulk()" style="margin-left:auto;font-size:11px">✕ Clear selection</button>` : `<span id="wt-bulk-count" style="font-size:11px;font-weight:600;color:var(--ibm-blue-50);min-width:70px"></span>`}
            </div>
            <div class="tile" style="padding:0;overflow:hidden">
              <div style="display:flex;align-items:center;justify-content:space-between;padding:8px 12px;border-bottom:1px solid var(--border-subtle);gap:10px;flex-wrap:wrap">
                <input type="text" id="wt-search" aria-label="Search cases" class="search-input" placeholder="Search cases, owner, category…" style="width:200px"/>
                <div id="wt-filter-chips" style="display:flex;align-items:center;gap:4px;flex-wrap:wrap;flex:1"></div>
                <span id="wt-row-count" style="font-size:11px;color:var(--text-tertiary);font-family:var(--font-mono);flex-shrink:0"></span>
              </div>
              <div id="wt-table-wrap" style="overflow-x:auto;overflow-y:auto;max-height:calc(100vh - 320px)"></div>
            </div>
          </div>

          <div id="wt-reopened-panel" style="display:${_activeTab==="reopened"?"block":"none"}"></div>
          <div id="wt-history-panel" style="display:${_activeTab==="history"?"block":"none"}">
            <div style="display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:14px;gap:10px;flex-wrap:wrap">
              <div>
                <div style="font-size:15px;font-weight:700;color:var(--text-primary)">Case History</div>
                <div class="text-11 text-muted mt-6">Tracks status and comment changes — useful when cases are reopened</div>
              </div>
              <button onclick="DashWeeklyTracker._switchTab('tracker');DashWeeklyTracker._jumpToToday();"
                style="flex-shrink:0;display:inline-flex;align-items:center;gap:6px;font-size:11px;font-weight:600;
                  padding:6px 14px;border-radius:var(--radius-sm);border:1.5px solid var(--ibm-blue-50);background:rgba(15,98,254,.08);
                  color:var(--ibm-blue-50);cursor:pointer;transition:all var(--t-fast);white-space:nowrap"
                onmouseover="this.style.background='rgba(15,98,254,.18)'" onmouseout="this.style.background='rgba(15,98,254,.08)'">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"/></svg>
                ← Back to this week
              </button>
            </div>
            <div id="wt-history-content"></div>
          </div>
          ${Data.isAdmin() ? `
          <!-- Danger Zone -->
          <div style="margin-top:24px;border:1.5px solid rgba(220,53,69,.35);border-radius:var(--radius-md);padding:16px 18px;background:rgba(220,53,69,.04)">
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--red)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
              <span style="font-size:12px;font-weight:600;text-transform:uppercase;letter-spacing:.05em;color:var(--red)">Danger Zone</span>
            </div>
            <div style="display:flex;align-items:center;justify-content:space-between;padding:10px 12px;background:var(--bg-layer);border:1px solid var(--border-subtle);border-radius:var(--radius-sm)">
              <div>
                <div style="font-size:var(--font-size-sm);font-weight:600;color:var(--text-primary)">Clear All Case History</div>
                <div class="text-11 text-muted mt-6">Permanently removes all history entries for all users and weeks. Cannot be undone.</div>
              </div>
              <button id="wt-clear-history-btn" class="btn btn-danger btn-sm" style="flex-shrink:0;margin-left:16px" title="Admin: permanently delete all history entries">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6M14 11v6"/><path d="M9 6V4h6v2"/></svg>
                Clear All History
              </button>
            </div>
          </div>` : ""}
        </div>
      </div>

      <!-- Add/Edit Modal -->
      <div id="wt-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:600;align-items:center;justify-content:center">
        <div style="background:var(--bg-layer);border:1px solid var(--border-subtle);border-radius:var(--radius-md);padding:24px;width:640px;max-width:95vw;max-height:92vh;overflow-y:auto;box-shadow:0 20px 60px rgba(0,0,0,.4)">
          <div id="wt-mtitle" style="font-size:15px;font-weight:700;margin-bottom:18px">Add Closed Case</div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
            <div class="form-group"><label class="form-label" for="wm-owner">Case Owner *</label><select id="wm-owner" class="form-input form-input-sm"></select></div>
            <div class="form-group"><label class="form-label" for="wm-cn">Case Number *</label><input id="wm-cn" class="form-input form-input-sm" placeholder="TS0…"/></div>
            <div class="form-group" style="grid-column:1/-1"><label class="form-label" for="wm-title">Title *</label><input id="wm-title" class="form-input form-input-sm"/></div>
            <div class="form-group"><label class="form-label" for="wm-prod">Product</label><input id="wm-prod" class="form-input form-input-sm"/></div>
            <div class="form-group"><label class="form-label" for="wm-sev">Severity</label>
              <select id="wm-sev" class="form-input form-input-sm">
                <option value="">—</option><option value="1">1 – Critical</option><option value="2">2 – Significant</option><option value="3">3 – Moderate</option><option value="4">4 – Minor</option>
              </select>
            </div>
            <div class="form-group"><label class="form-label" for="wm-status">Status</label><input id="wm-status" class="form-input form-input-sm" value="Closed by IBM"/></div>
            <div class="form-group"><label class="form-label" for="wm-age">Age</label><input id="wm-age" class="form-input form-input-sm" placeholder="e.g. 14 days"/></div>
            <div class="form-group"><label class="form-label" for="wm-closed">Closed Date</label><input id="wm-closed" type="date" class="form-input form-input-sm"/></div>
            <div class="form-group" style="grid-column:1/-1">
              <label class="form-label" for="wm-cat">Category <span id="wm-cat-suggest" style="font-size:10px;color:var(--blue);margin-left:6px;cursor:pointer"></span></label>
              <select id="wm-cat" class="form-input form-input-sm">
                <option value="">— Select category —</option>
                ${WT_CATEGORIES.map(c=>`<option value="${c}">${c}</option>`).join("")}
              </select>
            </div>
            <div class="form-group" style="grid-column:1/-1">
              <label class="form-label" for="wm-cmt">Update / Comments <span style="color:var(--text-tertiary);font-weight:400">(team notes)</span></label>
              <textarea id="wm-cmt" class="form-input form-input-sm" rows="3" style="resize:vertical"></textarea>
            </div>
          </div>
          <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:16px">
            <button class="btn btn-ghost btn-sm" id="wt-mcancel">Cancel</button>
            <button class="btn btn-primary btn-sm" id="wt-msave">Add Case</button>
          </div>
        </div>
      </div>
    `;

    _renderWeekNav(weeks);
    _renderContent(weeks);
    _bindEvents(weeks);
    if (_activeTab === "history")  _renderHistory();
    if (_activeTab === "reopened") _renderReopened();
  }

  /* ── Week nav (compact horizontal strip) ── */
  function _renderWeekNav(weeks) {
    const list = document.getElementById("wt-week-list"); if (!list) return;
    const allData = _ldy(_year);
    const MS = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    // Group weeks by month
    const groups = {};
    weeks.forEach(w => {
      if (!groups[w.month]) groups[w.month] = [];
      groups[w.month].push(w);
    });
    let html = "";
    Object.entries(groups).forEach(([mo, wks]) => {
      // Month label pill
      html += `<div style="display:flex;align-items:center;padding:0 4px 0 8px;flex-shrink:0">
        <span style="font-size:9px;font-weight:600;text-transform:none;letter-spacing:var(--tracking-wide);color:var(--text-disabled);white-space:nowrap;padding-right:4px;border-right:1px solid var(--border-subtle)">${MS[mo]}</span>
      </div>`;
      wks.forEach(w => {
        const cnt = (allData[w.key]||[]).length;
        const active = w.key === _currentWeek;
        const isCurrentWeek = w.key === _curCW(weeks);
        const label = w.label;
        // Style: blue fill = selected, amber border = today's week (may differ if user browsed away)
        const _nbBg    = active ? "var(--chart-1)" : "transparent";
        const _nbColor = active ? "#fff" : (cnt>0?"var(--text-primary)":"var(--text-tertiary)");
        const _nbFw    = active ? 700 : (isCurrentWeek ? 600 : (cnt>0?600:400));
        const _nbBorder= active ? "2px solid var(--ibm-blue-50)" : isCurrentWeek ? "2px solid var(--yellow)" : "1px solid transparent";
        const _nbShad  = active ? "0 1px 4px rgba(15,98,254,.35)" : isCurrentWeek ? "0 0 0 2px rgba(245,158,11,.18)" : "none";
        const _nbTitle = isCurrentWeek && !active ? " (Current week)" : "";
        html += `<button class="wt-nb" data-wk="${w.key}" onclick="DashWeeklyTracker._navClick('${w.key}')" title="${w.range}${_nbTitle}"
          style="flex-shrink:0;border:none;cursor:pointer;padding:5px 9px;margin:3px 2px;border-radius:var(--radius-sm);
            background:${_nbBg};
            color:${_nbColor};
            font-size:10px;font-family:var(--font-mono);font-weight:${_nbFw};
            display:inline-flex;align-items:center;gap:4px;white-space:nowrap;
            border:${_nbBorder};transition:all var(--t-fast);
            box-shadow:${_nbShad}"
          onmouseover="if(this.dataset.wk!=='${_currentWeek}'){this.style.background='var(--bg-hover)';}"
          onmouseout="if(this.dataset.wk!=='${_currentWeek}'){this.style.background='transparent';}"
        >${label}${isCurrentWeek&&!active?'<span style="font-size:8px;vertical-align:middle;margin-left:1px" title="This week">●</span>':''}${cnt>0?`<span style="font-size:9px;font-weight:600;padding:0 4px;border-radius:var(--radius-md);background:${active?"rgba(255,255,255,.28)":"rgba(15,98,254,.14)"};color:${active?"#fff":"var(--chart-1)"};min-width:14px;text-align:center;line-height:16px">${cnt}</span>`:""}</button>`;
      });
    });
    list.innerHTML = html;
    setTimeout(() => {
      const ab = list.querySelector(`.wt-nb[data-wk="${_currentWeek}"]`);
      if (ab) ab.scrollIntoView({ inline: "center", block: "nearest" });
    }, 50);
  }


  function _renderContent(weeks) {
    const w = weeks.find(x => x.key === _currentWeek); if (!w) return;
    document.getElementById("wt-week-title").textContent = _year + "  \u00B7  " + w.label;
    document.getElementById("wt-week-range").textContent  = w.range;
    _renderKPI(); _renderFollowUp(); _renderTable(weeks); // Fix C4: _renderWeekNav called once in _renderInner
    // Wire global search once the DOM is ready
    if (!document.getElementById('wt-global-search')?._wired) {
      _setupGlobalSearch();
      const si = document.getElementById('wt-global-search');
      if (si) si._wired = true;
    }
  }

  /* ── Follow-up panel: collapsible with badge count, grouped by case number ── */
  let _followupOpen = true;
  function _renderFollowUp() {
    const el = document.getElementById("wt-followup-panel"); if (!el) return;
    const allData = _ldy(_year);

    // Build team member set for filtering
    const _fupTeamSet = (() => {
      try {
        const m = (typeof DynamicConfig !== "undefined" && DynamicConfig.teamMembers)
          ? DynamicConfig.teamMembers()
          : (typeof AppData !== "undefined" ? AppData.teamMembers : []);
        return m.length ? new Set(m.map(n => n.toLowerCase())) : null;
      } catch(e) { return null; }
    })();

    // Collect all unresolved entries — team members only
    const needsAttention = [];
    Object.entries(allData).forEach(([wk, rows]) => {
      (rows||[]).forEach(r => {
        // Skip non-team-member rows
        if (_fupTeamSet && _fupTeamSet.size && !_fupTeamSet.has((r.owner||"").toLowerCase())) return;
        const av = r.availability || "";
        if (["Not Joined","On Leave","Follow Up","Reopened"].includes(av)) {
          if (!(r.comments && r.comments.trim())) {
            needsAttention.push({ ...r, _week: wk });
          }
        }
      });
    });
    if (!needsAttention.length) { el.innerHTML = ""; return; }

    // ── Group by case number ──────────────────────────────────────────
    const grouped = new Map(); // caseNumber → { entries[], owner, title, latestAv, latestWeek }
    needsAttention.sort((a,b) => a._week.localeCompare(b._week)).forEach(r => {
      const key = r.caseNumber || (r.owner + "|" + r.title); // fallback if no case number
      if (!grouped.has(key)) {
        grouped.set(key, { caseNumber: r.caseNumber, owner: r.owner, title: r.title, entries: [] });
      }
      grouped.get(key).entries.push({ week: r._week, av: r.availability, id: r.id });
    });

    const avIcon  = v => v==="Not Joined"?"✗":v==="On Leave"?"◌":v==="Reopened"?"↺":"→";
    const avColor = v => v==="Not Joined"?"var(--chart-5)":v==="On Leave"?"var(--chart-3)":v==="Reopened"?"var(--orange)":"var(--chart-4)";

    const uniqueCount = grouped.size;
    const totalCount  = needsAttention.length;

    const rows = [...grouped.values()].map(g => {
      const latest     = g.entries[g.entries.length - 1]; // most recent week entry
      const isDup      = g.entries.length > 1;
      const activeWk   = g.entries.find(e => e.week === _currentWeek);
      const rowBg      = activeWk ? "rgba(15,98,254,.04)" : "";

      // Week tags — each is clickable to focus that week's entry
      const weekTags = g.entries.map(e => {
        const wkLabel = e.week.replace("CW","W");
        const isCur   = e.week === _currentWeek;
        return `<span
          title="Click to jump to ${wkLabel} and focus this case"
          onclick="event.stopPropagation();DashWeeklyTracker._focusCase('${e.week}','${e.id}')"
          style="display:inline-flex;align-items:center;font-size:9px;font-weight:600;
            padding:1px 6px;border-radius:var(--radius-md);cursor:pointer;white-space:nowrap;
            background:${isCur?"var(--chart-1)":"rgba(15,98,254,.1)"};
            color:${isCur?"#fff":"var(--chart-1)"};
            border:1px solid ${isCur?"var(--chart-1)":"rgba(15,98,254,.3)"};
            transition:all var(--t-fast)"
          onmouseover="this.style.background='rgba(15,98,254,.25)';this.style.color='var(--chart-1)'"
          onmouseout="this.style.background='${isCur?"var(--chart-1)":"rgba(15,98,254,.1)"}';this.style.color='${isCur?"#fff":"var(--chart-1)"}'"
        >${wkLabel}</span>`;
      }).join("");

      // Duplicate badge
      const dupBadge = isDup
        ? `<span title="${g.entries.length} weeks unresolved" style="font-size:9px;font-weight:600;padding:1px 6px;border-radius:var(--radius-md);background:rgba(220,38,38,.12);color:var(--red);border:1px solid rgba(220,38,38,.3);white-space:nowrap;flex-shrink:0">
            ×${g.entries.length} weeks
          </span>`
        : "";

      return `<div style="display:flex;align-items:center;gap:10px;padding:7px 12px;border-bottom:1px solid var(--border-subtle);background:${rowBg};flex-wrap:wrap"
        onmouseover="this.style.background='var(--bg-hover)'" onmouseout="this.style.background='${rowBg}'"
      >
        <div style="display:flex;align-items:center;gap:4px;flex-shrink:0;flex-wrap:wrap;min-width:60px">${weekTags}</div>
        <span style="font-size:11px;font-weight:600;color:var(--text-secondary);min-width:90px;flex-shrink:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${Utils.escHtml((g.owner||"").split(" ").slice(0,2).join(" "))}</span>
        <span
          title="Click to focus — appears in ${g.entries.length} week(s)"
          onclick="event.stopPropagation();DashWeeklyTracker._focusCase('${latest.week}','${latest.id}')"
          style="font-family:var(--font-mono);font-size:10px;color:var(--blue);flex-shrink:0;cursor:pointer;
            text-decoration:underline;text-decoration-style:dotted;text-underline-offset:2px;transition:opacity var(--t-fast)"
          onmouseover="this.style.opacity='.7'" onmouseout="this.style.opacity='1'"
        >${Utils.escHtml(g.caseNumber||"")}</span>
        ${dupBadge}
        <span style="flex:1;font-size:11px;color:var(--text-secondary);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;min-width:100px" title="${Utils.escHtml(g.title||"")}">${Utils.escHtml(g.title||"")}</span>
        <span style="font-size:11px;font-weight:600;color:${avColor(latest.av)};white-space:nowrap;flex-shrink:0">${avIcon(latest.av)} ${Utils.escHtml((latest.av||"").replace("Reopened","Reopen"))}</span>
        <span style="font-size:10px;color:var(--text-disabled);font-style:italic;white-space:nowrap;flex-shrink:0">no comment</span>
      </div>`;
    }).join("");

    // Badge shows unique cases + total entries if they differ
    const badgeLabel = uniqueCount < totalCount
      ? `${uniqueCount} <span style="font-weight:400;opacity:.8">(${totalCount} entries)</span>`
      : `${uniqueCount}`;

    el.innerHTML = `<div style="border:1px solid rgba(220,38,38,.2);border-radius:var(--radius-md);overflow:hidden;background:rgba(220,38,38,.02)">
      <div onclick="DashWeeklyTracker._toggleFollowup()" style="display:flex;align-items:center;gap:8px;padding:8px 12px;background:rgba(220,38,38,.06);border-bottom:${_followupOpen?'1px solid rgba(220,38,38,.15)':'none'};cursor:pointer;user-select:none"
        onmouseover="this.style.background='rgba(220,38,38,.1)'" onmouseout="this.style.background='rgba(220,38,38,.06)'">
        <span style="font-size:12px;font-weight:600;color:var(--red)">🔔 Needs Follow Up</span>
        <span style="font-size:10px;background:var(--red);color:#fff;padding:1px 7px;border-radius:var(--radius-md);font-weight:600;font-family:var(--font-mono)">${badgeLabel}</span>
        <span style="font-size:10px;color:var(--text-tertiary);margin-left:4px;flex:1">
          ${uniqueCount < totalCount ? `${uniqueCount} unique cases across ${totalCount} weeks — ` : ""}Cases needing attention — click to ${_followupOpen?'collapse':'expand'}
        </span>
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="var(--chart-5)" stroke-width="2" style="transform:rotate(${_followupOpen?180:0}deg);transition:transform var(--transition-base);flex-shrink:0"><polyline points="6 9 12 15 18 9"/></svg>
      </div>
      <div style="display:${_followupOpen?'block':'none'}">${rows}</div>
    </div>`;
  }

  function _toggleFollowup() {
    _followupOpen = !_followupOpen;
    _renderFollowUp();
  }

  /* ── Focus a single case from the Follow-Up panel ── */
  let _focusedCaseId = null; // null = no focus filter active
  function _focusCase(week, id) {
    // Navigate to the correct week first
    if (_currentWeek !== week) {
      _navClick(week);
    }
    // Set focus filter — _renderTable will use this to show only the focused row
    _focusedCaseId = (_focusedCaseId === id) ? null : id; // toggle off if same case clicked again
    _renderTable(_buildWeeks(_year));
    // Scroll the table row into view and flash it
    setTimeout(() => {
      const row = document.getElementById("wt-row-" + id);
      if (row) {
        row.scrollIntoView({ behavior: "smooth", block: "center" });
        row.style.transition = "box-shadow .1s";
        row.style.boxShadow = "inset 0 0 0 2px var(--yellow)";
        setTimeout(() => { row.style.boxShadow = ""; }, 1400);
      }
    }, 80);
  }
  function _clearFocusCase() {
    _focusedCaseId = null;
    _renderTable(_buildWeeks(_year));
  }

  /* ── KPI ── */
  function _renderKPI() {
    const el = document.getElementById("wt-kpi"); if (!el) return;
    const rows = _wr(_year, _currentWeek);
    const sv = n => rows.filter(r=>String(r.severity)===String(n)).length;
    const commented = rows.filter(r=>r.comments&&r.comments.trim()).length;
    const cards = [
      { v: rows.length, l: "Total",    c: "var(--blue)",   bg: "var(--blue-bg)",   bold: true },
      { v: sv(1),       l: "Sev 1",    c: "var(--red)",    bg: "rgba(218,30,40,.06)" },
      { v: sv(2),       l: "Sev 2",    c: "var(--orange)", bg: "rgba(255,131,43,.06)" },
      { v: sv(3),       l: "Sev 3",    c: "var(--chart-3)",       bg: "rgba(166,120,0,.06)" },
      { v: sv(4),       l: "Sev 4",    c: "var(--green)",  bg: "var(--green-bg)" },
      { v: commented,   l: "Notes",    c: "var(--ibm-blue-50)",       bg: "rgba(0,114,195,.06)" },
    ];
    el.innerHTML = `<div style="display:flex;gap:8px;flex-wrap:wrap;width:100%">${
      cards.map(({v,l,c,bg,bold}) =>
        `<div style="flex:1;min-width:70px;max-width:130px;padding:8px 12px;border-radius:var(--radius-md);background:${bg};border:1px solid rgba(0,0,0,.06);display:flex;align-items:center;gap:10px">
          <span style="font-size:20px;font-weight:700;color:${c};font-family:var(--font-mono);line-height:1;min-width:24px">${v}</span>
          <span style="font-size:10px;font-weight:600;color:${c};text-transform:none;letter-spacing:var(--tracking-wide);opacity:.8">${l}</span>
        </div>`
      ).join("")
    }</div>`;
  }

  /* ── Filter chips ── */
  function _renderFilterChips(rows) {
    const el = document.getElementById("wt-filter-chips"); if (!el) return;
    // Collect unique owners & categories from this week's rows
    const owners = [...new Set(rows.map(r => r.owner).filter(Boolean))].sort();
    const cats   = [...new Set(rows.map(r => r.category).filter(Boolean))].sort();

    const chip = (label, key, field, val, color) => {
      const active = (field === "owner" ? _filterOwner : _filterCategory) === val;
      return `<button onclick="DashWeeklyTracker._setChip('${field}','${val.replace(/'/g,"\'")}')"
        title="${field === 'owner' ? 'Filter by owner' : 'Filter by category'}: ${label}"
        style="flex-shrink:0;border:none;cursor:pointer;padding:3px 9px;border-radius:var(--radius-md);font-size:10px;font-weight:600;
          letter-spacing:.02em;white-space:nowrap;transition:all var(--t-fast);
          background:${active ? color : "var(--bg-hover)"};
          color:${active ? "#fff" : "var(--text-secondary)"};
          border:1.5px solid ${active ? color : "var(--border-subtle)"};
          box-shadow:${active ? "0 1px 4px rgba(0,0,0,.18)" : "none"}"
        onmouseover="if(!this.classList.contains('active')){this.style.borderColor='${color}';this.style.color='${color}'}"
        onmouseout="if(!this.classList.contains('active')){this.style.borderColor='var(--border-subtle)';this.style.color='var(--text-secondary)'}">
        ${active ? "✕ " : ""}${label}</button>`;
    };

    let html = "";
    if (owners.length > 1) {
      html += `<span style="font-size:9px;font-weight:600;text-transform:none;letter-spacing:var(--tracking-wide);color:var(--text-disabled);padding-right:3px;flex-shrink:0">Owner</span>`;
      owners.forEach(o => {
        const initials = o.split(" ").map(p=>p[0]||"").join("").slice(0,2).toUpperCase();
        html += chip(initials, "owner", "owner", o, "var(--chart-1)");
      });
    }
    if (cats.length > 1) {
      html += `<span style="font-size:9px;font-weight:600;text-transform:none;letter-spacing:var(--tracking-wide);color:var(--text-disabled);padding-left:6px;padding-right:3px;flex-shrink:0;${owners.length>1?'border-left:1px solid var(--border-subtle);margin-left:2px':''}">${owners.length>1?'Cat':'Category'}</span>`;
      cats.forEach(c => {
        const short = c.length > 12 ? c.slice(0,11)+"…" : c;
        html += chip(short, "cat", "category", c, "var(--chart-4)");
      });
    }
    // Clear all chips button (only shown when a filter is active)
    if (_filterOwner || _filterCategory) {
      html += `<button onclick="DashWeeklyTracker._clearChips()"
        style="flex-shrink:0;border:1px dashed var(--border-subtle);background:none;cursor:pointer;padding:3px 8px;border-radius:var(--radius-md);font-size:10px;color:var(--text-tertiary);transition:all var(--t-fast)"
        onmouseover="this.style.color='var(--red)';this.style.borderColor='var(--red)'" onmouseout="this.style.color='var(--text-tertiary)';this.style.borderColor='var(--border-subtle)'">
        ✕ Clear filters</button>`;
    }
    el.innerHTML = html;
  }

  function _setChip(field, val) {
    if (field === "owner")    { _filterOwner    = _filterOwner    === val ? "" : val; }
    if (field === "category") { _filterCategory = _filterCategory === val ? "" : val; }
    _renderTable(_buildWeeks(_year));
  }

  function _clearChips() {
    _filterOwner = ""; _filterCategory = "";
    _renderTable(_buildWeeks(_year));
  }

  /* ── Table ── */
  function _renderTable(weeks) {
    const wrap = document.getElementById("wt-table-wrap"), cntEl = document.getElementById("wt-row-count");
    if (!wrap) return;
    // Auto-normalize any garbage/numeric category values on render
    let rows = _wr(_year, _currentWeek);

    // NOTE: Date-range filter removed. Rows from weekly_closed_cases already belong
    // to the correct week by DB assignment. Filtering by closedDate (which is the
    // CURRENT live closed_date from the cases table, not the historical snapshot)
    // incorrectly drops cases that were reopened and re-closed in a later week,
    // because their closedDate no longer falls within the original week's range.
    // The week assignment in the DB is the authoritative source of truth.

    let changed = false;

    // Fetch live statuses from IBM Cases to sync with current state
    const liveData = (typeof Data !== 'undefined' && Data.allCases) ? Data.allCases() : [];
    const liveByCase = {};
    liveData.forEach(c => {
      const caseNum = c["Case Number"] || c["Case#"] || "";
      if (caseNum) liveByCase[caseNum.toUpperCase()] = c;
    });

    // Helper to check if a status indicates a closed case
    const isClosed = (status) => {
      if (!status) return false;
      const s = String(status).toLowerCase();
      return s.includes('closed') || s.includes('cancel') || s.includes('cancelled');
    };

    rows = rows.map(r => {
      // Weekly tracker rows from DB are source of truth — no live status overwrite.

      const raw = r.category || "";
      const norm = _normCat(raw);
      if (norm !== raw) { changed = true; return { ...r, category: norm }; }
      return r;
    });

    // NOTE: Do NOT filter rows by current status here.
    // Rows from weekly_closed_cases are the source of truth for a given week —
    // a case that was closed in CW07 stays in CW07 even if later reopened.
    // Grayout styling handles the "reopened" visual indicator separately.
    if (changed) {
      _swk(_year, _currentWeek, rows);
    }
    // ── Team member filter — only show rows belonging to current team ────────
    const _teamMembers = (() => {
      try {
        const members = (typeof DynamicConfig !== "undefined" && DynamicConfig.teamMembers)
          ? DynamicConfig.teamMembers()
          : (typeof AppData !== "undefined" ? AppData.teamMembers : []);
        const aliases = (typeof DynamicConfig !== "undefined" && DynamicConfig.nameAliases)
          ? DynamicConfig.nameAliases() : {};
        // Include both raw names and display name values so alias owners pass the filter
        const displayNames = Object.values(aliases).filter(Boolean).map(v => v.toLowerCase());
        return new Set([...members.map(m => m.toLowerCase()), ...displayNames]);
      } catch(e) { return null; }
    })();
    const _isTeamRow = r => {
      if (!_teamMembers || !_teamMembers.size) return true; // no list = show all
      const owner = (r.owner || "").toLowerCase();
      return _teamMembers.has(owner);
    };

    const q = (document.getElementById("wt-search")?.value||"").toLowerCase();
    // Apply team filter + text search + chip filters + focus filter
    const filt = rows.filter(r => {
      if (_focusedCaseId) return r.id === _focusedCaseId; // focus-mode: only the pinned case
      if (!_isTeamRow(r)) return false; // hide non-team-member rows
      if (q && ![r.owner,r.caseNumber,r.title,r.category,r.comments].some(v=>v&&String(v).toLowerCase().includes(q))) return false;
      if (_filterOwner    && r.owner    !== _filterOwner)    return false;
      if (_filterCategory && r.category !== _filterCategory) return false;
      return true;
    });
    if (cntEl) cntEl.textContent = filt.length+" case"+(filt.length!==1?"s":"");

    // Focus-mode banner — shown when a single case is pinned from the Follow-Up panel
    const focusBanner = document.getElementById("wt-focus-banner");
    if (_focusedCaseId) {
      const fc = rows.find(r => r.id === _focusedCaseId);
      const bannerHtml = `<div id="wt-focus-banner" style="display:flex;align-items:center;gap:8px;padding:6px 12px;
        background:rgba(245,158,11,.08);border:1px solid rgba(245,158,11,.35);border-radius:var(--radius-md);margin-bottom:8px;flex-wrap:wrap">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--yellow)" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
        <span style="font-size:11px;font-weight:600;color:var(--yellow-text)">Showing case: ${Utils.escHtml(fc?.caseNumber||"")} — ${Utils.escHtml((fc?.title||"").slice(0,60))}${(fc?.title||"").length>60?"…":""}</span>
        <button onclick="DashWeeklyTracker._clearFocusCase()" style="margin-left:auto;display:inline-flex;align-items:center;gap:4px;font-size:10px;font-weight:600;padding:3px 9px;border-radius:var(--radius-sm);border:1px solid rgba(245,158,11,.4);background:none;color:var(--yellow-text);cursor:pointer;transition:all var(--t-fast)"
          onmouseover="this.style.background='rgba(245,158,11,.12)'" onmouseout="this.style.background='none'">
          ✕ Show all cases
        </button>
      </div>`;
      if (focusBanner) {
        focusBanner.outerHTML = bannerHtml;
      } else {
        const bulkBar = document.getElementById("wt-bulk-bar");
        if (bulkBar) bulkBar.insertAdjacentHTML("afterend", bannerHtml);
      }
    } else {
      if (focusBanner) focusBanner.remove();
    }

    // Build filter chip suggestions from current week's unique owners + categories
    _renderFilterChips(rows);

    // Apply sort — date-aware for closedDate, lexical for everything else
    const sortedFilt = _sortCol ? [...filt].sort((a,b) => {
      if (_sortCol === "closedDate") {
        const _parseDate = (v) => {
          if (!v) return 0;
          const s = String(v).trim();
          if (/^\d{4}-\d{2}-\d{2}/.test(s)) return new Date(s).getTime() || 0;
          // M/D/YYYY or MM/DD/YYYY, optionally followed by H:mm time
          const mdy = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})(?:\s+(\d{1,2}):(\d{2}))?/);
          if (mdy) {
            const iso = `${mdy[3]}-${mdy[1].padStart(2,"0")}-${mdy[2].padStart(2,"0")}T${(mdy[4]||"0").padStart(2,"0")}:${mdy[5]||"00"}:00`;
            return new Date(iso).getTime() || 0;
          }
          return 0;
        };
        const da = _parseDate(a.closedDate), db = _parseDate(b.closedDate);
        return (da - db) * _sortDir;
      }
      const va = String(a[_sortCol]||"").toLowerCase();
      const vb = String(b[_sortCol]||"").toLowerCase();
      return va < vb ? -_sortDir : va > vb ? _sortDir : 0;
    }) : filt;

    if (!rows.length) {
      wrap.innerHTML = `<div style="text-align:center;padding:56px 24px;color:var(--text-tertiary)"><div class="fs-32-mb10">📭</div><div style="font-size:14px;font-weight:600;color:var(--text-secondary);margin-bottom:4px">No cases this week</div><div class="fs-12">Upload your IBM cases CSV on the landing page — closed team cases are auto-populated here by week.</div></div>`;
      return;
    }
    if (!filt.length) {
      wrap.innerHTML = `<div style="text-align:center;padding:48px;color:var(--text-tertiary)"><div class="kpi-icon">🔍</div><div style="font-size:13px;font-weight:600;color:var(--text-secondary)">No results</div></div>`;
      return;
    }

    // Consistent rounded pill badge for severity (#10)
    const sevBadge = s => {
      const m={"1":["var(--red-bg)","var(--red)","rgba(218,30,40,.25)","S1"],"2":["var(--orange-bg)","var(--orange)","rgba(255,131,43,.25)","S2"],"3":["var(--yellow-bg)","var(--chart-3)","rgba(166,120,0,.2)","S3"],"4":["var(--green-bg)","var(--green)","rgba(25,128,56,.2)","S4"]};
      const entry=m[String(s)];
      if(!entry) return `<span class="text-dim">\u2014</span>`;
      const [bg,col,b,label]=entry;
      return `<span title="Severity ${s}" style="font-size:10px;font-weight:600;padding:2px 8px;border-radius:999px;background:${bg};color:${col};border:1px solid ${b};font-family:var(--font-mono);display:inline-block;min-width:28px;text-align:center">${label}</span>`;
    };
    const fmtDate = s => {
      if (!s) return "\u2014";
      try {
        const d = Utils.parseDate ? Utils.parseDate(s) : new Date(s);
        if (!d || isNaN(d)) return String(s);
        const dateStr = d.toLocaleDateString("en-GB", {day:"2-digit", month:"short", year:"numeric"});
        // Append time only when the original string actually contains a time component
        const hasTime = /\d{1,2}:\d{2}/.test(String(s));
        if (hasTime) {
          const timeStr = d.toLocaleTimeString("en-GB", {hour:"2-digit", minute:"2-digit", hour12:false});
          return dateStr + " " + timeStr;
        }
        return dateStr;
      } catch(e) { return String(s); }
    };

    // Category colour map for badges (matches Knowledge Hub canonical names)
    const CAT_COLORS = {
      "Issue Fixed in iFix":           ["var(--green-bg)","var(--green)","rgba(26,122,26,.2)"],
      "LQE Validation / Reindexing":   ["var(--ibm-blue-10)","var(--ibm-blue-60)","rgba(0,88,214,.2)"],
      "Export / Import Issues":        ["var(--yellow-bg)","var(--yellow-text)","rgba(153,119,0,.2)"],
      "Known Defect":                  ["var(--red-bg)","var(--red)","rgba(192,0,42,.2)"],
      "Out of Memory / Heap Issues":   ["var(--red-bg)","#c00","rgba(192,0,0,.2)"],
      "TRS Feed Validation":           ["var(--ibm-blue-10)","var(--ibm-blue-50)","rgba(0,122,184,.2)"],
      "Insufficient Information in Logs": ["var(--bg-layer)","#555","rgba(80,80,80,.18)"],
      "Single Occurrence Issue":       ["var(--purple-bg)","var(--purple)","rgba(90,46,204,.2)"],
      "DCM Connectivity Issues":       ["var(--orange-bg)","var(--orange)","rgba(184,104,0,.2)"],
      "Database Connectivity Issues":  ["var(--orange-bg)","#d84","rgba(216,132,0,.2)"],
      "Backup & Restore":             ["var(--red-bg)","var(--red)","rgba(192,48,96,.2)"],
    };

    // Category cell — standard select, no colors
    const catCell = r => {
      const norm = _normCat(r.category);
      const isAdmin = Data.isAdmin();
      if (!isAdmin) {
        return `<div style="min-width:110px;max-width:180px;font-size:12px;color:${norm ? "var(--text-primary)" : "var(--text-tertiary)"}">
          ${norm ? Utils.escHtml(norm) : "\u2014"}
        </div>`;
      }
      return `<div style="min-width:110px;max-width:180px">
        <select class="form-select" style="font-size:11px;padding:3px 6px;width:100%"
          name="wt-category" aria-label="Case category"
          onchange="DashWeeklyTracker._setCat('${r.id}',this.value)"
          title="Select category">
          <option value="">\u2014 category \u2014</option>
          ${WT_CATEGORIES.map(c => `<option value="${Utils.escHtml(c)}"${c === norm ? " selected" : ""}>${Utils.escHtml(c)}</option>`).join("")}
        </select>
      </div>`;
    };

    // Availability dropdown — coloured select with per-option styling (#6)
    const avChip = r => {
      const av = r.availability || "";
      const avColor = v => v==="Attended"?"var(--chart-2)":v==="Not Joined"?"var(--chart-5)":v==="On Leave"?"var(--chart-3)":v==="Follow Up"?"var(--chart-4)":v==="Reopened"?"var(--orange)":"var(--text-tertiary)";
      const avBg   = v => v==="Attended"?"rgba(25,128,56,.08)":v==="Not Joined"?"rgba(218,30,40,.07)":v==="On Leave"?"rgba(166,120,0,.08)":v==="Follow Up"?"rgba(124,58,237,.08)":v==="Reopened"?"rgba(224,112,0,.09)":"";
      if (!Data.isAdmin()) {
        // Non-admin: show read-only badge
        const label = av==="Attended"?"✓ Attended":av==="Not Joined"?"✗ Not Joined":av==="On Leave"?"◌ On Leave":av==="Follow Up"?"→ Follow Up":av==="Reopened"?"↺ Reopen":av||"—";
        return `<span style="font-size:10px;font-weight:${av?"600":"400"};color:${avColor(av)};background:${avBg(av)||"transparent"};padding:3px 6px;border-radius:var(--radius-sm);display:inline-block;border:1px solid ${av?"currentColor":"var(--border-subtle)"}">${label}</span>`;
      }
      return `<select class="form-input form-input-sm" name="wt-availability" aria-label="Attendance status"
        style="font-size:10px;padding:3px 4px;width:100%;font-weight:${av?"600":"400"};
          color:${avColor(av)};background:${avBg(av)};border-color:${av?"currentColor":"var(--border-subtle)"};
          border-radius:var(--radius-sm);transition:all var(--t-fast)"
        onchange="DashWeeklyTracker._setAvailability('${r.id}',this.value);const c=this.value;const col=c==='Attended'?'var(--chart-2)':c==='Not Joined'?'var(--chart-5)':c==='On Leave'?'var(--chart-3)':c==='Follow Up'?'var(--chart-4)':c==='Reopened'?'var(--orange)':'var(--text-tertiary)';const bg=c==='Attended'?'rgba(25,128,56,.08)':c==='Not Joined'?'rgba(218,30,40,.07)':c==='On Leave'?'rgba(166,120,0,.08)':c==='Follow Up'?'rgba(124,58,237,.08)':c==='Reopened'?'rgba(224,112,0,.09)':'';this.style.color=col;this.style.background=bg;this.style.borderColor=c?'currentColor':'var(--border-subtle)';this.style.fontWeight=c?'600':'400'">
        <option value="" ${!av?"selected":""}>— select —</option>
        <option value="Attended"  ${av==="Attended"  ?"selected":""}>✓ Attended</option>
        <option value="Not Joined"${av==="Not Joined"?"selected":""}>✗ Not Joined</option>
        <option value="On Leave"  ${av==="On Leave"  ?"selected":""}>◌ On Leave</option>
        <option value="Follow Up" ${av==="Follow Up" ?"selected":""}>→ Follow Up</option>
        <option value="Reopened"  ${av==="Reopened"  ?"selected":""}>↺ Reopen</option>
      </select>`;
    };

    const trs = sortedFilt.map((r,i) => {
      // Comment cell — PRIMARY focus column: warm background, pulse when empty
      const CMT_PREVIEW_LEN = 80;
      const cmtFull = r.comments || "";
      const cmtTrunc = cmtFull.length > CMT_PREVIEW_LEN;
      const cmtPreview = cmtTrunc ? cmtFull.slice(0, CMT_PREVIEW_LEN) : cmtFull;
      const cmtInner = cmtFull
        ? `<div style="display:flex;flex-direction:column;gap:4px">
            <span style="font-size:11px;line-height:1.5;color:var(--text-primary);font-weight:500">${_linkify(cmtPreview)}${cmtTrunc
              ? `<span style="color:var(--ibm-blue-50);font-size:10px;font-weight:600;margin-left:3px">…more</span>`
              : ""}</span>
            <span style="font-size:9px;color:var(--text-tertiary);font-family:var(--font-mono)">${cmtFull.length} chars</span>
          </div>`
        : `<span class="wt-cmt-empty" style="display:inline-flex;align-items:center;gap:6px;
              padding:4px 8px;border-radius:var(--radius-sm);
              background:rgba(245,158,11,.1);border:1.5px dashed rgba(245,158,11,.5);
              color:var(--yellow-text);font-size:10px;font-weight:600;white-space:nowrap">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
            Add note
          </span>`;
      const isRowAdmin = Data.isAdmin();
      const cmtTitle = cmtFull ? Utils.escHtml(cmtFull).replace(/"/g, '&quot;') : "";
      const cmtCell = isRowAdmin
        ? `<div id="wt-cmttrig-${r.id}"
             title="${cmtTitle}"
             onclick="DashWeeklyTracker._openCmtPopover('${r.id}',this)"
             style="min-width:160px;max-width:240px;cursor:pointer;padding:5px 7px;border-radius:var(--radius-sm);
               background:${r.comments?"rgba(15,98,254,.04)":"rgba(245,158,11,.04)"};
               border:1px solid ${r.comments?"rgba(15,98,254,.15)":"rgba(245,158,11,.25)"};
               transition:all var(--transition-fast)"
             onmouseover="this.style.background='${r.comments?"rgba(15,98,254,.1)":"rgba(245,158,11,.12)"}';this.style.borderColor='${r.comments?"rgba(15,98,254,.4)":"rgba(245,158,11,.6)"}';this.style.transform='translateY(-1px)';this.style.boxShadow='0 2px 8px ${r.comments?"rgba(15,98,254,.12)":"rgba(245,158,11,.2)"}'"
             onmouseout="this.style.background='${r.comments?"rgba(15,98,254,.04)":"rgba(245,158,11,.04)"}';this.style.borderColor='${r.comments?"rgba(15,98,254,.15)":"rgba(245,158,11,.25)"}';this.style.transform='';this.style.boxShadow=''"
           >${cmtInner}</div>`
        : `<div id="wt-cmttrig-${r.id}"
             title="${cmtTitle}"
             style="min-width:160px;max-width:240px;padding:5px 7px;border-radius:var(--radius-sm);
               background:${r.comments?"rgba(15,98,254,.04)":"transparent"};
               border:1px solid ${r.comments?"rgba(15,98,254,.15)":"transparent"}"
           >${cmtInner}</div>`;

      // History indicator
      const hist = _loadHistory()[r.caseNumber];
      const histBadge = (hist && Data.isAdmin()) ? `<span title="${hist.entries.length} history entries" style="cursor:pointer;font-size:9px;background:rgba(255,131,43,.15);color:var(--orange);border:1px solid rgba(255,131,43,.3);padding:1px 5px;border-radius:var(--radius-xs);margin-left:4px" onclick="DashWeeklyTracker._switchTab('history')">⏱ ${hist.entries.length}</span>` : "";

      // Performance case highlighting
      const _wtPerfNums    = new Set(typeof Data !== "undefined" ? Data.getPerfCaseNums() : []);
      const _wtNonPerfNums = new Set(typeof Data !== "undefined" ? Data.getNonPerfCaseNums() : []);
      // isPerf: must be in perfNums AND not explicitly in nonPerfNums.
      // Meta category is NOT used as a standalone fallback — removePerfCaseNum clears meta,
      // so if a case was removed from perf tagging it will not show the badge.
      const _isPerf = r.caseNumber &&
        _wtPerfNums.has(r.caseNumber) &&
        !_wtNonPerfNums.has(r.caseNumber);
      const perfRowStyle = _isPerf ? "background:rgba(218,30,40,.06);border-left:3px solid rgba(218,30,40,.6);" : "";
      const perfBadgeWT  = _isPerf
        ? `<span title="Performance Case" style="font-size:9px;background:rgba(218,30,40,.15);color:var(--red);border:1px solid rgba(218,30,40,.3);padding:1px 5px;border-radius:var(--radius-xs);margin-left:4px;font-weight:600">\u26a1 Perf</span>`
        : "";

      const isSelected = _selectedRows.has(r.id);
      const _closedStatuses = ['Closed by IBM','Closed by Client','Closed - Archived'];
      const isActiveReopened = r.isReopened && !_closedStatuses.includes(r.status);
      return `<tr id="wt-row-${r.id}" data-case-number="${Utils.escHtml(r.caseNumber||String(''))}" data-week="${_currentWeek||String('')}" data-year="${_year}" data-later-week="${r.laterWeek||''}" data-later-year="${r.laterYear||(r.laterWeek?_year:'')}" style="${perfRowStyle}${isActiveReopened?'opacity:.6;background:rgba(224,112,0,.03);border-left:3px solid rgba(224,112,0,.4);':''} ${isSelected?'outline:2px solid rgba(15,98,254,.35);outline-offset:-2px;background:rgba(15,98,254,.04);':''}"> 
        <td style="text-align:center;width:28px">${isRowAdmin ? `<input type="checkbox" name="wt-row-select" aria-label="Select case ${r.caseNumber}" ${isSelected?"checked":""} onchange="DashWeeklyTracker._selRow('${r.id}',this.checked)" class="cursor-p" width="14" height="14" onclick="event.stopPropagation()">` : ""}</td>
        <td style="color:var(--text-tertiary);font-family:var(--font-mono);font-size:11px;width:28px">${i+1}</td>
        <td class="nowrap"><span style="display:inline-flex;align-items:center;gap:4px;background:var(--bg-hover);border:1px solid var(--border-subtle);border-radius:var(--radius-md);padding:2px 7px;font-size:11px;font-weight:500;white-space:nowrap;max-width:130px;overflow:hidden;text-overflow:ellipsis">${Utils.escHtml((r.owner||"\u2014").split(" ").slice(0,2).join(" "))}</span></td>
        <td class="nowrap">
          <div style="font-family:var(--font-mono);font-size:11px;color:var(--blue)">${Utils.escHtml(r.caseNumber||"\u2014")}${histBadge}</div>
          ${_isPerf ? `<div style="margin-top:2px">${perfBadgeWT}</div>` : ""}
          ${r.isDuplicate ? `<div style="margin-top:3px"><span style="font-size:9px;font-weight:700;padding:1px 6px;border-radius:var(--radius-xs);background:rgba(218,30,40,.1);color:var(--red);border:1px solid rgba(218,30,40,.3);letter-spacing:.03em">DUPE</span></div>` : ""}
          ${r.isReopened ? (() => {
            const badgeStyle = 'font-size:9px;font-weight:700;padding:1px 6px;border-radius:var(--radius-xs);background:rgba(224,112,0,.12);color:var(--orange);border:1px solid rgba(224,112,0,.3);letter-spacing:.03em';
            // Detect same-day or same-week reopen
            let subText = '';
            if (isActiveReopened && r.reopenedUploadDate && r.lastClosedDate) {
              const closedD  = r.lastClosedDate.slice(0,10);
              const reopenD  = r.reopenedUploadDate.slice(0,10);
              const wkStart  = r.weekStartDate ? r.weekStartDate.slice(0,10) : null;
              const wkEnd    = r.weekEndDate   ? r.weekEndDate.slice(0,10)   : null;
              if (closedD === reopenD) {
                subText = 'Closed & reopened same day';
              } else if (wkStart && wkEnd && reopenD >= wkStart && reopenD <= wkEnd) {
                subText = 'Closed & reopened same week';
              }
            }
            const mainBadge = r.laterWeek
              ? `<span style="${badgeStyle}">&#8635; Re-closed in ${Utils.escHtml(r.laterWeek)}</span>`
              : `<span style="${badgeStyle}">&#8635; Reopened</span>`;
            const subBadge = subText
              ? `<span style="font-size:9px;font-weight:600;padding:1px 6px;border-radius:var(--radius-xs);background:rgba(224,112,0,.07);color:var(--orange);border:1px solid rgba(224,112,0,.2);letter-spacing:.02em;margin-top:2px;display:inline-block">${subText}</span>`
              : '';
            return `<div style="margin-top:3px;display:flex;flex-direction:column;gap:2px">${mainBadge}${subBadge}</div>`;
          })() : ""}
        </td>
        <td style="max-width:200px"><div style="display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;font-size:12px" title="${Utils.escHtml(r.title||"")}">${Utils.escHtml(r.title||"\u2014")}</div></td>
        <td class="text-center">${sevBadge(r.severity)}</td>
        <td><span style="font-size:10px;font-weight:500;color:var(--green);white-space:normal;line-height:1.3">✓ ${Utils.escHtml(r.status||'Closed')}</span></td>
        <td style="font-family:var(--font-mono);font-size:11px;white-space:nowrap">${fmtDate(isActiveReopened?(r.lastClosedDate||r.closedDate):r.closedDate)}</td>
        <td style="background:${r.comments?"rgba(15,98,254,.03)":"rgba(245,158,11,.05)"};border-left:2px solid ${r.comments?"rgba(15,98,254,.2)":"rgba(245,158,11,.4)"};border-right:2px solid ${r.comments?"rgba(15,98,254,.2)":"rgba(245,158,11,.4)"}">${cmtCell}</td>
        <td>${catCell(r)}</td>
        <td>${avChip(r)}</td>
        <td>
          ${isRowAdmin ? `<div class="wt-ra" style="display:flex;gap:4px;opacity:0;transition:opacity var(--t-fast)">
            <button class="btn btn-ghost btn-2xs" onclick="DashWeeklyTracker._editRow('${r.id}')">Edit</button>
            <button class="btn btn-danger btn-2xs" onclick="DashWeeklyTracker._delRow('${r.id}')">&times;</button>
          </div>` : ""}
        </td>
      </tr>`;
    }).join("");

    const thStyle = (col) => {
      const active = _sortCol === col;
      const arrow = active ? (_sortDir===1 ? " ▲" : " ▼") : " ⇅";
      return `<th style="cursor:pointer;user-select:none;white-space:nowrap;color:${active?"var(--blue)":"inherit"}"
        onclick="DashWeeklyTracker._sortBy('${col}')"
        onmouseover="this.style.color='var(--blue)'" onmouseout="this.style.color='${active?"var(--blue)":"inherit"}'"
        title="Sort by ${col}">${col==="owner"?"Case Owner":col==="caseNumber"?"Case Number":col==="title"?"Title":col==="severity"?"Sev":col==="status"?"Status":col==="closedDate"?"Closed Date":col==="comments"?"Comments":col==="category"?"Category":col==="availability"?"Availability":col}<span class="fs-9-muted">${arrow}</span></th>`;
    };

    wrap.innerHTML = `
      <table class="data-table" style="font-size:11px;table-layout:fixed;width:100%;min-width:1100px">
        <colgroup>
          <col style="width:28px"><col style="width:28px"><col style="width:110px"><col style="width:115px"><col style="width:190px">
          <col style="width:44px"><col style="width:95px">
          <col class="w-100"><col style="width:165px"><col style="width:155px"><col style="width:125px"><col style="width:72px">
        </colgroup>
        <thead><tr>
          <th style="width:28px;text-align:center">${Data.isAdmin() ? `<input type="checkbox" id="wt-sel-all" title="Select all" onchange="DashWeeklyTracker._selAll(this.checked)" class="cursor-p" width="14" height="14">` : ""}</th>
          <th style="width:32px">#</th>
          ${thStyle("owner")}
          ${thStyle("caseNumber")}
          ${thStyle("title")}
          <th style="text-align:center;width:44px;cursor:pointer;user-select:none" onclick="DashWeeklyTracker._sortBy('severity')" title="Sort by Severity">Sev<span class="fs-9-muted">${_sortCol==="severity"?(_sortDir===1?" ▲":" ▼"):" ⇅"}</span></th>
          ${thStyle("status")}
          ${thStyle("closedDate")}
          <th style="cursor:pointer;user-select:none;white-space:nowrap;background:rgba(245,158,11,.08);border-left:2px solid rgba(245,158,11,.35);border-right:2px solid rgba(245,158,11,.35);color:var(--yellow-text);font-weight:700;letter-spacing:.02em"
            onclick="DashWeeklyTracker._sortBy('comments')"
            onmouseover="this.style.background='rgba(245,158,11,.16)'" onmouseout="this.style.background='rgba(245,158,11,.08)'"
            title="Sort by Comments — this is the most important column">
            <span style="display:inline-flex;align-items:center;gap:4px">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
              Comments
              <span style="font-size:8px;background:rgba(245,158,11,.3);color:var(--yellow-text);padding:1px 5px;border-radius:var(--radius-md);font-weight:700">KEY</span>
            </span>
            <span class="fs-9-muted">${_sortCol==="comments"?(_sortDir===1?" ▲":" ▼"):" ⇅"}</span>
          </th>
          ${thStyle("category")}
          ${thStyle("availability")}
          <th></th>
        </tr></thead>
        <tbody>${trs}</tbody>
      </table>
      <style>
        .data-table tbody tr:hover .wt-ra{opacity:1!important}
        .data-table td{overflow:hidden;text-overflow:ellipsis}
        #wt-table-wrap{overflow-x:auto}
        .data-table thead th{transition:color var(--t-fast)}
        @keyframes wt-cmt-pulse {
          0%,100%{box-shadow:0 0 0 0 rgba(245,158,11,0);border-color:rgba(245,158,11,.35)}
          50%{box-shadow:0 0 0 3px rgba(245,158,11,.2);border-color:rgba(245,158,11,.7)}
        }
        .wt-cmt-empty{animation:wt-cmt-pulse 2.4s ease-in-out infinite}
        .data-table tbody tr:hover .wt-cmt-empty{animation:none}
      </style>`;

    // (comment popover handled separately via _openCmtPopover)
    _applyGrayoutToVisibleRows();
  }

  /* ── History panel (#13 hide-empty toggle) ── */
  function _renderHistory() { _renderHistoryFiltered(); }

  /* ── Cases Reopened panel ────────────────────────────────────────────────── */
  /* Merges two sources:                                                        */
  /*   Section 1 — True Reopened Cases (from v_reopened_cases / CSV upload)    */
  /*   Section 2 — Cross-Week Tracker Cases (from localStorage grayout data)   */
  async function _renderReopened() {
    const panel = document.getElementById("wt-reopened-panel");
    if (!panel) return;

    // Invalidate cache when year changes so we always fetch fresh
    _reopenedCasesCache = null;

    const escH = s => String(s||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
    const sevColor = s => s==="1"?"var(--red)":s==="2"?"var(--orange)":s==="3"?"var(--chart-2)":"var(--text-tertiary)";

    panel.innerHTML = `<div style="padding:20px 16px;text-align:center;color:var(--text-tertiary);font-size:12px">Loading…</div>`;

    // ── Source 1: DB reopened cases (true reopened, filtered by year) ─────────
    const dbReopened = await _fetchReopenedCases();

    // ── Source 2: localStorage cross-week cases ───────────────────────────────
    const lsCrossWeek = (typeof WTCrossWeekGrayout !== 'undefined')
      ? WTCrossWeekGrayout.getCrossWeekCases()
      : new Map();

    // ── Filter DB cases to team members ──────────────────────────────────────
    const _tmSet = (() => {
      try {
        const m = (typeof DynamicConfig !== "undefined" && DynamicConfig.teamMembers)
          ? DynamicConfig.teamMembers()
          : (typeof AppData !== "undefined" ? AppData.teamMembers : []);
        return m && m.length ? new Set(m.map(x => (x.name||x||"").trim())) : null;
      } catch(e) { return null; }
    })();

    const filteredDB = _tmSet
      ? (dbReopened || []).filter(r => _tmSet.has((r.owner||"").trim()))
      : (dbReopened || []);

    // ── Status pill helper ────────────────────────────────────────────────────
    const statusPill = (r) => {
      const s = r.currentStatus || '';
      const isClosed = ['Closed by IBM','Closed by Client','Closed - Archived'].includes(s);
      const color = isClosed ? 'var(--green)' : 'var(--red)';
      const icon  = isClosed ? '✅' : '🔴';
      const pillClass = isClosed ? (s === 'Closed - Archived' ? 'pill--archived' : 'pill--closed') : 'pill--open';
      return `<span class="pill ${pillClass}" style="color:${color}">${icon} ${s || 'Unknown'}</span>`;
    };

    // ── Date pill helper ──────────────────────────────────────────────────────
    const datePill = (d, extraStyle) => d
      ? `<span style="font-size:10px;padding:1px 7px;border-radius:20px;background:var(--bg-layer);border:1px solid var(--border-subtle);color:var(--text-secondary);white-space:nowrap;${extraStyle||''}">${escH(d)}</span>`
      : `<span style="color:var(--text-tertiary)">—</span>`;

    // ── Week timeline builder ─────────────────────────────────────────────────
    const buildTimeline = (labels, years, caseNumber) => {
      if (!Array.isArray(labels) || !labels.length) return "";
      const steps = [];
      const cn = caseNumber || '';
      for (let i = 0; i < labels.length; i++) {
        const yr = (years && years[i]) || _year;
        const wk = String(labels[i] || '');
        steps.push(`<span class="wt-week-link-badge wt-nav-week-btn"
          title="Click to view ${wk} ${yr}"
          data-navyr="${yr}" data-navwk="${wk}" data-navcn="${escH(cn)}"
        >${escH(wk)}</span>`);
        if (i < labels.length - 1)
          steps.push('<span class="wt-reopened-timeline-separator">→</span>');
      }
      return `<div class="wt-reopened-timeline" style="margin-top:4px">${steps.join('')}</div>`;
    };

    // ═══════════════════════════════════════════════════════
    // SECTION 1 — True Reopened Cases
    // ═══════════════════════════════════════════════════════
    let _section1Filter = null; // null = show all

    const renderSection1 = () => {
      const data = _section1Filter
        ? filteredDB.filter(r => {
            if (_section1Filter === 'open')     return r.isCurrentlyOpen;
            if (_section1Filter === 'closed')   return !r.isCurrentlyOpen && r.currentStatus !== 'Closed - Archived';
            if (_section1Filter === 'archived') return r.currentStatus === 'Closed - Archived';
            if (_section1Filter === 'missed')   return r.missedWeekly;
            return true;
          })
        : filteredDB;

      const openCount     = filteredDB.filter(r => r.isCurrentlyOpen).length;
      const closedCount   = filteredDB.filter(r => !r.isCurrentlyOpen && r.currentStatus !== 'Closed - Archived').length;
      const archivedCount = filteredDB.filter(r => r.currentStatus === 'Closed - Archived').length;
      const missedCount   = filteredDB.filter(r => r.missedWeekly).length;

      const statBtn = (key, icon, label, count) => count > 0
        ? `<button class="wt-reopened-stat-btn${_section1Filter===key?' active':''}"
             onclick="window._wtSetReopenFilter('${key}')">
             ${icon} ${count} ${label}</button>`
        : '';

      const rows1 = data.map(r => {
        const srcBadge = `<span title="Detected from IBM CSV upload" style="font-size:9px;font-weight:600;padding:1px 5px;border-radius:var(--radius-xs);background:rgba(25,128,56,.1);color:var(--green);border:1px solid rgba(25,128,56,.2);margin-left:4px">upload</span>`;
        const missedBadge = r.missedWeekly
          ? `<span class="pill pill--missed" style="font-size:9px;margin-left:4px">⚠ missed weekly</span>`
          : '';
        return `<tr style="border-bottom:1px solid var(--border-subtle)">
          <td style="padding:10px 12px;font-weight:600;color:var(--text-secondary);font-size:12px;white-space:nowrap">
            ${escH((r.owner||'—').split(' ').slice(0,2).join(' '))}
          </td>
          <td style="padding:10px 12px">
            <div style="display:flex;align-items:center;gap:4px;flex-wrap:wrap">
              <span class="case-number-copy" data-cn="${escH(r.caseNumber)}"
                style="cursor:pointer;color:var(--ibm-blue-50);font-weight:700;font-family:var(--font-mono);font-size:12px"
                title="Click to copy">${escH(r.caseNumber)}</span>
              ${srcBadge}${missedBadge}
            </div>
          </td>
          <td style="padding:10px 12px;font-size:12px;color:var(--text-primary);max-width:260px">
            <span title="${escH(r.title)}" style="display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:240px">${escH(r.title||'—')}</span>
          </td>
          <td style="padding:10px 12px;text-align:center">
            ${r.severity ? `<span style="font-size:11px;font-weight:700;color:${sevColor(String(r.severity))}">S${escH(String(r.severity))}</span>` : '<span style="color:var(--text-tertiary)">—</span>'}
          </td>
          <td style="padding:10px 12px;white-space:nowrap">
            ${datePill(r.firstClosedDate)}
          </td>
          <td style="padding:10px 12px;white-space:nowrap">
            ${datePill(r.reopenedUploadDate, 'background:rgba(224,112,0,.08);border-color:rgba(224,112,0,.3);color:var(--orange)')}
          </td>
          <td style="padding:10px 12px;white-space:nowrap">
            ${datePill(r.finalClosedDate)}
          </td>
          <td style="padding:10px 12px">
            ${statusPill(r)}
          </td>
          <td style="padding:10px 12px">
            ${r.weekLabels && r.weekLabels.length
              ? buildTimeline(r.weekLabels, r.weekYears, r.caseNumber)
              : r.missedWeekly
                ? `<span class="pill pill--missed">⚠ missed</span>`
                : `<span style="color:var(--text-tertiary);font-size:11px">—</span>`}
          </td>
        </tr>`;
      }).join('');

      const emptyState = data.length === 0 && filteredDB.length > 0
        ? `<tr><td colspan="9" style="padding:20px;text-align:center;color:var(--text-tertiary);font-size:12px">No cases match this filter</td></tr>`
        : data.length === 0
          ? `<tr><td colspan="9" style="padding:40px;text-align:center;color:var(--text-tertiary);font-size:12px">No reopened cases found for ${_year}</td></tr>`
          : '';

      return `
        <div class="wt-reopened-stats-bar">
          ${statBtn('open','🔴','Still Open',openCount)}
          ${statBtn('closed','✅','Closed',closedCount)}
          ${statBtn('archived','📦','Archived',archivedCount)}
          ${statBtn('missed','⚠','Missed Weekly',missedCount)}
          ${_section1Filter ? `<button class="wt-reopened-stat-btn" onclick="window._wtSetReopenFilter(null)">✕ Clear</button>` : ''}
        </div>
        <div style="overflow-x:auto;border-radius:8px;border:1px solid var(--border-subtle)">
          <table style="width:100%;border-collapse:collapse;font-family:var(--font-sans)">
            <thead>
              <tr style="background:var(--bg-layer);border-bottom:2px solid var(--border-subtle)">
                <th style="padding:8px 12px;text-align:left;font-size:11px;font-weight:600;color:var(--text-tertiary);white-space:nowrap">OWNER</th>
                <th style="padding:8px 12px;text-align:left;font-size:11px;font-weight:600;color:var(--text-tertiary);white-space:nowrap">CASE #</th>
                <th style="padding:8px 12px;text-align:left;font-size:11px;font-weight:600;color:var(--text-tertiary)">TITLE</th>
                <th style="padding:8px 12px;text-align:center;font-size:11px;font-weight:600;color:var(--text-tertiary)">SEV</th>
                <th style="padding:8px 12px;text-align:left;font-size:11px;font-weight:600;color:var(--text-tertiary);white-space:nowrap">FIRST CLOSED</th>
                <th style="padding:8px 12px;text-align:left;font-size:11px;font-weight:600;color:var(--text-tertiary);white-space:nowrap">REOPENED ON</th>
                <th style="padding:8px 12px;text-align:left;font-size:11px;font-weight:600;color:var(--text-tertiary);white-space:nowrap">FINAL CLOSED</th>
                <th style="padding:8px 12px;text-align:left;font-size:11px;font-weight:600;color:var(--text-tertiary)">STATUS</th>
                <th style="padding:8px 12px;text-align:left;font-size:11px;font-weight:600;color:var(--text-tertiary)">IN WEEKLY</th>
              </tr>
            </thead>
            <tbody>${rows1}${emptyState}</tbody>
          </table>
        </div>`;
    };

    // ═══════════════════════════════════════════════════════
    // SECTION 2 — Cross-Week Tracker Cases (collapsed)
    // ═══════════════════════════════════════════════════════
    const dbByCn = new Map((filteredDB || []).map(r => [r.caseNumber, r]));

    const lsFiltered = (() => {
      const result = [];
      lsCrossWeek.forEach((appearances, cn) => {
        if (dbByCn.has(cn)) return;
        const latest = appearances[appearances.length - 1];
        const first  = appearances[0];
        const owner  = (latest.owner || first.owner || '—');
        if (_tmSet && !_tmSet.has(owner.trim())) return;
        result.push({ caseNumber: cn, owner, title: latest.title || first.title || '—',
          severity: latest.severity || first.severity || '', cycles: appearances.map(a => ({week:a.week,year:a.year})),
          currentStatus: latest.status || 'Closed' });
      });
      return result;
    })();

    const lsRows = lsFiltered.map(r => {
      const srcBadge = `<span title="Detected from tracker data" style="font-size:9px;font-weight:600;padding:1px 5px;border-radius:var(--radius-xs);background:rgba(15,98,254,.1);color:var(--ibm-blue-50);border:1px solid rgba(15,98,254,.2);margin-left:4px">tracker</span>`;
      const isActive = r.currentStatus && !r.currentStatus.toLowerCase().includes('closed');
      const statusColor = isActive ? 'rgba(15,98,254,0.1)' : 'rgba(34,177,76,0.1)';
      const statusTextColor = isActive ? 'var(--ibm-blue-50)' : 'var(--green)';
      const cycles = r.cycles || [];
      return `<tr style="border-bottom:1px solid var(--border-subtle)">
        <td style="padding:10px 12px;font-weight:600;color:var(--text-secondary);font-size:12px;white-space:nowrap">
          ${escH((r.owner||'—').split(' ').slice(0,2).join(' '))}
        </td>
        <td style="padding:10px 12px">
          <div style="display:flex;align-items:center;gap:4px">
            <span class="case-number-copy" data-cn="${escH(r.caseNumber)}"
              style="cursor:pointer;color:var(--ibm-blue-50);font-weight:700;font-family:var(--font-mono);font-size:12px"
              title="Click to copy">${escH(r.caseNumber)}</span>
            ${srcBadge}
          </div>
        </td>
        <td style="padding:10px 12px;font-size:12px;max-width:280px">
          <span title="${escH(r.title)}" style="display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:260px">${escH(r.title||'—')}</span>
        </td>
        <td style="padding:10px 12px;text-align:center">
          ${r.severity ? `<span style="font-size:11px;font-weight:700;color:${sevColor(String(r.severity))}">S${escH(String(r.severity))}</span>` : '<span style="color:var(--text-tertiary)">—</span>'}
        </td>
        <td style="padding:10px 12px">
          <span style="font-size:11px;padding:2px 8px;border-radius:20px;background:${statusColor};color:${statusTextColor};font-weight:600;white-space:nowrap">${escH(r.currentStatus||'Closed')}</span>
          <span style="font-size:10px;font-weight:600;padding:1px 6px;border-radius:var(--radius-xs);background:rgba(224,112,0,.12);color:var(--orange);border:1px solid rgba(224,112,0,.25);margin-left:4px">${cycles.length}× closed</span>
        </td>
        <td style="padding:10px 12px">
          <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">
            ${cycles.map((c,i) => { const w=String(c.week||''); const y=c.year||_year; return `<span class="wt-week-link-badge wt-nav-week-btn" title="Click to view ${w} ${y}" data-navyr="${y}" data-navwk="${w}" data-navcn="${escH(r.caseNumber)}">${escH(w)}</span>${i<cycles.length-1?'<span class="wt-reopened-timeline-separator">→</span>':''}`; }).join('')}
          </div>
        </td>
      </tr>`;
    }).join('');

    // ═══════════════════════════════════════════════════════
    // BUILD FULL PANEL HTML
    // ═══════════════════════════════════════════════════════
    panel.innerHTML = `
      <div style="padding:16px 16px 0">

        <!-- SECTION 1 header -->
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;flex-wrap:wrap">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="var(--red)" stroke-width="2" stroke-linecap="round"><path d="M1 4v6h6"/><path d="M3.51 15a9 9 0 1 0 .49-5.6L1 10"/></svg>
          <span style="font-size:13px;font-weight:700;color:var(--text-primary)">Reopened Cases</span>
          <span style="font-size:11px;padding:1px 8px;border-radius:20px;background:rgba(218,30,40,.08);color:var(--red);font-weight:600;border:1px solid rgba(218,30,40,.2)">${filteredDB.length}</span>
          <span style="font-size:11px;color:var(--text-tertiary)">for ${_year} — cases IBM closed that the customer reopened</span>
        </div>

        <!-- Section 1 content (stats bar + table) -->
        <div id="wt-s1-content">
          ${renderSection1()}
        </div>

        <!-- SECTION 2 — Cross-Week Tracker Cases (collapsible) -->
        <details style="margin-top:16px;margin-bottom:16px">
          <summary style="cursor:pointer;display:flex;align-items:center;gap:8px;padding:8px 12px;border-radius:var(--radius-md);background:var(--bg-layer);border:1px solid var(--border-subtle);font-size:12px;font-weight:600;color:var(--text-secondary);list-style:none;user-select:none">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M1 4v6h6"/><path d="M3.51 15a9 9 0 1 0 .49-5.6L1 10"/></svg>
            Cross-Week Tracker Cases
            <span style="font-size:11px;padding:1px 7px;border-radius:20px;background:rgba(15,98,254,.08);color:var(--ibm-blue-50);font-weight:600;border:1px solid rgba(15,98,254,.2)">${lsFiltered.length}</span>
            <span style="font-size:11px;color:var(--text-tertiary);font-weight:400">same case appearing in multiple weeks (from tracker)</span>
          </summary>
          <div style="margin-top:8px;overflow-x:auto;border-radius:8px;border:1px solid var(--border-subtle)">
            <div style="padding:8px 14px;background:rgba(15,98,254,.04);border-bottom:1px solid rgba(15,98,254,.12);font-size:11px;color:var(--text-secondary)">
              <strong style="color:var(--text-primary)">How this works:</strong>
              When a case number appears in multiple weeks, the earlier week is automatically grayed out and the latest week stays active. Click any week badge to jump there.
            </div>
            ${lsFiltered.length > 0 ? `
            <table style="width:100%;border-collapse:collapse;font-family:var(--font-sans)">
              <thead>
                <tr style="background:var(--bg-layer);border-bottom:2px solid var(--border-subtle)">
                  <th style="padding:8px 12px;text-align:left;font-size:11px;font-weight:600;color:var(--text-tertiary)">OWNER</th>
                  <th style="padding:8px 12px;text-align:left;font-size:11px;font-weight:600;color:var(--text-tertiary)">CASE #</th>
                  <th style="padding:8px 12px;text-align:left;font-size:11px;font-weight:600;color:var(--text-tertiary)">TITLE</th>
                  <th style="padding:8px 12px;text-align:center;font-size:11px;font-weight:600;color:var(--text-tertiary)">SEV</th>
                  <th style="padding:8px 12px;text-align:left;font-size:11px;font-weight:600;color:var(--text-tertiary)">STATUS</th>
                  <th style="padding:8px 12px;text-align:left;font-size:11px;font-weight:600;color:var(--text-tertiary)">WEEK TIMELINE</th>
                </tr>
              </thead>
              <tbody>${lsRows}</tbody>
            </table>` : `<div style="padding:20px;text-align:center;color:var(--text-tertiary);font-size:12px">No cross-week tracker cases detected</div>`}
          </div>
        </details>
      </div>`;

    // Expose filter function globally so stat buttons can call it directly
    window._wtSetReopenFilter = function(key) {
      _section1Filter = key;
      const s1 = document.getElementById('wt-s1-content');
      if (s1) s1.innerHTML = renderSection1();
    };

    // Delegated click handler for week navigation badges (avoids inline escaping issues)
    panel.onclick = function(e) {
      const btn = e.target.closest('.wt-nav-week-btn');
      if (!btn) return;
      const yr  = parseInt(btn.dataset.navyr, 10);
      const wk  = btn.dataset.navwk;
      const cn  = btn.dataset.navcn;
      DashWeeklyTracker._setYear(yr);
      DashWeeklyTracker._switchTab('tracker');
      DashWeeklyTracker._navClick(wk);
      if (cn) {
        setTimeout(function() {
          var el = document.querySelector('[data-cn="' + cn + '"]');
          if (el) {
            var row = el.closest('tr');
            if (row) {
              row.style.outline    = '2px solid var(--ibm-blue-50)';
              row.style.background = 'rgba(15,98,254,.07)';
              el.scrollIntoView({ block: 'center', behavior: 'smooth' });
              setTimeout(function() {
                row.style.outline    = '';
                row.style.background = '';
              }, 2500);
            }
          }
        }, 400);
      }
    };
  }

    async function _dismissReopen(caseNumber) {
    try {
      const existing = await IIPStore.getReopened();
      const updated = existing.filter(r => r.caseNumber !== caseNumber);
      await IIPStore.setReopened(updated);
      _renderReopened();
    } catch(e) {}
  }
  function _renderHistoryFiltered() {
    const el = document.getElementById("wt-history-content"); if (!el) return;
    const h = _loadHistory();
    const q = (document.getElementById("wt-hist-search")?.value||"").toLowerCase();
    const hideEmpty = document.getElementById("wt-hist-hide-empty")?.checked || false;
    const entries = Object.values(h).filter(item => {
      if (!(!q || item.caseNumber.toLowerCase().includes(q) || (item.owner||"").toLowerCase().includes(q))) return false;
      if (hideEmpty) {
        // Keep only cases where at least one entry has a real comment or meaningful status change
        const hasContent = item.entries.some(e =>
          (e.commentAfter && e.commentAfter.trim()) ||
          (e.statusBefore !== e.statusAfter) ||
          e.isReopen || e.availability
        );
        if (!hasContent) return false;
      }
      return true;
    });
    // Sort: cases with most recent activity first
    entries.sort((a, b) => {
      const ta = a.entries[0]?.ts || ""; const tb = b.entries[0]?.ts || "";
      return tb.localeCompare(ta);
    });
    if (!entries.length) {
      el.innerHTML = `<div style="text-align:center;padding:56px;color:var(--text-tertiary)">
        <div class="fs-32-mb10">⏱</div>
        <div style="font-size:14px;font-weight:600;color:var(--text-secondary);margin-bottom:4px">No history yet</div>
        <div class="fs-12">History is recorded automatically when you save comments or edit cases.<br>Reopen cases and alert-category changes are tracked here permanently.</div>
      </div>`;
      return;
    }
    el.innerHTML = entries.map(item => {
      // Count reopened appearances
      const reopenCount = item.entries.filter(e => e.isReopen || e.availability === "Reopened").length;
      const reopenBadge = reopenCount > 0
        ? `<span style="font-size:10px;background:rgba(224,112,0,.15);color:var(--orange);border:1px solid rgba(224,112,0,.3);padding:1px 7px;border-radius:var(--radius-md);font-weight:600">↺ Reopen ×${reopenCount}</span>`
        : "";
      const rows = item.entries.map(e => {
        const dt = (() => { try { const d = new Date(e.ts); return isNaN(d) ? (e.ts || "—") : d.toLocaleString("en-GB",{day:"2-digit",month:"short",year:"numeric",hour:"2-digit",minute:"2-digit"}); } catch(err) { return e.ts || "—"; } })();
        const isReopenEntry = e.isReopen || e.availability === "Reopened";
        const isAlertEntry  = e.availability && e.availability !== "Attended" && !isReopenEntry;
        // Border color: orange for reopen, purple for alert, default for comment/status changes
        const borderColor = isReopenEntry ? "var(--orange)" : isAlertEntry ? "var(--chart-4)" : "var(--border-subtle)";
        const bgColor     = isReopenEntry ? "rgba(224,112,0,.06)" : isAlertEntry ? "rgba(124,58,237,.05)" : "var(--bg-hover)";

        // Entry type badge
        let typeBadge = "";
        if (isReopenEntry) {
          const prevWk = e.prevWeek ? ` (from ${e.prevWeek})` : "";
          typeBadge = `<span style="font-size:10px;font-weight:600;background:rgba(224,112,0,.15);color:var(--orange);border:1px solid rgba(224,112,0,.3);padding:1px 7px;border-radius:var(--radius-xs);margin-right:6px">↺ Reopen${prevWk}</span>`;
        } else if (e.availability === "Not Joined") {
          typeBadge = `<span style="font-size:10px;font-weight:600;background:rgba(218,30,40,.1);color:var(--red);border:1px solid rgba(218,30,40,.25);padding:1px 7px;border-radius:var(--radius-xs);margin-right:6px">✗ Not Joined</span>`;
        } else if (e.availability === "On Leave") {
          typeBadge = `<span style="font-size:10px;font-weight:600;background:rgba(166,120,0,.1);color:var(--yellow);border:1px solid rgba(166,120,0,.25);padding:1px 7px;border-radius:var(--radius-xs);margin-right:6px">◌ On Leave</span>`;
        } else if (e.availability === "Follow Up") {
          typeBadge = `<span style="font-size:10px;font-weight:600;background:rgba(124,58,237,.1);color:var(--purple);border:1px solid rgba(124,58,237,.25);padding:1px 7px;border-radius:var(--radius-xs);margin-right:6px">→ Follow Up</span>`;
        }

        const statusChange = e.statusBefore !== e.statusAfter
          ? `<div style="font-size:11px;margin-bottom:4px"><span class="text-muted">Status:</span> <span style="color:var(--red);text-decoration:line-through">${Utils.escHtml(e.statusBefore||"—")}</span> → <span class="text-green-c">${Utils.escHtml(e.statusAfter||"—")}</span></div>`
          : "";
        const cmtChange = e.commentAfter
          ? `<div class="fs-11"><span class="text-muted">Comment:</span> <span class="c-primary">${Utils.escHtml(e.commentAfter)}</span></div>`
          : "";
        const noContent = !statusChange && !cmtChange && !typeBadge;
        const eIdx = item.entries.indexOf(e);
        return `<div style="padding:8px 12px;border-left:2px solid ${borderColor};margin-bottom:6px;background:${bgColor};border-radius:0 6px 6px 0;position:relative">
          <div style="font-size:10px;color:var(--text-tertiary);font-family:var(--font-mono);margin-bottom:4px;display:flex;align-items:center;flex-wrap:wrap;gap:4px">
            ${dt} · ${Utils.escHtml(e.week||"")} ${e.year||""} ${typeBadge}
            <button class="wt-hist-del-entry" data-cn="${Utils.escHtml(item.caseNumber)}" data-idx="${eIdx}"
              title="Delete this entry" style="margin-left:auto;background:none;border:none;cursor:pointer;color:var(--text-disabled);font-size:12px;padding:0 2px;line-height:1;border-radius:var(--radius-xs);flex-shrink:0"
              onmouseover="this.style.color='var(--red)'" onmouseout="this.style.color='var(--text-disabled)'">✕</button>
          </div>
          ${statusChange}${cmtChange}
          ${noContent ? '<div style="font-size:11px;color:var(--text-disabled);font-style:italic">Case edited</div>' : ""}
        </div>`;
      }).join("");
      return `<div class="tile" style="margin-bottom:12px;padding:14px 16px">
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px;flex-wrap:wrap">
          <span style="font-family:var(--font-mono);font-size:13px;font-weight:700;color:var(--blue)">${Utils.escHtml(item.caseNumber)}</span>
          <span style="background:var(--bg-hover);border:1px solid var(--border-subtle);border-radius:var(--radius-md);padding:2px 8px;font-size:11px">${Utils.escHtml(item.owner||"")}</span>
          ${reopenBadge}
          <span class="text-10 text-muted">${item.entries.length} change${item.entries.length!==1?"s":""}</span>
          <button class="wt-hist-del-case" data-cn="${Utils.escHtml(item.caseNumber)}"
            title="Delete all history for this case"
            style="margin-left:auto;display:inline-flex;align-items:center;gap:4px;background:rgba(218,30,40,.07);border:1px solid rgba(218,30,40,.2);color:var(--red);border-radius:var(--radius-sm);padding:2px 9px;font-size:10px;font-weight:600;cursor:pointer;flex-shrink:0"
            onmouseover="this.style.background='rgba(218,30,40,.15)'" onmouseout="this.style.background='rgba(218,30,40,.07)'">
            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6M14 11v6"/><path d="M9 6V4h6v2"/></svg>
            Delete case history
          </button>
        </div>
        ${rows}
      </div>`;
    }).join("");
  }

  /* ── History Delete helpers ── */
  function _deleteEntireHistory() {
    _saveHistory({});
    _renderHistory();
    _toast("All history cleared");
  }

  function _deleteCaseHistory(cn) {
    const h = _loadHistory();
    delete h[cn];
    _saveHistory(h);
    _renderHistory();
    _renderTable(_buildWeeks(_year)); // refresh history badges on tracker rows
    _toast(`History for ${cn} deleted`);
  }

  function _deleteHistoryEntry(cn, idx) {
    const h = _loadHistory();
    if (!h[cn]) return;
    h[cn].entries.splice(idx, 1);
    if (!h[cn].entries.length) {
      delete h[cn];
    }
    _saveHistory(h);
    _renderHistory();
    _renderTable(_buildWeeks(_year));
    _toast(`Entry deleted`);
  }

  /* ── History Export / Import ── */
  function _exportHistory() {
    const h = _loadHistory();
    if (!Object.keys(h).length) { _toast("No history to export", true); return; }
    const blob = new Blob([JSON.stringify(h, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "wtracker_history_" + new Date().toISOString().slice(0, 10) + ".json";
    a.click();
    _toast("History exported — " + Object.keys(h).length + " cases");
  }

  function _importHistory() {
    const inp = document.createElement("input");
    inp.type = "file"; inp.accept = ".json";
    inp.onchange = e => {
      const file = e.target.files[0]; if (!file) return;
      const reader = new FileReader();
      reader.onload = ev => {
        try {
          const text = ev.target.result.replace(/```json|```/g, "").trim();
          const imported = JSON.parse(text);
          if (typeof imported !== "object" || Array.isArray(imported)) throw new Error("Invalid format");
          const existing = _loadHistory();
          // Merge: imported entries prepended to existing entries per case
          let count = 0;
          Object.entries(imported).forEach(([cn, item]) => {
            count++;
            if (!existing[cn]) {
              existing[cn] = item;
            } else {
              const merged = [...(item.entries || []), ...existing[cn].entries];
              // Deduplicate by timestamp + week
              const seen = new Set();
              existing[cn].entries = merged.filter(entry => {
                const key = (entry.ts || "") + "|" + (entry.week || "") + "|" + (entry._seedId || "");
                if (seen.has(key)) return false;
                seen.add(key);
                return true;
              }).slice(0, 50);
              existing[cn].owner = item.owner || existing[cn].owner;
            }
          });
          _saveHistory(existing);
          _renderHistory();
          _renderTable(_buildWeeks(_year)); // refresh history badges
          _toast("History imported — " + count + " cases merged");
        } catch(err) {
          _toast("Import failed: " + err.message, true);
        }
      };
      reader.readAsText(file);
    };
    inp.click();
  }

  /* ── Event binding ── */
  function _bindEvents(weeks) {
    const searchInput = document.getElementById("wt-search");
    searchInput?.addEventListener("input", () => _renderTable(weeks));
    searchInput?.addEventListener("keydown", e => {
      if (e.key === "Enter") {
        const q = (searchInput.value || "").toLowerCase().trim();
        if (!q) return;
        // Get filtered rows
        const filtered = weeks.flatMap(w => w.rows || []).filter(r => {
          if (q && ![r.owner,r.caseNumber,r.title,r.category,r.comments].some(v=>v&&String(v).toLowerCase().includes(q))) return false;
          return true;
        });
        // If exactly one result, open it
        if (filtered.length === 1 && filtered[0].caseNumber) {
          e.preventDefault();
          if (typeof App !== "undefined" && App.showCaseModal) {
            App.showCaseModal(filtered[0].caseNumber);
          }
        }
      }
    });
    document.getElementById("wt-export-year-btn")?.addEventListener("click", _exportYearCSV);
    document.getElementById("wt-mcancel")?.addEventListener("click", _closeModal);
    document.getElementById("wt-msave")?.addEventListener("click", () => _saveModal(weeks));
    document.getElementById("wt-modal")?.addEventListener("click", e => { if(e.target===document.getElementById("wt-modal")) _closeModal(); });
    // History toolbar: Export / Import / Reset

    document.getElementById("wt-hist-export-csv-btn")?.addEventListener("click", _exportHistoryCSV);
    document.getElementById("wt-hist-search")?.addEventListener("input", _renderHistoryFiltered);
    document.getElementById("wt-hist-import-btn")?.addEventListener("click", _importHistory);
    document.getElementById("wt-hist-reset-btn")?.addEventListener("click", () => {
      if (!confirm("⚠️ This will permanently delete ALL case history entries.\n\nThis action cannot be undone. Continue?")) return;
      try { localStorage.removeItem(HISTORY_KEY); } catch(e) {}
      _renderHistory();
      _renderTable(weeks);
      _toast("All history cleared");
    });

    // Admin: clear all history (danger zone button — same action)
    document.getElementById("wt-clear-history-btn")?.addEventListener("click", () => {
      if (!confirm("⚠️ This will permanently delete ALL case history entries for all users and weeks.\n\nThis action cannot be undone. Continue?")) return;
      _deleteEntireHistory();
      _renderTable(weeks);
    });

    // ── Event delegation for per-case and per-entry delete buttons ────
    // Attach to wt-history-panel (stable parent) not wt-history-content
    // (which gets its innerHTML replaced on every _renderHistory call)
    const histContent = document.getElementById("wt-history-panel");
    if (histContent && !histContent._delWired) {
      histContent._delWired = true;
      histContent.addEventListener("click", e => {
        // Delete entire case history
        const delCaseBtn = e.target.closest(".wt-hist-del-case");
        if (delCaseBtn) {
          const cn = delCaseBtn.dataset.cn;
          if (!cn) return;
          if (!confirm(`Delete ALL history entries for ${cn}?\n\nThis cannot be undone.`)) return;
          _deleteCaseHistory(cn);
          return;
        }
        // Delete single entry
        const delEntryBtn = e.target.closest(".wt-hist-del-entry");
        if (delEntryBtn) {
          const cn  = delEntryBtn.dataset.cn;
          const idx = parseInt(delEntryBtn.dataset.idx, 10);
          if (!cn || isNaN(idx)) return;
          if (!confirm(`Delete this history entry for ${cn}?`)) return;
          _deleteHistoryEntry(cn, idx);
        }
      });
    }
    // Auto-suggest category in modal when title changes — hint only, never auto-applies
    document.getElementById("wm-title")?.addEventListener("input", function() {
      const catSel = document.getElementById("wm-cat");
      // Only show suggestion if no category is already selected
      if (catSel && catSel.value) return;
      const sug = wtSuggestCategory(this.value, document.getElementById("wm-cmt")?.value||"");
      const hint = document.getElementById("wm-cat-suggest");
      if (hint) {
        if (sug) {
          hint.textContent = "💡 Click to apply: "+sug;
          hint.onclick = () => { if(catSel){ catSel.value=sug; hint.textContent=""; } };
        } else {
          hint.textContent = "";
          hint.onclick = null;
        }
      }
    });
  }

  /* ── Public handlers ── */
  function _setYear(yr) {
    _year = yr; _currentWeek = null; _editComment = null;
    render();
  }

  function _switchTab(tab) {
    // Non-admins cannot access history or reopened tabs
    if ((tab === "history" || tab === "reopened") && !Data.isAdmin()) tab = "tracker";
    _activeTab = tab;
    const trackerPanel  = document.getElementById("wt-tracker-panel");
    const historyPanel  = document.getElementById("wt-history-panel");
    const reopenedPanel = document.getElementById("wt-reopened-panel");
    const navStrip      = document.getElementById("wt-nav-strip");
    const histStrip     = document.getElementById("wt-hist-strip");
    if (trackerPanel)  trackerPanel.style.display  = tab==="tracker"?"block":"none";
    if (historyPanel)  historyPanel.style.display  = tab==="history"?"block":"none";
    if (reopenedPanel) reopenedPanel.style.display = tab==="reopened"?"block":"none";
    if (navStrip)      navStrip.style.display      = tab==="tracker"?"flex":"none";
    if (histStrip)     histStrip.style.display      = tab==="history"?"flex":"none";
    ["tracker","reopened","history"].forEach(t => {
      const btn = document.querySelector(`button[onclick="DashWeeklyTracker._switchTab('${t}')"]`);
      if (btn) {
        btn.style.fontWeight   = t===tab?"700":"500";
        btn.style.borderBottom = t===tab?"2px solid var(--blue)":"2px solid transparent";
        btn.style.color        = t===tab?"var(--blue)":"var(--text-secondary)";
      }
    });
    if (tab==="history")  _renderHistory();
    if (tab==="reopened") { _reopenedCasesCache = null; _renderReopened(); }
  }

  function _navClick(key) {
    _currentWeek=key; _editComment=null; _filterOwner=""; _filterCategory=""; _focusedCaseId=null;
    const weeks = _buildWeeks(_year);
    const allData = _ldy(_year);
    document.querySelectorAll(".wt-nb").forEach(b => {
      const a = b.dataset.wk === key;
      const cnt = (allData[b.dataset.wk]||[]).length;
      b.style.background   = a ? "var(--chart-1)" : "transparent";
      b.style.color        = a ? "var(--bg-ui)" : (cnt>0 ? "var(--text-primary)" : "var(--text-tertiary)");
      b.style.fontWeight   = a ? "700" : (cnt>0 ? "600" : "400");
      b.style.borderColor  = a ? "var(--chart-1)" : "transparent";
      b.style.boxShadow    = a ? "0 1px 4px rgba(15,98,254,.35)" : "none";
      // Re-bind hover so inactive buttons hover correctly after active changes
      b.onmouseover = a ? null : function(){ this.style.background="var(--bg-hover)"; this.style.borderColor="var(--border-subtle)"; };
      b.onmouseout  = a ? null : function(){ this.style.background="transparent"; this.style.borderColor="transparent"; };
    });
    _renderContent(weeks);
    document.querySelector(`.wt-nb[data-wk="${key}"]`)?.scrollIntoView({inline:"center",block:"nearest"});
  }

  function _jumpToToday() {
    const weeks = _buildWeeks(_year);
    const todayKey = _curCW(weeks);
    // If already on today's week, just pulse the button to confirm
    if (_currentWeek === todayKey) {
      const btn = document.getElementById('wt-today-btn');
      if (btn) { btn.textContent = '✓ Here!'; setTimeout(() => { btn.textContent = '⟲ Today'; }, 1200); }
      return;
    }
    _navClick(todayKey);
  }

  function _startEdit(id) { _editComment=id; _renderTable(_buildWeeks(_year)); }

  /* ── Comment Popover ── */
  let _activeCmtPopoverId = null;
  let _autoSaveTimer = null;
  /* _pastedLinkMap: populated on paste events from clipboard HTML.
     Maps display-text (lowercased) → { label, href } for any <a> tags
     found in rich-text pastes. Allows generic hyperlink detection
     regardless of the link format (TS, DT, URLs, etc.).
     Persisted to localStorage keyed by case number so links survive
     popover close/reopen. */
  let _pastedLinkMap = {};
  let _pastedLinkMapCaseNo = null; // case number currently loaded in _pastedLinkMap

  // _pastedLinkStore: in-memory link map (was localStorage; now session-scoped)
  const _pastedLinkStore = {};
  function _loadLinkMap(caseNo) {
    return _pastedLinkStore[caseNo] || {};
  }
  function _saveLinkMap(caseNo, map) {
    _pastedLinkStore[caseNo] = map;
  }

  function _openCmtPopover(id, triggerEl) {
    _closeCmtPopover(); // close any existing
    const rows = _wr(_year, _currentWeek);
    const row  = rows.find(r=>r.id===id); if(!row) return;
    const currentCmt = (_serverComments[row.caseNumber] !== undefined)
      ? _serverComments[row.caseNumber] : (row.comments || "");

    // Load any previously pasted links for this case from localStorage
    _pastedLinkMap = _loadLinkMap(row.caseNumber);
    _pastedLinkMapCaseNo = row.caseNumber;

    // Build severity badge inline
    const sev = String(row.severity||"").trim();
    const sevCol = sev.startsWith("1") ? "var(--chart-5)" : sev.startsWith("2") ? "var(--chart-7)" : sev.startsWith("3") ? "var(--yellow)" : "var(--text-tertiary)";
    const fmtDate = d => { if(!d) return "—"; const p=Utils.parseDate(d); return p ? p.toLocaleDateString("en-GB",{day:"2-digit",month:"short",year:"2-digit"}) : d; };

    // Overlay backdrop
    const backdrop = document.createElement("div");
    backdrop.id = "wt-cmt-backdrop";
    backdrop.style.cssText = "position:fixed;inset:0;z-index:699;background:rgba(0,0,0,.25);animation:wt-bd-in .18s ease";
    backdrop.addEventListener("mousedown", e => {
      const ta = document.getElementById("wt-pop-ta");
      if (ta) _doSaveCmt(id, ta.value, true);
      _closeCmtPopover();
      _renderTable(_buildWeeks(_year)); _renderWeekNav(_buildWeeks(_year));
    });
    document.body.appendChild(backdrop);

    // Drawer panel
    const pop = document.createElement("div");
    pop.id = "wt-cmt-popover";
    pop.style.cssText = "position:fixed;top:0;right:0;bottom:0;z-index:700;width:420px;max-width:96vw;background:var(--bg-layer,#fff);border-left:1px solid var(--border-subtle,var(--border-subtle));box-shadow:-8px 0 40px rgba(0,0,0,.14);display:flex;flex-direction:column;animation:wt-drawer-in .2s cubic-bezier(.4,0,.2,1)";
    pop.innerHTML = `
      <style>
        @keyframes wt-drawer-in{from{transform:translateX(100%)}to{transform:translateX(0)}}
        @keyframes wt-bd-in{from{opacity:0}to{opacity:1}}
        #wt-autosave-status{transition:opacity .3s}
        .wt-info-card{background:var(--surface-1,#f4f4f4);border:1px solid var(--border-subtle);border-radius:var(--radius-md);padding:12px 14px;flex:1;min-width:0}
        .wt-info-label{font-size:10px;font-weight:600;letter-spacing:var(--tracking-wide);text-transform:uppercase;color:var(--text-tertiary);margin-bottom:4px}
        .wt-info-value{font-size:13px;font-weight:600;color:var(--text-primary);word-break:break-word}
      </style>

      <!-- Header -->
      <div style="display:flex;align-items:center;justify-content:space-between;padding:16px 20px;border-bottom:1px solid var(--border-subtle,var(--border-subtle));flex-shrink:0">
        <div>
          <a href="https://www.ibm.com/mysupport/s/case/${Utils.escHtml(row.caseNumber)}" target="_blank"
             style="font-size:16px;font-weight:700;color:var(--ibm-blue-50,#0f62fe);text-decoration:none;font-family:var(--font-mono)">${Utils.escHtml(row.caseNumber)}</a>
          <div class="text-11 text-muted mt-6">Weekly Tracker · ${Utils.escHtml(_currentWeek||"")} · ${Utils.escHtml(_year)}</div>
        </div>
        <button onclick="DashWeeklyTracker._closeCmtPopover()" style="background:none;border:none;cursor:pointer;font-size:20px;color:var(--text-tertiary);padding:4px 8px;border-radius:var(--radius-sm);line-height:1;transition:background var(--t-fast)" onmouseover="this.style.background='var(--bg-hover)'" onmouseout="this.style.background='none'" title="Close (Esc)">×</button>
      </div>

      <!-- Info cards -->
      <div style="padding:16px 20px 0;flex-shrink:0">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:10px">
          <div class="wt-info-card">
            <div class="wt-info-label">Owner</div>
            <div class="wt-info-value">${Utils.escHtml(row.owner||"—")}</div>
          </div>
          <div class="wt-info-card">
            <div class="wt-info-label">Status</div>
            <div class="wt-info-value fs-12">${Utils.statusBadge ? Utils.statusBadge(row.status||"Closed") : Utils.escHtml(row.status||"Closed")}</div>
          </div>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;margin-bottom:16px">
          <div class="wt-info-card">
            <div class="wt-info-label">Severity</div>
            <div class="wt-info-value" style="color:${sevCol}">${Utils.escHtml(sev||"—")}</div>
          </div>
          <div class="wt-info-card">
            <div class="wt-info-label">Closed Date</div>
            <div class="wt-info-value" style="font-size:12px;font-family:var(--font-mono)">${fmtDate(row.closedDate)}</div>
          </div>
          <div class="wt-info-card">
            <div class="wt-info-label">Category</div>
            <div class="wt-info-value fs-12">${Utils.escHtml(row.category||"—")}</div>
          </div>
        </div>

        <!-- Title -->
        <div style="background:var(--surface-1,#f4f4f4);border:1px solid var(--border-subtle);border-radius:var(--radius-md);padding:10px 14px;margin-bottom:16px">
          <div class="wt-info-label">Title</div>
          <div style="font-size:12px;color:var(--text-primary);line-height:1.5">${Utils.escHtml(row.title||"—")}</div>
        </div>
      </div>

      <!-- Comment section -->
      <div style="padding:0 20px;flex:1;display:flex;flex-direction:column;min-height:0">
        <div style="font-size:12px;font-weight:600;color:var(--text-primary);margin-bottom:8px;display:flex;align-items:center;gap:6px">
          ✏️ Comment
          <span id="wt-autosave-status" style="font-size:10px;font-weight:400;color:var(--text-tertiary)">Ctrl+Enter to save</span>
        </div>
        <textarea id="wt-pop-ta" rows="6"
          style="flex:1;width:100%;box-sizing:border-box;resize:none;font-size:13px;line-height:1.6;
            font-family:inherit;border:1px solid var(--border-subtle);border-radius:var(--radius-md);
            padding:12px 14px;background:var(--surface-1,#f4f4f4);color:var(--text-primary);
            outline:none /* focus-visible handles focus ring */;transition:border .15s;min-height:120px"
          placeholder="Add a comment for this case…"
          onfocus="this.style.border='1px solid var(--ibm-blue-50)';this.style.background='var(--bg-layer,#fff)'"
          onblur="this.style.border='1px solid var(--border-subtle,var(--border-subtle))';this.style.background='var(--surface-1,#f4f4f4)'"
          onkeydown="DashWeeklyTracker._popKey(event,'${id}')"
          oninput="DashWeeklyTracker._onCmtInput('${id}',this)"
        >${Utils.escHtml(currentCmt)}</textarea>
        <div style="font-size:10px;color:var(--text-tertiary);font-family:var(--font-mono);margin-top:4px">
          <span id="wt-pop-count">${currentCmt.length} chars</span>
        </div>
        <!-- URL preview — shown when comment contains links -->
        <div id="wt-pop-urlpreview" style="display:${_buildUrlPreview(currentCmt)?'block':'none'};margin-top:8px;padding:8px 12px;border-radius:var(--radius-sm);background:rgba(15,98,254,.04);border:1px solid rgba(15,98,254,.15)">
          <div style="font-size:10px;font-weight:600;color:var(--ibm-blue-50);margin-bottom:5px;letter-spacing:.04em;text-transform:none">🔗 Links in comment</div>
          <div id="wt-pop-urllist" style="display:flex;flex-direction:column;gap:4px;font-size:11px">${_buildUrlPreview(currentCmt)}</div>
        </div>
      </div>

      <!-- Footer -->
      <div style="display:flex;gap:10px;justify-content:flex-end;padding:16px 20px;border-top:1px solid var(--border-subtle,var(--border-subtle));flex-shrink:0;margin-top:12px">
        <button onclick="DashWeeklyTracker._closeCmtPopover()" class="btn btn-ghost btn-sm" style="min-width:80px">Cancel</button>
        <button onclick="DashWeeklyTracker._saveCmtPopover('${id}')" class="btn btn-primary btn-sm" style="min-width:100px">💾 Save</button>
      </div>`;
    document.body.appendChild(pop);

    const ta = document.getElementById("wt-pop-ta");
    if (ta) {
      ta.focus(); ta.selectionStart = ta.value.length; ta.selectionEnd = ta.value.length;
      // Intercept paste: extract hyperlinks from clipboard rich-text (HTML) generically.
      // When a user copies text that contains hyperlinks (e.g. from a browser or email),
      // the clipboard carries both plain text and HTML. We parse the HTML to find <a> tags
      // and populate _pastedLinkMap so _buildUrlPreview can surface those links.
      ta.addEventListener("paste", function _onCmtPaste(e) {
        const html = e.clipboardData && e.clipboardData.getData("text/html");
        if (!html) return;
        // Parse the clipboard HTML in a sandboxed inert container (no scripts run)
        const tmp = document.createElement("div");
        tmp.innerHTML = html;
        tmp.querySelectorAll("a[href]").forEach(a => {
          const href = a.href; // absolute URL resolved by browser
          const label = (a.textContent || "").trim();
          if (!href || !label || !/^https?:/i.test(href)) return; // Fix D4: allow only http(s)
          // Key by lowercased label so we can match against textarea plain text
          _pastedLinkMap[label.toLowerCase()] = { label, href };
        });
        // Persist the updated map for this case so links survive popover close/reopen
        if (_pastedLinkMapCaseNo) _saveLinkMap(_pastedLinkMapCaseNo, _pastedLinkMap);
        // After paste, textarea value updates asynchronously — use setTimeout(0)
        // to trigger preview update once the pasted plain text is in ta.value
        setTimeout(() => {
          const urlPreview = document.getElementById("wt-pop-urlpreview");
          const urlList    = document.getElementById("wt-pop-urllist");
          if (urlPreview && urlList) {
            const previewHtml = _buildUrlPreview(ta.value);
            if (previewHtml) {
              urlList.innerHTML = previewHtml;
              urlPreview.style.display = "block";
            } else {
              urlPreview.style.display = "none";
            }
          }
        }, 0);
      });
    }
    _activeCmtPopoverId = id;
  }

  function _onCmtInput(id, ta) {
    // Update char count
    const countEl = document.getElementById("wt-pop-count");
    if (countEl) countEl.textContent = ta.value.length + " chars";
    // Update live URL preview panel
    const urlPreview = document.getElementById("wt-pop-urlpreview");
    const urlList    = document.getElementById("wt-pop-urllist");
    if (urlPreview && urlList) {
      const html = _buildUrlPreview(ta.value);
      if (html) {
        urlList.innerHTML = html;
        urlPreview.style.display = "block";
      } else {
        urlPreview.style.display = "none";
      }
    }
    // Show "Saving…" indicator
    const statusEl = document.getElementById("wt-autosave-status");
    if (statusEl) { statusEl.textContent = "⏳ Saving…"; statusEl.style.color = "var(--text-tertiary)"; }
    // Debounce: save 1.2s after user stops typing
    clearTimeout(_autoSaveTimer);
    _autoSaveTimer = setTimeout(() => {
      _doSaveCmt(id, ta.value, /* silent */ true);
      if (statusEl) {
        statusEl.textContent = "✅ Saved";
        statusEl.style.color = "var(--green)";
        setTimeout(() => {
          if (statusEl) { statusEl.textContent = "Ctrl+Enter to save · Esc to close"; statusEl.style.color = "var(--text-tertiary)"; }
        }, 2000);
      }
    }, 1200);
  }

  function _doSaveCmt(id, value, silent) {
    const rows = _wr(_year, _currentWeek);
    const row  = rows.find(r=>r.id===id); if(!row) return;
    const oldCmt = _serverComments[row.caseNumber] !== undefined
      ? _serverComments[row.caseNumber] : (row.comments || "");
    const newCmt = value.trim();
    if (oldCmt === newCmt) return; // nothing changed
    _serverComments[row.caseNumber] = newCmt;
    _saveServerComments();
    // Auto-set category to Duplicate if comment contains a TS case number
    const _TS_RE = /TS0\d{6,}/i;
    const _hasCaseRef = _TS_RE.test(newCmt);
    // Auto-set category to RFE if comment contains an idea reference or Aha! URL
    const _IDEA_RE = /\b[A-Z]+-I-\d+\b|https?:\/\/[^\s]*ideas\.aha\.io[^\s]*/i;
    const _hasIdeaRef = _IDEA_RE.test(newCmt);
    let _cat = (row.category || "").trim();
    if (_hasCaseRef && _cat !== "Duplicate") {
      _cat = "Duplicate";
      row.category = "Duplicate";
      const _weekData1 = _wtDbCache && _wtDbCache[String(_year)] && _wtDbCache[String(_year)][_currentWeek];
      if (_weekData1) {
        const _dbRow1 = _weekData1.find(r => (r.caseNumber || r.case_number || "") === row.caseNumber);
        if (_dbRow1) { _dbRow1.category = "Duplicate"; _dbRow1.isDuplicate = true; }
      }
      _renderTable(_buildWeeks(_year));
    } else if (!_hasCaseRef && _cat === "Duplicate") {
      _cat = "";
      row.category = "";
      const _weekData2 = _wtDbCache && _wtDbCache[String(_year)] && _wtDbCache[String(_year)][_currentWeek];
      if (_weekData2) {
        const _dbRow2 = _weekData2.find(r => (r.caseNumber || r.case_name || "") === row.caseNumber);
        if (_dbRow2) { _dbRow2.category = ""; _dbRow2.isDuplicate = false; _dbRow2.originalCaseNumber = null; }
      }
      _renderTable(_buildWeeks(_year));
    } else if (_hasIdeaRef && _cat !== "RFE") {
      _cat = "RFE";
      row.category = "RFE";
      const _weekData3 = _wtDbCache && _wtDbCache[String(_year)] && _wtDbCache[String(_year)][_currentWeek];
      if (_weekData3) {
        const _dbRow3 = _weekData3.find(r => (r.caseNumber || r.case_number || "") === row.caseNumber);
        if (_dbRow3) { _dbRow3.category = "RFE"; }
      }
      _renderTable(_buildWeeks(_year));
    } else if (!_hasIdeaRef && _cat === "RFE") {
      _cat = "";
      row.category = "";
      const _weekData4 = _wtDbCache && _wtDbCache[String(_year)] && _wtDbCache[String(_year)][_currentWeek];
      if (_weekData4) {
        const _dbRow4 = _weekData4.find(r => (r.caseNumber || r.case_number || "") === row.caseNumber);
        if (_dbRow4) { _dbRow4.category = ""; }
      }
      _renderTable(_buildWeeks(_year));
    }
    // Sync comment+category to weekly_closed_cases for live duplicate detection
    (function() {
      try {
        const _base = window.API_BASE_V2 || '/iip/api/v2';
        const _wlbl = _currentWeek;
        const _av   = (row.availability || "").trim();
        fetch(_base + "/weekly/" + _year + "/" + _wlbl + "/" + row.caseNumber, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ comments: newCmt, category: _cat, availability: _av })
        }).then(function(r) { return r.ok ? r.json() : Promise.reject(r.status); })
          .then(function(data) {
            if (data.is_duplicate && _wtDbCache && _wtDbCache[String(_year)] && _wtDbCache[String(_year)][_wlbl]) {
              const dr = _wtDbCache[String(_year)][_wlbl].find(function(r) {
                return (r.caseNumber || r.case_number || "") === row.caseNumber;
              });
              if (dr) { dr.is_duplicate = true; dr.original_case_number = data.original_case_number; }
              _renderTable(_buildWeeks(_year));
            }
          })
          .catch(function(e) { console.warn("[IIP] weekly sync failed:", e.message); });
      } catch(e) {}
    })();
    const lsRows = _ldy(_year)[_currentWeek] || [];
    const lsRow  = lsRows.find(r => r.id === id);
    if (lsRow) { lsRow.comments = ""; _swk(_year, _currentWeek, lsRows); }
    _recordHistory(row.caseNumber, row.owner, row.status, row.status, oldCmt, newCmt, _currentWeek, _year);
    // Silently refresh the background cells without closing popover
    _renderKPI(); _renderFollowUp(); _renderWeekNav(_buildWeeks(_year));
    const tbl = document.getElementById("wt-table-wrap");
    if (tbl) {
      // Update just the trigger cell text to reflect new comment without full re-render
      const trig = document.getElementById("wt-cmttrig-" + id);
      if (trig) {
        const td = trig.parentElement;
        if (newCmt) {
          // Has comment — blue accent
          trig.style.background = "rgba(15,98,254,.04)";
          trig.style.borderColor = "rgba(15,98,254,.15)";
          if (td) { td.style.background="rgba(15,98,254,.03)"; td.style.borderLeftColor="rgba(15,98,254,.2)"; td.style.borderRightColor="rgba(15,98,254,.2)"; }
          const preview = newCmt.length > 80 ? newCmt.slice(0,80) : newCmt;
          const more = newCmt.length > 80 ? `<span style="color:var(--ibm-blue-50);font-size:10px;font-weight:600;margin-left:3px">…more</span>` : "";
          trig.innerHTML = `<div style="display:flex;flex-direction:column;gap:4px">
            <span style="font-size:11px;line-height:1.5;color:var(--text-primary);font-weight:500">${_linkify(preview)}${more}</span>
            <span style="font-size:9px;color:var(--text-tertiary);font-family:var(--font-mono)">${newCmt.length} chars</span>
          </div>`;
        } else {
          // Empty — amber accent + pulse
          trig.style.background = "rgba(245,158,11,.04)";
          trig.style.borderColor = "rgba(245,158,11,.25)";
          if (td) { td.style.background="rgba(245,158,11,.05)"; td.style.borderLeftColor="rgba(245,158,11,.4)"; td.style.borderRightColor="rgba(245,158,11,.4)"; }
          trig.innerHTML = `<span class="wt-cmt-empty" style="display:inline-flex;align-items:center;gap:6px;padding:4px 8px;border-radius:var(--radius-sm);background:rgba(245,158,11,.1);border:1.5px dashed rgba(245,158,11,.5);color:var(--yellow-text);font-size:10px;font-weight:600;white-space:nowrap"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>Add note</span>`;
        }
      }
    }
    if (!silent) _toast("Comment saved");
  }

  function _popoverOutsideClick(e) {
    const pop = document.getElementById("wt-cmt-popover");
    if (pop && !pop.contains(e.target)) {
      const trig = document.getElementById("wt-cmttrig-" + _activeCmtPopoverId);
      if (trig && trig.contains(e.target)) return;
      // Auto-save current value before closing
      const ta = document.getElementById("wt-pop-ta");
      if (ta) _doSaveCmt(_activeCmtPopoverId, ta.value, true);
      _closeCmtPopover();
      _renderTable(_buildWeeks(_year)); _renderWeekNav(_buildWeeks(_year));
    }
  }
  function _closeCmtPopover() {
    clearTimeout(_autoSaveTimer);
    document.removeEventListener("mousedown", _popoverOutsideClick);
    const pop = document.getElementById("wt-cmt-popover");
    if (pop) pop.remove();
    const bd = document.getElementById("wt-cmt-backdrop");
    if (bd) bd.remove();
    _activeCmtPopoverId = null;
    _pastedLinkMap = {}; // reset paste-captured links for next session
  }
  function _popKey(e, id) {
    if (e.key === "Escape") { e.preventDefault();
      const ta = document.getElementById("wt-pop-ta");
      if (ta) _doSaveCmt(id, ta.value, true);
      _closeCmtPopover();
      _renderTable(_buildWeeks(_year)); _renderWeekNav(_buildWeeks(_year));
    }
    if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) { e.preventDefault(); _saveCmtPopover(id); }
    // Arrow key navigation between rows in drawer (#12)
    if ((e.key === "ArrowDown" || e.key === "ArrowUp") && e.altKey) {
      e.preventDefault();
      const ta = document.getElementById("wt-pop-ta");
      if (ta) _doSaveCmt(id, ta.value, true);
      const rows = _wr(_year, _currentWeek);
      const idx  = rows.findIndex(r => r.id === id);
      const next = e.key === "ArrowDown" ? rows[idx+1] : rows[idx-1];
      if (!next) return;
      _closeCmtPopover();
      setTimeout(() => {
        const trig = document.getElementById("wt-cmttrig-" + next.id);
        if (trig) _openCmtPopover(next.id, trig);
      }, 50);
    }
  }
  function _saveCmtPopover(id) {
    clearTimeout(_autoSaveTimer);
    const ta = document.getElementById("wt-pop-ta"); if(!ta) return;
    _doSaveCmt(id, ta.value, false);
    _closeCmtPopover();
    _editComment=null; _renderKPI(); _renderFollowUp(); _renderTable(_buildWeeks(_year)); _renderWeekNav(_buildWeeks(_year)); // Fix C4: single nav render
  }

  function _saveCmt(id) { _saveCmtPopover(id); }
  function _cmtKey(e,id) {
    if (e.key==="Escape") { _editComment=null; _renderTable(_buildWeeks(_year)); }
    if (e.key==="Enter"&&(e.ctrlKey||e.metaKey)) _saveCmt(id);
  }

  function _setCat(id, val) {
    const norm = _normCat(val);
    const weekData = _wtDbCache && _wtDbCache[String(_year)] && _wtDbCache[String(_year)][_currentWeek];
    if (weekData) {
      const dbRow = weekData.find(r => {
        const cn = (r.caseNumber || r.case_number || "");
        return (cn + "_" + _currentWeek) === id || cn === id.replace("_" + _currentWeek, "");
      });
      if (dbRow) dbRow.category = norm;
    }
    const rows = _wr(_year, _currentWeek);
    const row = rows.find(r=>r.id===id);
    if (row) {
      row.category = norm;
      _renderWeekNav(_buildWeeks(_year));
      _renderTable(_buildWeeks(_year));
      try {
        const _base = window.API_BASE_V2 || '/iip/api/v2';
        const _cmt  = (_serverComments[row.caseNumber] || row.comments || "").trim();
        const _av   = (row.availability || "").trim();
        fetch(_base + "/weekly/" + _year + "/" + _currentWeek + "/" + row.caseNumber, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ comments: _cmt, category: norm, availability: _av })
        }).then(r => r.ok ? r.json() : Promise.reject(r.status))
          .then(data => {
            if (data.is_duplicate && _wtDbCache && _wtDbCache[String(_year)] && _wtDbCache[String(_year)][_currentWeek]) {
              const dr = _wtDbCache[String(_year)][_currentWeek].find(r => {
                const cn = (r.caseNumber || r.case_number || "");
                return cn === row.caseNumber;
              });
              if (dr) { dr.is_duplicate = true; dr.original_case_number = data.original_case_number; }
            }
          })
          .catch(function(e) { console.warn("[IIP] weekly cat sync failed:", e); });
      } catch(e) {}
    }
  }

  function _editRow(id) { const r=_wr(_year,_currentWeek).find(r=>r.id===id); if(r) _openModal(r,_buildWeeks(_year)); }

  // Categories that trigger the follow-up alert and require a history entry
  const _ALERT_AVAILABILITIES = new Set(["Not Joined", "On Leave", "Follow Up", "Reopened"]);

  function _setAvailability(id, val) {
    const weekData = _wtDbCache && _wtDbCache[String(_year)] && _wtDbCache[String(_year)][_currentWeek];
    if (weekData) {
      const dbRow = weekData.find(r => {
        const cn = (r.caseNumber || r.case_number || "");
        return (cn + "_" + _currentWeek) === id || cn === id.replace("_" + _currentWeek, "");
      });
      if (dbRow) dbRow.availability = val;
    }
    const rows = _wr(_year, _currentWeek);
    const row = rows.find(r=>r.id===id);
    if (row) {
      const prevAvail = row.availability || "";
      row.availability = val;
      // Auto-record a history entry whenever an alert-category availability is set
      // and it differs from the previous value — history stays even when alert is cleared
      if (_ALERT_AVAILABILITIES.has(val) && val !== prevAvail) {
        const cmt = (_serverComments[row.caseNumber] !== undefined)
          ? _serverComments[row.caseNumber] : (row.comments || "");
        _recordHistory(row.caseNumber, row.owner, row.status, row.status,
          cmt, cmt, _currentWeek, _year, val);
      }
      _renderFollowUp();
      _renderWeekNav(_buildWeeks(_year));
      _renderTable(_buildWeeks(_year)); // refresh history badge counts
      // Persist availability to DB
      try {
        const _base = window.API_BASE_V2 || '/iip/api/v2';
        const _cmt = (_serverComments[row.caseNumber] !== undefined ? _serverComments[row.caseNumber] : (row.comments || "")).trim();
        const _cat = (row.category || "").trim();
        fetch(_base + "/weekly/" + _year + "/" + _currentWeek + "/" + row.caseNumber, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ comments: _cmt, category: _cat, availability: val })
        }).catch(function(e) { console.warn("[IIP] availability sync failed:", e.message); });
      } catch(e) {}
    }
  }

  function _delRow(id) {
    if(!confirm("Remove this case?")) return;
    const row = _wr(_year, _currentWeek).find(r => r.id === id);
    if(!row) return;
    const weekData = _wtDbCache && _wtDbCache[String(_year)] && _wtDbCache[String(_year)][_currentWeek];
    if(weekData) {
      const idx = weekData.findIndex(r => (r.caseNumber || r.case_number || "") === row.caseNumber);
      if(idx !== -1) weekData.splice(idx, 1);
    }
    _swk(_year, _currentWeek, _wr(_year, _currentWeek).filter(r => r.id !== id));
    _renderKPI(); _renderFollowUp(); _renderWeekNav(_buildWeeks(_year)); _renderTable(_buildWeeks(_year)); _renderWeekNav(_buildWeeks(_year)); _toast("Removed");
    const _base = window.API_BASE_V2 || '/iip/api/v2';
    fetch(_base + "/weekly/" + _year + "/" + _currentWeek + "/" + row.caseNumber, {
      method: "DELETE"
    }).catch(function(e) { console.warn("[IIP] weekly delete failed:", e.message); });
  }

  function _exportCSV() { _exportYearCSV(); } // legacy alias
  function _exportYearCSV() {
    if (typeof XLSX === "undefined") {
      _toast("Excel library not loaded yet — please wait a moment and try again", true);
      return;
    }
    const allData  = _ldy(_year);
    const headers  = ["Sl.No","Case Owner","Case Number","Title","Product","Severity","Status","Age","Closed Date","Comments","Category","Availability"];
    const weeks    = _buildWeeks(_year);

    const wb = XLSX.utils.book_new();

    // ── Sheet per week ──────────────────────────────────────────────
    let totalCases = 0;
    const summaryRows = [["Week","Week Range","Total Cases","With Comments","Without Comments","Attended","Not Joined","On Leave","Follow Up","Reopened"]];

    weeks.forEach(w => {
      const rows = _wr(_year, w.key);
      if (!rows.length) return; // skip empty weeks

      const sheetData = [headers];
      rows.forEach((r, i) => {
        const cmt = (_serverComments[r.caseNumber] !== undefined && _serverComments[r.caseNumber] !== "")
          ? _serverComments[r.caseNumber] : (r.comments || "");
        sheetData.push([
          i+1, r.owner||"", r.caseNumber||"", r.title||"", r.product||"",
          r.severity ? Number(r.severity) : "", r.status||"", r.age||"",
          r.closedDate||"", cmt, r.category||"", r.availability||""
        ]);
      });

      const ws = XLSX.utils.aoa_to_sheet(sheetData);

      // Column widths
      ws["!cols"] = [
        {wch:6},{wch:18},{wch:14},{wch:42},{wch:14},
        {wch:6},{wch:12},{wch:10},{wch:14},{wch:50},{wch:24},{wch:14}
      ];

      // Style header row bold + background (using SheetJS cell styles where supported)
      const headerRange = XLSX.utils.decode_range(ws["!ref"]);
      for (let C = headerRange.s.c; C <= headerRange.e.c; C++) {
        const addr = XLSX.utils.encode_cell({r:0, c:C});
        if (!ws[addr]) continue;
        ws[addr].s = {
          font: { bold: true, sz: 10 },
          fill: { fgColor: { rgb: "1A56DB" } },
          font: { bold: true, color: { rgb: "FFFFFF" }, sz: 10 },
          alignment: { horizontal: "center" }
        };
      }
      // Highlight comment column header (index 9) in amber
      const cmtHdrAddr = XLSX.utils.encode_cell({r:0, c:9});
      if (ws[cmtHdrAddr]) ws[cmtHdrAddr].s = {
        font: { bold: true, color: { rgb: "FFFFFF" }, sz: 10 },
        fill: { fgColor: { rgb: "D97706" } },
        alignment: { horizontal: "center" }
      };
      // Highlight comment cells that are empty
      for (let R = 1; R <= rows.length; R++) {
        const addr = XLSX.utils.encode_cell({r:R, c:9});
        if (ws[addr] && (!ws[addr].v || ws[addr].v === "")) {
          ws[addr].s = { fill: { fgColor: { rgb: "FEF3C7" } }, font: { italic: true, color: { rgb: "92400E" } } };
          ws[addr].v = "⚠ No comment";
        }
      }

      // Sheet name: "W03", "W04" etc (max 31 chars)
      const sheetName = w.key.replace("CW","W") + " " + w.range.slice(0,16);
      XLSX.utils.book_append_sheet(wb, ws, sheetName.slice(0,31));

      // Summary stats for this week
      const withCmt  = rows.filter(r => { const c = (_serverComments[r.caseNumber]||r.comments||"").trim(); return c !== ""; }).length;
      const avCount  = v => rows.filter(r => r.availability === v).length;
      summaryRows.push([
        w.key.replace("CW","W"), w.range,
        rows.length, withCmt, rows.length - withCmt,
        avCount("Attended"), avCount("Not Joined"), avCount("On Leave"),
        avCount("Follow Up"), avCount("Reopened")
      ]);
      totalCases += rows.length;
    });

    if (totalCases === 0) { _toast("No data for " + _year, true); return; }

    // ── Summary sheet (first sheet) ──────────────────────────────────
    const summaryWs = XLSX.utils.aoa_to_sheet(summaryRows);
    summaryWs["!cols"] = [{wch:8},{wch:28},{wch:13},{wch:15},{wch:18},{wch:11},{wch:12},{wch:11},{wch:12},{wch:10}];
    // Bold + blue header
    const sr = XLSX.utils.decode_range(summaryWs["!ref"]);
    for (let C = sr.s.c; C <= sr.e.c; C++) {
      const addr = XLSX.utils.encode_cell({r:0, c:C});
      if (!summaryWs[addr]) continue;
      summaryWs[addr].s = {
        font: { bold: true, color: { rgb: "FFFFFF" }, sz: 10 },
        fill: { fgColor: { rgb: "1A56DB" } },
        alignment: { horizontal: "center" }
      };
    }
    // Highlight "Without Comments" column (index 4) in amber for rows with missing comments
    for (let R = 1; R < summaryRows.length; R++) {
      const addr = XLSX.utils.encode_cell({r:R, c:4});
      if (summaryWs[addr] && summaryWs[addr].v > 0) {
        summaryWs[addr].s = { fill: { fgColor: { rgb: "FEF3C7" } }, font: { bold: true, color: { rgb: "92400E" } } };
      }
    }
    // Insert summary as first sheet
    XLSX.utils.book_append_sheet(wb, summaryWs, "📊 Summary");
    // Move summary to front
    wb.SheetNames.unshift(wb.SheetNames.pop());

    // ── Write file ───────────────────────────────────────────────────
    XLSX.writeFile(wb, "Closed_Cases_" + _year + "_FullYear.xlsx");
    _toast("✅ Exported " + totalCases + " cases across " + (summaryRows.length-1) + " weeks for " + _year);
  }

  /* ── Modal ── */
  let _editId = null;
  function _openModal(rowData, weeks) {
    _editId=rowData?.id||null;
    const modal=document.getElementById("wt-modal"); if(!modal) return;
    const members=(() => { try { return Contacts.teamMembers(); } catch(e) { return []; } })();
    // Build owner list — include the existing row owner even if not in members list
    const ownerSet = new Set(members);
    if (rowData && rowData.owner) ownerSet.add(rowData.owner);
    const ownerList = [...ownerSet].sort();
    document.getElementById("wm-owner").innerHTML='<option value="">Select owner\u2026</option>'+
      ownerList.map(m=>`<option value="${Utils.escHtml(m)}">${Utils.escHtml(m)}</option>`).join("");
    document.getElementById("wt-mtitle").textContent=rowData?"Edit Case":"Add Closed Case";
    document.getElementById("wt-msave").textContent=rowData?"Save Changes":"Add Case";
    if (rowData) {
      // Fetch live status from IBM Cases for real-time sync
      let liveStatus = rowData.status;
      const liveData = (typeof Data !== 'undefined' && Data.allCases) ? Data.allCases() : [];
      const liveCase = liveData.find(c => (c["Case Number"] || c["Case#"] || "").toUpperCase() === String(rowData.caseNumber||"").toUpperCase());
      if (liveCase && liveCase["Status"]) {
        liveStatus = liveCase["Status"];
      }

      // Normalize closedDate to YYYY-MM-DD for date input
      let isoDate = "";
      if (rowData.closedDate) {
        // Handle various date formats
        const raw = rowData.closedDate.trim();
        const d = new Date(raw);
        if (!isNaN(d)) {
          isoDate = d.toISOString().split("T")[0];
        } else {
          // Try DD Mon YYYY format
          isoDate = raw.slice(0,10);
        }
      }
      // Set owner — must be done AFTER innerHTML is set
      const ownerSel = document.getElementById("wm-owner");
      if (ownerSel) {
        ownerSel.value = rowData.owner || "";
        // If not found in list, add it and select it
        if (ownerSel.value !== (rowData.owner||"") && rowData.owner) {
          const opt = document.createElement("option");
          opt.value = rowData.owner;
          opt.textContent = rowData.owner;
          ownerSel.appendChild(opt);
          ownerSel.value = rowData.owner;
        }
      }
      [["wm-cn","caseNumber"],["wm-title","title"],["wm-prod","product"],["wm-sev","severity"],
       ["wm-age","age"],["wm-cmt","comments"]
      ].forEach(([id,k]) => { const e=document.getElementById(id); if(e) e.value=rowData[k]||""; });
      // Set status from live data
      const statusEl = document.getElementById("wm-status");
      if (statusEl) statusEl.value = liveStatus || "";
      const clEl=document.getElementById("wm-closed"); if(clEl) clEl.value=isoDate;
      // Set category separately to ensure correct option is selected
      const catSel=document.getElementById("wm-cat");
      if(catSel) { catSel.value=_normCat(rowData.category||""); }
      // Make case number readonly when editing (it's the identifier)
      const cnEl=document.getElementById("wm-cn");
      if(cnEl){ cnEl.readOnly=true; cnEl.style.background="var(--bg-hover)"; cnEl.style.color="var(--text-tertiary)"; cnEl.style.cursor="default"; }
      // Clear any leftover category suggestion hint
      const hint=document.getElementById("wm-cat-suggest"); if(hint) hint.textContent="";
    } else {
      ["wm-cn","wm-title","wm-prod","wm-age","wm-cmt"].forEach(id => { const e=document.getElementById(id); if(e) e.value=""; });
      const sevEl=document.getElementById("wm-sev"); if(sevEl) sevEl.value="";
      const catEl=document.getElementById("wm-cat"); if(catEl) catEl.value="";
      const st=document.getElementById("wm-status"); if(st) st.value="Closed by IBM";
      const cl=document.getElementById("wm-closed"); if(cl) cl.value=new Date().toISOString().split("T")[0];
      // Make case number editable for new case
      const cnEl=document.getElementById("wm-cn");
      if(cnEl){ cnEl.readOnly=false; cnEl.style.background=""; cnEl.style.color=""; cnEl.style.cursor=""; }
      // Clear suggestion hint
      const hint=document.getElementById("wm-cat-suggest"); if(hint) hint.textContent="";
    }
    modal.style.display="flex";
    setTimeout(()=>{ if(!rowData) document.getElementById("wm-cn")?.focus(); else document.getElementById("wm-title")?.focus(); },80);
  }
  function _closeModal() { const m=document.getElementById("wt-modal"); if(m) m.style.display="none"; _editId=null; }
  function _saveModal(weeks) {
    const owner=document.getElementById("wm-owner")?.value.trim();
    const cn=document.getElementById("wm-cn")?.value.trim();
    const title=document.getElementById("wm-title")?.value.trim();
    if(!owner||!cn||!title){_toast("Owner, Case Number and Title required",true);return;}
    const rows=_wr(_year,_currentWeek);
    const oldRow=_editId?rows.find(r=>r.id===_editId):null;
    // Dedup guard: block adding a case that already exists in this week (new case only)
    if (!_editId && rows.some(r => r.caseNumber === cn)) {
      _toast("Case " + cn + " already exists in " + _currentWeek, true);
      return;
    }

    // CRITICAL: Validate that only CLOSED cases can be added to this tracker
    const status = document.getElementById("wm-status")?.value.trim() || "Closed by IBM";
    const isClosed = status.toLowerCase().includes('closed') || status.toLowerCase().includes('cancel');
    if (!isClosed) {
      _toast("Only CLOSED cases can be added to this tracker. Current status: " + status, true);
      return;
    }

    const row={
      id:_editId||(cn+"_"+_currentWeek+"_"+Date.now().toString(36)),
      owner, caseNumber:cn, title,
      product:document.getElementById("wm-prod")?.value.trim()||"",
      severity:document.getElementById("wm-sev")?.value||"",
      status:status,
      age:document.getElementById("wm-age")?.value.trim()||"",
      closedDate:document.getElementById("wm-closed")?.value||"",
      category:_normCat(document.getElementById("wm-cat")?.value||""),
      comments:document.getElementById("wm-cmt")?.value.trim()||"",
      availability: oldRow ? (oldRow.availability||"") : "",
      customerNumber:"", created:"", solutionDate:"", addedAt:new Date().toISOString()
    };
    // Record history if status or comment changed
    if (oldRow && (oldRow.status!==row.status || oldRow.comments!==row.comments))
      _recordHistory(cn, owner, oldRow.status, row.status, oldRow.comments, row.comments, _currentWeek, _year);

    // Persist comment to server-side store; strip it from the localStorage row
    if (row.comments !== undefined) {
      _serverComments[cn] = row.comments;
      _saveServerComments();
    }
    row.comments = ""; // do not persist in localStorage

    if (_editId) {
      const i = rows.findIndex(r => r.id === _editId);
      if (i >= 0) rows[i] = row; else rows.push(row);
      _swk(_year, _currentWeek, rows); _closeModal();
      _renderKPI(); _renderFollowUp(); _renderWeekNav(_buildWeeks(_year)); _renderTable(weeks); _renderWeekNav(weeks);
      _toast("Updated");
    } else {
      const _base = window.API_BASE_V2 || '/iip/api/v2';
      fetch(_base + '/weekly/' + _year + '/' + _currentWeek, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          owner: row.owner, case_number: row.caseNumber, title: row.title,
          product: row.product||'', severity: String(row.severity||''),
          status: row.status||'Closed by IBM', age: String(row.age||''),
          closed_date: row.closedDate||'', category: row.category||'',
          comments: (_serverComments[row.caseNumber]||'').trim(),
          customer_number: row.customerNumber||''
        })
      }).then(r => r.ok ? r.json() : r.json().then(e => { throw new Error(e.detail||r.status); }))
        .then(() => {
          _wtDbLoaded = false;
          return _loadWTFromDB(true);
        })
        .then(() => {
          _renderKPI(); _renderFollowUp(); _renderWeekNav(_buildWeeks(_year)); _renderTable(weeks); _renderWeekNav(weeks);
          _toast("Added to " + _currentWeek);
        })
        .catch(e => _toast("Save failed: " + e.message, true));
      _closeModal();
    }
  }

  /* ── Bulk action handlers (#7) ── */
  function _selRow(id, checked) {
    if (checked) _selectedRows.add(id); else _selectedRows.delete(id);
    _updateBulkBar();
    // Update row highlight without full re-render
    const tr = document.querySelector(`input[onchange*="_selRow('${id}"]`)?.closest("tr");
    if (tr) tr.style.outline = checked ? "2px solid rgba(15,98,254,.35)" : "";
  }
  function _selAll(checked) {
    const rows = _wr(_year, _currentWeek);
    rows.forEach(r => { if (checked) _selectedRows.add(r.id); else _selectedRows.delete(r.id); });
    _renderTable(_buildWeeks(_year));
  }
  function _updateBulkBar() {
    const bar = document.getElementById("wt-bulk-bar");
    const cnt = document.getElementById("wt-bulk-count");
    if (!bar || !cnt) return;
    if (_selectedRows.size > 0) {
      bar.style.display = "flex";
      cnt.textContent = `${_selectedRows.size} selected`;
    } else {
      bar.style.display = "none";
    }
  }
  function _bulkSetCat(val) {
    if (!val || !_selectedRows.size) return;
    const rows = _wr(_year, _currentWeek);
    const norm = _normCat(val);
    const base = window.API_BASE_V2 || '/iip/api/v2';
    rows.forEach(r => {
      if (!_selectedRows.has(r.id)) return;
      r.category = norm;
      fetch(base + '/weekly/' + _year + '/' + _currentWeek + '/' + r.caseNumber, {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ comments: (_serverComments[r.caseNumber]||'').trim(), category: norm, availability: r.availability||'' })
      }).catch(e => console.warn('[WT] bulk cat:', e.message));
    });
    _swk(_year, _currentWeek, rows);
    _renderTable(_buildWeeks(_year));
    _toast(`Category set for ${_selectedRows.size} cases`);
  }
  function _bulkSetAv(val) {
    if (!_selectedRows.size) return;
    const rows = _wr(_year, _currentWeek);
    const base = window.API_BASE_V2 || '/iip/api/v2';
    rows.forEach(r => {
      if (!_selectedRows.has(r.id)) return;
      r.availability = val;
      fetch(base + '/weekly/' + _year + '/' + _currentWeek + '/' + r.caseNumber, {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ comments: (_serverComments[r.caseNumber]||'').trim(), category: r.category||'', availability: val })
      }).catch(e => console.warn('[WT] bulk av:', e.message));
    });
    _swk(_year, _currentWeek, rows);
    _renderFollowUp(); _renderTable(_buildWeeks(_year));
    _toast(`Availability set for ${_selectedRows.size} cases`);
  }
  function _clearBulk() {
    _selectedRows.clear();
    _renderTable(_buildWeeks(_year));
  }

  /* ── History CSV export (#11) ── */
  function _exportHistoryCSV() {
    const h = _loadHistory();
    if (!Object.keys(h).length) { _toast("No history to export", true); return; }
    const rows = [["Case Number","Owner","Date","Week","Year","Status Before","Status After","Comment After","Type"]];
    Object.values(h).forEach(item => {
      item.entries.forEach(e => {
        rows.push([
          item.caseNumber, item.owner||"",
          e.ts ? new Date(e.ts).toLocaleString("en-GB") : "",
          e.week||"", e.year||"",
          e.statusBefore||"", e.statusAfter||"",
          e.commentAfter||"",
          e.isReopen ? "Reopen" : e.availability || "Comment/Edit"
        ]);
      });
    });
    const csv = rows.map(r => r.map(v => '"'+String(v||"").replace(/"/g,'""')+'"').join(",")).join("\n");
    const a = document.createElement("a");
    a.href = "data:text/csv;charset=utf-8," + encodeURIComponent(csv);
    a.download = "case_history_" + new Date().toISOString().slice(0,10) + ".csv";
    a.click();
    _toast("History exported as CSV — " + (rows.length-1) + " entries");
  }

  function _toast(msg, isErr) {
    let t = document.getElementById("wt-toast");
    if (!t) {
      t = document.createElement("div");
      t.id = "wt-toast";
      t.style.cssText = [
        "position:fixed",
        "bottom:28px",
        "left:50%",
        "transform:translateX(-50%) translateY(12px)",
        "z-index:var(--z-modal)9",
        "padding:10px 22px",
        "border-radius:var(--radius-sm)",
        "font-size:13px",
        "font-weight:500",
        "letter-spacing:0.01em",
        "box-shadow:0 4px 18px rgba(0,0,0,0.18)",
        "display:flex",
        "align-items:center",
        "gap:8px",
        "pointer-events:none",
        "opacity:0",
        "transition:opacity var(--transition-base), transform var(--transition-base)",
        "font-family:var(--font-sans,'IBM Plex Sans',sans-serif)",
        "white-space:nowrap"
      ].join(";");
      document.body.appendChild(t);
    }
    // Atlassian blue for success, red for error
    const bg  = isErr ? "var(--red)" : "var(--ibm-blue-50)";
    const ico = isErr
      ? `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><circle cx="12" cy="16.5" r="1.2" fill="currentColor"/></svg>`
      : `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>`;
    t.style.background = bg;
    t.style.color = "#fff";
    t.innerHTML = `${ico}<span>${Utils.escHtml(msg)}</span>`;
    // Animate in
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        t.style.opacity = "1";
        t.style.transform = "translateX(-50%) translateY(0)";
      });
    });
    clearTimeout(t._t);
    t._t = setTimeout(() => {
      t.style.opacity = "0";
      t.style.transform = "translateX(-50%) translateY(12px)";
    }, 2400);
  }

  /* ── Category picker popover (#3) ── */
  let _activeCatPicker = null;
  function _openCatPicker(id, trigEl) {
    _closeCatPicker();
    const rect = trigEl.getBoundingClientRect();
    const CAT_COLORS_PICKER = Object.keys(WT_CATEGORY_COLORS).length ? WT_CATEGORY_COLORS : {
      "Issue Fixed in iFix":           "var(--green)",
      "LQE Validation / Reindexing":   "var(--ibm-blue-60)",
      "Export / Import Issues":        "var(--yellow-text)",
      "Known Defect":                  "var(--red)",
      "Out of Memory / Heap Issues":   "#c00",
      "TRS Feed Validation":           "var(--ibm-blue-50)",
      "Insufficient Information in Logs": "#555",
      "Single Occurrence Issue":       "var(--purple)",
      "DCM Connectivity Issues":       "var(--orange)",
      "Database Connectivity Issues":  "var(--orange)",
      "Backup & Restore":             "var(--red)",
    };
    const picker = document.createElement("div");
    picker.id = "wt-cat-picker";
    picker.style.cssText = `position:fixed;z-index:900;background:var(--bg-layer);border:1px solid var(--border-subtle);
      border-radius:var(--radius-md);box-shadow:0 8px 32px rgba(0,0,0,.18);padding:8px;width:210px;
      top:${Math.min(rect.bottom+4, window.innerHeight-280)}px;left:${Math.min(rect.left, window.innerWidth-220)}px;
      animation:wt-picker-in .14s ease`;
    picker.innerHTML = `<style>@keyframes wt-picker-in{from{opacity:0;transform:translateY(-6px)}to{opacity:1;transform:translateY(0)}}</style>
      <div style="font-size:10px;font-weight:600;text-transform:none;letter-spacing:var(--tracking-wide);color:var(--text-tertiary);padding:2px 6px 6px;border-bottom:1px solid var(--border-subtle);margin-bottom:6px">Set Category</div>
      ${WT_CATEGORIES.map(cat => {
        const color = CAT_COLORS_PICKER[cat] || "#555";
        return `<div onclick="DashWeeklyTracker._pickCat('${id}','${cat.replace(/'/g,"\'")}',this)" 
          style="display:flex;align-items:center;gap:8px;padding:6px 8px;border-radius:var(--radius-sm);cursor:pointer;transition:background var(--t-fast)"
          onmouseover="this.style.background='var(--bg-hover)'" onmouseout="this.style.background=''">
          <span style="width:8px;height:8px;border-radius:50%;background:${color};flex-shrink:0"></span>
          <span style="font-size:11px;color:var(--text-primary)">${Utils.escHtml(cat)}</span>
        </div>`;
      }).join("")}
      <div onclick="DashWeeklyTracker._pickCat('${id}','',this)"
        style="display:flex;align-items:center;gap:8px;padding:6px 8px;border-radius:var(--radius-sm);cursor:pointer;border-top:1px solid var(--border-subtle);margin-top:4px;transition:background var(--t-fast)"
        onmouseover="this.style.background='var(--bg-hover)'" onmouseout="this.style.background=''">
        <span style="width:8px;height:8px;border-radius:50%;background:var(--text-disabled);flex-shrink:0"></span>
        <span style="font-size:11px;color:var(--text-tertiary);font-style:italic">Clear category</span>
      </div>`;
    document.body.appendChild(picker);
    _activeCatPicker = id;
    setTimeout(() => document.addEventListener("mousedown", _catPickerOutside), 0);
  }
  function _catPickerOutside(e) {
    const p = document.getElementById("wt-cat-picker");
    if (p && !p.contains(e.target)) _closeCatPicker();
  }
  function _closeCatPicker() {
    document.removeEventListener("mousedown", _catPickerOutside);
    const p = document.getElementById("wt-cat-picker"); if (p) p.remove();
    _activeCatPicker = null;
  }
  function _pickCat(id, val, el) {
    _closeCatPicker();
    _setCat(id, val);
  }

  function _sortBy(col) {
    if (_sortCol === col) { _sortDir = -_sortDir; }
    else { _sortCol = col; _sortDir = 1; }
    _renderTable(_buildWeeks(_year));
  }

  // ── Rename owner names stored in tracker localStorage ──────────────────
  // Called after admin renames a team member so all historical tracker rows update.
  function renameInTracker(renameMap) {
    if (!renameMap || !Object.keys(renameMap).length) return;
    // Find all tracker year keys in storage
    // Owner rename in _wtDbCache (in-memory DB cache) — DB is updated server-side
    [2025, 2026].forEach(yr => {
      const yearData = _wtDbCache && _wtDbCache[String(yr)];
      if (!yearData) return;
      Object.keys(yearData).forEach(wk => {
        if (!Array.isArray(yearData[wk])) return;
        yearData[wk] = yearData[wk].map(row => {
          const newOwner = renameMap[row.owner];
          return newOwner ? { ...row, owner: newOwner } : row;
        });
      });
    });

    // Also rename in change history
    try {
      const h = _loadHistory();
      let hChanged = false;
      Object.keys(h).forEach(cn => {
        if (renameMap[h[cn].owner]) { h[cn].owner = renameMap[h[cn].owner]; hChanged = true; }
      });
      if (hChanged) _saveHistory(h);
    } catch(e) {}
  }

  async function _reloadCategories() {
    try {
      const base = (window.API_BASE_V2 || '/iip/api/v2');
      const resp = await fetch(base + "/wt-categories", { cache: "no-store" });
      if (resp.ok) {
        const data = await resp.json();
        if (Array.isArray(data) && data.length) {
          WT_CATEGORIES = data.map(c => c.name).filter(Boolean).sort();
          data.forEach(c => { if (c.name && c.color) WT_CATEGORY_COLORS[c.name] = c.color; });
        }
      }
    } catch(e) { console.warn("[IIP] _reloadCategories failed:", e.message); }
  }

  return { render, enrichFromCases, renameInTracker, _setYear, _switchTab, _renderReopened, _dismissReopen, _navClick, _jumpToToday, _toggleFollowup, _focusCase, _clearFocusCase, _startEdit, _saveCmt, _cmtKey, _setCat, _setAvailability, _editRow, _delRow, _normCat, _sortBy, _applySeed, _mergeServerComments, _mergeServerCommentsNoOverwrite, _ensureServerCommentsLoaded, _openCmtPopover, _closeCmtPopover, _saveCmtPopover, _popKey, _onCmtInput, _doSaveCmt, _setChip, _clearChips, _openCatPicker, _closeCatPicker, _pickCat, _selRow, _selAll, _clearBulk, _bulkSetCat, _bulkSetAv, _renderHistoryFiltered, _getAllWTCases, _showWTCaseModal, _reloadCategories,
    // Exposed for WTCrossWeekGrayout module
    _seed: _wtDbCache, // DB cache reference (replaces _WT_SEED)
    _ldy,              // localStorage year-data reader
    get _serverComments() { return _serverComments; } };

})();
