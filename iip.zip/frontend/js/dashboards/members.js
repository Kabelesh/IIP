/* ============================================================
   js/dashboards/members.js  —  Team Member Dashboard
   ============================================================ */
const DashMembers = (() => {
  /* ── Loading state helper ─────────────────────────────────────
     Usage: _setLoading(true) before data fetch, _setLoading(false) after.
     Applies .is-loading class to the dashboard root element.
  ────────────────────────────────────────────────────────────── */
  function _setLoading(active) {
    const el = document.getElementById('content-area') || document.body;
    el.classList.toggle('dashboard-loading', active);
    // Show/hide skeleton shimmer on tables
    document.querySelectorAll('.table-wrap, .dash-table').forEach(t => {
      t.classList.toggle('skeleton-loading', active);
    });
  }


  let _selectedMember = "";
  let _sortKey = "active";  // default: sort by Active desc
  let _sortDir = -1;        // -1 = descending
  let _memberMetadata = {};  // Cache team member metadata (team, status)
  let _memberFilter = null;  // active KPI filter key in member detail view

  /* ── KPI card helper ─────────────────────────────────── */
  function kpi(label, value, cls = "", sub = "", filterKey = "") {
    const filterAttrs = filterKey
      ? ` data-filter="${filterKey}" tabindex="0" role="button" aria-label="Filter by ${label}"
         style="cursor:pointer;transition:box-shadow .15s,outline .15s"`
      : "";
    return `<div class="kpi-card ${cls}"${filterAttrs}>
      <div class="kpi-label">${label}</div>
      <div class="kpi-value">${value}</div>
      ${sub ? `<div class="text-11 text-muted mt-6">${sub}</div>` : ""}
    </div>`;
  }

  /* ── Build member metadata from DynamicConfig (no extra API call needed) ── */
  async function _loadMemberMetadata() {
    try {
      if (typeof DynamicConfig === 'undefined') return;
      const groups = DynamicConfig.teamGroups ? DynamicConfig.teamGroups() : {};
      const emails = DynamicConfig.teamEmails ? DynamicConfig.teamEmails() : {};
      _memberMetadata = {};
      (DynamicConfig.teamMembers ? DynamicConfig.teamMembers() : []).forEach(name => {
        _memberMetadata[name] = { team: groups[name.toLowerCase()] || '', status: 'Active', email: emails[name] || '' };
      });
      (DynamicConfig.departedMembers ? DynamicConfig.departedMembers() : []).forEach(name => {
        _memberMetadata[name] = { team: groups[name.toLowerCase()] || '', status: 'Departed', email: emails[name] || '' };
      });
    } catch(e) {
      console.warn('Failed to load member metadata:', e);
    }
  }

  /* ── Main render ─────────────────────────────────────── */
  async function render() {
    const el = document.getElementById("tab-members");
    if (!el) return;

    await _loadMemberMetadata();  // Wait for team/status metadata to load

    // Fetch members from API; fall back to DynamicConfig if unavailable
    let members = [];
    try {
      const tok = sessionStorage.getItem('ibm_admin_token_v1') || '';
      const r = await fetch('/iip/api/admin/team-members', { headers: { 'x-iip-admin-token': tok } });
      if (r.ok) {
        const apiMembers = await r.json();
        // Rebuild _memberMetadata from API data (authoritative source)
        _memberMetadata = {};
        apiMembers.forEach(m => {
          _memberMetadata[m.name] = {
            team:   m.team   || '',
            status: m.status || 'Active',
            email:  m.email  || '',
            display_name: m.display_name || ''
          };
        });
        const active   = apiMembers.filter(m => (m.status || 'Active') === 'Active').map(m => m.name).sort();
        const departed = apiMembers.filter(m => m.status === 'Departed').map(m => m.name).sort();
        members = [...active, ...departed];
      } else {
        throw new Error('API error');
      }
    } catch(e) {
      // Fallback: DynamicConfig-derived list
      const activeMembers = Data.teamMembers().slice();
      const departedNames = Object.entries(_memberMetadata)
        .filter(([, m]) => m.status === 'Departed')
        .map(([name]) => name)
        .filter(name => !activeMembers.includes(name));
      members = [...activeMembers, ...departedNames].sort();
    }
    const teamAll = Data.teamCases();
    const stats   = members.map(m => getMemberStats(m, teamAll));

    const activeTeam = teamAll.filter(r => !Utils.isClosed(r.Status));
    const awaitAll   = teamAll.filter(r => r.Status === "Awaiting your feedback");
    const closed7d   = teamAll.filter(r => {
      if (!Utils.isClosed(r.Status)) return false;
      const d = Utils.parseDate(r.Updated || r.Created);
      return d && (Utils.today() - d) / 86400000 <= 7;
    });

    const allMeta      = Object.values(_memberMetadata);
    const activeCount  = allMeta.filter(m => m.status === 'Active').length;
    const departedCount = allMeta.filter(m => m.status === 'Departed').length;

    const teamMembersKpi = `<div class="kpi-card">
      <div class="kpi-label">Team Members</div>
      <div class="kpi-value" style="display:flex;align-items:center;gap:6px;font-size:inherit">
        <span style="color:var(--green,#22a06b)" title="Active members">${activeCount}<span style="font-size:0.55em;vertical-align:super">&#9650;</span></span>
        <span style="font-size:0.6em;color:var(--text-tertiary,#888)">+</span>
        <span style="color:var(--red,#e5484d)" title="Departed members">${departedCount}<span style="font-size:0.55em;vertical-align:super">&#9660;</span></span>
      </div>
    </div>`;

    const memberOpts = members.map(m =>
      `<option value="${Utils.escHtml(m)}" ${m === _selectedMember ? "selected" : ""}>${Utils.escHtml(Utils.shortName(m))}</option>`
    ).join("");

    el.innerHTML = `
      <!-- ── Top KPI row ─────────────────────── -->
      <div class="kpi-row" id="members-kpi-row">
        ${teamMembersKpi}
        ${kpi("Active Cases",       activeTeam.length,  "kpi-blue")}
        ${kpi("Open Cases",         activeTeam.length,  "kpi-yellow")}
        ${kpi("Awaiting Feedback",  awaitAll.length,    "kpi-red")}
        ${kpi("Closed (Last 7days)", closed7d.length,   "kpi-green")}
      </div>

      <!-- ── Member Selector ─────────────────── -->
      <div class="filter-bar mt-5">
        <div class="filter-group">
          <span class="filter-label">Select Team Member</span>
          <select id="member-select" class="form-select" style="min-width:240px">
            <option value="">— All Members Overview —</option>${memberOpts}
          </select>
        </div>
        <button id="member-clear" aria-label="Clear member filter" class="btn btn-ghost btn-sm">Show All</button>
      </div>

      <!-- ── Overview / Detail ───────────────── -->
      <div id="members-content" class="mt-5"></div>
    `;

    document.getElementById("member-select").addEventListener("change", e => {
      _selectedMember = e.target.value;
      renderContent(teamAll, stats);
    });
    document.getElementById("member-clear").addEventListener("click", () => {
      _selectedMember = "";
      document.getElementById("member-select").value = "";
      renderContent(teamAll, stats);
    });

    renderContent(teamAll, stats);
  }

  /* ── Stats calculator ────────────────────────────────── */
  function getMemberStats(member, teamAll) {
    const cases   = teamAll.filter(r => r.Owner === member);
    const open    = cases.filter(r => !Utils.isClosed(r.Status));
    const closed  = cases.filter(r =>  Utils.isClosed(r.Status));
    const closed7d = closed.filter(r => {
      const d = Utils.parseDate(r.Updated || r.Created);
      return d && (Utils.today() - d) / 86400000 <= 7;
    }).length;
    const await_   = cases.filter(r => r.Status === "Awaiting your feedback");
    const inprog   = cases.filter(r => r.Status === "IBM is working" || r.Status === "Waiting for IBM");
    const perfNums = Data.getPerfCaseNums();
    const perf     = cases.filter(r => perfNums.includes(r["Case Number"]));
    const perfActive = perf.filter(r => !Utils.isClosed(r.Status));
    const stale    = open.filter(r => Utils.daysDiff(Utils.parseDate(r.Updated)) >= 5);
    const avgDays  = open.length > 0
      ? Math.round(open.reduce((sum, r) => sum + Utils.daysDiff(Utils.parseDate(r.Updated)), 0) / open.length)
      : 0;

    // Workload health: 0 (worst) – 100 (best)
    const health = Math.max(0, Math.min(100,
      Math.round(100 - (stale.length / Math.max(open.length,1)) * 60
                     - (await_.length / Math.max(open.length,1)) * 30)
    ));

    const sorted = [...cases].sort((a, b) => (Utils.parseDate(b.Created)||0) - (Utils.parseDate(a.Created)||0));
    return { member, cases, open, closed, closed7d, await_, inprog, perf, perfActive, stale, avgDays, health, latest: sorted[0] };
  }

  function renderContent(teamAll, stats) {
    const container = document.getElementById("members-content");
    if (!container) return;
    if (_selectedMember) renderMemberDetail(_selectedMember, teamAll);
    else                  renderAllMembersGrid(stats);
  }

  /* ── Overview Table ──────────────────────────────────── */
  function renderAllMembersGrid(stats) {
    const container = document.getElementById("members-content");
    // Restore top KPI row
    const _topKpi = document.getElementById("members-kpi-row");
    if (_topKpi) _topKpi.style.display = "";

    // Split by status: Active members with activity first, Departed always at bottom
    const _isDepart = s => _memberMetadata[s.member]?.status === 'Departed';
    const hasActivity = s =>
      s.cases.length > 0 || s.open.length > 0 || s.closed7d > 0 ||
      s.await_.length > 0 || s.inprog.length > 0 || s.perf.length > 0 || s.stale.length > 0;

    const activeMembers   = stats.filter(s => !_isDepart(s) && hasActivity(s));
    const departedMembers = stats.filter(s =>  _isDepart(s));
    const active = activeMembers; // used below for maxOpen/maxStale

    const SORT_FN = {
      rank:    s => s.open.length,
      member:  s => Utils.shortName(s.member).toLowerCase(),
      team:    s => (_memberMetadata[s.member]?.team || "").toLowerCase(),
      status:  s => (_memberMetadata[s.member]?.status || "").toLowerCase(),
      active:  s => s.open.length,
      open:    s => s.cases.length,
      closed7d:s => s.closed7d,
      await:   s => s.await_.length,
      inprog:  s => s.inprog.length,
      perf:    s => s.perf.length,
      stale:   s => s.stale.length,
      avgdays: s => s.avgDays,
      health:  s => s.health,
    };
    const fn = SORT_FN[_sortKey] || SORT_FN.active;
    const sortedActive = [...activeMembers].sort((a, b) => {
      const aActive = a.open.length, bActive = b.open.length;
      if (aActive === 0 && bActive > 0) return 1;
      if (bActive === 0 && aActive > 0) return -1;
      const av = fn(a), bv = fn(b);
      if (typeof av === "string") return av < bv ? -_sortDir : av > bv ? _sortDir : 0;
      return (av - bv) * _sortDir;
    });
    const sortedDeparted = [...departedMembers].sort((a, b) =>
      Utils.shortName(a.member).toLowerCase() < Utils.shortName(b.member).toLowerCase() ? -1 : 1
    );
    const sorted = [...sortedActive, ...sortedDeparted];

    function thSort(key, label, tip) {
      const cur = _sortKey === key;
      const arrow = cur ? (_sortDir === -1 ? " ↓" : " ↑") : "";
      const tipAttr = tip ? ` title="${tip}"` : "";
      return `<th class="sort-th" data-sort="${key}"
        style="cursor:pointer;user-select:none;white-space:nowrap${cur ? ";background:var(--ibm-blue-10)" : ""}"
        ${tipAttr}>${label}${arrow}</th>`;
    }

    // Compute team averages for mini-bars
    const maxOpen  = Math.max(...active.map(s => s.open.length), 1);
    const maxStale = Math.max(...active.map(s => s.stale.length), 1);

    let html = `
      <div class="tile">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;flex-wrap:wrap;gap:8px">
          <div class="section-title" class="mb-0">Team Performance Overview
            <span style="font-size:11px;font-weight:400;color:var(--text-tertiary);margin-left:8px">${active.length} members</span>
          </div>
          <div style="display:flex;gap:8px;align-items:center">
            <input id="members-search" type="text" placeholder="Search member..."
              style="border:1px solid var(--border-subtle);border-radius:var(--radius-xs);padding:5px 10px;font-size:12px;
                outline:none /* focus-visible handles focus ring */;background:var(--bg-layer);color:var(--text-primary);width:200px"
              onfocus="this.style.borderColor='var(--ibm-blue-30)'" onblur="this.style.borderColor='var(--border-subtle)'"/>
            <button class="btn btn-secondary btn-sm" id="members-export" aria-label="Export members to Excel"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg> Export Excel</button>
          </div>
        </div>
        <div class="data-table-wrap" style="border:1px solid var(--border-subtle);border-radius:var(--radius-md)">
          <table class="data-table" id="members-table">
            <thead><tr>
              ${thSort("rank",    "#")}
              ${thSort("member",  "Member")}
              ${thSort("team",    "Team")}
              ${thSort("status",  "Status")}
              ${thSort("active",  "Active", "Open (non-closed) cases")}
              ${thSort("open",    "All")}
              ${thSort("closed7d","Closed (7d)")}
              ${thSort("await",   "Awaiting Feedback")}
              ${thSort("inprog",  "In Progress")}
              ${thSort("perf",    "Perf Cases", "Active / Total performance-tagged cases")}
              ${thSort("stale",   "Stale (5d+)")}
              ${thSort("avgdays", "Avg Days")}
            </tr></thead>
            <tbody id="members-tbody">`;

    sorted.forEach((s, i) => {
      // Inline mini-bar widths
      const openPct  = Math.round((s.open.length  / maxOpen)  * 40);
      const stalePct = Math.round((s.stale.length / maxStale) * 40);

      // Departed members: grayed out at bottom
      const isDeparted = _isDepart(s);
      const rowStyle = isDeparted
        ? "opacity:.45;filter:grayscale(.6);"
        : s.open.length === 0 ? "opacity:.55;" : "";
      // Separator before first departed member
      if (isDeparted && sortedDeparted.length > 0 && s === sortedDeparted[0]) {
        html += `<tr style="pointer-events:none">
          <td colspan="12" style="padding:4px 10px;background:var(--bg-layer-02,#f4f4f4);border-top:1px solid var(--border-subtle);font-size:11px;color:var(--text-tertiary);letter-spacing:.05em;font-weight:500">
            &#9660; DEPARTED MEMBERS
          </td>
        </tr>`;
      }
      html += `
        <tr data-member="${Utils.escHtml(s.member)}" style="${rowStyle}">
          <td class="text-muted" style="font-size:12px;width:32px">${i + 1}</td>
          <td style="font-weight:500;white-space:nowrap;min-width:160px">
            <span class="member-detail-btn" aria-label="View member details" data-member="${Utils.escHtml(s.member)}"
              style="display:inline-flex;align-items:center;gap:8px;cursor:pointer;color:var(--ibm-blue-50);text-decoration:underline;text-underline-offset:2px">
              <span class="member-avatar">${Utils.escHtml(Utils.shortName(s.member).split(" ").map(p=>p[0]).join("").slice(0,2).toUpperCase())}</span>
              ${Utils.escHtml(Utils.shortName(s.member))}
            </span>
          </td>
          <td style="white-space:nowrap;color:var(--text-secondary);font-size:12px">${Utils.escHtml(_memberMetadata[s.member]?.team || "—")}</td>
          <td style="white-space:nowrap;font-size:12px">
            <span style="padding:2px 6px;border-radius:var(--radius-xs);font-weight:500;background:${_memberMetadata[s.member]?.status === 'Active' ? 'var(--green-20);color:var(--green-text)' : _memberMetadata[s.member]?.status === 'Departed' ? 'var(--red-20);color:var(--red-text)' : 'var(--bg-layer);color:var(--text-secondary)'}">
              ${Utils.escHtml(_memberMetadata[s.member]?.status || "—")}
            </span>
          </td>
          <td class="col-stat-blue">
            <div class="row-6">
              <span>${s.open.length}</span>
              ${openPct > 0 ? `<div style="width:${openPct}px;height:4px;background:var(--ibm-blue-30);border-radius:2px;flex-shrink:0"></div>` : ""}
            </div>
          </td>
          <td class="col-stat-yellow">${s.cases.length}</td>
          <td class="col-stat-green">${s.closed7d}</td>
          <td class="col-stat-await">${s.await_.length > 0 ? `<span style="color:var(--yellow);font-weight:600">${s.await_.length}</span>` : `<span class="text-muted">0</span>`}</td>
          <td class="col-stat-blue">${s.inprog.length}</td>
          <td class="col-stat-red">${
            (function(pa, pt) {
              if (pt === 0) return '<span class="text-muted">0</span>';
              var diff = pt > pa ? '<span style="font-size:10px;padding:1px 4px;border-radius:var(--radius-xs);background:var(--green-20);color:var(--green-text);font-weight:500">-' + (pt - pa) + '</span>' : '';
              return '<div style="display:flex;align-items:center;gap:4px;white-space:nowrap"><span style="font-weight:600;color:var(--text-primary)">' + pa + '</span><span style="font-size:10px;color:var(--text-tertiary)">/ ' + pt + '</span>' + diff + '</div>';
            })(s.perfActive.length, s.perf.length)
          }</td>
          <td class="col-stat-stale">
            <div class="row-6">
              ${s.stale.length > 0
                ? `<span style="color:var(--red);font-weight:600">${s.stale.length}</span>
                   ${stalePct > 0 ? `<div style="width:${stalePct}px;height:4px;background:rgba(218,30,40,.3);border-radius:2px;flex-shrink:0"></div>` : ""}`
                : `<span class="text-muted">0</span>`}
            </div>
          </td>
          <td class="col-stat-days" style="color:${s.avgDays >= 10 ? "var(--red)" : s.avgDays >= 5 ? "var(--yellow)" : "var(--text-tertiary)"}">${s.avgDays}d</td>
        </tr>`;
    });

    html += `</tbody></table></div>
      <div style="padding:8px 12px;font-size:11px;color:var(--text-tertiary);border-top:1px solid var(--border-subtle);margin-top:4px">
        Click any column header to sort · Click member name to view details
      </div>
    </div>`;

    // Charts
    html += `
      <div class="grid-2 mt-5">
        <div class="tile"><div class="section-title">Active Cases by Member</div>
          <div class="chart-canvas-wrap" class="chart-lg"><canvas id="chart-members-open"></canvas></div></div>
        <div class="tile"><div class="section-title">Stale Cases by Member <span style="font-size:10px;font-weight:400;margin-left:6px;background:rgba(218,30,40,0.10);color:#DA1E28;padding:2px 8px;border-radius:10px;vertical-align:middle;">&#9200; Not updated 5+ days</span></div>
          <div class="chart-canvas-wrap" class="chart-lg" style="position:relative"><canvas id="chart-members-stale"></canvas></div>
          <div id="chart-members-stale-legend" style="display:flex;flex-wrap:wrap;gap:4px 12px;justify-content:center;padding:6px 4px 0;font-size:11px;font-family:'IBM Plex Sans',sans-serif;"></div>
        </div>
      </div>
      <div class="grid-2 mt-5">
        <div class="tile"><div class="section-title">Total Cases by Member</div>
          <div class="chart-canvas-wrap" class="chart-lg"><canvas id="chart-members-total"></canvas></div></div>
        <div class="tile"><div class="section-title">Awaiting Feedback by Member</div>
          <div class="chart-canvas-wrap" class="chart-lg"><canvas id="chart-members-await"></canvas></div></div>
      </div>`;

    container.innerHTML = html;

    // Column sorting
    container.querySelectorAll(".sort-th").forEach(th => {
      th.addEventListener("click", () => {
        const key = th.dataset.sort;
        if (_sortKey === key) _sortDir *= -1;
        else { _sortKey = key; _sortDir = -1; }
        renderAllMembersGrid(stats);
      });
    });

    // Search filter
    document.getElementById("members-search")?.addEventListener("input", e => {
      const q = e.target.value.toLowerCase();
      document.querySelectorAll("#members-tbody tr").forEach(tr => {
        tr.style.display = tr.textContent.toLowerCase().includes(q) ? "" : "none";
      });
    });

    // Export
    document.getElementById("members-export")?.addEventListener("click", () => exportMembersTable(sorted));

    // Row click → member detail
    // Row click → member detail (remove previous listener to prevent accumulation)
    if (container._memberClickHandler) {
      container.removeEventListener("click", container._memberClickHandler);
    }
    container._memberClickHandler = function(e) {
      const btn = e.target.closest(".member-detail-btn");
      if (!btn) return;
      _selectedMember = btn.dataset.member;
      document.getElementById("member-select").value = _selectedMember;
      renderMemberDetail(_selectedMember, Data.teamCases());
    };
    container.addEventListener("click", container._memberClickHandler);

    renderMembersCharts(sorted);
  }

  /* ── Charts ──────────────────────────────────────────── */
  function renderMembersCharts(stats) {
    const clickMember = name => {
      const s = stats.find(s => s.member === name);
      if (!s) return;
      _selectedMember = name;
      document.getElementById("member-select").value = name;
      renderMemberDetail(name, Data.teamCases());
    };

    // 1. Active Cases — gradient vertical bars (blue→teal per bar)
    _memGradBars("chart-members-open",
      stats.filter(s => s.open.length > 0).map(s => ({ name: Utils.shortName(s.member), fullName: s.member, count: s.open.length })),
      clickMember);

    // 2. Stale Cases — Yearly Created-style donut
    _memHorizBar("chart-members-stale",
      stats.filter(s => s.stale.length > 0).map(s => ({ name: Utils.shortName(s.member), fullName: s.member, count: s.stale.length })));

    // 3. Total Cases — gradient area line chart
    _memAreaLine("chart-members-total",
      stats.map(s => ({ name: Utils.shortName(s.member), fullName: s.member, count: s.cases.length })));

    // 4. Awaiting Feedback — horizontal histogram (one bar per member)
    _memLollipop("chart-members-await",
      stats.filter(s => s.await_.length > 0).map(s => ({ name: Utils.shortName(s.member), fullName: s.member, count: s.await_.length })));
  }

  /* ── Member Detail View ──────────────────────────────── */
  function renderMemberDetail(member, teamAll) {
    const container = document.getElementById("members-content");
    // Hide top KPI row — not relevant in single-member view
    const _topKpi = document.getElementById("members-kpi-row");
    if (_topKpi) _topKpi.style.display = "none";
    const s         = getMemberStats(member, teamAll);
    const trend     = Utils.monthlyTrend(s.cases);

    const initials  = Utils.shortName(member).split(" ").map(p => p[0]).join("").slice(0,2).toUpperCase();
    const email     = Data.teamEmails()[member] || "";

    // Status distribution
    const statusMap = {};
    s.cases.forEach(r => { statusMap[r.Status] = (statusMap[r.Status]||0)+1; });
    const statusData = Object.entries(statusMap).map(([name,value]) => ({ name, value }));


    container.innerHTML = `
      <!-- ── Member Header Card ── -->
      <div class="tile" style="display:flex;align-items:center;gap:20px;flex-wrap:wrap;border-left:4px solid var(--ibm-blue-50);padding:20px">
        <div class="member-avatar member-avatar-lg">${initials}</div>
        <div class="flex-1-0">
          <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
            <span style="font-size:20px;font-weight:700;color:var(--text-primary)">${Utils.escHtml(Utils.shortName(member))}</span>
          </div>
          ${email ? `<a href="mailto:${Utils.escHtml(email)}" style="font-size:12px;color:var(--ibm-blue-50);text-decoration:none;margin-top:2px;display:inline-block"
            onmouseover="this.style.textDecoration='underline'" onmouseout="this.style.textDecoration='none'">${Utils.escHtml(email)}</a>` : ""}
        </div>
        <div style="display:flex;flex-direction:column;gap:6px;align-items:flex-end">
          <button id="back-to-all" aria-label="Back to all members" class="btn btn-ghost btn-sm">← All Members</button>
        </div>
      </div>

      <!-- ── Member KPI Cards ── -->
      <div class="kpi-row" style="margin-top:12px">
        ${kpi("Active Cases",       s.open.length,    "kpi-blue",   "of " + s.cases.length + " total",  "active")}
        ${kpi("Closed (Last 7D)",   s.closed7d,       s.closed7d > 0 ? "kpi-green" : "",                "",       "closed7d")}
        ${kpi("Awaiting Feedback",  s.await_.length,  s.await_.length > 0 ? "kpi-red" : "",             "",       "await")}
        ${kpi("In Progress",        s.inprog.length,  "kpi-blue",                                        "",       "inprog")}
        ${kpi("Perf Cases",         s.perf.length,    s.perf.length > 0 ? "kpi-red" : "",               "",       "perf")}
        ${kpi("Stale (5D+)",        s.stale.length,   s.stale.length > 0 ? "kpi-red" : "",              "",       "stale")}
        ${kpi("Avg Days Open",      s.avgDays + "d",  "")}
      </div>
      <p style="font-size:11px;color:var(--text-tertiary);margin:4px 0 0 2px">↑ Click a KPI card to filter the cases table below</p>

      <!-- ── Charts (3-panel, mirrors Overview) ── -->
      <div class="ov7-z2 mt-5">
        <div class="tile no-hover">
          <div class="ov7-tile-hdr">
            <div class="section-title mb-0"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg> Created vs Closed</div>
            <div class="ov7-tw-group">
              <button class="ov7-tw ov7-tw-active" data-member-tw="3">3M</button>
              <button class="ov7-tw" data-member-tw="6">6M</button>
              <button class="ov7-tw" data-member-tw="12">12M</button>
              <button class="ov7-tw" data-member-tw="0">ALL</button>
            </div>
          </div>
          <div class="ov7-trend-summary" id="member-trend-summary"></div>
          <div class="chart-canvas-wrap" style="height:220px"><canvas id="chart-member-trend"></canvas></div>
          <div id="member-kpi-bar" style="margin-top:8px"></div>
        </div>
        <div class="tile no-hover">
          <div class="ov7-tile-hdr mb-8">
            <div class="section-title mb-0"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="4"/></svg> Cases by Status</div>
            <div class="ov7-tw-group">
              <button class="ov7-tw ov7-mstw ov7-tw-active" data-mstw="0">ALL</button>
              <button class="ov7-tw ov7-mstw" data-mstw="3">3M</button>
              <button class="ov7-tw ov7-mstw" data-mstw="6">6M</button>
              <button class="ov7-tw ov7-mstw" data-mstw="12">12M</button>
            </div>
          </div>
          <div class="ov7-trend-summary" id="member-status-summary" style="font-size:12px;color:var(--text-secondary);margin-bottom:16px">
            <span class="ov7-ts-label">All Time:</span>
            <span class="ov7-ts-created">${s.cases.length} Total Cases</span>
          </div>
          <div class="chart-canvas-wrap" style="height:200px"><canvas id="chart-member-status"></canvas></div>
          <div id="chart-member-status-legend" style="display:flex;flex-wrap:wrap;gap:4px 14px;justify-content:center;padding:8px 6px 2px;font-size:12px;"></div>
        </div>
        <div class="tile no-hover">
          <div class="ov7-tile-hdr">
            <div class="section-title mb-0"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="3" x2="9" y2="21"/></svg> <span id="chart3-title">Cases by Product</span></div>
            <div class="ov7-tw-group">
              <button class="ov7-tw ov7-tw-active" data-chart3="product" title="Cases by Product">Product</button>
              <button class="ov7-tw" data-chart3="severity" title="Cases by Severity">Severity</button>
              <button class="ov7-tw" data-chart3="aging" title="Stale Case Aging">Aging</button>
            </div>
          </div>
          <div class="chart-canvas-wrap" style="height:220px">
            <canvas id="chart-member-product"></canvas>
            <canvas id="chart-member-severity" style="display:none"></canvas>
            <canvas id="chart-member-aging" style="display:none"></canvas>
          </div>
          <div id="chart3-kpi-strip" style="display:flex;gap:0;align-items:stretch;border-top:1px solid var(--border-subtle);padding:8px 0 2px;flex-wrap:wrap;margin-top:6px"></div>
        </div>
      </div>

      <!-- ── Stale Cases ── -->
      ${s.stale.length > 0 ? `
      <div class="tile mt-5" style="border-left:4px solid var(--red)">
        <div class="section-title">⚠ Stale Cases — Not Updated 5+ Days</div>
        <div id="tbl-member-stale"></div>
      </div>` : ""}

      <!-- ── Awaiting Feedback ── -->
      ${s.await_.length > 0 ? `
      <div class="tile mt-5" style="border-left:4px solid var(--yellow)">
        <div class="section-title">⏳ Awaiting Feedback Cases</div>
        <div id="tbl-member-await"></div>
      </div>` : ""}

      <!-- ── All Cases ── -->
      <div class="tile mt-5">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
          <div class="section-title mb-0" id="all-cases-title">All Cases
            <span id="all-cases-count" style="font-size:11px;font-weight:400;color:var(--text-tertiary);margin-left:6px">${s.cases.length} total</span>
          </div>
          <button id="clear-kpi-filter" class="btn btn-ghost btn-sm" style="display:none">✕ Clear Filter</button>
        </div>
        <div id="tbl-member-all"></div>
      </div>
    `;

    document.getElementById("back-to-all")?.addEventListener("click", () => {
      _selectedMember = "";
      document.getElementById("member-select").value = "";
      render();
    });

    // ── 3-panel charts (mirrors Overview) ──────────────────────────
    let _mTw = 3;
    const _mTrend = trend; // full trend data from Utils.monthlyTrend(s.cases)

    function _mTrendSlice(tw) {
      return tw === 3 ? _mTrend.slice(-3) : tw === 6 ? _mTrend.slice(-6) : tw === 12 ? _mTrend.slice(-12) : _mTrend;
    }

    function _mKpiBar(created, closed, slice) {
      const peak   = slice && slice.length ? slice.reduce((b,r) => r.closed   > (b?.closed  ||0) ? r : b, null) : null;
      const peakCr = slice && slice.length ? slice.reduce((b,r) => r.created  > (b?.created ||0) ? r : b, null) : null;
      const net     = closed - created;
      const rate    = created > 0 ? Math.round(closed / created * 100) : 0;
      const netCol  = net >= 0 ? "var(--green,#24a148)" : "var(--red,#da1e28)";
      const rateCol = rate >= 100 ? "var(--green,#24a148)" : rate >= 70 ? "var(--yellow,#f1c21b)" : "var(--red,#da1e28)";
      const barW    = (v, max) => Math.min(100, max > 0 ? Math.round(v/max*100) : 0);
      const maxVal  = Math.max(created, closed, 1);
      const card = (bl, label, bigVal, bigCol, sub, barCss) =>
        `<div style="flex:1;min-width:80px;display:flex;flex-direction:column;padding:0 10px 8px ${bl?"10":"4"}px;${bl?"border-left:1px solid var(--border-subtle);":""}">`
        + `<div style="font-size:9px;font-weight:700;letter-spacing:.08em;color:var(--text-tertiary);text-transform:uppercase;margin-bottom:4px">${label}</div>`
        + `<div style="font-size:16px;font-weight:700;font-family:var(--font-mono);color:${bigCol};line-height:1">${bigVal}</div>`
        + `<div style="flex:1"></div>`
        + `<div style="font-size:10px;color:var(--text-tertiary);min-height:14px;white-space:nowrap">${sub}</div>`
        + `<div style="height:3px;background:var(--border-subtle);border-radius:2px;margin-top:5px;overflow:hidden"><div style="height:3px;border-radius:2px;${barCss}transition:width .4s ease"></div></div>`
        + `</div>`;
      return `<div style="display:flex;gap:0;align-items:stretch;border-top:1px solid var(--border-subtle);padding:10px 0 2px;flex-wrap:wrap">`
        + card(false,"Created",    created,             "var(--text-primary)", "&nbsp;",                            `background:var(--red,#da1e28);width:${barW(created,maxVal)}%;`)
        + card(true, "Closed",     closed,              "var(--text-primary)", "&nbsp;",                            `background:var(--green,#24a148);width:${barW(closed,maxVal)}%;`)
        + card(true, "Difference", (net>=0?"+":"")+net, netCol,               "&nbsp;",                            `background:${net>=0?"var(--green,#24a148)":"var(--red,#da1e28)"};width:100%;`)
        + card(true, "Close Rate", rate+"%",            rateCol,              "&nbsp;",                            `background:var(--green,#24a148);width:${Math.min(rate,100)}%;`)
        + (peak   ? card(true,"Peak Close",   peak.label,   "var(--green,#24a148)", peak.closed+" cases closed",   `background:var(--green,#24a148);width:${barW(peak.closed,maxVal)}%;`) : "")
        + (peakCr ? card(true,"Peak Created", peakCr.label, "var(--text-primary)", peakCr.created+" cases created",`background:var(--red,#da1e28);width:${barW(peakCr.created,maxVal)}%;`) : "")
        + `</div>`;
    }

    function _mRenderTrend(tw) {
      const slice = _mTrendSlice(tw);
      const tC = slice.reduce((s,r)=>s+r.created,0);
      const tCl = slice.reduce((s,r)=>s+r.closed,0);
      const sumEl = document.getElementById("member-trend-summary");
      if (sumEl) sumEl.innerHTML = `<span class="ov7-ts-label">${tw === 0 ? "All Time" : `Last ${tw}M`}:</span> <span class="ov7-ts-created">${tC} Created</span> <span class="ov7-ts-sep">·</span> <span class="ov7-ts-closed">${tCl} Closed</span>`;
      const kpiEl = document.getElementById("member-kpi-bar");
      if (kpiEl) kpiEl.innerHTML = _mKpiBar(tC, tCl, slice);
      try { Charts.trendLine("chart-member-trend", slice, {
        onClick: lbl => {
          // Labels are "MM/YY" e.g. "04/26" — match Utils.monthlyTrend label format
          const monthCases = s.cases.filter(r => {
            const d = Utils.parseDate(r.Created);
            if (!d) return false;
            const mm = String(d.getMonth() + 1).padStart(2, "0");
            const yy = String(d.getFullYear()).slice(2);
            return (mm + "/" + yy) === lbl;
          });
          _drillChart("Month: " + lbl, monthCases);
        }
      }); } catch(e){}
    }

    _mRenderTrend(_mTw);

    // Wire 3M/6M/12M toggle buttons
    container.querySelectorAll("[data-member-tw]").forEach(btn => {
      btn.addEventListener("click", () => {
        _mTw = parseInt(btn.dataset.memberTw);
        container.querySelectorAll("[data-member-tw]").forEach(b => b.classList.toggle("ov7-tw-active", b === btn));
        _mRenderTrend(_mTw);
      });
    });

    // Initial render — ALL cases
    Charts.statusDonut("chart-member-status", statusData, {
      legendId: "chart-member-status-legend",
      centerLabel: "Total Cases",
      onClick: st => _drillChart("Status: " + st, s.cases.filter(r => r.Status === st))
    });

    // ── Member status donut time window toggle ──────────────
    container.querySelectorAll(".ov7-mstw").forEach(btn => {
      btn.addEventListener("click", () => {
        const mstw = parseInt(btn.dataset.mstw);
        container.querySelectorAll(".ov7-mstw").forEach(b => b.classList.toggle("ov7-tw-active", b === btn));
        const now = Utils.today();
        const msFiltered = mstw === 0 ? s.cases : s.cases.filter(r => {
          const d = Utils.parseDate(r.Created);
          return d && (now - d) / (86400000 * 30) <= mstw;
        });
        const msMap = {};
        msFiltered.forEach(r => { const st = (r.Status||"").trim(); msMap[st] = (msMap[st]||0)+1; });
        const msData = Object.entries(msMap).filter(([,v])=>v>0).sort((a,b)=>b[1]-a[1]).map(([name,value])=>({name,value}));
        const msLabel = mstw === 0 ? "All Time" : `Last ${mstw}M`;
        const msSumEl = document.getElementById("member-status-summary");
        if (msSumEl) msSumEl.innerHTML = `
          <span class="ov7-ts-label">${msLabel}:</span>
          <span class="ov7-ts-created">${msFiltered.length} Total Cases</span>`;
        Charts.statusDonut("chart-member-status", msData, {
          legendId: "chart-member-status-legend",
          centerLabel: "Total Cases",
          onClick: st => _drillChart("Status: " + st, msFiltered.filter(r => r.Status === st))
        });
      });
    });

    // ── Chart 3: Product / Severity / Aging tabs ────────────────────

    // Product data
    const _mProdMap = {};
    s.cases.forEach(r => { const p = r.Product || "Unknown"; _mProdMap[p] = (_mProdMap[p]||0)+1; });
    const _mProdData = Object.entries(_mProdMap).sort((a,b)=>b[1]-a[1]).slice(0,8).map(([name,value])=>({name,value}));

    // Severity data
    const _mSevMap = { "1":0, "2":0, "3":0, "4":0 };
    s.cases.forEach(r => { const sv = String(r.Severity||"").trim(); if (_mSevMap[sv]!==undefined) _mSevMap[sv]++; else if(sv) _mSevMap[sv]=(_mSevMap[sv]||0)+1; });
    const _mSevData = Object.entries(_mSevMap).filter(([,v])=>v>0).map(([name,value])=>({name:"Sev "+name,value}));

    // Aging buckets (based on Updated date)
    const _mAgingBuckets = {"0-4d":0,"5-9d":0,"10-29d":0,"30d+":0};
    s.open.forEach(r => {
      const d = Utils.daysDiff(Utils.parseDate(r.Updated || r.Created));
      if      (d <  5) _mAgingBuckets["0-4d"]++;
      else if (d < 10) _mAgingBuckets["5-9d"]++;
      else if (d < 30) _mAgingBuckets["10-29d"]++;
      else             _mAgingBuckets["30d+"]++;
    });
    const _mAgingData = Object.entries(_mAgingBuckets).map(([name,value])=>({name,value}));

    // Render helpers — each swaps canvas visibility + redraws

    function _renderChart3KpiStrip(items, color) {
      const el = document.getElementById("chart3-kpi-strip");
      if (!el) return;
      const total = items.reduce((s,d) => s + d.value, 0) || 1;
      const top   = [...items].sort((a,b) => b.value - a.value).slice(0,6);
      const _abbr = name => {
        const MAP = {
          "engineering wf mgmt": "EWM", "engineering workflow mgmt": "EWM",
          "engineering req. mgmt doors next": "DNG", "engineering req. mgmt door": "DNG",
          "engineering requirements management doors next": "DNG",
          "engineering test mgmt": "ETM", "engineering test management": "ETM",
          "engineering lc mgmt base": "ELMB", "engineering lifecycle mgmt base": "ELMB",
          "engineering lc mgmt suite": "ELMS", "engineering lifecycle mgmt suite": "ELMS",
          "engineering lc management base": "ELMB", "engineering lc management suite": "ELMS",
        };
        const key = (name||"").toLowerCase().trim();
        if (MAP[key]) return MAP[key];
        // fallback: initials of words (skip short words like "by","of","the")
        const skip = new Set(["by","of","the","and","for","in","a"]);
        const initials = key.split(/[\s.\-_]+/)
          .filter(w => w.length > 0 && !skip.has(w))
          .map(w => w[0].toUpperCase())
          .join("");
        return initials.slice(0,5) || name.slice(0,5).toUpperCase();
      };
      el.innerHTML = top.map((d,i) => {
        const pct   = Math.round(d.value / total * 100);
        const bl    = i > 0 ? "border-left:1px solid var(--border-subtle);" : "";
        const short = _abbr(d.name);
        return `<div style="flex:1;min-width:50px;display:flex;flex-direction:column;padding:4px 8px 6px ${i?8:4}px;${bl}">`
          + `<div style="font-size:8px;font-weight:700;letter-spacing:.06em;color:var(--text-tertiary);text-transform:uppercase;margin-bottom:3px;white-space:nowrap" title="${d.name}">${short}</div>`
          + `<div style="font-size:15px;font-weight:700;font-family:var(--font-mono);color:var(--text-primary);line-height:1">${d.value}</div>`
          + `<div style="flex:1"></div>`
          + `<div style="font-size:9px;color:var(--text-tertiary);margin-top:3px">${pct}%</div>`
          + `<div style="height:3px;background:var(--border-subtle);border-radius:2px;margin-top:4px;overflow:hidden"><div style="height:3px;border-radius:2px;background:${color};width:${pct}%;transition:width .4s ease"></div></div>`
          + `</div>`;
      }).join("");
    }

    function _renderChart3Product() {
      document.getElementById("chart-member-product").style.display  = "";
      document.getElementById("chart-member-severity").style.display = "none";
      document.getElementById("chart-member-aging").style.display    = "none";
      document.getElementById("chart3-title").textContent = "Cases by Product";
      try { Charts.productBar("chart-member-product", _mProdData, {
        onClick: p => _drillChart("Product: " + p, s.cases.filter(r => (r.Product||"Unknown") === p))
      }); } catch(e){}
      _renderChart3KpiStrip(_mProdData, "var(--ibm-blue-40,#4589ff)");
    }
    function _renderChart3Severity() {
      document.getElementById("chart-member-product").style.display  = "none";
      document.getElementById("chart-member-severity").style.display = "";
      document.getElementById("chart-member-aging").style.display    = "none";
      document.getElementById("chart3-title").textContent = "Cases by Severity";
      try {
        Charts.ownerBar("chart-member-severity", _mSevData.map(d=>({name:d.name,count:d.value,fullName:d.name})), {
          color: "var(--chart-5)",
          label: "Cases",
          onClick: name => {
            const sevNum = name.replace("Sev ", "");
            _drillChart("Severity " + name, s.cases.filter(r => String(r.Severity||"").trim() === sevNum));
          }
        });
      } catch(e){}
      _renderChart3KpiStrip(_mSevData, "var(--chart-5,#9f1853)");
    }
    function _renderChart3Aging() {
      document.getElementById("chart-member-product").style.display  = "none";
      document.getElementById("chart-member-severity").style.display = "none";
      document.getElementById("chart-member-aging").style.display    = "";
      document.getElementById("chart3-title").textContent = "Stale Case Aging";
      try {
        Charts.ownerBar("chart-member-aging", _mAgingData.map(d=>({name:d.name,count:d.value,fullName:d.name})), {
          color: "var(--yellow)",
          label: "Cases",
          onClick: name => {
            const agingCases = s.open.filter(r => {
              const d = Utils.daysDiff(Utils.parseDate(r.Updated || r.Created));
              if (name === "0-4d")   return d <  5;
              if (name === "5-9d")   return d >= 5  && d < 10;
              if (name === "10-29d") return d >= 10 && d < 30;
              if (name === "30d+")   return d >= 30;
              return false;
            });
            _drillChart("Aging: " + name, agingCases);
          }
        });
      } catch(e){}
      _renderChart3KpiStrip(_mAgingData, "var(--yellow,#f1c21b)");
    }

    // Default view
    _renderChart3Product();

    // Wire tab buttons
    container.querySelectorAll("[data-chart3]").forEach(btn => {
      btn.addEventListener("click", () => {
        container.querySelectorAll("[data-chart3]").forEach(b => b.classList.toggle("ov7-tw-active", b === btn));
        if (btn.dataset.chart3 === "product")   _renderChart3Product();
        if (btn.dataset.chart3 === "severity")  _renderChart3Severity();
        if (btn.dataset.chart3 === "aging")     _renderChart3Aging();
      });
    });

    const extraCols = [{
      key: "_days", label: "Days Stale", sortable: true,
      render: row => {
        const days  = Utils.daysDiff(Utils.parseDate(row.Updated));
        const color = days >= 10 ? "var(--red)" : days >= 5 ? "var(--yellow)" : "var(--text-tertiary)";
        return `<span style="color:${color};font-family:var(--font-mono);font-weight:600">${days}d</span>`;
      },
      sortValue: row => Utils.daysDiff(Utils.parseDate(row.Updated))
    }];

    if (s.stale.length > 0)  Table.render(document.getElementById("tbl-member-stale"),  s.stale,  { showActions: false, extraCols });
    if (s.await_.length > 0) Table.render(document.getElementById("tbl-member-await"), s.await_, { showActions: false, extraCols });
    const allCasesTbl = Table.render(document.getElementById("tbl-member-all"), s.cases, { showActions: false, extraCols });

    // ── Shared chart click → drill All Cases table ───────────────────────────
    // NOTE: function declaration is hoisted, so chart onClick callbacks defined
    // earlier in this scope can safely call _drillChart() at click time.
    function _drillChart(title, cases) {
      _memberFilter = null;  // clear KPI filter state
      container.querySelectorAll(".kpi-card[data-filter]").forEach(c => {
        c.style.boxShadow = ""; c.style.outline = ""; c.style.outlineOffset = "";
      });
      const titleEl  = document.getElementById("all-cases-title");
      const countEl  = document.getElementById("all-cases-count");
      const clearBtn = document.getElementById("clear-kpi-filter");
      if (titleEl) titleEl.firstChild.textContent = "Filtered: " + title;
      if (countEl) countEl.textContent = cases.length + " case" + (cases.length !== 1 ? "s" : "");
      if (clearBtn) clearBtn.style.display = "";
      if (allCasesTbl && typeof allCasesTbl.refresh === "function") allCasesTbl.refresh(cases);
      document.getElementById("tbl-member-all")
        ?.closest(".tile")
        ?.scrollIntoView({ behavior: "smooth", block: "start" });
    }

    // ── KPI card click-to-filter ──────────────────────────────
    _memberFilter = null;
    const _filterDatasets = {
      active:   s.open,
      closed7d: s.cases.filter(r => {
        if (!Utils.isClosed(r.Status)) return false;
        const d = Utils.parseDate(r.Updated || r.Created);
        return d && (Utils.today() - d) / 86400000 <= 7;
      }),
      await:  s.await_,
      inprog: s.inprog,
      perf:   s.perf,
      stale:  s.stale,
    };

    function _applyMemberFilter(key) {
      _memberFilter = key;
      const filtered    = key ? (_filterDatasets[key] || s.cases) : s.cases;
      const titleEl     = document.getElementById("all-cases-title");
      const countEl     = document.getElementById("all-cases-count");
      const clearBtn    = document.getElementById("clear-kpi-filter");
      const activeCard  = container.querySelector(`.kpi-card[data-filter="${key}"]`);

      // Update tile header
      if (titleEl) titleEl.firstChild.textContent = key && activeCard
        ? `Filtered: ${activeCard.querySelector(".kpi-label").textContent}`
        : "All Cases";
      if (countEl) countEl.textContent = `${filtered.length} case${filtered.length !== 1 ? "s" : ""}`;
      if (clearBtn) clearBtn.style.display = key ? "" : "none";

      // Highlight active KPI card
      container.querySelectorAll(".kpi-card[data-filter]").forEach(c => {
        const isActive = key && c.dataset.filter === key;
        c.style.boxShadow = isActive ? "0 0 0 2px var(--ibm-blue-50)" : "";
        c.style.outline   = isActive ? "2px solid var(--ibm-blue-50)" : "";
        c.style.outlineOffset = isActive ? "1px" : "";
      });

      // Use .refresh() to update the existing table in-place (re-render replaces nothing)
      if (allCasesTbl && typeof allCasesTbl.refresh === "function") {
        allCasesTbl.refresh(filtered);
      }

      // Scroll to KPI strip on clear, or to All Cases table on filter
      if (key) {
        const allCasesEl = document.getElementById("tbl-member-all");
        if (allCasesEl) {
          allCasesEl.closest(".tile")?.scrollIntoView({ behavior: "smooth", block: "start" });
        }
      }    }

    container.querySelectorAll(".kpi-card[data-filter]").forEach(card => {
      card.addEventListener("click", () => {
        _applyMemberFilter(_memberFilter === card.dataset.filter ? null : card.dataset.filter);
      });
      card.addEventListener("keydown", e => {
        if (e.key === "Enter" || e.key === " ") { e.preventDefault(); card.click(); }
      });
    });

    document.getElementById("clear-kpi-filter")?.addEventListener("click", () => {
      _applyMemberFilter(null);
      document.querySelector(".main-content").scrollTo({ top: 0, behavior: "smooth" });
    });
  }

  /* ── Export ──────────────────────────────────────────── */
  function exportMembersTable(stats) {
    const headers = ["Member","Total","Active","Closed (7d)","Awaiting Feedback","In Progress","Perf Cases","Stale (5d+)","Avg Days Open"];
    const rows = stats.map(s => [
      Utils.shortName(s.member), s.cases.length, s.open.length, s.closed7d,
      s.await_.length, s.inprog.length, s.perf.length, s.stale.length, s.avgDays
    ].map(v => `"${v}"`).join(","));
    const csv  = [headers.join(","), ...rows].join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement("a");
    a.href = url;
    a.download = `team_performance_${new Date().toISOString().slice(0,10)}.csv`;
    document.body.appendChild(a); a.click();
    setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 1000);
  }


  /* ══════════════════════════════════════════════════════════════════════════
     Member Dashboard — 4 distinct chart helpers
  ══════════════════════════════════════════════════════════════════════════ */
  function _memCssClr(v) {
    try { return getComputedStyle(document.documentElement).getPropertyValue(v).trim() || v; }
    catch(e) { return v; }
  }
  function _memDestroyChart(canvas) {
    try { const ex = Chart.getChart ? Chart.getChart(canvas) : null; if (ex) ex.destroy(); } catch(e) {}
  }

  /* 1. Gradient vertical bars — blue→teal, rounded tops ─────────────────── */
  function _memGradBars(canvasId, items, onClick) {
    const canvas = document.getElementById(canvasId); if (!canvas) return;
    if (typeof Chart === "undefined") { setTimeout(() => _memGradBars(canvasId, items, onClick), 200); return; }
    _memDestroyChart(canvas);
    canvas.parentElement.style.height = "280px";
    const labels = items.map(d => d.name);
    const data   = items.map(d => d.count);
    const n = items.length;
    const colors = items.map((_, i) => {
      const t = n > 1 ? i / (n - 1) : 0;
      const r = Math.round(0x45 + (0x00 - 0x45) * t);
      const g = Math.round(0x89 + (0xBE - 0x89) * t);
      const b = Math.round(0xFF + (0x65 - 0xFF) * t);
      return "rgba("+r+","+g+","+b+",0.88)";
    });
    try { new Chart(canvas, {
      type: "bar",
      data: { labels, datasets: [{ data, backgroundColor: colors,
        hoverBackgroundColor: colors.map(c => c.replace("0.88","1")),
        borderRadius: 7, borderSkipped: false }] },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false }, tooltip: { backgroundColor: "#fff",
          borderColor: _memCssClr("--border-subtle"), borderWidth: 1,
          titleColor: _memCssClr("--text-primary"), bodyColor: _memCssClr("--text-secondary"),
          callbacks: { label: item => " " + item.raw + " cases" + (onClick ? " \u2014 click to view" : "") } } },
        scales: {
          x: { grid: { display: false }, border: { display: false },
               ticks: { color: _memCssClr("--text-tertiary"), font: { size: 10 }, maxRotation: 45 } },
          y: { grid: { color: "rgba(0,0,0,0.05)", drawTicks: false }, border: { display: false },
               ticks: { color: _memCssClr("--text-tertiary"), font: { size: 11 }, padding: 6 }, beginAtZero: true }
        },
        onClick: onClick ? (evt, els) => {
          if (els.length) { const fullName = items[els[0].index].fullName;
            setTimeout(() => { try { onClick(fullName); } catch(e) {} }, 0); }
        } : undefined
      }
    }); } catch(e) { console.warn("[Members] GradBars:", e); }
    if (onClick) canvas.style.cursor = "pointer";
  }

  /* 2. Doughnut chart — stale cases per member, center text + click-to-toggle ── */
  /* 2. Yearly Closed Donut — center = total active cases, click legend to toggle ── */
  /* 2. Stale Cases Donut — styled after Yearly Created (IBM palette, custom legend, toggle) ── */
  function _memHorizBar(canvasId, items) {
    const canvas = document.getElementById(canvasId); if (!canvas) return;
    if (typeof Chart === "undefined") { setTimeout(() => _memHorizBar(canvasId, items), 200); return; }
    _memDestroyChart(canvas);
    canvas.parentElement.style.height = "280px";

    const labels = items.map(d => d.name);
    const data   = items.map(d => d.count);
    const total  = data.reduce((s, v) => s + v, 0);
    const visible = labels.map(() => true);
    let visibleTotal = total;

    // IBM palette — same as Yearly Created
    const palette = ["#4589FF","#42BE65","#8A3FFC","#F1C21B","#FF832B","#33B1FF","#FA4D56","#08BDBA"];
    const FONT    = "'IBM Plex Sans','Helvetica Neue',Arial,sans-serif";

    const centerPlugin = {
      id: "staleCenterDonut_" + canvasId,
      afterDraw(chart) {
        const { ctx, chartArea: { left, right, top, bottom } } = chart;
        const cx = (left + right) / 2, cy = (top + bottom) / 2;
        ctx.save();
        ctx.textAlign = "center"; ctx.textBaseline = "middle";
        ctx.font = `700 ${Math.max(18, Math.min(26, (right - left) * 0.13))}px ${FONT}`;
        ctx.fillStyle = _memCssClr("--text-primary") || "#161616";
        ctx.fillText(visibleTotal.toLocaleString(), cx, cy - 8);
        ctx.font = `400 11px ${FONT}`;
        ctx.fillStyle = _memCssClr("--text-tertiary") || "#6f6f6f";
        ctx.fillText("Stale Cases", cx, cy + 12);
        ctx.restore();
      }
    };

    let chartInst;
    try {
      chartInst = new Chart(canvas, {
        type: "doughnut",
        plugins: [centerPlugin],
        data: {
          labels,
          datasets: [{
            data,
            backgroundColor:      labels.map((_, i) => palette[i % palette.length] + "dd"),
            borderColor:          labels.map((_, i) => palette[i % palette.length]),
            borderWidth: 2.5,
            hoverBackgroundColor: labels.map((_, i) => palette[i % palette.length]),
            hoverBorderWidth: 0,
            hoverOffset: 8
          }]
        },
        options: {
          responsive: true, maintainAspectRatio: false,
          cutout: "62%",
          animation: { animateRotate: true, animateScale: false, duration: 700, easing: "easeOutQuart" },
          plugins: {
            legend: { display: false },
            tooltip: {
              backgroundColor: _memCssClr("--bg-ui") || "#fff",
              borderColor: _memCssClr("--border-subtle"), borderWidth: 1,
              titleColor: _memCssClr("--text-primary"), bodyColor: _memCssClr("--text-secondary"),
              padding: 10, cornerRadius: 8,
              callbacks: {
                label: item => {
                  const pct = total ? ((item.raw / total) * 100).toFixed(1) : 0;
                  return `  ${item.raw} stale (${pct}%) — not updated 5+ days`;
                }
              }
            }
          }
        }
      });
    } catch(e) { console.warn("[Members] StaleCasesDonut:", e); }

    // ── Custom legend with toggle + strikeout (mirrors Yearly Created) ──────
    const legendEl = document.getElementById("chart-members-stale-legend");
    if (legendEl && chartInst) {
      legendEl.innerHTML = labels.map((lbl, i) => {
        const color = palette[i % palette.length];
        return `<span data-smidx="${i}" style="display:inline-flex;align-items:center;gap:4px;cursor:pointer;user-select:none;white-space:nowrap;">
          <span class="sm-swatch" style="display:inline-block;width:10px;height:10px;border-radius:2px;background:${color};flex-shrink:0;"></span>
          <span class="sm-text" style="color:${_memCssClr("--text-primary") || "#161616"};">${lbl} (${data[i]})</span>
        </span>`;
      }).join("");

      legendEl.querySelectorAll("span[data-smidx]").forEach(item => {
        item.addEventListener("click", () => {
          const i      = parseInt(item.dataset.smidx);
          const color  = palette[i % palette.length];
          const swatch = item.querySelector(".sm-swatch");
          const text   = item.querySelector(".sm-text");
          visible[i]   = !visible[i];
          chartInst.toggleDataVisibility(i);
          visibleTotal = data.reduce((s, v, idx) => s + (visible[idx] ? v : 0), 0);
          chartInst.update();
          swatch.style.background   = visible[i] ? color : "transparent";
          swatch.style.border       = visible[i] ? "none" : `1.5px solid ${color}`;
          text.style.color          = visible[i] ? (_memCssClr("--text-primary") || "#161616") : (_memCssClr("--text-tertiary") || "#6f6f6f");
          text.style.textDecoration = visible[i] ? "none" : "line-through";
        });
      });
    }

    canvas.style.cursor = "default";
  }

  /* 3. Gradient area line — smooth curve with blue gradient fill ─────────── */
  function _memAreaLine(canvasId, items) {
    const canvas = document.getElementById(canvasId); if (!canvas) return;
    if (typeof Chart === "undefined") { setTimeout(() => _memAreaLine(canvasId, items), 200); return; }
    _memDestroyChart(canvas);
    canvas.parentElement.style.height = "280px";
    const labels = items.map(d => d.name);
    const data   = items.map(d => d.count);
    const ctx2d  = canvas.getContext("2d");
    const grad   = ctx2d.createLinearGradient(0, 0, 0, 280);
    grad.addColorStop(0,   "rgba(69,137,255,0.40)");
    grad.addColorStop(0.6, "rgba(69,137,255,0.10)");
    grad.addColorStop(1,   "rgba(69,137,255,0.00)");
    try { new Chart(canvas, {
      type: "line",
      data: { labels, datasets: [{ data, borderColor: "#4589FF", backgroundColor: grad,
        borderWidth: 2.5, pointRadius: data.length > 15 ? 2 : 5, pointHoverRadius: 7,
        pointBackgroundColor: "#4589FF", pointBorderColor: "#fff", pointBorderWidth: 2,
        tension: 0.4, fill: true }] },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false }, tooltip: { backgroundColor: "#fff",
          borderColor: _memCssClr("--border-subtle"), borderWidth: 1,
          titleColor: _memCssClr("--text-primary"), bodyColor: _memCssClr("--text-secondary"),
          callbacks: { label: item => " " + item.raw + " total cases" } } },
        scales: {
          x: { grid: { display: false }, border: { display: false },
               ticks: { color: _memCssClr("--text-tertiary"), font: { size: 10 }, maxRotation: 45 } },
          y: { grid: { color: "rgba(0,0,0,0.05)", drawTicks: false }, border: { display: false },
               ticks: { color: _memCssClr("--text-tertiary"), font: { size: 11 }, padding: 6 }, beginAtZero: true }
        }
      }
    }); } catch(e) { console.warn("[Members] AreaLine:", e); }
  }

  /* 4. Radar chart — awaiting feedback per member ─────────────────────── */
  /* 4. Awaiting Feedback — Horizontal histogram, one bar per member ──────── */
  /* 4. Awaiting Feedback — styled after Charts.productBar (IBM Plex, blue→teal gradient, indexAxis:y) ── */
  function _memLollipop(canvasId, items) {
    const canvas = document.getElementById(canvasId); if (!canvas) return;
    if (typeof Chart === "undefined") { setTimeout(() => _memLollipop(canvasId, items), 200); return; }
    _memDestroyChart(canvas);
    canvas.parentElement.style.height = "280px";

    // Sort descending — longest bar on top (matches productBar's typical sort)
    const sorted = [...items].sort((a, b) => b.count - a.count);

    const FONT      = "'IBM Plex Sans','Helvetica Neue',Arial,sans-serif";
    const GRID_CLR  = "rgba(0,0,0,0.05)";
    const n         = sorted.length;

    // Blue→teal gradient — exact same formula as Charts._barGradient
    const gradColors = Array.from({ length: n }, (_, i) => {
      const t = n > 1 ? i / (n - 1) : 0;
      const r = Math.round(0x45 + (0x00 - 0x45) * t);
      const g = Math.round(0x89 + (0xBE - 0x89) * t);
      const b = Math.round(0xFF + (0x65 - 0xFF) * t);
      return `rgba(${r},${g},${b},0.85)`;
    });

    // Smart label abbreviation — same as productBar
    const abbrev = name => {
      let s = name
        .replace(/^IBM Engineering /, "")
        .replace(/^IBM Rational /, "")
        .replace(/^IBM /, "")
        .replace(" Management", " Mgmt")
        .replace(" Requirements", " Req.")
        .replace(" Workflow", " WF")
        .replace(" Lifecycle", " LC");
      return s.length > 28 ? s.slice(0, 26) + "…" : s;
    };

    const shortLabels = sorted.map(d => abbrev(d.name));
    const fullLabels  = sorted.map(d => d.fullName || d.name);
    const data        = sorted.map(d => d.count);

    try {
      new Chart(canvas, {
        type: "bar",
        data: {
          labels: shortLabels,
          datasets: [{
            data,
            backgroundColor: gradColors,
            borderColor:     gradColors.map(c => c.replace("0.85)", "1)")),
            borderWidth:  0,
            borderRadius: 6,
            borderSkipped: false
          }]
        },
        options: {
          indexAxis: "y",
          responsive: true, maintainAspectRatio: false,
          layout: { padding: { left: 0 } },
          plugins: {
            legend: { display: false },
            tooltip: {
              backgroundColor: _memCssClr("--bg-ui") || "#fff",
              borderColor:  _memCssClr("--border-subtle"), borderWidth: 1,
              titleColor:   _memCssClr("--text-primary"),
              bodyColor:    _memCssClr("--text-secondary"),
              bodyFont:  { family: FONT, size: 12 },
              padding: 10, cornerRadius: 8,
              callbacks: {
                title:  items => fullLabels[items[0].dataIndex] || items[0].label,
                label:  item  => `  ${item.raw} awaiting feedback`
              }
            }
          },
          scales: {
            x: {
              beginAtZero: true,
              grid:   { color: GRID_CLR, drawTicks: false },
              border: { display: false },
              ticks:  { color: _memCssClr("--text-tertiary") || "#6f6f6f",
                        font: { family: FONT, size: 10 }, padding: 6,
                        maxRotation: 0, minRotation: 0, stepSize: 1 }
            },
            y: {
              grid:   { display: false },
              border: { display: false },
              ticks:  { color: _memCssClr("--text-tertiary") || "#6f6f6f",
                        font: { family: FONT, size: 10.5 },
                        maxRotation: 0, minRotation: 0, autoSkip: false },
              afterFit: axis => { axis.width = Math.max(axis.width, 160); }
            }
          }
        }
      });
    } catch(e) { console.warn("[Members] AwaitProductBar:", e); }
  }

  return { render };
})();
