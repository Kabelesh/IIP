/* ============================================================
   js/dashboards/team.js  —  Team Cases tab
   ============================================================ */
const DashTeam = (() => {
  /* ── Loading state helper ─────────────────────────────────────
     Usage: _setLoading(true) before data fetch, _setLoading(false) after.
     Applies .is-loading class to the dashboard root element.
  ────────────────────────────────────────────────────────────── */
  function _setLoading(active) {
    const el = document.getElementById('content-area') || document.body;
    el.classList.toggle('dashboard-loading', active);
    // Show/hide skeleton shimmer on tables
    document.querySelectorAll('.table-wrap, .dash-table').forEach(t => {
      t.classList.toggle('skeleton-loading', active);
    });
  }


  let _filterOwner   = "";
  let _filterStatus  = "";
  let _filterDays    = "";
  let _filterTeam    = "";
  let _tableRef      = null;
  let _memberTeamMap = {}; // name → team, built from DynamicConfig.teamGroups()

  async function _loadMemberTeams() {
    try {
      if (typeof DynamicConfig === 'undefined') return;
      const groups = DynamicConfig.teamGroups ? DynamicConfig.teamGroups() : {};
      _memberTeamMap = {};
      Object.entries(groups).forEach(([nameLower, team]) => {
        _memberTeamMap[nameLower] = team;
      });
    } catch(e) {
      console.warn('[DashTeam] Failed to load member teams:', e);
    }
  }

  // Save filter state to StateManager (production-grade persistence)
  function _saveFilters() {
    if (typeof StateManager !== "undefined") {
      StateManager.saveFiltersForDashboard("team", {
        owner: _filterOwner,
        status: _filterStatus,
        days: _filterDays,
        team: _filterTeam
      });
    }
  }

  // Update filter badge: shows count of active filters
  function _updateFilterBadge() {
    const badge = document.getElementById("filter-count-badge");
    if (!badge) return;
    const count = (_filterOwner?1:0) + (_filterStatus?1:0) + (_filterDays?1:0) + (_filterTeam?1:0);
    badge.style.display = count > 0 ? 'inline-flex' : 'none';
    badge.textContent = count;
  }

  async function render() {
    const el = document.getElementById("tab-team");
    if (!el) return;

    // Restore filter state from StateManager (production-grade persistence)
    if (typeof StateManager !== "undefined") {
      const savedFilters = StateManager.getFiltersForDashboard("team");
      if (savedFilters.owner !== undefined) _filterOwner = savedFilters.owner;
      if (savedFilters.status !== undefined) _filterStatus = savedFilters.status;
      if (savedFilters.days !== undefined) _filterDays = savedFilters.days;
      if (savedFilters.team !== undefined) _filterTeam = savedFilters.team;
    }

    const team    = Data.teamCases();
    // Include ALL members (active + departed) from _memberTeamMap
    // _memberTeamMap is populated by _loadMemberTeams() below

    const statusOpts = [
      { value: "__inprogress__", label: "In Progress (All)" },
      { value: "__closed__",     label: "Closed (All)" },
      { value: "Awaiting your feedback", label: "Awaiting your feedback" },
      { value: "IBM is working",         label: "IBM is working" },
      { value: "Waiting for IBM",        label: "Waiting for IBM" },
      { value: "Closed by IBM",          label: "Closed by IBM" },
      { value: "Closed by Client",       label: "Closed by Client" },
      { value: "Closed - Archived",      label: "Closed - Archived" },
    ].map(s => `<option value="${Utils.escHtml(s.value)}" ${s.value===_filterStatus?"selected":""}>${Utils.escHtml(s.label)}</option>`)
     .join("");

    // Load team data from DB via API, then build unique teams
    await _loadMemberTeams();
    const uniqueTeams = new Set(Object.values(_memberTeamMap).filter(t => t.trim()));
    const teamOpts = Array.from(uniqueTeams).sort()
      .map(t => `<option value="${Utils.escHtml(t)}" ${t===_filterTeam?"selected":""}>${Utils.escHtml(t)}</option>`)
      .join("");

    el.innerHTML = `
      <div class="kpi-row" id="team-kpi-row"></div>

      <!-- Toolbar: Send Mail button + filters -->
      <div class="filter-bar mt-5">
        <div class="filter-group" style="position:relative">
          <span class="filter-label">Owner</span>
          <input id="tf-owner-search" type="text" class="form-input form-input-sm"
            placeholder="Search owner…" autocomplete="off"
            style="min-width:180px;cursor:pointer" readonly/>
        </div>
        <div class="filter-group">
          <span class="filter-label">Status</span>
          <select id="tf-status" class="form-select min-200">
            <option value="">All Statuses</option>${statusOpts}
          </select>
        </div>
        <div class="filter-group">
          <span class="filter-label">Last Updated ≥ (days)</span>
          <input id="tf-days" type="number" class="form-input form-input-sm"
            style="width:90px" placeholder="e.g. 5" value="${Utils.escHtml(_filterDays)}"/>
        </div>
        <div class="filter-group">
          <span class="filter-label">Team</span>
          <select id="tf-team" class="form-select min-160">
            <option value="">All Teams</option>${teamOpts}
          </select>
        </div>
        <div style="display:flex;align-items:center;gap:6px">
          <button id="tf-clear" aria-label="Clear team filter" class="btn btn-ghost btn-sm">Clear</button>
          <span id="filter-count-badge" style="display:${_filterOwner || _filterStatus || _filterDays ? 'inline-flex' : 'none'};align-items:center;justify-content:center;background:var(--ibm-blue-50);color:white;font-size:11px;font-weight:600;border-radius:50%;width:20px;height:20px;min-width:20px">${(_filterOwner?1:0)+(_filterStatus?1:0)+(_filterDays?1:0)}</span>
        </div>
        <button id="tf-send-mail" aria-label="Send reminder mail" class="btn btn-primary btn-sm">✉ Send Reminder Mail</button>
      </div>

      <div class="tile mt-5">
        <div class="section-title">Owner vs Case Count</div>
        <div class="chart-canvas-wrap" style="height:300px"><canvas id="chart-team-owners"></canvas></div>
      </div>

      <div class="tile mt-5">
        <div id="tbl-team" data-title="Case Details"></div>
      </div>
    `;

    const filtered = filteredCases();
    renderKPIs(filtered);

    try { Charts.ownerBar("chart-team-owners", Utils.ownerCounts(filtered), {
      color: "#0043ce",
      onClick: ownerName => {
        // Toggle: if clicking same owner, clear filter; otherwise set to that owner
        if (_filterOwner === ownerName) {
          _filterOwner = "";
          document.getElementById("tf-owner-search").value = "";
        } else {
          _filterOwner = ownerName;
          document.getElementById("tf-owner-search").value = Utils.shortName(ownerName);
        }
        _saveFilters();
        _updateFilterBadge();
        applyFilters();
        // Scroll to table after a brief delay to let filters apply
        setTimeout(() => {
          const tableEl = document.getElementById("tbl-team");
          if (tableEl) tableEl.scrollIntoView({ behavior: "smooth", block: "start" });
        }, 100);
      }
    }); } catch(e) { console.warn("[DashTeam] chart error:", e); }

    // ── SearchableSelect owner dropdown ──────────────
    (function() {
      const searchInput = document.getElementById("tf-owner-search");
      if (!searchInput) return;

      const ssInst = SearchableSelect.create({
        trigger:     searchInput,
        valueEl:     null,
        members:     [],
        placeholder: 'Search owner…',
        onSelect: function(value, label) {
          _filterOwner = value;
          _saveFilters();
          _updateFilterBadge();
          applyFilters();
        }
      });

      const tok = sessionStorage.getItem("ibm_admin_token_v1") || "";
      fetch("/iip/api/admin/team-members", { headers: { "x-iip-admin-token": tok } })
        .then(function(r) { return r.ok ? r.json() : Promise.reject(); })
        .then(function(apiMembers) {
          const active   = apiMembers.filter(m => (m.status || "Active") === "Active").sort((a,b) => a.name.localeCompare(b.name));
          const departed = apiMembers.filter(m => m.status === "Departed").sort((a,b) => a.name.localeCompare(b.name));
          ssInst.setMembers([
            ...active.map(m   => ({ value: m.name, label: m.display_name || m.name })),
            ...departed.map(m => ({ value: m.name, label: m.display_name || m.name, group: "Departed" }))
          ]);
        })
        .catch(function() {
          const fallback = [...new Set((Data.allCases ? Data.allCases() : []).map(c => c.Owner || "").filter(Boolean))].sort();
          ssInst.setMembers(fallback.map(n => ({ value: n, label: n })));
        });

      if (_filterOwner) ssInst._setTriggerText(Utils.shortName ? Utils.shortName(_filterOwner) : _filterOwner);
    })();

    document.getElementById("tf-status").addEventListener("change", e => { _filterStatus = e.target.value; _saveFilters(); _updateFilterBadge(); applyFilters(); });
    document.getElementById("tf-days").addEventListener("input",  e => { _filterDays = e.target.value; _saveFilters(); _updateFilterBadge(); applyFilters(); });
    document.getElementById("tf-team").addEventListener("change", e => { _filterTeam = e.target.value; _saveFilters(); _updateFilterBadge(); applyFilters(); });
    document.getElementById("tf-clear").addEventListener("click", () => {
      _filterOwner=""; _filterStatus=""; _filterDays=""; _filterTeam="";
      const tos = document.getElementById("tf-owner-search"); if(tos){tos.value="";}
      const tod = document.getElementById("tf-owner-dropdown"); if(tod) tod.style.display="none";
      document.getElementById("tf-status").value="";
      document.getElementById("tf-days").value="";
      document.getElementById("tf-team").value="";
      _saveFilters();
      _updateFilterBadge();
      applyFilters();
    });

    // Send Reminder Mail — opens Outlook directly, no restrictions
    document.getElementById("tf-send-mail").addEventListener("click", () => {
      const visible = filteredCases();
      if (!visible.length) { alert("No cases in current view."); return; }
      Mail.openReminderPreview(visible);
    });

    const container = document.getElementById("tbl-team");
    const tableOpts = {
      showActions: true,
      showRemind: false,
      showReassign: Data.isAdmin(),
      onReassign: row => {
        Modal.showReassign(row, (caseNum, newOwner) => {
          const prevOwner = row.Owner;
          Data.reassignCase(caseNum, newOwner);
          if (typeof DashWeeklyTracker !== "undefined") DashWeeklyTracker.enrichFromCases(Data.allCases());
          render();
          // Tier 4.3: Push undo action
          if (typeof PerfUtils !== "undefined") {
            PerfUtils.pushAction({
              name: `Reassigned ${Utils.shortName(caseNum)} → ${Utils.shortName(newOwner)}`,
              undo: () => { Data.reassignCase(caseNum, prevOwner); render(); },
            });
          }
          // Tier 5.3: Celebrate success
          if (typeof Polish !== "undefined") {
            Polish.Celebrate.show({
              title: `Case reassigned`,
              message: `${caseNum} → ${Utils.shortName(newOwner)}`,
              count: 1,
              duration: 2500,
            });
          }
        });
      },
      extraCols: [lastUpdatedDaysCol()],
      defaultSortKey: "_lastUpdDays",
      defaultSortDir: -1   // oldest (highest days) first
    };

    // Only add clear button callback if owner filter is active
    if (_filterOwner) {
      tableOpts.onClear = () => {
        _filterOwner = "";
        document.getElementById("tf-owner-search").value = "";
        _saveFilters();
        _updateFilterBadge();
        applyFilters();
        setTimeout(() => {
          const chartEl = document.querySelector(".chart-canvas-wrap");
          if (chartEl) chartEl.scrollIntoView({ behavior: "smooth", block: "start" });
        }, 100);
      };
    }

    _tableRef = Table.render(container, filtered, tableOpts);

  }

  // Opens Outlook with mailto — matches screenshot format with table rows
  function lastUpdatedDaysCol() {
    return {
      key: "_lastUpdDays", label: "Last Updated (Days)", sortable: true,
      render: row => {
        const d = Utils.parseDate(row.Updated) || Utils.parseDate(row.Created);
        const days = Utils.daysDiff(d);
        const color = days >= 10 ? "var(--red)" : days >= 5 ? "var(--yellow)" : "var(--text-tertiary)";
        return `<span style="color:${color};font-family:var(--font-mono);font-weight:600">${days}</span>`;
      },
      sortValue: row => {
        const d = Utils.parseDate(row.Updated) || Utils.parseDate(row.Created);
        return Utils.daysDiff(d);
      }
    };
  }

  function renderKPIs(cases) {
    const row = document.getElementById("team-kpi-row");
    if (!row) return;
    const today   = new Date();
    const active  = cases.filter(r => !Utils.isClosed(r.Status));
    const inprog  = active.filter(r => r.Status==="IBM is working"||r.Status==="Waiting for IBM");
    const await_  = active.filter(r => r.Status==="Awaiting your feedback");
    const members = new Set(active.map(r=>r.Owner)).size;
    const closed7 = cases.filter(r => {
      if (!Utils.isClosed(r.Status)) return false;
      const d = Utils.parseDate(r["Closed Date"]) || Utils.parseDate(r.Updated);
      if (!d) return false;
      return (today - d) >= 0 && (today - d) <= 7 * 86400000;
    });
    const custActive = Data.customerCases().filter(r => !Utils.isClosed(r.Status)).length;
    row.innerHTML = [
      kpi("Total Cases",       active.length,             "kpi-yellow"),
      kpi("In Progress",        inprog.length,             "kpi-blue",
          "IBM Working: "+active.filter(r=>r.Status==="IBM is working").length+" · Waiting: "+active.filter(r=>r.Status==="Waiting for IBM").length),
      kpi("Awaiting Feedback",  await_.length,             "kpi-red"),
      kpi("Closed (Last 7days)",   closed7.length,            "kpi-green"),
      kpi("Active Members",     Data.teamMembers().length, "kpi-purple"),
    ].join("");
  }

  function filteredCases() {
    return Data.teamCases().filter(r => {
      if (_filterOwner && r.Owner !== _filterOwner) return false;
      if (_filterStatus) {
        if (_filterStatus === "__inprogress__") {
          if (Utils.isClosed(r.Status)) return false;
        } else if (_filterStatus === "__closed__") {
          if (!Utils.isClosed(r.Status)) return false;
        } else {
          if (r.Status !== _filterStatus) return false;
        }
      }
      if (_filterDays) {
        const d = Utils.parseDate(r.Updated) || Utils.parseDate(r.Created);
        if (Utils.daysDiff(d) < parseInt(_filterDays)) return false;
      }
      if (_filterTeam && _memberTeamMap[(r.Owner||"").toLowerCase()] !== _filterTeam) return false;
      return true;
    });
  }

  function applyFilters() {
    const cases = filteredCases();
    renderKPIs(cases);
    // Redraw histogram with filtered data
    try { Charts.ownerBar("chart-team-owners", Utils.ownerCounts(cases), {
      color: "#0043ce",
      onClick: ownerName => {
        // Toggle: if clicking same owner, clear filter; otherwise set to that owner
        if (_filterOwner === ownerName) {
          _filterOwner = "";
          document.getElementById("tf-owner-search").value = "";
        } else {
          _filterOwner = ownerName;
          document.getElementById("tf-owner-search").value = Utils.shortName(ownerName);
        }
        applyFilters();
        // Scroll to table after a brief delay to let filters apply
        setTimeout(() => {
          const tableEl = document.getElementById("tbl-team");
          if (tableEl) tableEl.scrollIntoView({ behavior: "smooth", block: "start" });
        }, 100);
      }
    }); } catch(e) { console.warn("[DashTeam] chart error:", e); }
    if (_tableRef) _tableRef.refresh(cases);
  }

  function kpi(label, value, cls="", sub="") {
    return `<div class="kpi-card ${cls}">
      <div class="kpi-label">${label}</div>
      <div class="kpi-value">${value}</div>
      ${sub ? `<div class="text-meta-top">${sub}</div>` : ""}
    </div>`;
  }

  return {
    render,
    // F24: Stable method for global search to pre-fill team search without fragile DOM query
    setSearch: val => { if (_tableRef) _tableRef.setSearch(val); }
  };

})();
