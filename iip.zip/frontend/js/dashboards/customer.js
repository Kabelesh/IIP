/* ============================================================
   js/dashboards/customer.js  —  Customer Cases tab
   ============================================================ */
const DashCustomer = (() => {
  /* ── Loading state helper ─────────────────────────────────────
     Usage: _setLoading(true) before data fetch, _setLoading(false) after.
     Applies .is-loading class to the dashboard root element.
  ────────────────────────────────────────────────────────────── */
  function _setLoading(active) {
    const el = document.getElementById('content-area') || document.body;
    el.classList.toggle('dashboard-loading', active);
    // Show/hide skeleton shimmer on tables
    document.querySelectorAll('.table-wrap, .dash-table').forEach(t => {
      t.classList.toggle('skeleton-loading', active);
    });
  }

  let _year="", _month="", _status="", _fromDate="", _toDate="", _lastDays="";
  let _ownerFilter="";
  let _tableRef = null;

  function render() {
    const el = document.getElementById("tab-customer");
    if (!el) return;
    _tableRef = null; // reset so drawAll creates a fresh table instance
    el.querySelectorAll("canvas").forEach(c => {
      try { const ch = (typeof Chart !== "undefined" && Chart.getChart) ? Chart.getChart(c) : null; if (ch) ch.destroy(); } catch(e) {}
    });

    // Only 2 status options: In Progress and Closed
    const statusOpts = [
      { label: "In Progress",  value: "__inprogress__" },
      { label: "Closed Cases", value: "__closed__"     },
    ].map(s=>`<option value="${s.value}" ${_status===s.value?"selected":""}>${s.label}</option>`)
     .join("");

    el.innerHTML = `
      <div class="kpi-row" id="cust-kpi-row"></div>
      <div class="filter-bar mt-5">
        ${yearSelect("cu-year",_year)} ${monthSelect("cu-month",_month)}
        <div class="filter-group">
          <span class="filter-label">Status</span>
          <select id="cu-status" aria-label="Filter by status" class="form-select" style="min-width:160px">
            <option value="">All</option>${statusOpts}
          </select>
        </div>
        <div class="filter-group">
          <span class="filter-label">From</span>
          <input id="cu-from" aria-label="From date" type="date" class="form-input form-input-sm w-140" value="${_fromDate}"/>
        </div>
        <div class="filter-group">
          <span class="filter-label">To</span>
          <input id="cu-to" aria-label="To date" type="date" class="form-input form-input-sm w-140" value="${_toDate}"/>
        </div>
        <div class="filter-group">
          <span class="filter-label">Last N Days</span>
          <input id="cu-lastdays" aria-label="Last N days" type="number" class="form-input form-input-sm w-80" placeholder="e.g. 5" value="${_lastDays}"/>
        </div>
        <button id="cu-clear" class="btn btn-ghost btn-sm">Clear</button>
      </div>
      <div class="grid-3 mt-5" id="cu-charts-grid">
        <div class="tile">
          <div class="section-title mt-0">Monthly Customer</div>
          <div class="chart-canvas-wrap chart-md"><canvas id="chart-cust-monthly"></canvas></div>
        </div>
        <div class="tile">
          <div class="section-title mt-0">Weekly Customer (Last 12w)</div>
          <div class="chart-canvas-wrap chart-md"><canvas id="chart-cust-weekly"></canvas></div>
        </div>
        <div class="tile">
          <div class="section-title mt-0">Yearly Customer</div>
          <div class="chart-canvas-wrap chart-md"><canvas id="chart-cust-yearly"></canvas></div>
          <div id="chart-cust-yearly-legend" style="display:flex;flex-wrap:wrap;gap:4px 12px;justify-content:center;padding:6px 4px 0;font-size:11px;font-family:'IBM Plex Sans',sans-serif;"></div>
        </div>
      </div>
      <div class="tile mt-5">
        <div class="section-title">Owner vs Customer Cases Count</div>
        <div class="chart-canvas-wrap" style="height:300px"><canvas id="chart-cust-owners"></canvas></div>
      </div>
      <div class="tile mt-5">
        <div id="tbl-cust" data-title="Customer Cases"></div>
      </div>
    `;

    document.getElementById("cu-status")?.addEventListener("change",e=>{_status=e.target.value;_ownerFilter="";drawAll();});
    document.getElementById("cu-year")?.addEventListener("change",e=>{_year=e.target.value;_ownerFilter="";drawAll();});
    document.getElementById("cu-month")?.addEventListener("change",e=>{_month=e.target.value;_ownerFilter="";drawAll();});
    document.getElementById("cu-from")?.addEventListener("change",e=>{_fromDate=e.target.value;_year="";_month="";document.getElementById("cu-year").value="";document.getElementById("cu-month").value="";_ownerFilter="";drawAll();});
    document.getElementById("cu-to")?.addEventListener("change",e=>{_toDate=e.target.value;_year="";_month="";document.getElementById("cu-year").value="";document.getElementById("cu-month").value="";_ownerFilter="";drawAll();});
    document.getElementById("cu-lastdays")?.addEventListener("input",e=>{_lastDays=e.target.value;_year="";_month="";_fromDate="";_toDate="";document.getElementById("cu-year").value="";document.getElementById("cu-month").value="";document.getElementById("cu-from").value="";document.getElementById("cu-to").value="";_ownerFilter="";drawAll();});
    document.getElementById("cu-clear")?.addEventListener("click",()=>{
      _status="";_year="";_month="";_fromDate="";_toDate="";_lastDays="";_ownerFilter="";
      document.getElementById("cu-status").value="";
      document.getElementById("cu-year").value="";
      document.getElementById("cu-month").value="";
      document.getElementById("cu-from").value="";
      document.getElementById("cu-to").value="";
      document.getElementById("cu-lastdays").value="";
      drawAll();
    });

    try { drawAll(); } catch(e) {
      console.warn("[DashCustomer] render error:", e);
      try {
        const tblEl = document.getElementById("tbl-cust");
        const cases = Data.customerCases();
        if (tblEl && cases.length) Table.render(tblEl, cases, { showActions: false });
        else if (tblEl) tblEl.innerHTML = '<div style="padding:40px;text-align:center;color:var(--text-tertiary)">No customer cases found. Upload a CSV/Excel file to get started.</div>';
      } catch(e2) {}
    }
  }

  function filtered() {
    const today = new Date();
    return Data.customerCases().filter(r => {
      // Status group filter
      if (_status === "__inprogress__") {
        if (Utils.isClosed(r.Status)) return false;
      } else if (_status === "__closed__") {
        if (!Utils.isClosed(r.Status)) return false;
      }
      // Year/Month/From/To: use Created date (when the case was opened)
      const d = Utils.parseDate(r.Created) || Utils.parseDate(r["Closed Date"]);
      if (_year  && (!d || String(d.getFullYear())!==_year)) return false;
      if (_month && (!d || String(d.getMonth()+1).padStart(2,"0")!==_month)) return false;
      if (_fromDate && (!d || d < new Date(_fromDate))) return false;
      if (_toDate   && (!d || d > new Date(_toDate + "T23:59:59"))) return false;
      // Last N Days: use Updated (last IBM activity) so active old cases are included
      if (_lastDays && _lastDays > 0) {
        const cutoff = new Date(today); cutoff.setDate(today.getDate() - parseInt(_lastDays, 10));
        const dActivity = Utils.parseDate(r.Updated) || Utils.parseDate(r.Created) || Utils.parseDate(r["Closed Date"]);
        if (!dActivity || dActivity < cutoff) return false;
      }
      return true;
    });
  }

  function drawAll(ownerFilter) {
    if (ownerFilter !== undefined) _ownerFilter = ownerFilter;
    const cases = filtered();
    let tableData = _ownerFilter ? cases.filter(r=>r.Owner===_ownerFilter) : cases;

    renderKPIs(cases);

    const cuLastDaysMode = !!(_lastDays && parseInt(_lastDays,10) > 0);
    const cuGrid = document.getElementById("cu-charts-grid");
    if (cuGrid) cuGrid.style.display = cuLastDaysMode ? "none" : "";
    if (!cuLastDaysMode) { try { _drawTrendCharts(cases); } catch(e) { console.warn("[DashCustomer] trend charts:", e); } }

    try {
      const ownerData = Utils.ownerCounts(cases);
      Charts.ownerBar("chart-cust-owners", ownerData, {
        color:"var(--purple)",
        onClick: name => drawAll(name === _ownerFilter ? "" : name)
      });
    } catch(e) { console.warn("[DashCustomer] ownerBar error:", e); }

    const tblEl = document.getElementById("tbl-cust");
    if (_tableRef) {
      _tableRef.refresh(tableData);
    } else {
      _tableRef = Table.render(tblEl, tableData, { showActions:false });
    }
  }

  function renderKPIs(cases) {
    const row=document.getElementById("cust-kpi-row");
    if(!row) return;
    const allCust = Data.customerCases(); // always use full set for closed KPI
    const open  =cases.filter(r=>!Utils.isClosed(r.Status));
    const close =cases.filter(r=> Utils.isClosed(r.Status));
    const inprog=cases.filter(r=>r.Status==="IBM is working"||r.Status==="Waiting for IBM");
    const closed7d = allCust.filter(r => {
      if (!Utils.isClosed(r.Status)) return false;
      const d = Utils.parseDate(r["Closed Date"]) || Utils.parseDate(r.Updated) || Utils.parseDate(r.Created);
      return d && (Utils.today() - d) / 86400000 <= 7;
    });
    row.innerHTML=[
      kpi("Total Customer Cases", cases.length,     ""),
      kpi("In Progress",          open.length,      "kpi-yellow"),
      kpi("Closed (Last 7days)",     closed7d.length,  "kpi-green"),
      kpi("IBM Working",          inprog.length,    "kpi-blue"),
    ].join("");
  }

  function kpi(label,value,cls){
    return `<div class="kpi-card ${cls}"><div class="kpi-label">${label}</div><div class="kpi-value">${value}</div></div>`;
  }

  /* ── Shared filter helpers (self-contained) ── */
  function yearSelect(id, selected) {
    const yearsFromData = (() => {
      try {
        const all = Data.allCases();
        const ySet = new Set();
        all.forEach(r => {
          ["Created", "Closed Date"].forEach(col => {
            const v = (r[col] || "").trim();
            if (!v) return;
            const d = Utils.parseDate(v);
            if (d && !isNaN(d)) ySet.add(d.getFullYear());
          });
        });
        return [...ySet].sort();
      } catch(e) { return [2023, 2024, 2025, 2026]; }
    })();
    const opts = yearsFromData.map(y =>
      `<option value="${y}" ${String(y)===String(selected)?"selected":""}>${y}</option>`).join("");
    return `<div class="filter-group"><span class="filter-label">Year</span>
      <select id="${id}" class="form-select w-100">
        <option value="">All</option>${opts}</select></div>`;
  }

  function monthSelect(id, selected) {
    const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    const opts = months.map((m,i) => {
      const v = String(i+1).padStart(2,"0");
      return `<option value="${v}" ${v===selected?"selected":""}>${m}</option>`;
    }).join("");
    return `<div class="filter-group"><span class="filter-label">Month</span>
      <select id="${id}" class="form-select w-100">
        <option value="">All</option>${opts}</select></div>`;
  }


  /* ── Trend chart helpers (Monthly / Weekly / Yearly) ───────────────────── */
  function _cuCssClr(v) {
    try { return getComputedStyle(document.documentElement).getPropertyValue(v).trim() || v; }
    catch(e) { return v; }
  }
  function _cuIsoWeekKey(d) {
    const yr = d.getFullYear(), jan1Day = new Date(yr,0,1).getDay();
    const w1Sun = new Date(yr, 0, 1 - jan1Day);
    const target = new Date(yr, d.getMonth(), d.getDate());
    if (target < w1Sun) return _cuIsoWeekKey(new Date(yr-1, 11, 31));
    return yr + "-W" + String(Math.floor((target - w1Sun)/(7*86400000))+1).padStart(2,"0");
  }
  function _drawTrendCharts(cases) {
    const byMonth={}, byWeek={}, byYear={};
    cases.forEach(r => {
      const d = Utils.parseDate(r.Created) || Utils.parseDate(r["Closed Date"]);
      if (!d) return;
      const mKey = d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0");
      byMonth[mKey] = (byMonth[mKey]||0)+1;
      const wKey = _cuIsoWeekKey(d); byWeek[wKey] = (byWeek[wKey]||0)+1;
      const yKey = String(d.getFullYear()); byYear[yKey] = (byYear[yKey]||0)+1;
    });
    // Monthly — gradient area chart
    const allMonths = Object.keys(byMonth).sort().slice(-18);
    _cuDrawAreaChart("chart-cust-monthly",
      allMonths.map(k => k.slice(5)+"/"+k.slice(0,4)),
      allMonths.map(k => byMonth[k]),
      label => {
        const [mm,yyyy] = label.split("/");
        _fromDate = yyyy+"-"+mm+"-01";
        _toDate = yyyy+"-"+mm+"-"+String(new Date(parseInt(yyyy),parseInt(mm),0).getDate()).padStart(2,"0");
        _year=yyyy; _month=mm; _lastDays="";
        ["cu-year","cu-month","cu-from","cu-to","cu-lastdays"].forEach(id => {
          const el=document.getElementById(id); if(!el) return;
          el.value = id==="cu-year"?yyyy : id==="cu-month"?mm : id==="cu-from"?_fromDate : id==="cu-to"?_toDate : "";
        });
        _ownerFilter=""; drawAll();
        document.getElementById("tbl-cust")?.scrollIntoView({behavior:"smooth",block:"start"});
      });
    // Weekly — gradient rounded bars blue->teal
    const allWeeks = Object.keys(byWeek).sort().slice(-12);
    _cuDrawGradientBars("chart-cust-weekly", allWeeks, allWeeks.map(k=>byWeek[k]), wkKey => {
      const [yr,wn] = wkKey.split("-W");
      const jan1=new Date(parseInt(yr),0,1), startOfWk=new Date(jan1);
      startOfWk.setDate(jan1.getDate()+(parseInt(wn)-1)*7-jan1.getDay());
      const endOfWk=new Date(startOfWk); endOfWk.setDate(startOfWk.getDate()+6);
      const fmt=d=>d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0");
      _fromDate=fmt(startOfWk); _toDate=fmt(endOfWk); _year=""; _month=""; _lastDays="";
      ["cu-year","cu-month","cu-lastdays"].forEach(id=>{const el=document.getElementById(id);if(el)el.value="";});
      const fe=document.getElementById("cu-from"); if(fe) fe.value=_fromDate;
      const te=document.getElementById("cu-to");   if(te) te.value=_toDate;
      _ownerFilter=""; drawAll();
      document.getElementById("tbl-cust")?.scrollIntoView({behavior:"smooth",block:"start"});
    });
    // Yearly — donut
    const allYears = Object.keys(byYear).sort();
    _cuDrawPolarArea("chart-cust-yearly", allYears, allYears.map(k=>byYear[k]), label => {
      _year=label; _month=""; _fromDate=""; _toDate=""; _lastDays="";
      ["cu-year","cu-month","cu-from","cu-to","cu-lastdays"].forEach(id=>{
        const el=document.getElementById(id); if(!el) return; el.value=id==="cu-year"?label:"";
      });
      _ownerFilter=""; drawAll();
      document.getElementById("tbl-cust")?.scrollIntoView({behavior:"smooth",block:"start"});
    });
  }
  function _cuDrawAreaChart(canvasId, labels, data, onPointClick) {
    const canvas=document.getElementById(canvasId); if(!canvas) return;
    if(typeof Chart==="undefined"){setTimeout(()=>_cuDrawAreaChart(canvasId,labels,data,onPointClick),200);return;}
    try{const ex=Chart.getChart?Chart.getChart(canvas):null;if(ex)ex.destroy();}catch(e){}
    const ctx2d=canvas.getContext("2d");
    const grad=ctx2d.createLinearGradient(0,0,0,canvas.offsetHeight||220);
    grad.addColorStop(0,"rgba(69,137,255,0.38)"); grad.addColorStop(0.6,"rgba(69,137,255,0.10)"); grad.addColorStop(1,"rgba(69,137,255,0.00)");
    try{new Chart(canvas,{type:"line",data:{labels,datasets:[{data,borderColor:"#4589FF",backgroundColor:grad,borderWidth:2.5,
      pointRadius:data.length>12?2:4,pointHoverRadius:6,pointBackgroundColor:"#4589FF",pointBorderColor:"#fff",pointBorderWidth:2,tension:0.4,fill:true}]},
      options:{responsive:true,maintainAspectRatio:false,
        plugins:{legend:{display:false},tooltip:{backgroundColor:"#fff",borderColor:_cuCssClr("--border-subtle"),borderWidth:1,
          titleColor:_cuCssClr("--text-primary"),bodyColor:_cuCssClr("--text-secondary"),
          callbacks:{label:item=>" "+item.raw+" cases \u2014 click to filter"}}},
        scales:{x:{grid:{display:false},border:{display:false},ticks:{color:_cuCssClr("--text-tertiary"),font:{size:10},maxRotation:45}},
                y:{grid:{color:"rgba(0,0,0,0.05)",drawTicks:false},border:{display:false},ticks:{color:_cuCssClr("--text-tertiary"),font:{size:11},padding:8},beginAtZero:true}},
        onClick:onPointClick?(evt,els)=>{if(els.length){const lbl=labels[els[0].index];setTimeout(()=>{try{onPointClick(lbl);}catch(e){console.warn("[DashCustomer] area onClick:",e);}},0);}}:undefined
      }})}catch(e){console.warn("[DashCustomer] Area chart:",e);}
    if(onPointClick)canvas.style.cursor="pointer";
  }
  function _cuDrawGradientBars(canvasId, keys, data, onBarClick) {
    const canvas=document.getElementById(canvasId); if(!canvas) return;
    if(typeof Chart==="undefined"){setTimeout(()=>_cuDrawGradientBars(canvasId,keys,data,onBarClick),200);return;}
    try{const ex=Chart.getChart?Chart.getChart(canvas):null;if(ex)ex.destroy();}catch(e){}
    const n=keys.length;
    const colors=keys.map((_,i)=>{const t=n>1?i/(n-1):0;const r=Math.round(0x45+(0x00-0x45)*t);const g=Math.round(0x89+(0xBE-0x89)*t);const b=Math.round(0xFF+(0x65-0xFF)*t);return"rgba("+r+","+g+","+b+",0.85)";});
    const labels=keys.map(k=>k.replace(/-W/,"-W"));
    try{new Chart(canvas,{type:"bar",data:{labels,datasets:[{data,backgroundColor:colors,hoverBackgroundColor:colors.map(c=>c.replace("0.85","1")),borderRadius:7,borderSkipped:false}]},
      options:{responsive:true,maintainAspectRatio:false,
        plugins:{legend:{display:false},tooltip:{backgroundColor:"#fff",borderColor:_cuCssClr("--border-subtle"),borderWidth:1,
          titleColor:_cuCssClr("--text-primary"),bodyColor:_cuCssClr("--text-secondary"),
          callbacks:{label:item=>" "+item.raw+" cases \u2014 click to filter"}}},
        scales:{x:{grid:{display:false},border:{display:false},ticks:{color:_cuCssClr("--text-tertiary"),font:{size:10},maxRotation:0}},
                y:{grid:{color:"rgba(0,0,0,0.05)",drawTicks:false},border:{display:false},ticks:{color:_cuCssClr("--text-tertiary"),font:{size:11},padding:8},beginAtZero:true}},
        onClick:onBarClick?(evt,els)=>{if(els.length){const key=keys[els[0].index];setTimeout(()=>{try{onBarClick(key);}catch(e){console.warn("[DashCustomer] bars onClick:",e);}},0);}}:undefined
      }})}catch(e){console.warn("[DashCustomer] Gradient bars:",e);}
    if(onBarClick)canvas.style.cursor="pointer";
  }
  function _cuDrawPolarArea(canvasId, labels, data, onClick) {
    const canvas=document.getElementById(canvasId); if(!canvas) return;
    if(typeof Chart==="undefined"){setTimeout(()=>_cuDrawPolarArea(canvasId,labels,data,onClick),200);return;}
    try{const ex=Chart.getChart?Chart.getChart(canvas):null;if(ex)ex.destroy();}catch(e){}
    const palette=["#4589FF","#42BE65","#8A3FFC","#F1C21B","#FF832B","#33B1FF","#FA4D56","#08BDBA"];
    const total=data.reduce((s,v)=>s+v,0); const visible=labels.map(()=>true); let visibleTotal=total;
    const centerPlugin={id:"custDonutCenter",afterDraw(chart){
      const{ctx,chartArea:{left,right,top,bottom}}=chart; const cx=(left+right)/2,cy=(top+bottom)/2;
      ctx.save(); ctx.textAlign="center"; ctx.textBaseline="middle";
      ctx.font="700 "+Math.max(18,Math.min(26,(right-left)*0.13))+"px 'IBM Plex Sans',sans-serif";
      ctx.fillStyle=_cuCssClr("--text-primary")||"#161616"; ctx.fillText(visibleTotal.toLocaleString(),cx,cy-8);
      ctx.font="400 11px 'IBM Plex Sans',sans-serif"; ctx.fillStyle=_cuCssClr("--text-tertiary")||"#6f6f6f";
      ctx.fillText("Total Cases",cx,cy+12); ctx.restore();
    }};
    let chartInst;
    try{chartInst=new Chart(canvas,{type:"doughnut",
      data:{labels,datasets:[{data,backgroundColor:labels.map((_,i)=>palette[i%palette.length]+"dd"),
        borderColor:labels.map((_,i)=>palette[i%palette.length]),borderWidth:2.5,
        hoverBackgroundColor:labels.map((_,i)=>palette[i%palette.length]),hoverBorderWidth:0,hoverOffset:8}]},
      plugins:[centerPlugin],
      options:{responsive:true,maintainAspectRatio:false,cutout:"62%",
        animation:{animateRotate:true,animateScale:false,duration:700,easing:"easeOutQuart"},
        interaction:{mode:"nearest",intersect:true},
        plugins:{legend:{display:false},tooltip:{backgroundColor:"#fff",borderColor:_cuCssClr("--border-subtle"),borderWidth:1,
          titleColor:_cuCssClr("--text-primary"),bodyColor:_cuCssClr("--text-secondary"),padding:10,cornerRadius:8,
          callbacks:{label:item=>"  "+item.raw+" cases ("+(total?((item.raw/total)*100).toFixed(1):0)+"%) \u2014 click to filter"}}},
        onClick:onClick?(evt,els)=>{if(els.length){const lbl=labels[els[0].index];setTimeout(()=>{try{onClick(lbl);}catch(e){}},0);}}:undefined
      }})}catch(e){console.warn("[DashCustomer] Donut:",e);}
    const legendEl=document.getElementById("chart-cust-yearly-legend");
    if(legendEl&&chartInst){
      legendEl.innerHTML=labels.map((lbl,i)=>{const color=palette[i%palette.length];
        return "<span data-cidx=\""+i+"\" style=\"display:inline-flex;align-items:center;gap:4px;cursor:pointer;user-select:none;white-space:nowrap;\">"
          +"<span class=\"cul-swatch\" style=\"display:inline-block;width:10px;height:10px;border-radius:2px;background:"+color+";flex-shrink:0;\"></span>"
          +"<span class=\"cul-text\" style=\"color:"+(_cuCssClr("--text-primary")||"#161616")+"\">"+lbl+" ("+data[i].toLocaleString()+")</span>"
          +"</span>";}).join("");
      legendEl.querySelectorAll("span[data-cidx]").forEach(item=>{
        item.addEventListener("click",()=>{
          const i=parseInt(item.dataset.cidx); visible[i]=!visible[i];
          chartInst.toggleDataVisibility(i);
          visibleTotal=data.reduce((s,v,idx)=>s+(visible[idx]?v:0),0); chartInst.update();
          const sw=item.querySelector(".cul-swatch"),tx=item.querySelector(".cul-text"),c=palette[i%palette.length];
          sw.style.background=visible[i]?c:"transparent"; sw.style.border=visible[i]?"none":"1.5px solid "+c;
          tx.style.color=visible[i]?(_cuCssClr("--text-primary")||"#161616"):(_cuCssClr("--text-tertiary")||"#6f6f6f");
          tx.style.textDecoration=visible[i]?"none":"line-through";
        });
      });
    }
    if(onClick)canvas.style.cursor="pointer";
  }

  return { render };
})();
