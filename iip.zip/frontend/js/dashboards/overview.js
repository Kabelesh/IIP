/* ============================================================
   overview.js  — IBM Case Operations Command Center  v1.0.2
   7-zone operational dashboard following engineering observability
   principles: high density · instant signal · minimal scrolling
   ============================================================ */
const DashOverview = (() => {
  /* ── Loading state helper ─────────────────────────────────────
     Usage: _setLoading(true) before data fetch, _setLoading(false) after.
     Applies .is-loading class to the dashboard root element.
  ────────────────────────────────────────────────────────────── */
  function _setLoading(active) {
    const el = document.getElementById('content-area') || document.body;
    el.classList.toggle('dashboard-loading', active);
    // Show/hide skeleton shimmer on tables
    document.querySelectorAll('.table-wrap, .dash-table').forEach(t => {
      t.classList.toggle('skeleton-loading', active);
    });
  }


  /* ── Module state ─────────────────────────────────────────*/
  let _tw     = 6;      // trend window: 3 | 6 | 12 | 0=ALL
  let _stw    = 0;      // status donut window: 3 | 6 | 12 | 0=ALL
  let _filter = "all";  // table status filter
  let _search = "";     // table search string
  let _tableRef = null;

  /* ── Icons (same stroke style as rest of app) ─────────── */
  const IC = {
    activity: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>`,
    alert:    `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>`,
    trend:    `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>`,
    donut:    `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="4"/></svg>`,
    users:    `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75"/></svg>`,
    pkg:      `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="16.5" y1="9.4" x2="7.5" y2="4.21"/><path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 002 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>`,
    table:    `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="3" y1="15" x2="21" y2="15"/><line x1="9" y1="3" x2="9" y2="21"/><line x1="15" y1="3" x2="15" y2="21"/></svg>`,
    zap:      `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>`,
    refresh:  `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 11-2.12-9.36L23 10"/></svg>`,
    export:   `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>`,
    search:   `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>`,
    ext:      `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>`,
    clock:    `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>`,
    fire:     `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8.5 14.5A2.5 2.5 0 0011 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 01-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 002.5 2.5z"/></svg>`,
    check:    `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>`,
    invest:   `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>`,
    close:    `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>`,
    upgrade:  `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/><polyline points="12 14 12 18"/><polyline points="10 16 12 14 14 16"/></svg>`,
    arrowUp:  `<svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="18 15 12 9 6 15"/></svg>`,
    arrowDn:  `<svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>`,
    layers:   `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/></svg>`,
  };

  /* ══════════════════════════════════════════════════════════
     DATA AGGREGATION
     ════════════════════════════════════════════════════════ */
  function _aggregate() {
    const team     = Data.teamCases();
    const cust     = Data.customerCases();
    const open     = team.filter(r => !Utils.isClosed(r.Status));
    const inprog   = open.filter(r => r.Status === "IBM is working" || r.Status === "Waiting for IBM");
    const acc02    = open.filter(r => (r["Customer number"]||"").replace(/^0+/,"").startsWith("2"));
    const acc08    = open.filter(r => (r["Customer number"]||"").includes(Data.customerAccountId()));
    const custOpen = cust.filter(r => !Utils.isClosed(r.Status));

    // Closed last 7 days — use Closed Date, not Updated (which is last IBM touch, not close date)
    const closed7d = team.filter(r => {
      if (!Utils.isClosed(r.Status)) return false;
      const d = Utils.parseDate(r["Closed Date"]) || Utils.parseDate(r.Updated) || Utils.parseDate(r.Created);
      return d && Utils.daysDiff(d) <= 7;
    });

    // Previous week open-count estimate for trend arrows.
    // "Cases that were open last week" = created before 7 days ago AND not closed
    // before 7 days ago (i.e. either still open, or closed within the last 7 days).
    // This gives a stable comparable baseline regardless of Update timestamp noise.
    const _7dAgo  = new Date(Utils.today() - 7  * 86400000);
    const _14dAgo = new Date(Utils.today() - 14 * 86400000);
    const prev7Open = team.filter(r => {
      const created = Utils.parseDate(r.Created);
      if (!created || created > _7dAgo) return false;     // created within last 7d — not "last week"
      if (!Utils.isClosed(r.Status)) return true;          // still open → was open last week
      const closed = Utils.parseDate(r["Closed Date"]);
      return !closed || closed > _7dAgo;                   // closed in last 7d → was open last week
    });
    const prev7Closed = team.filter(r => {
      if (!Utils.isClosed(r.Status)) return false;
      const closed = Utils.parseDate(r["Closed Date"] || r.Updated);
      if (!closed) return false;
      const age = Utils.daysDiff(closed);
      return age >= 7 && age < 14;                         // closed in the previous 7-14d window
    });

    // Status distribution — uses Utils.ACTIVE_STATUSES (single source of truth)
    const statusMap = {};
    open.forEach(r => {
      const st = (r.Status || "").trim();
      if (Utils.ACTIVE_STATUSES.has(st)) statusMap[st] = (statusMap[st]||0)+1;
    });
    Utils.ACTIVE_STATUSES.forEach(st => { if (!(st in statusMap)) statusMap[st] = 0; });
    const statusData  = Object.entries(statusMap).filter(([,v])=>v>0).sort((a,b)=>b[1]-a[1]).map(([name,value])=>({name,value}));
    const statusTotal = statusData.reduce((s,d)=>s+d.value, 0);

    // Product distribution (top 12, active only)
    const prodMap = {};
    open.forEach(r => { const p = r.Product||"Unknown"; prodMap[p]=(prodMap[p]||0)+1; });
    const prodData = Object.entries(prodMap).sort((a,b)=>b[1]-a[1]).slice(0,12).map(([name,value])=>({name,value}));

    // Owner counts (top 10, active only)
    const ownerData = Utils.ownerCounts(open).slice(0,10);

    // Team distribution (active cases by sub-team)
    const _tg = (typeof DynamicConfig !== 'undefined' && DynamicConfig.teamGroups) ? DynamicConfig.teamGroups() : {};
    const _teamOrder = ['Operation','German','Automation','Tools','Database'];
    const teamMap = {};
    _teamOrder.forEach(t => { teamMap[t] = 0; });
    open.forEach(r => {
      const owner = (r.Owner||'').trim();
      const grp = _tg[owner.toLowerCase()] || '';
      const key = _teamOrder.find(t => grp.toLowerCase() === t.toLowerCase()) || null;
      if (key) teamMap[key] = (teamMap[key]||0) + 1;
      else if (grp) teamMap[grp] = (teamMap[grp]||0) + 1;
    });
    const teamData = Object.entries(teamMap).map(([name,value])=>({name,value}));

    // Trend data
    const allTrend = Utils.monthlyTrend(team);

    // ── Alert data ──────────────────────────────────────────
    // "Awaiting your feedback > 5d" — staleness measured from last Update
    // (i.e. how long since IBM last touched the case), not Created date.
    // This is the correct metric: if IBM updated it yesterday, it's not stale yet.
    const awaitCust5d = open.filter(r => {
      if (r.Status !== "Awaiting your feedback") return false;
      const d = Utils.parseDate(r.Updated) || Utils.parseDate(r.Created);
      return d && Utils.daysDiff(d) >= 5;
    });
    const waitIBM5d = open.filter(r => {
      if (r.Status !== "Waiting for IBM") return false;
      const d = Utils.parseDate(r.Updated) || Utils.parseDate(r.Created);
      return d && Utils.daysDiff(d) >= 5;
    });
    const escalated = open.filter(r =>
      (r.Priority||"").includes("1") || (r.Severity||"").includes("1")
    );
    let oldestCase = null, oldestDays = 0;
    open.forEach(r => {
      const d = Utils.parseDate(r.Created);
      if (d) { const age = Utils.daysDiff(d); if (age > oldestDays) { oldestDays = age; oldestCase = r; } }
    });

    // Recent activity — last 5 updated cases
    const recent = [...team]
      .filter(r => Utils.parseDate(r.Updated || r.Created))
      .sort((a,b) => {
        const da = Utils.parseDate(a.Updated||a.Created);
        const db = Utils.parseDate(b.Updated||b.Created);
        return db - da;
      })
      .slice(0, 5);

    // ── Performance Cases for Overview panel ────────────────
    const perfNums   = new Set(Data.getPerfCaseNums());
    const nonPerfNums= new Set(Data.getNonPerfCaseNums ? Data.getNonPerfCaseNums() : []);
    const perfMeta   = Data.performanceMeta ? Data.performanceMeta() : {};
    const isPerfCase = r => {
      const cn = r["Case Number"];
      if (nonPerfNums.has(cn)) return false;
      return perfNums.has(cn) || (perfMeta[cn]||{}).category === "performance";
    };
    // All perf cases from team (open + closed)
    const allPerfCases = team.filter(isPerfCase);
    // In-progress = open (not closed)
    const perfInProgress = allPerfCases.filter(r => !Utils.isClosed(r.Status));
    // Newly raised this week = Created within last 7 days
    const perfNewThisWeek = allPerfCases.filter(r => {
      const d = Utils.parseDate(r.Created);
      return d && Utils.daysDiff(d) <= 7;
    });

    return {
      team, open, inprog, acc02, acc08, custOpen,
      totalActive: open.length + custOpen.length,
      closed7d, prev7Open, prev7Closed,
      statusData, statusTotal, prodData, ownerData, teamData, allTrend,
      awaitCust5d, waitIBM5d, escalated, oldestCase, oldestDays,
      recent,
      perfInProgress, perfNewThisWeek, perfMeta,
    };
  }

  /* ══════════════════════════════════════════════════════════
     MAIN RENDER ENTRY POINT
     ════════════════════════════════════════════════════════ */
  function render() {
    const el = document.getElementById("tab-overview");
    if (!el) return;
    _tableRef = null;
    const D = _aggregate();
    el.innerHTML = _buildPage(D);
    // Tier 1.1: initialise Progressive Disclosure toggles
    if (typeof PD !== "undefined") PD.init(el);
    _wireEvents(D);

    // Render charts — defer until Detailed Analysis section is visible.
    // If the section is already open (or doesn't use PD), render immediately;
    // otherwise wait for the first toggle click so the canvas has real dimensions.
    const analysisSection = el.querySelector('[data-pd-id="ov-analysis"]');
    const analysisIsOpen  = !analysisSection || analysisSection.classList.contains('pd-open');
    if (analysisIsOpen) {
      _renderCharts(D);
    } else {
      // Defer chart render until the section is opened for the first time
      let chartsRendered = false;
      const toggle = analysisSection.querySelector('.pd-toggle');
      if (toggle) {
        toggle.addEventListener('click', function onFirstOpen() {
          if (!chartsRendered) {
            chartsRendered = true;
            setTimeout(() => _renderCharts(D), 60); // wait for CSS transition to start
          }
        });
      }
    }
    // F20: Show top 10 at-risk cases — render immediately if table section is open
    const atRisk = D.open
      .slice()
      .sort((a,b) => (parseInt(b.Age)||0) - (parseInt(a.Age)||0))
      .slice(0,10);

    const tableSection = el.querySelector('[data-pd-id="ov-table"]');
    const tableIsOpen  = !tableSection || tableSection.classList.contains('pd-open');
    if (tableIsOpen) {
      _renderTable(atRisk, "Top 10 At-Risk Cases");
    } else {
      // Render table when section first opens
      let tableRendered = false;
      if (tableSection) {
        const toggle = tableSection.querySelector('.pd-toggle');
        if (toggle) {
          toggle.addEventListener('click', function onFirstTableOpen() {
            if (!tableRendered) {
              tableRendered = true;
              setTimeout(() => _renderTable(atRisk, "Top 10 At-Risk Cases"), 30);
            }
          });
        }
      }
    }

    // ── Zone 7: Post-Upgrade section — load upgrades when section first opens ──
    const upgradeSection = el.querySelector('[data-pd-id="ov-upgrade"]');
    if (upgradeSection) {
      let upgradeLoaded = false;
      const _initUpgrade = () => {
        if (!upgradeLoaded) { upgradeLoaded = true; _loadUpgradeDropdown(); }
      };
      const upgToggle = upgradeSection.querySelector('.pd-toggle');
      if (upgToggle) {
        upgToggle.addEventListener('click', () => setTimeout(_initUpgrade, 50));
      }
      // If already open (e.g. localStorage pref), load immediately
      if (upgradeSection.classList.contains('pd-open')) _initUpgrade();
    } else {
      // No PD — load immediately
      _loadUpgradeDropdown();
    }
  }

  /* ══════════════════════════════════════════════════════════
     PAGE HTML BUILDER  (Tier 1: Progressive Disclosure)
     ════════════════════════════════════════════════════════ */
  function _buildPage(D) {
    const alertCount = [
      D.awaitCust5d.length > 0,
      D.waitIBM5d.length   > 0,
      D.escalated.length   > 0,
      D.oldestDays         > 30,
    ].filter(Boolean).length;

    const trendSlice = _trendSlice(D);
    const tCreated   = trendSlice.reduce((s,r)=>s+r.created, 0);
    const tClosed    = trendSlice.reduce((s,r)=>s+r.closed,  0);
    window._ov7KpiBarHTML = (created, closed, slice) => {
      const peak   = slice.reduce((best,r) => r.closed  > (best?.closed  ||0) ? r : best, null);
      const peakCr = slice.reduce((best,r) => r.created > (best?.created ||0) ? r : best, null);
      const netD   = closed - created;
      const rate   = created > 0 ? Math.round(closed / created * 100) : 0;
      const netCol  = netD >= 0 ? 'var(--green,#24a148)' : 'var(--red,#da1e28)';
      const rateCol = rate >= 100 ? 'var(--green,#24a148)' : rate >= 70 ? 'var(--yellow,#f1c21b)' : 'var(--red,#da1e28)';
      const barW = (v, max) => Math.min(100, max > 0 ? Math.round(v/max*100) : 0);
      const maxVal = Math.max(created, closed, 1);
      const card = (bl, label, bigVal, bigCol, sub, barCss) =>
        `<div style="flex:1;min-width:90px;display:flex;flex-direction:column;padding:0 12px 10px ${bl?'12':'4'}px;${bl?'border-left:1px solid var(--border-subtle);':''}">`
        + `<div style="font-size:9px;font-weight:700;letter-spacing:.08em;color:var(--text-tertiary);text-transform:uppercase;margin-bottom:4px">${label}</div>`
        + `<div style="font-size:18px;font-weight:700;font-family:var(--font-mono);color:${bigCol};line-height:1">${bigVal}</div>`
        + `<div style="flex:1"></div>`
        + `<div style="font-size:10px;color:var(--text-tertiary);min-height:14px;white-space:nowrap">${sub}</div>`
        + `<div style="height:3px;background:var(--border-subtle);border-radius:2px;margin-top:6px;overflow:hidden"><div style="height:3px;border-radius:2px;${barCss}transition:width .4s ease"></div></div>`
        + `</div>`;
      return `<div id="ov7-kpi-bar" style="display:flex;gap:0;align-items:stretch;border-top:1px solid var(--border-subtle);padding:14px 0 4px;margin-top:10px;flex-wrap:wrap">`
        + card(false,'Total Created', created,             'var(--text-primary)', '&nbsp;',                          `background:var(--red,#da1e28);width:${barW(created,maxVal)}%;`)
        + card(true, 'Total Closed',  closed,              'var(--text-primary)', '&nbsp;',                          `background:var(--green,#24a148);width:${barW(closed,maxVal)}%;`)
        + card(true, 'Difference',(netD>=0?'+':'')+netD, netCol,             '&nbsp;',                          `background:${netD>=0?'var(--green,#24a148)':'var(--red,#da1e28)'};width:100%;`)
        + card(true, 'Close Rate',    rate+'%',            rateCol,              '&nbsp;',                          `background:var(--green,#24a148);width:${Math.min(rate,100)}%;`)
        + (peak   ? card(true,'Peak Close',  peak.label,   'var(--green,#24a148)', peak.closed+' cases closed',   `background:var(--green,#24a148);width:${barW(peak.closed,maxVal)}%;`) : '')
        + (peakCr ? card(true,'Peak Created',peakCr.label,'var(--text-primary)', peakCr.created+' cases created',`background:var(--red,#da1e28);width:${barW(peakCr.created,maxVal)}%;`)   : '')
        + `</div>`;
    };

    // ── Zone 2: Trend + Status charts HTML ──────────────────
    const z2Html = `
<div class="ov7-z2">
  <div class="tile no-hover">
    <div class="ov7-tile-hdr">
      <div class="section-title mb-0">${IC.trend} Created vs Closed</div>
      <div class="ov7-tw-group">
        <button class="ov7-tw${_tw===3?" ov7-tw-active":""}" data-tw="3">3M</button>
        <button class="ov7-tw${_tw===6?" ov7-tw-active":""}" data-tw="6">6M</button>
        <button class="ov7-tw${_tw===12?" ov7-tw-active":""}" data-tw="12">12M</button>
        <button class="ov7-tw${_tw===0?" ov7-tw-active":""}" data-tw="0">ALL</button>
      </div>
    </div>
    <div class="ov7-trend-summary" id="ov7-trend-summary">
      <span class="ov7-ts-label">${_tw === 0 ? "All Time" : `Last ${_tw}M`}:</span>
      <span class="ov7-ts-created">${tCreated} Created</span>
      <span class="ov7-ts-sep">·</span>
      <span class="ov7-ts-closed">${tClosed} Closed</span>
    </div>
    <div class="chart-canvas-wrap" style="height:350px"><canvas id="chart-trend"></canvas></div>
    ${window._ov7KpiBarHTML(tCreated, tClosed, trendSlice)}
  </div>
  <div class="tile no-hover">
    <div class="ov7-tile-hdr mb-8">
      <div class="section-title mb-0">${IC.donut} Cases by Status</div>
      <div class="ov7-tw-group">
        <button class="ov7-tw ov7-stw${_stw===3?" ov7-tw-active":""}" data-stw="3">3M</button>
        <button class="ov7-tw ov7-stw${_stw===6?" ov7-tw-active":""}" data-stw="6">6M</button>
        <button class="ov7-tw ov7-stw${_stw===12?" ov7-tw-active":""}" data-stw="12">12M</button>
        <button class="ov7-tw ov7-stw${_stw===0?" ov7-tw-active":""}" data-stw="0">ALL</button>
      </div>
    </div>
    <div class="ov7-trend-summary" id="ov7-status-summary" style="font-size:12px;color:var(--text-secondary);margin-bottom:16px">
      <span class="ov7-ts-label">${_stw === 0 ? "All Time" : `Last ${_stw}M`}:</span>
      <span class="ov7-ts-created" id="ov7-status-active-count">${D.open.length} Active Cases</span>
    </div>
    <div class="chart-canvas-wrap" style="height:255px"><canvas id="chart-status"></canvas></div>
    <div id="chart-status-legend" style="display:flex;flex-wrap:wrap;gap:4px 14px;justify-content:center;padding:10px 6px 2px;font-size:12px;font-family:'IBM Plex Sans',sans-serif;"></div>
  </div>
  <div class="tile no-hover">
    <div class="ov7-tile-hdr mb-8">
      <div class="section-title mb-0">${IC.layers} Cases by Team</div>
    </div>
    <div id="ov7-team-cards" style="padding:4px 0">${_teamCardsHTML(D.teamData)}</div>
  </div>
</div>`;

    // ── Zone 3+4: Workload + Alerts HTML ────────────────────
    const z34Html = `
<div class="ov7-z34">
  <div class="tile no-hover">
    <div class="section-title mb-2">${IC.users} Owner Workload <span class="ov7-sub-label">(active · top 10)</span></div>
    <div class="chart-canvas-wrap chart-md"><canvas id="chart-owners"></canvas></div>
    ${D.ownerData.length >= 10 ? `<div style="margin-top:6px;text-align:right;font-size:11px;color:var(--text-tertiary)">...and more team members · <button id="ov7-view-members-btn" aria-label="View member dashboard" class="btn btn-ghost btn-xs text-blue-c">View Member Dashboard →</button></div>` : ""}
  </div>
  <div class="tile no-hover">
    <div class="ov7-tile-hdr mb-4">
      <div class="section-title mb-0">${IC.pkg} <span id="ov7-chart3-title">Cases by Product</span></div>
      <div class="ov7-tw-group">
        <button class="ov7-tw ov7-tw-active ov7-c3tab" data-c3tab="product">Product</button>
        <button class="ov7-tw ov7-c3tab" data-c3tab="severity">Severity</button>
        <button class="ov7-tw ov7-c3tab" data-c3tab="aging">Aging</button>
      </div>
    </div>
    <div class="chart-canvas-wrap chart-md" style="position:relative">
      <canvas id="chart-products"></canvas>
      <canvas id="chart-ov7-severity" style="display:none"></canvas>
      <canvas id="chart-ov7-aging" style="display:none"></canvas>
    </div>
    <div id="ov7-chart3-kpi-strip" style="display:flex;gap:0;align-items:stretch;border-top:1px solid var(--border-subtle);padding:8px 0 2px;flex-wrap:wrap;margin-top:6px"></div>
  </div>
  <div class="tile no-hover ov7-alerts-tile">
    <div class="section-title red mb-10">${IC.alert} Operational Alerts</div>
    <div id="ov7-alerts-body">${_alertsHTML(D)}</div>
  </div>
</div>`;

    // ── Zone 5: Performance Cases HTML ──────────────────────
    const z5Html = `
<div class="tile no-hover ov7-activity-tile" style="padding:14px">
  ${_perfCasesHTML(D)}
</div>`;

    // ── Zone 6: Cases Table HTML ─────────────────────────────
    const z6Html = `
<div class="tile no-hover ov7-table-tile" id="tile-drill">
  <div class="ov7-table-hdr">
    <div class="ov7-table-hdr-left">
      <div class="section-title" id="drill-title" class="mb-0">${IC.table} Top 10 At-Risk Cases</div>
      <button id="drill-reset" aria-label="Reset drill-down filter" class="btn btn-ghost btn-xs" style="display:none">${IC.close} Show All</button>
    </div>
    <div style="display:flex;align-items:center;gap:12px;flex-shrink:0">
      <button id="ov7-view-all-btn" aria-label="View all cases" class="btn btn-ghost btn-xs fs-11">View all →</button>
      <div class="ov7-table-meta">${_tableMeta(D)}</div>
    </div>
  </div>
  <div class="ov7-table-ctrl">
    <input id="ov7-table-search" type="text" class="form-input form-input-sm" style="width:260px" placeholder="Search case #, title, owner…" value="${Utils.escHtml(_search)}">
    <div class="ov7-chips" id="ov7-chips">${_chipsHTML(D)}</div>
  </div>
  <div id="tbl-overview"></div>
</div>`;

    // ── Build page with Progressive Disclosure sections ──────
    // PD is available globally from progressive-disclosure.js
    const usePD = (typeof PD !== "undefined");

    // Alert badge for section header
    const alertBadgeClass = alertCount > 0 ? "alert-count" : "";
    const alertMeta = alertCount > 0
      ? `${alertCount} issue${alertCount > 1 ? "s" : ""} need attention`
      : "All clear";

    const analysisMeta = `${D.statusTotal} active · ${_tw === 0 ? "All time" : `${_tw}M window`}`;
    const perfMeta     = `${D.perfInProgress.length} in progress · ${D.perfNewThisWeek.length} new this week`;
    const tablesMeta   = `${D.open.length} active cases`;
    const upgradeMeta  = `Select an iFix to analyse post-upgrade cases`;

    if (usePD) {
      return `
<!-- ZONE 1 — Executive Metrics Strip (always visible — primary focus) -->
<div class="ov7-strip">
  ${_kpi("Total Active",    D.totalActive,          "",          IC.table, null, null, "Team + Customer")}
  ${_kpi("Team Cases",      D.open.length,          "kpi-yellow",IC.users,  D.open.length    - D.prev7Open.length,   "down")}
  ${_kpi("Closed 7d",       D.closed7d.length,      "kpi-green", IC.check,  D.closed7d.length - D.prev7Closed.length, "up")}
  ${_kpi("In Progress",     D.inprog.length,         "kpi-blue",  IC.activity)}
  ${_kpi("O2 Account",      D.acc02.length,          "kpi-purple",IC.pkg)}
  ${_kpi("O8 Account",      D.acc08.length,          "kpi-purple",IC.pkg)}
  ${_kpi("Customer Cases",  D.custOpen.length,       "kpi-red",   IC.users)}
</div>

<!-- ZONE 2+3+4 — Detailed Analysis (collapsible) -->
${PD.section("ov-analysis", "Detailed Analysis", z2Html + z34Html, {
  defaultOpen : true,
  count       : analysisMeta,
  icon        : IC.trend,
  id          : "ov-analysis",
})}

<!-- ZONE 5 — Performance Cases (collapsible) -->
${PD.section("ov-perf", "Performance Cases", z5Html, {
  defaultOpen : false,
  count       : perfMeta,
  icon        : IC.zap,
  id          : "ov-perf",
})}

<!-- ZONE 6 — Active Cases Table (collapsible) -->
${PD.section("ov-table", "Active Cases", z6Html, {
  defaultOpen : true,
  count       : tablesMeta,
  countClass  : alertBadgeClass,
  icon        : IC.table,
  id          : "ov-table",
})}

<!-- ZONE 7 — Post-Upgrade Case Tracking (collapsible) -->
${PD.section("ov-upgrade", "Post-Upgrade Case Tracking", _buildUpgradeShell(), {
  defaultOpen : false,
  count       : upgradeMeta,
  icon        : IC.upgrade,
  id          : "ov-upgrade",
})}`;
    }

    // Fallback: no PD module (render flat like before)
    return `
<div class="ov7-strip">
  ${_kpi("Total Active",    D.totalActive,          "",          IC.table, null, null, "Team + Customer")}
  ${_kpi("Team Cases",      D.open.length,          "kpi-yellow",IC.users,  D.open.length    - D.prev7Open.length,   "down")}
  ${_kpi("Closed 7d",       D.closed7d.length,      "kpi-green", IC.check,  D.closed7d.length - D.prev7Closed.length, "up")}
  ${_kpi("In Progress",     D.inprog.length,         "kpi-blue",  IC.activity)}
  ${_kpi("O2 Account",      D.acc02.length,          "kpi-purple",IC.pkg)}
  ${_kpi("O8 Account",      D.acc08.length,          "kpi-purple",IC.pkg)}
  ${_kpi("Customer Cases",  D.custOpen.length,       "kpi-red",   IC.users)}
</div>
${z2Html}${z34Html}${z5Html}${z6Html}
<div style="margin-top:16px">${_buildUpgradeShell()}</div>`;
  }

  /* ══════════════════════════════════════════════════════════
     COMPONENT BUILDERS
     ════════════════════════════════════════════════════════ */

  // KPI card with optional trend arrow
  function _kpi(label, value, cls, icon, delta, goodDir, subLabel) {
    let trendHtml = "";
    if (delta !== undefined && delta !== null) {
      const abs  = Math.abs(delta);
      const up   = delta > 0;
      const good = goodDir === "up" ? up : goodDir === "down" ? !up : null;
      const col  = delta === 0 ? "var(--text-disabled)"
                 : good === true  ? "var(--green)"
                 : good === false ? "var(--red)"
                 : "var(--text-tertiary)";
      if (delta === 0) {
        trendHtml = `<div class="ov7-kpi-trend text-dim">— no change</div>`;
      } else {
        trendHtml = `<div class="ov7-kpi-trend" style="color:${col}">${up?IC.arrowUp:IC.arrowDn} ${abs} vs last wk</div>`;
      }
    }
    return `<div class="kpi-card ${cls}">
      <div class="kpi-label">${label}</div>
      <div class="kpi-value">${value}</div>
      ${subLabel ? `<div style="font-size:10px;color:var(--text-tertiary);margin-top:2px;font-weight:500">${subLabel}</div>` : (value === 0 ? `<div class="ov7-kpi-trend text-green-c">All clear ✓</div>` : trendHtml)}
    </div>`;
  }

  // Status legend rows
  const STATUS_COL = {
    "Awaiting your feedback": "var(--yellow)",
    "IBM is working":         "var(--ibm-blue-30)",
    "Waiting for IBM":        "var(--purple)",
    "Closed by IBM":          "var(--green)",
    "Closed by Client":       "var(--text-tertiary)",
    "Closed - Archived":      "var(--text-secondary)",
  };
  function _statusLegend(data, total) {
    if (!data.length) return `<p class="ov7-empty">No data</p>`;
    return data.map(s => {
      const pct   = total > 0 ? Math.round(s.value / total * 100) : 0;
      const color = STATUS_COL[s.name] || "var(--text-secondary)";
      return `<div class="ov7-leg-row" data-status="${Utils.escHtml(s.name)}">
        <span class="ov7-leg-dot" style="background:${color}"></span>
        <span class="ov7-leg-name">${Utils.escHtml(s.name)}</span>
        <span class="ov7-leg-count">${s.value}</span>
        <span class="ov7-leg-pct">${pct}%</span>
      </div>`;
    }).join("");
  }

  // Status segmented progress bar
  function _statusBar(data, total) {
    if (!total) return '';
    return data.map(s => {
      const pct   = Math.max(1, Math.round(s.value / total * 100));
      const color = STATUS_COL[s.name] || "var(--text-secondary)";
      return `<div class="ov7-sbar-seg" data-status="${Utils.escHtml(s.name)}" style="width:${pct}%;background:${color}" title="${Utils.escHtml(s.name)}: ${s.value} (${pct}%)"></div>`;
    }).join('');
  }

  // Oldest age helper
  function _maxAge(cases) {
    let max = 0;
    cases.forEach(r => {
      const d = Utils.parseDate(r.Updated||r.Created);
      if (d) max = Math.max(max, Utils.daysDiff(d));
    });
    return max;
  }

  // Alerts panel
  function _alertsHTML(D) {
    const rows = [];

    // 1. Sev-1 cases — always first
    if (D.escalated.length > 0) {
      const sev1 = D.escalated.filter(r => (r.Severity||"").trim() === "1");
      const esc  = D.escalated.filter(r => (r.Severity||"").trim() !== "1");
      if (sev1.length > 0) {
        rows.push(_alertRow("critical",
          `${sev1.length} Severity-1 case${sev1.length>1?"s":""}`,
          `Immediate attention required · Cases: ${sev1.map(r=>r["Case Number"]||"").filter(Boolean).slice(0,3).join(", ")}${sev1.length>3?"…":""}`,
          "sev1"
        ));
      }
      if (esc.length > 0) {
        rows.push(_alertRow("critical",
          `${esc.length} escalated case${esc.length>1?"s":""}`,
          "Priority-1 escalation — immediate review required",
          "esc"
        ));
      }
    }

    // 2. Performance cases this week
    if (D.perfNewThisWeek && D.perfNewThisWeek.length > 0) {
      rows.push(_alertRow("warn",
        `${D.perfNewThisWeek.length} performance case${D.perfNewThisWeek.length>1?"s":""} raised this week`,
        `${D.perfInProgress.length} in progress · Review performance dashboard`,
        "perf"
      ));
    }

    // 3. Awaiting feedback >5d
    if (D.awaitCust5d.length > 0) {
      const crit = D.awaitCust5d.length >= 5;
      rows.push(_alertRow(
        crit ? "critical" : "warn",
        `${D.awaitCust5d.length} case${D.awaitCust5d.length>1?"s":""} awaiting your feedback >5d`,
        `Oldest: ${_maxAge(D.awaitCust5d)}d · Customer follow-up required`,
        "awaitcust"
      ));
    }

    // 4. Waiting for IBM >5d
    if (D.waitIBM5d.length > 0) {
      const crit = D.waitIBM5d.length >= 5;
      rows.push(_alertRow(
        crit ? "critical" : "warn",
        `${D.waitIBM5d.length} case${D.waitIBM5d.length>1?"s":""} waiting for IBM >5d`,
        `Oldest: ${_maxAge(D.waitIBM5d)}d · IBM response overdue`,
        "waitibm"
      ));
    }

    // 5. Oldest open case
    if (D.oldestDays > 30 && D.oldestCase) {
      const crit = D.oldestDays > 90;
      rows.push(_alertRow(
        crit ? "critical" : "warn",
        `Oldest open case: ${D.oldestDays} days`,
        `${Utils.escHtml(D.oldestCase["Case Number"]||"")} · ${Utils.escHtml((D.oldestCase.Title||"").slice(0,40))}`,
        "oldest"
      ));
    }

    if (!rows.length) {
      return `<div class="ov7-alert-ok">
        <span class="text-green-c">${IC.check}</span>
        <span>All clear — no operational alerts</span>
      </div>`;
    }
    // Tier 1.1: Show first 2 alerts immediately; "Show N more" for the rest
    const INITIAL_ALERTS = 2;
    if (rows.length <= INITIAL_ALERTS) return rows.join("");

    const visible = rows.slice(0, INITIAL_ALERTS);
    const hidden  = rows.slice(INITIAL_ALERTS).map(r => `<div class="pd-hidden-item">${r}</div>`);
    const showBtn = (typeof PD !== "undefined")
      ? PD.showMoreBtn(rows.length - INITIAL_ALERTS, "alerts")
      : `<div class="pd-show-more" data-pd-show-more-label="alerts">▼ <span>Show ${rows.length - INITIAL_ALERTS} more alerts</span></div>`;

    return visible.join("") + hidden.join("") + showBtn;
  }

  function _alertRow(level, title, sub, id) {
    const crit   = level === "critical";
    const color  = crit ? "var(--red)" : "var(--yellow)";
    const bg     = crit ? "var(--red-bg)" : "var(--yellow-bg)";
    const border = crit ? "rgba(218,30,40,.2)" : "rgba(166,120,0,.2)";
    return `<div class="ov7-alert-row" data-aid="${id}" style="background:${bg};border-color:${border}">
      <span class="ov7-alert-icon" style="color:${color}">${crit?IC.fire:IC.alert}</span>
      <div class="ov7-alert-body">
        <div class="ov7-alert-title" style="color:${color}">${title}</div>
        <div class="ov7-alert-sub">${sub}</div>
      </div>
    </div>`;
  }

  // Performance Cases panel (replaces Recent Activity)
  function _perfCasesHTML(D) {
    const newCount  = D.perfNewThisWeek.length;
    const inpCount  = D.perfInProgress.length;
    const perfIcon  = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>`;

    // Summary header with two KPI chips
    const header = `
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;flex-wrap:wrap;gap:8px">
        <div class="section-title mb-0">${perfIcon} Performance Cases</div>
        <div style="display:flex;gap:6px;flex-wrap:wrap">
          <span style="display:inline-flex;align-items:center;gap:4px;font-size:11px;font-weight:600;padding:3px 10px;border-radius:var(--radius-md);background:rgba(218,30,40,.09);color:var(--red);border:1px solid rgba(218,30,40,.2)">
            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            ${newCount} New this week
          </span>
          <span style="display:inline-flex;align-items:center;gap:4px;font-size:11px;font-weight:600;padding:3px 10px;border-radius:var(--radius-md);background:rgba(15,98,254,.09);color:var(--ibm-blue-50);border:1px solid rgba(15,98,254,.2)">
            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
            ${inpCount} In Progress
          </span>
        </div>
      </div>`;

    // Merge: new-this-week first, then remaining in-progress, deduplicated
    const newCNs  = new Set(D.perfNewThisWeek.map(r => r["Case Number"]));
    const inpOnly = D.perfInProgress.filter(r => !newCNs.has(r["Case Number"]));
    const rows    = [...D.perfNewThisWeek, ...inpOnly];

    if (!rows.length) {
      return header + `<div class="ov7-empty" style="padding:18px 4px">No performance cases found</div>`;
    }

    const SEV_COLORS = { "1": "var(--chart-5)", "2": "var(--orange)", "3": "var(--chart-3)", "4": "var(--chart-2)" };
    const SEV_BG     = { "1": "rgba(218,30,40,.1)", "2": "rgba(224,112,0,.1)", "3": "rgba(166,120,0,.1)", "4": "rgba(25,128,56,.1)" };

    const list = rows.map(r => {
      const cn        = r["Case Number"] || "—";
      const sev       = String(r.Severity || r.severity || "");
      const sevColor  = SEV_COLORS[sev] || "var(--text-tertiary)";
      const sevBg     = SEV_BG[sev]    || "rgba(107,114,128,.1)";
      const status    = r.Status || "";
      const isClosed  = Utils.isClosed(status);
      const isNew     = newCNs.has(cn);
      const wi        = ((D.perfMeta[cn] || {}).workItem || "").trim();
      const latestWc     = ((D.perfMeta[cn] || {}).latestWc     || "").trim();
      const latestWcDate = ((D.perfMeta[cn] || {}).latestWcDate || "").trim();

      // Status pill
      const stLabel = status === "Awaiting your feedback" ? "Awaiting Feedback"
                    : status === "IBM is working"         ? "IBM Working"
                    : status === "Waiting for IBM"        ? "Waiting IBM"
                    : status.includes("Closed")           ? "Closed"
                    : status || "—";
      const stColor = status === "Awaiting your feedback" ? "var(--chart-3)"
                    : status === "IBM is working"         ? "var(--chart-1)"
                    : status === "Waiting for IBM"        ? "var(--chart-4)"
                    : status.includes("Closed")           ? "var(--text-tertiary)"
                    : "var(--text-tertiary)";
      const stBg    = status === "Awaiting your feedback" ? "rgba(166,120,0,.09)"
                    : status === "IBM is working"         ? "rgba(15,98,254,.08)"
                    : status === "Waiting for IBM"        ? "rgba(105,41,196,.08)"
                    : status.includes("Closed")           ? "rgba(107,114,128,.08)"
                    : "rgba(107,114,128,.08)";

      // Age badge
      const createdD  = Utils.parseDate(r.Created);
      const ageD      = createdD ? Utils.daysDiff(createdD) : null;
      const ageBadge  = ageD !== null
        ? `<span style="font-size:10px;color:${ageD<=7?'var(--chart-5)':'var(--text-tertiary)'};font-family:var(--font-mono)">${ageD === 0 ? "today" : ageD + "d"}</span>`
        : "";

      // New-this-week badge
      const newBadge = isNew
        ? `<span style="font-size:9px;font-weight:600;padding:1px 5px;border-radius:var(--radius-sm);background:rgba(218,30,40,.12);color:var(--red);border:1px solid rgba(218,30,40,.25);flex-shrink:0">NEW</span>`
        : "";

      // Work Item badge
      const wiBadge = wi
        ? `<span style="font-size:10px;font-family:var(--font-mono);padding:1px 6px;border-radius:var(--radius-sm);background:rgba(0,125,121,.08);color:var(--teal);border:1px solid rgba(0,125,121,.2);flex-shrink:0" title="Work Item">${Utils.escHtml(wi)}</span>`
        : `<span style="font-size:10px;padding:1px 6px;border-radius:var(--radius-sm);background:rgba(218,30,40,.06);color:var(--red);border:1px solid rgba(218,30,40,.15);flex-shrink:0">No WI</span>`;

      const title = r.Title || r.title || "";
      const owner = Utils.shortName ? Utils.shortName(r.Owner || "") : (r.Owner || "");

      const wcBadge = latestWc
        ? `<div style="font-size:var(--font-size-xs);color:var(--text-secondary);background:var(--bg-hover);border:1px solid var(--border-subtle);border-radius:var(--radius-xs);padding:3px 8px;margin-top:4px;line-height:1.4;word-break:break-word" title="Wednesday update ${Utils.escHtml(latestWcDate)}">
             <span style="font-size:9px;font-weight:600;color:var(--text-tertiary);text-transform:none;letter-spacing:.04em;margin-right:4px">💬 ${Utils.escHtml(latestWcDate)}</span>${Utils.escHtml(latestWc)}
           </div>`
        : "";

      return `<div class="ov7-act-row" style="align-items:flex-start;gap:8px;padding:8px 4px;flex-wrap:wrap">
        <!-- Left: sev dot + case number + new badge -->
        <div style="display:flex;align-items:center;gap:4px;flex-shrink:0;min-width:130px">
          <span style="width:7px;height:7px;border-radius:50%;background:${sevColor};flex-shrink:0;margin-top:3px"></span>
          <span style="font-family:var(--font-mono);font-size:12px;font-weight:600;color:var(--ibm-blue-50)">${Utils.escHtml(cn)}</span>
          ${newBadge}
        </div>
        <!-- Middle: title + owner + WI badge + wednesday comment -->
        <div style="flex:1;min-width:0;display:flex;flex-direction:column;gap:4px">
          <span style="font-size:12px;color:var(--text-primary);overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${Utils.escHtml(title)}">${Utils.escHtml(title) || "—"}</span>
          <div style="display:flex;align-items:center;gap:4px;flex-wrap:wrap">
            <span class="text-11 text-muted">${Utils.escHtml(owner)}</span>
            <span style="color:var(--text-disabled);font-size:10px">·</span>
            ${wiBadge}
          </div>
          ${wcBadge}
        </div>
        <!-- Right: severity + status + age -->
        <div style="display:flex;align-items:center;gap:4px;flex-shrink:0;flex-wrap:wrap;justify-content:flex-end">
          <span style="font-size:10px;font-weight:600;padding:1px 6px;border-radius:var(--radius-sm);background:${sevBg};color:${sevColor};font-family:var(--font-mono)">S${Utils.escHtml(sev)||"?"}</span>
          <span style="font-size:10px;font-weight:600;padding:1px 7px;border-radius:var(--radius-sm);background:${stBg};color:${stColor}">${Utils.escHtml(stLabel)}</span>
          ${ageBadge}
        </div>
      </div>`;
    }).join("");

    return header + `<div class="ov7-activity-list">${list}</div>`;
  }

  // Table meta summary row
  function _tableMeta(D) {
    const aw = D.open.filter(r=>r.Status==="Awaiting your feedback").length;
    const wi = D.open.filter(r=>r.Status==="Waiting for IBM").length;
    return `
      <span class="ov7-meta-chip">${IC.table} <b>${D.open.length}</b> Active</span>
      <span class="ov7-meta-chip" style="color:var(--yellow)">${IC.clock} Oldest <b>${D.oldestDays}d</b></span>
      <span class="ov7-meta-chip" style="color:var(--yellow)">${IC.alert} <b>${aw}</b> Awaiting Feedback</span>
      <span class="ov7-meta-chip c-purple">${IC.alert} <b>${wi}</b> Awaiting IBM</span>`;
  }

  // Filter chips
  function _chipsHTML(D) {
    const configs = [
      ["all",                      "All",               D.open.length],
      ["Awaiting your feedback",   "Awaiting your Feedback", D.open.filter(r=>r.Status==="Awaiting your feedback").length],
      ["IBM is working",           "IBM Working",       D.open.filter(r=>r.Status==="IBM is working").length],
      ["Waiting for IBM",          "Waiting for IBM",   D.open.filter(r=>r.Status==="Waiting for IBM").length],
    ];
    return configs.map(([v,l,c]) =>
      `<button class="ov7-chip${_filter===v?" ov7-chip-on":""}" data-chipval="${Utils.escHtml(v)}">${l} <span class="ov7-chip-n">${c}</span></button>`
    ).join("");
  }

  // Trend slice helper
  function _trendSlice(D) {
    return _tw === 3 ? D.allTrend.slice(-3)
         : _tw === 6 ? D.allTrend.slice(-6)
         : _tw === 12 ? D.allTrend.slice(-12)
         : D.allTrend;   // 0 = ALL
  }

  /* ══════════════════════════════════════════════════════════
     EVENT WIRING
     ════════════════════════════════════════════════════════ */
  function _wireEvents(D) {

    // ── Tier 1.1: Wire PD show-more buttons (alerts list) ─────────
    if (typeof PD !== "undefined") {
      const alertsBody = document.getElementById("ov7-alerts-body");
      if (alertsBody) PD.wireShowMore(alertsBody);
    }

    // ── Trend window toggle ────────────────────────────────
    document.querySelectorAll(".ov7-tw:not(.ov7-stw):not(.ov7-c3tab)").forEach(btn => {
      btn.addEventListener("click", () => {
        _tw = parseInt(btn.dataset.tw);
        document.querySelectorAll(".ov7-tw").forEach(b => b.classList.toggle("ov7-tw-active", b === btn));
        const slice   = _trendSlice(D);
        const tC      = slice.reduce((s,r)=>s+r.created,0);
        const tCl     = slice.reduce((s,r)=>s+r.closed,0);
        const twLabel = _tw === 0 ? "All Time" : `Last ${_tw}M`;
        const sumEl   = document.getElementById("ov7-trend-summary");
        if (sumEl) sumEl.innerHTML = `
          <span class="ov7-ts-label">${twLabel}:</span>
          <span class="ov7-ts-created">${tC} Created</span>
          <span class="ov7-ts-sep">·</span>
          <span class="ov7-ts-closed">${tCl} Closed</span>`;
        const kpiBarEl = document.getElementById("ov7-kpi-bar");
        if (kpiBarEl) kpiBarEl.outerHTML = window._ov7KpiBarHTML(tC, tCl, slice);
        try { Charts.trendLine("chart-trend", slice, { onClick: lbl => _drillByMonth(lbl, D) }); } catch(e){}
        const winEl = document.querySelector(".text-11.text-muted");
        if (winEl) winEl.textContent = _tw === 0 ? "All time" : `${_tw}M window`;
      });
    });

    // ── Status donut window toggle (independent) ──────────
    document.querySelectorAll(".ov7-stw").forEach(btn => {
      btn.addEventListener("click", () => {
        _stw = parseInt(btn.dataset.stw);
        document.querySelectorAll(".ov7-stw").forEach(b => b.classList.toggle("ov7-tw-active", b === btn));
        const sSlice = _stw === 3 ? D.allTrend.slice(-3)
                     : _stw === 6 ? D.allTrend.slice(-6)
                     : _stw === 12 ? D.allTrend.slice(-12)
                     : D.allTrend;
        const sC  = sSlice.reduce((s,r)=>s+r.created,0);
        const sCl = sSlice.reduce((s,r)=>s+r.closed,0);
        const sLabel = _stw === 0 ? "All Time" : `Last ${_stw}M`;
        const sSum = document.getElementById("ov7-status-summary");
        if (sSum) sSum.innerHTML = `
          <span class="ov7-ts-label">${sLabel}:</span>
          <span class="ov7-ts-created">${sC} Created</span>
          <span class="ov7-ts-sep">·</span>
          <span class="ov7-ts-closed">${sCl} Closed</span>`;
        // Filter active cases by Created date window
        const now = Utils.today();
        const sFiltered = _stw === 0 ? D.open : D.open.filter(r => {
          const d = Utils.parseDate(r.Created);
          return d && (now - d) / (86400000 * 30) <= _stw;
        });
        const sMap = {};
        sFiltered.forEach(r => {
          const st = (r.Status || "").trim();
          if (Utils.ACTIVE_STATUSES.has(st)) sMap[st] = (sMap[st]||0)+1;
        });
        const sData = Object.entries(sMap).filter(([,v])=>v>0).sort((a,b)=>b[1]-a[1]).map(([name,value])=>({name,value}));
        // Update summary line with active count
        const sSumEl = document.getElementById("ov7-status-summary");
        if (sSumEl) sSumEl.innerHTML = `
          <span class="ov7-ts-label">${sLabel}:</span>
          <span class="ov7-ts-created">${sFiltered.length} Active Cases</span>`;
        try {
          Charts.statusDonut("chart-status", sData, {
            onClick: st => _drillTo(`Status: ${st}`, sFiltered.filter(r => r.Status === st))
          });
        } catch(e) { console.warn("statusDonut:", e); }
      });
    });

    // ── Status legend click ────────────────────────────────
    document.querySelectorAll(".ov7-leg-row").forEach(row => {
      row.addEventListener("click", () => {
        const st = row.dataset.status;
        _drillTo(`Status: ${st}`, D.open.filter(r => r.Status === st));
      });
    });

    // ── Alert row click ────────────────────────────────────
    document.querySelectorAll(".ov7-alert-row").forEach(row => {
      row.addEventListener("click", () => {
        const aid = row.dataset.aid;
        const map = {
          awaitcust: [D.awaitCust5d, "Awaiting your Feedback >5d"],
          waitibm:   [D.waitIBM5d,   "Waiting for IBM >5d"],
          esc:       [D.escalated,    "Escalated Cases"],
          oldest:    [D.open,         "All Active (by Age)"],
        };
        if (map[aid]) _drillTo(map[aid][1], map[aid][0]);
      });
    });

    // ── Table filter chips ─────────────────────────────────
    function wireChips() {
      document.querySelectorAll(".ov7-chip").forEach(c => {
        c.addEventListener("click", () => {
          _filter = c.dataset.chipval;
          _applyTableFilter(D);
          const chipsEl = document.getElementById("ov7-chips");
          if (chipsEl) { chipsEl.innerHTML = _chipsHTML(D); wireChips(); }
        });
      });
    }
    wireChips();

    // ── Table search ───────────────────────────────────────
    document.getElementById("ov7-table-search")?.addEventListener("input", function() {
      _search = this.value;
      _applyTableFilter(D);
    });

    // ── Drill reset ────────────────────────────────────────
    document.getElementById("drill-reset")?.addEventListener("click", () => {
      _filter = "all";
      _search = "";
      const si = document.getElementById("ov7-table-search");
      if (si) si.value = "";
      // F20: Drill-reset shows full table when triggered
      _renderTable(D.open, "Active Team Cases");
      document.getElementById("drill-reset").style.display = "none";
      const chipsEl = document.getElementById("ov7-chips");
      if (chipsEl) { chipsEl.innerHTML = _chipsHTML(D); wireChips(); }
    });

    // F20: View all → navigates to Team Cases
    document.getElementById("ov7-view-all-btn")?.addEventListener("click", () => {
      try { if (typeof App !== "undefined") App.renderTab("team"); } catch(e) {}
    });

    // ── Quick actions ──────────────────────────────────────
    document.getElementById("ov7-btn-refresh")?.addEventListener("click", () => {
      try { if (typeof App !== "undefined" && App.refresh) App.refresh(); else render(); } catch(e) { render(); }
    });
    document.getElementById("ov7-btn-export")?.addEventListener("click", () => {
      try {
        if (typeof Export !== "undefined") Export.run(D.open);
        else if (typeof toast !== "undefined") toast("Export", "Use the Performance or Created tabs to export CSV", "info");
      } catch(e){}
    });
    document.getElementById("ov7-btn-invest")?.addEventListener("click", () => {
      document.querySelector("[data-tab='investigate']")?.click();
    });
    // F23: View Member Dashboard link
    document.getElementById("ov7-view-members-btn")?.addEventListener("click", () => {
      try { if (typeof App !== "undefined") App.renderTab("members"); } catch(e) {}
    });
  }

  /* ══════════════════════════════════════════════════════════
     TABLE HELPERS
     ════════════════════════════════════════════════════════ */
  function _applyTableFilter(D) {
    let cases = _filter === "all" ? D.open : D.open.filter(r => r.Status === _filter);
    if (_search.trim()) {
      const q = _search.toLowerCase();
      cases = cases.filter(r =>
        (r["Case Number"]||"").toLowerCase().includes(q) ||
        (r.Title||"").toLowerCase().includes(q)          ||
        (r.Owner||"").toLowerCase().includes(q)          ||
        (r.Status||"").toLowerCase().includes(q)         ||
        (r.Product||"").toLowerCase().includes(q)
      );
    }
    _renderTable(cases, _filter === "all" ? "Active Team Cases" : _filter);
  }

  function _drillTo(title, cases) {
    _renderTable(cases, title);
    document.getElementById("drill-reset").style.display = "";
    document.getElementById("tile-drill")?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function _drillByMonth(label, D) {
    // label format is "MM/YY" e.g. "04/26"
    const parts = label.split("/");
    const mon = parseInt(parts[0], 10) - 1; // 0-indexed
    const yr  = 2000 + parseInt(parts[1], 10);
    const cases = D.team.filter(r => {
      const d = Utils.parseDate(r.Created);
      return d && d.getMonth() === mon && d.getFullYear() === yr;
    });
    _drillTo(`Monthly: ${label}`, cases);
  }

  function _renderTable(cases, title) {
    const el = document.getElementById("drill-title");
    if (el) el.innerHTML = `${IC.table} ${Utils.escHtml(title)} <span style="font-family:var(--font-mono);font-size:10px;color:var(--text-disabled);font-weight:400">(${cases.length})</span>`;
    try {
      const tblEl = document.getElementById("tbl-overview");
      if (_tableRef) {
        _tableRef.refresh(cases);
      } else {
        _tableRef = Table.render(tblEl, cases, { showRemind: false, showReassign: false });
      }
    } catch(e) { console.warn("Table.render:", e); }
  }


  /* ── Cases by Team: stat cards ─────────────────────────── */
  function _teamCardsHTML(teamData) {
    if (!teamData || !teamData.length) {
      return '<div style="padding:20px;text-align:center;color:var(--text-tertiary);font-size:12px;">No team data</div>';
    }
    const COLORS = {
      'Operation':  '#0f62fe',
      'German':     '#8a3ffc',
      'Automation': '#009d9a',
      'Tools':      '#ff832b',
      'Database':   '#198038',
    };
    const total = teamData.reduce((s, d) => s + d.value, 0) || 1;
    return teamData
      .sort((a, b) => b.value - a.value)
      .map(d => {
        const pct   = Math.round(d.value / total * 100);
        const color = COLORS[d.name] || '#6f6f6f';
        return '<div style="display:flex;align-items:center;gap:12px;padding:10px 14px;margin-bottom:8px;transition:background .15s;'
             + 'background:var(--bg-subtle);border-radius:8px;border:1px solid var(--border-subtle);cursor:pointer;"'
             + ' onclick="window._ov7TeamDrill&&window._ov7TeamDrill(\'' + d.name + '\')">'
             + '<div style="flex:1;min-width:0;">'
             + '<div style="font-size:11px;font-weight:600;color:var(--text-secondary);text-transform:uppercase;'
             + 'letter-spacing:.06em;margin-bottom:6px;">'
             + d.name + '</div>'
             + '<div style="height:7px;background:var(--border-subtle);border-radius:4px;overflow:hidden;">'
             + '<div style="height:7px;background:' + color + ';border-radius:4px;width:' + pct + '%;transition:width .5s ease;"></div>'
             + '</div></div>'
             + '<div style="text-align:right;flex-shrink:0;min-width:44px;">'
             + '<div style="font-size:20px;font-weight:700;color:var(--text-primary);line-height:1;">' + d.value + '</div>'
             + '<div style="font-size:10px;color:var(--text-tertiary);margin-top:1px;">' + pct + '%</div>'
             + '</div></div>';
      }).join('');
  }


  /* ══════════════════════════════════════════════════════════
     CHART RENDERING
     ════════════════════════════════════════════════════════ */
  function _renderCharts(D) {
    const slice = _trendSlice(D);

    try {
      Charts.trendLine("chart-trend", slice, {
        onClick: lbl => _drillByMonth(lbl, D)
      });
    } catch(e) { console.warn("trendLine:", e); }

    try {
      Charts.statusDonut("chart-status", D.statusData, {
        onClick: st => _drillTo(`Status: ${st}`, D.open.filter(r => r.Status === st))
      });
    } catch(e) { console.warn("statusDonut:", e); }

    try {
      Charts.ownerBar("chart-owners", D.ownerData, {
        color: "var(--ibm-blue-30)",
        onClick: own => _drillTo(`Owner: ${Utils.shortName(own)}`, D.open.filter(r => r.Owner === own))
      });
    } catch(e) { console.warn("ownerBar:", e); }

    // Severity data
    const _ovSevMap = { "1":0, "2":0, "3":0, "4":0 };
    D.open.forEach(r => { const sv = String(r.Severity||"").trim(); if (_ovSevMap[sv]!==undefined) _ovSevMap[sv]++; else if(sv) _ovSevMap[sv]=(_ovSevMap[sv]||0)+1; });
    const _ovSevData = Object.entries(_ovSevMap).filter(([,v])=>v>0).map(([name,value])=>({name:"Sev "+name,value}));

    // Aging buckets
    const _ovAgingBuckets = {"0-4d":0,"5-9d":0,"10-29d":0,"30d+":0};
    D.open.forEach(r => {
      const d = Utils.daysDiff(Utils.parseDate(r.Updated || r.Created));
      if      (d <  5) _ovAgingBuckets["0-4d"]++;
      else if (d < 10) _ovAgingBuckets["5-9d"]++;
      else if (d < 30) _ovAgingBuckets["10-29d"]++;
      else             _ovAgingBuckets["30d+"]++;
    });
    const _ovAgingData = Object.entries(_ovAgingBuckets).map(([name,value])=>({name,value}));

    // KPI strip renderer
    function _ovChart3KpiStrip(items, color) {
      const el = document.getElementById("ov7-chart3-kpi-strip");
      if (!el) return;
      const total = items.reduce((s,d) => s + d.value, 0) || 1;
      const top   = [...items].sort((a,b) => b.value - a.value).slice(0,6);
      const _abbr = name => {
        const MAP = {
          "engineering wf mgmt":"EWM","engineering workflow mgmt":"EWM",
          "engineering req. mgmt doors next":"DNG","engineering req. mgmt door":"DNG",
          "engineering requirements management doors next":"DNG",
          "engineering test mgmt":"ETM","engineering test management":"ETM",
          "engineering lc mgmt base":"ELMB","engineering lifecycle mgmt base":"ELMB",
          "engineering lc mgmt suite":"ELMS","engineering lifecycle mgmt suite":"ELMS",
        };
        const key = (name||"").toLowerCase().trim();
        if (MAP[key]) return MAP[key];
        const skip = new Set(["by","of","the","and","for","in","a"]);
        return key.split(/[\s.\-_]+/).filter(w=>w.length>0&&!skip.has(w)).map(w=>w[0].toUpperCase()).join("").slice(0,5)||name.slice(0,5).toUpperCase();
      };
      el.innerHTML = top.map((d,i) => {
        const pct = Math.round(d.value/total*100);
        const bl  = i > 0 ? "border-left:1px solid var(--border-subtle);" : "";
        return `<div style="flex:1;min-width:50px;display:flex;flex-direction:column;padding:4px 8px 6px ${i?8:4}px;${bl}">`
          + `<div style="font-size:8px;font-weight:700;letter-spacing:.06em;color:var(--text-tertiary);text-transform:uppercase;margin-bottom:3px;white-space:nowrap" title="${d.name}">${_abbr(d.name)}</div>`
          + `<div style="font-size:15px;font-weight:700;font-family:var(--font-mono);color:var(--text-primary);line-height:1">${d.value}</div>`
          + `<div style="flex:1"></div>`
          + `<div style="font-size:9px;color:var(--text-tertiary);margin-top:3px">${pct}%</div>`
          + `<div style="height:3px;background:var(--border-subtle);border-radius:2px;margin-top:4px;overflow:hidden"><div style="height:3px;border-radius:2px;background:${color};width:${pct}%;transition:width .4s ease"></div></div>`
          + `</div>`;
      }).join("");
    }

    function _ovRenderProduct() {
      document.getElementById("chart-products").style.display       = "";
      document.getElementById("chart-ov7-severity").style.display   = "none";
      document.getElementById("chart-ov7-aging").style.display      = "none";
      document.getElementById("ov7-chart3-title").textContent = "Cases by Product";
      try { Charts.productBar("chart-products", D.prodData, {
        onClick: p => _drillTo(`Product: ${p}`, D.open.filter(r => (r.Product||"Unknown") === p))
      }); } catch(e) {}
      _ovChart3KpiStrip(D.prodData, "var(--ibm-blue-40,#4589ff)");
    }
    function _ovRenderSeverity() {
      document.getElementById("chart-products").style.display       = "none";
      document.getElementById("chart-ov7-severity").style.display   = "";
      document.getElementById("chart-ov7-aging").style.display      = "none";
      document.getElementById("ov7-chart3-title").textContent = "Cases by Severity";
      try { Charts.ownerBar("chart-ov7-severity", _ovSevData.map(d=>({name:d.name,count:d.value,fullName:d.name})), {
        color: "var(--chart-5)",
        label: "Cases",
        onClick: name => { const sv=name.replace("Sev ",""); _drillTo("Severity "+name, D.open.filter(r=>String(r.Severity||"").trim()===sv)); }
      }); } catch(e) {}
      _ovChart3KpiStrip(_ovSevData, "var(--chart-5,#8a3ffc)");
    }
    function _ovRenderAging() {
      document.getElementById("chart-products").style.display       = "none";
      document.getElementById("chart-ov7-severity").style.display   = "none";
      document.getElementById("chart-ov7-aging").style.display      = "";
      document.getElementById("ov7-chart3-title").textContent = "Cases by Aging";
      try { Charts.ownerBar("chart-ov7-aging", _ovAgingData.map(d=>({name:d.name,count:d.value,fullName:d.name})), {
        color: "var(--red,#da1e28)",
        label: "Cases"
      }); } catch(e) {}
      _ovChart3KpiStrip(_ovAgingData, "var(--red,#da1e28)");
    }

    try { _ovRenderProduct(); } catch(e) { console.warn("productBar:", e); }

    // Wire tab buttons
    document.querySelectorAll(".ov7-c3tab").forEach(btn => {
      btn.addEventListener("click", () => {
        document.querySelectorAll(".ov7-c3tab").forEach(b => b.classList.toggle("ov7-tw-active", b===btn));
        if (btn.dataset.c3tab === "product")  _ovRenderProduct();
        if (btn.dataset.c3tab === "severity") _ovRenderSeverity();
        if (btn.dataset.c3tab === "aging")    _ovRenderAging();
      });
    });

    // Expose team drill for card onclick
    window._ov7TeamDrill = function(team) {
      const tg = (typeof DynamicConfig !== 'undefined' && DynamicConfig.teamGroups) ? DynamicConfig.teamGroups() : {};
      const cases = D.open.filter(function(r) {
        const grp = tg[(r.Owner || '').toLowerCase()] || '';
        return grp.toLowerCase() === team.toLowerCase();
      });
      _drillTo('Team: ' + team, cases);
    };
  }

  /* ══════════════════════════════════════════════════════════
     POST-UPGRADE CASE TRACKING  (Zone 7)
     ════════════════════════════════════════════════════════ */

  function _buildUpgradeShell() {
    return `
<div class="tile no-hover" style="padding:16px" id="ov-upgrade-shell">
  <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:12px">
    <div class="section-title mb-0" style="color:var(--teal,#009d9a)">${IC.upgrade} Post-Upgrade Case Tracking</div>
    <select id="ov-upgrade-select" class="form-input form-input-sm" style="min-width:260px;max-width:400px">
      <option value="">— Loading upgrades… —</option>
    </select>
    <span id="ov-upgrade-hint" style="font-size:11px;color:var(--text-tertiary)">Select an ELM iFix upgrade to see cases raised after that date</span>
  </div>
  <div id="ov-upgrade-results"></div>
</div>`;
  }

  async function _loadUpgradeDropdown() {
    const sel = document.getElementById('ov-upgrade-select');
    if (!sel) return;
    try {
      const API = (window.API_BASE_V2 || '/iip/api/v2');
      const upgrades = await fetch(API + '/elm-upgrades').then(r => r.ok ? r.json() : []);
      if (!upgrades.length) {
        sel.innerHTML = '<option value="">— No upgrades recorded yet —</option>';
        return;
      }
      sel.innerHTML = '<option value="">— Select an upgrade — </option>' +
        upgrades.map(u => {
          const label = `${u.elm_version}  ${u.ifix_version}  (${u.upgrade_date})`;
          return `<option value="${u.id}" data-date="${u.upgrade_date}" data-label="${Utils.escHtml(label)}">${Utils.escHtml(label)}</option>`;
        }).join('');
      sel.addEventListener('change', () => {
        const opt = sel.options[sel.selectedIndex];
        if (!opt.value) { document.getElementById('ov-upgrade-results').innerHTML = ''; return; }
        _renderUpgradeResults(
          parseInt(opt.value), opt.dataset.date, opt.dataset.label,
          upgrades.find(u => u.id === parseInt(opt.value))
        );
      });
    } catch(e) {
      sel.innerHTML = '<option value="">— Failed to load upgrades —</option>';
      console.warn('ELM upgrades load failed:', e);
    }
  }

  function _renderUpgradeResults(upgradeId, upgradeDate, upgradeLabel, upgradeRow) {
    const resultsEl = document.getElementById('ov-upgrade-results');
    if (!resultsEl) return;

    // Filter cases from in-memory data — no extra API call needed
    const allCases = typeof Data !== 'undefined' ? Data.allCases() : [];
    const cutoff   = upgradeDate ? new Date(upgradeDate) : null;
    if (!cutoff) { resultsEl.innerHTML = '<p style="color:var(--text-tertiary);font-size:12px">Invalid upgrade date.</p>'; return; }

    const postUpgrade = allCases.filter(c => {
      const d = Utils.parseDate(c.Created || c.created_date || c['Created Date'] || '');
      return d && d >= cutoff;
    });

    const CLOSED = new Set(['Closed by IBM','Closed by Client','Closed - Archived','Cancelled']);
    const open_  = postUpgrade.filter(c => !CLOSED.has(c.Status || c.status || ''));
    const closed = postUpgrade.filter(c =>  CLOSED.has(c.Status || c.status || ''));

    // Severity breakdown
    const sevMap = {};
    postUpgrade.forEach(c => { const s = c.Severity || c.severity || 'Unknown'; sevMap[s] = (sevMap[s]||0)+1; });
    const sevOrder = ['1','2','3','4','Unknown'];
    const sevBadges = sevOrder
      .filter(s => sevMap[s])
      .map(s => `<span style="display:inline-flex;align-items:center;gap:4px;background:var(--bg-secondary);border-radius:4px;padding:2px 8px;font-size:11px;font-family:var(--font-mono)">${s === 'Unknown' ? '?' : 'Sev '+s} <b>${sevMap[s]}</b></span>`)
      .join(' ');

    // Top owners (open cases only)
    const ownerMap = {};
    open_.forEach(c => { const o = c['Display Name'] || c.Owner || c.owner_name || '?'; ownerMap[o]=(ownerMap[o]||0)+1; });
    const topOwners = Object.entries(ownerMap).sort((a,b)=>b[1]-a[1]).slice(0,8);

    // Newly created this week post-upgrade
    const _7dAgo = new Date(Date.now() - 7*86400000);
    const newThisWeek = postUpgrade.filter(c => {
      const d = Utils.parseDate(c.Created || c.created_date || '');
      return d && d >= _7dAgo;
    });

    const noteHtml = upgradeRow && upgradeRow.notes
      ? `<div style="margin-top:4px;font-size:11px;color:var(--text-tertiary);font-style:italic">${Utils.escHtml(upgradeRow.notes)}</div>`
      : '';

    resultsEl.innerHTML = `
<div style="border-top:1px solid var(--border-subtle);padding-top:12px;margin-top:4px">
  <!-- Banner -->
  <div style="display:flex;align-items:center;gap:8px;margin-bottom:12px;flex-wrap:wrap">
    <span style="font-size:12px;font-weight:600;color:var(--teal,#009d9a);background:var(--bg-teal-subtle,rgba(0,157,154,.08));border:1px solid var(--teal,#009d9a);border-radius:4px;padding:2px 10px;font-family:var(--font-mono)">${Utils.escHtml(upgradeLabel)}</span>
    <span style="font-size:11px;color:var(--text-secondary)">Cases created on or after <b>${upgradeDate}</b></span>
  </div>
  ${noteHtml}

  <!-- KPI strip -->
  <div style="display:flex;gap:12px;flex-wrap:wrap;margin-bottom:14px">
    <div style="background:var(--bg-secondary);border-radius:6px;padding:10px 16px;min-width:90px;text-align:center">
      <div style="font-size:22px;font-weight:700;font-family:var(--font-mono);color:var(--text-primary)">${postUpgrade.length}</div>
      <div style="font-size:11px;color:var(--text-tertiary);margin-top:2px">Total cases</div>
    </div>
    <div style="background:var(--bg-secondary);border-radius:6px;padding:10px 16px;min-width:90px;text-align:center">
      <div style="font-size:22px;font-weight:700;font-family:var(--font-mono);color:var(--yellow,#f1c21b)">${open_.length}</div>
      <div style="font-size:11px;color:var(--text-tertiary);margin-top:2px">Still open</div>
    </div>
    <div style="background:var(--bg-secondary);border-radius:6px;padding:10px 16px;min-width:90px;text-align:center">
      <div style="font-size:22px;font-weight:700;font-family:var(--font-mono);color:var(--green,#24a148)">${closed.length}</div>
      <div style="font-size:11px;color:var(--text-tertiary);margin-top:2px">Closed</div>
    </div>
    <div style="background:var(--bg-secondary);border-radius:6px;padding:10px 16px;min-width:90px;text-align:center">
      <div style="font-size:22px;font-weight:700;font-family:var(--font-mono);color:var(--ibm-blue-40,#4589ff)">${newThisWeek.length}</div>
      <div style="font-size:11px;color:var(--text-tertiary);margin-top:2px">New this week</div>
    </div>
    ${postUpgrade.length > 0 ? `<div style="background:var(--bg-secondary);border-radius:6px;padding:10px 16px;min-width:90px;text-align:center">
      <div style="font-size:22px;font-weight:700;font-family:var(--font-mono);color:var(--text-primary)">${Math.round(closed.length*100/postUpgrade.length)}%</div>
      <div style="font-size:11px;color:var(--text-tertiary);margin-top:2px">Close rate</div>
    </div>` : ''}
  </div>

  <!-- Severity row -->
  ${sevBadges ? `<div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:12px;align-items:center">
    <span style="font-size:11px;color:var(--text-tertiary);margin-right:4px">Severity:</span>${sevBadges}
  </div>` : ''}

  <!-- Top owners -->
  ${topOwners.length ? `<div style="margin-bottom:14px">
    <div style="font-size:11px;font-weight:600;color:var(--text-secondary);margin-bottom:6px;text-transform:uppercase;letter-spacing:.05em">Top owners (open cases)</div>
    <div style="display:flex;gap:6px;flex-wrap:wrap">
      ${topOwners.map(([o,n]) => `<span style="background:var(--bg-secondary);border-radius:4px;padding:2px 8px;font-size:11px">${Utils.escHtml(o)} <b style="color:var(--ibm-blue-40,#4589ff)">${n}</b></span>`).join('')}
    </div>
  </div>` : ''}

  <!-- Case table -->
  ${postUpgrade.length === 0
    ? '<div style="color:var(--text-tertiary);font-size:12px;padding:12px 0">No cases found created on or after this upgrade date.</div>'
    : `<div style="margin-top:4px">
    <div style="font-size:11px;font-weight:600;color:var(--text-secondary);margin-bottom:6px;text-transform:uppercase;letter-spacing:.05em">Cases (${postUpgrade.length})</div>
    <div style="overflow-x:auto">
    <table style="width:100%;border-collapse:collapse;font-size:12px">
      <thead>
        <tr style="border-bottom:1px solid var(--border-subtle)">
          <th style="text-align:left;padding:4px 8px;color:var(--text-tertiary);font-weight:600">Case #</th>
          <th style="text-align:left;padding:4px 8px;color:var(--text-tertiary);font-weight:600">Title</th>
          <th style="text-align:left;padding:4px 8px;color:var(--text-tertiary);font-weight:600">Owner</th>
          <th style="text-align:left;padding:4px 8px;color:var(--text-tertiary);font-weight:600">Sev</th>
          <th style="text-align:left;padding:4px 8px;color:var(--text-tertiary);font-weight:600">Status</th>
          <th style="text-align:left;padding:4px 8px;color:var(--text-tertiary);font-weight:600">Created</th>
        </tr>
      </thead>
      <tbody>
        ${postUpgrade.slice(0,50).map(c => {
          const cn     = c['Case Number'] || c.case_number || '';
          const title  = c.Title  || c.title  || '';
          const owner  = c['Display Name'] || c.Owner || c.owner_name || '';
          const sev    = c.Severity || c.severity || '';
          const status = c.Status  || c.status  || '';
          const created= c.Created || c.created_date || '';
          const isClosed = CLOSED.has(status);
          const sevColor = sev === '1' ? 'var(--red)' : sev === '2' ? 'var(--orange)' : 'var(--text-secondary)';
          return `<tr style="border-bottom:1px solid var(--border-subtle);${isClosed ? 'opacity:.55' : ''}">
            <td style="padding:5px 8px;font-family:var(--font-mono);white-space:nowrap"><a class="link-blue" data-case="${Utils.escHtml(cn)}" style="cursor:pointer">${Utils.escHtml(cn)}</a></td>
            <td style="padding:5px 8px;max-width:260px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${Utils.escHtml(title)}">${Utils.escHtml(title)}</td>
            <td style="padding:5px 8px;white-space:nowrap">${Utils.escHtml(Utils.shortName(owner))}</td>
            <td style="padding:5px 8px;color:${sevColor};font-weight:600">${Utils.escHtml(sev)}</td>
            <td style="padding:5px 8px;white-space:nowrap">${Utils.escHtml(status)}</td>
            <td style="padding:5px 8px;white-space:nowrap;font-family:var(--font-mono)">${Utils.escHtml(created ? created.slice(0,10) : '')}</td>
          </tr>`;
        }).join('')}
      </tbody>
    </table>
    ${postUpgrade.length > 50 ? `<div style="font-size:11px;color:var(--text-tertiary);margin-top:6px">Showing first 50 of ${postUpgrade.length} cases</div>` : ''}
    </div>
  </div>`
  }
</div>`;

    // Wire case-number clicks → investigate tab
    resultsEl.querySelectorAll('[data-case]').forEach(a => {
      a.addEventListener('click', () => {
        const cn = a.dataset.case;
        try { if (typeof App !== 'undefined') App.renderTab('investigate', { caseNumber: cn }); } catch(e) {}
      });
    });
  }

  return { render };
})();
