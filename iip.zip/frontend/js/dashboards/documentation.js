﻿/* ================================================================
   documentation.js  —  IBM Case Intelligence Platform
   Complete rewrite — IBM Documentation style.
   Accurate to source code. No fabricated content.
   Stack: RHEL9 · Apache 2.4 · FastAPI 0.115.5 (Python) · asyncpg · PostgreSQL
   ================================================================ */
(function () {
  'use strict';

  const DashDocumentation = (() => {

    /* ── Icons ──────────────────────────────────────────── */
    const ICON = {
      home:    `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>`,
      rocket:  `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"/><path d="m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"/></svg>`,
      grid:    `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>`,
      cog:     `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>`,
      server:  `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="8" rx="2"/><rect x="2" y="14" width="20" height="8" rx="2"/><line x1="6" y1="6" x2="6.01" y2="6"/><line x1="6" y1="18" x2="6.01" y2="18"/></svg>`,
      tag:     `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/></svg>`,
      book:    `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>`,
      help:    `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>`,
      search:  `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>`,
      chevron: `<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>`,
      info:    `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>`,
      warn:    `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>`,
      tip:     `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>`,
      note:    `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>`,
      code:    `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>`,
    };

    /* ── Nav structure ──────────────────────────────────── */
    const NAV = [
      { id:'g-overview',  label:'Overview',          icon:'home',   items:[
        { id:'platform-overview', label:'Platform Overview'        },
        { id:'whats-new',         label:"What's New — v1.0.0"      },
        { id:'architecture',      label:'System Architecture'      },
        { id:'e2e-flowchart',     label:'Application Flowchart'    },
      ]},
      { id:'g-start',     label:'Getting Started',   icon:'rocket', items:[
        { id:'prerequisites',     label:'Prerequisites'            },
        { id:'installation',      label:'Installation & Setup'     },
        { id:'access',            label:'Accessing the Platform'   },
        { id:'first-upload',      label:'Your First Upload'        },
        { id:'navigation',        label:'Navigating the Interface' },
        { id:'boot-sequence',     label:'Boot Sequence'            },
      ]},
      { id:'g-dash',      label:'Dashboards',        icon:'grid',   items:[
        { id:'dash-overview',     label:'Overview Dashboard'       },
        { id:'dash-team',         label:'Team Cases'               },
        { id:'dash-members',      label:'Member Dashboard'         },
        { id:'dash-performance',  label:'Performance Metrics'      },
        { id:'dash-customer',     label:'Customer Cases'           },
        { id:'dash-closed',       label:'Closed Cases'             },
        { id:'dash-created',      label:'Created Cases'            },
        { id:'dash-weekly',       label:'Weekly Tracker'           },
        { id:'dash-rfe',          label:'RFE Tracking'             },
        { id:'dash-investigate',  label:'Investigate'              },
      ]},
      { id:'g-admin',     label:'Administration',    icon:'cog',    items:[
        { id:'admin-portal',      label:'Admin Portal'             },
        { id:'admin-access-guide',label:'Access Guide (Admin)'     },
        { id:'admin-config',      label:'Team Configuration'       },
        { id:'admin-tagging',     label:'Performance Tagging'      },
        { id:'admin-reassign',    label:'Owner Reassignment'       },
        { id:'admin-password',    label:'Admin Password'           },
        { id:'admin-data',        label:'Data Management'          },
      ]},
      { id:'g-ops',       label:'Operations',        icon:'server', items:[
        { id:'ops-stack',         label:'Server Stack'             },
        { id:'ops-deploy',        label:'Deploying Updates'        },
        { id:'ops-deploy-history',label:'Deployment History'       },
        { id:'ops-postgres',      label:'PostgreSQL Reference'     },
        { id:'ops-rhel9',         label:'RHEL9 + Apache Setup'     },
        { id:'ops-pm2',           label:'systemd Service'           },
        { id:'ops-security',      label:'Security Model'           },
        { id:'ops-backup',        label:'Backup and Restore'       },
      ]},
      { id:'g-tools',     label:'Tools & Features',  icon:'rocket', items:[
        { id:'cmd-palette',       label:'Command Palette'          },
        { id:'global-search',     label:'Global Search'            },
        { id:'guided-tour',       label:'Guided Tour'              },
        { id:'ref-shortcuts',     label:'Keyboard Shortcuts'       },
      ]},
      { id:'g-ref',       label:'Reference',         icon:'tag',    items:[
        { id:'ref-storage',       label:'Storage — What Lives Where'},
        { id:'ref-iipstore',      label:'IIPStore API'             },
        { id:'ref-rest-api',      label:'REST API Endpoints'       },
        { id:'ref-auth-api',      label:'Auth API'                 },
        { id:'ref-csv',           label:'CSV Column Reference'     },
        { id:'ref-metrics',       label:'Metrics Definitions'      },
        { id:'ref-sse',           label:'Real-time Updates (SSE)'  },
      ]},
      { id:'g-ts',        label:'Troubleshooting',   icon:'help',   items:[
        { id:'ts-faq',            label:'FAQs'                     },
        { id:'ts-issues',         label:'Common Issues and Fixes'  },
        { id:'ts-limits',         label:'Limits and Performance'   },
      ]},
      { id:'g-dev',       label:'Developer Docs',   icon:'code',   items:[
        { id:'dev-security-qa',   label:'Security Questions & Password Reset' },
        { id:'dev-setup',         label:'Developer Setup & Workflow'          },
        { id:'dev-auth',          label:'Authentication Architecture'         },
        { id:'dev-database',      label:'Database Schema Reference'           },
        { id:'dev-deployment',    label:'Deployment & Server Ops'            },
        { id:'dev-debugging',     label:'Debugging & Troubleshooting Guide'  },
      ]},
    ];

    /* ── HTML helpers ───────────────────────────────────── */
    const e = s => s.replace(/</g,'&lt;').replace(/>/g,'&gt;');
    function h1(t){return `<h1 style="font-size:26px;font-weight:700;color:var(--text-primary);margin:0 0 6px;letter-spacing:-.3px;line-height:1.25">${t}</h1>`;}
    function h2(t){return `<h2 style="font-size:17px;font-weight:700;color:var(--text-primary);margin:38px 0 12px;padding-bottom:9px;border-bottom:2px solid var(--border-subtle)">${t}</h2>`;}
    function h3(t){return `<h3 style="font-size:14px;font-weight:700;color:var(--text-primary);margin:22px 0 8px">${t}</h3>`;}
    function strong(t){return `<strong style="font-weight:600;color:var(--text-primary)">${t}</strong>`;}    function h3(t){return `<h3 style="font-size:14px;font-weight:700;color:var(--text-primary);margin:22px 0 8px">${t}</h3>`;}
    function p(t) {return `<p style="font-size:14px;color:var(--text-secondary);line-height:1.8;margin:0 0 14px">${t}</p>`;}
    function ic(t){return `<code style="background:var(--bg-layer-2,#e0e0e0);padding:1px 6px;border-radius:3px;font-family:var(--font-mono,'IBM Plex Mono',monospace);font-size:12px;color:var(--text-primary)">${t}</code>`;}
    function cb(t){return `<pre style="background:#13171f;color:#dde3ed;border-radius:6px;padding:15px 18px;font-family:var(--font-mono,'IBM Plex Mono',monospace);font-size:12px;line-height:1.8;overflow-x:auto;margin:12px 0 18px;border:1px solid #252c3a"><code style="background:none;padding:0;color:inherit;font-size:inherit">${t.trim()}</code></pre>`;}
    function ul(a) {return `<ul style="padding-left:20px;margin:6px 0 14px;color:var(--text-secondary);font-size:14px;line-height:1.85">${a.map(i=>`<li style="margin-bottom:4px">${i}</li>`).join('')}</ul>`;}
    function ol(a) {return `<ol style="padding-left:20px;margin:6px 0 14px;color:var(--text-secondary);font-size:14px;line-height:1.85">${a.map(i=>`<li style="margin-bottom:5px">${i}</li>`).join('')}</ol>`;}
    function steps(a){return `<ol style="list-style:none;padding:0;margin:12px 0 20px">${a.map((item,i)=>`<li style="display:flex;gap:12px;margin-bottom:11px;align-items:flex-start"><span style="flex-shrink:0;width:22px;height:22px;border-radius:50%;background:var(--ibm-blue-50,#0f62fe);color:#fff;font-size:11px;font-weight:700;display:flex;align-items:center;justify-content:center">${i+1}</span><span style="flex:1;padding-top:2px;font-size:14px;color:var(--text-secondary);line-height:1.7">${item}</span></li>`).join('')}</ol>`;}
    function tbl(heads,rows){
      const hs=heads.map(h=>`<th style="padding:8px 13px;font-size:11px;font-weight:700;color:var(--text-secondary);text-transform:uppercase;letter-spacing:.5px;background:var(--bg-layer,#f4f4f4);text-align:left;border-bottom:2px solid var(--border-mid,#d0d3da);white-space:nowrap">${h}</th>`).join('');
      const rs=rows.map((row,ri)=>`<tr style="${ri%2?'background:var(--bg-layer,#f4f4f4)':''}">${row.map((c,ci)=>`<td style="padding:8px 13px;font-size:13px;color:${ci===0?'var(--text-primary)':'var(--text-secondary)'};vertical-align:top;border-bottom:1px solid var(--border-subtle,#e4e7ed)">${ci===0?`<strong>${c}</strong>`:c}</td>`).join('')}</tr>`).join('');
      return `<div style="overflow-x:auto;margin:12px 0 20px"><table style="width:100%;border-collapse:collapse;border:1px solid var(--border-subtle,#e4e7ed);border-radius:6px;overflow:hidden"><thead><tr>${hs}</tr></thead><tbody>${rs}</tbody></table></div>`;
    }
    function badge(t,c){c=c||'#0f62fe';return `<span style="display:inline-flex;align-items:center;background:${c}1a;color:${c};font-size:11px;font-weight:600;padding:2px 8px;border-radius:20px;letter-spacing:.3px">${t}</span>`;}
    function meta(upd,ver){return `<div style="display:flex;align-items:center;gap:12px;margin-bottom:24px;padding-bottom:14px;border-bottom:1px solid var(--border-subtle,#e4e7ed);flex-wrap:wrap"><span style="font-size:12px;color:var(--text-tertiary)">Last updated: <strong style="color:var(--text-secondary)">${upd}</strong></span><span style="width:1px;height:11px;background:var(--border-mid)"></span><span style="font-size:12px;color:var(--text-tertiary)">Version: <strong style="color:var(--text-secondary)">${ver}</strong></span></div>`;}
    function callout(type,title,body){
      const map={info:{bg:'#edf5ff',bd:'#0f62fe',fc:'#0043ce',ic:'info'},warning:{bg:'#fef8e7',bd:'#a67800',fc:'#7d5800',ic:'warn'},tip:{bg:'#defbe6',bd:'#198038',fc:'#145228',ic:'tip'},note:{bg:'#f6f2ff',bd:'#6929c4',fc:'#4d1fa0',ic:'note'}};
      const m=map[type]||map.info;
      return `<div style="background:${m.bg};border-left:3px solid ${m.bd};border-radius:0 5px 5px 0;padding:13px 15px;margin:16px 0;display:flex;gap:11px;align-items:flex-start"><span style="color:${m.fc};flex-shrink:0;margin-top:1px">${ICON[m.ic]}</span><div style="flex:1">${title?`<div style="font-weight:700;font-size:11px;color:${m.fc};margin-bottom:3px;text-transform:uppercase;letter-spacing:.6px">${title}</div>`:''}<div style="font-size:13.5px;color:var(--text-secondary);line-height:1.65">${body}</div></div></div>`;
    }

    /* ═══════════════════════════════════════════════════════
       CONTENT — every page written from source code truth
       ═══════════════════════════════════════════════════════ */
    const SECTIONS = {

      /* ── OVERVIEW ─────────────────────────────────────── */
      'platform-overview':{
        crumbs:['IIP','Overview','Platform Overview'], title:'Platform Overview',
        content(){
          return h1('IBM Case Intelligence Platform')+
          `<div style="display:flex;gap:7px;margin-bottom:16px;flex-wrap:wrap">`+badge('v1.0.0')+' '+badge('Production','#198038')+' '+badge('RHEL9','#6929c4')+' '+badge('Hardened','#da1e28')+`</div>`+
          meta('2026-05-12','v1.0.0')+
          p('IIP is a server-hosted analytics application for the BD/TOA-ETS5 IBM ELM support team. It runs on Apache HTTPS on a RHEL9 server, with a FastAPI (Python) REST API backed by PostgreSQL. Team members open it in any browser — no installation needed.')+
          callout('info','Access',`Open ${ic('https://rb-alm-01-d8.de.bosch.com/iip/')} from any browser on the Bosch intranet.`)+
          h2('Capabilities')+
          tbl(['Capability','What It Does'],[
            ['Case Dashboards','Real-time view of open IBM support cases: status, owner, age, stale detection, product breakdown'],
            ['Member Workload','Per-engineer health scores, stale case alerts, bulk filter and export'],
            ['Performance Tracking','Resolution velocity, SLA adherence, performance case tagging, CLM defect linking'],
            ['Weekly Tracker','Closed-case register by calendar week — XLSM upload and CSV import routes'],
            ['RFE Tracking','Enhancement request pipeline: owner, status, notes, action items'],
            ['Investigate','All-time case archive search across every imported case ever'],
            ['Admin Portal','Team config, name aliases, owner reassignment, data management'],
          ])+
          h2('Technology Stack')+
          tbl(['Layer','Technology','Detail'],[
            ['Web Server','Apache 2.4 on RHEL9',ic('/etc/httpd/conf.d/rb-alm-01-d8.conf')],
            ['API Server','FastAPI 0.115.5 (Python) + Uvicorn',`systemd-managed (${ic('iip-fastapi')}) · bound to ${ic('127.0.0.1:3001')}`],
            ['Database','PostgreSQL',`${ic('iip_db')} · localhost:5432 · 26 normalized tables across 5 routers`],
            ['Async DB Driver','asyncpg','High-performance async PostgreSQL driver'],
            ['Auth','passlib + bcrypt','Password hashing; security question-based password reset'],
            ['Frontend','Vanilla JS (ES6+) · IBM Plex fonts','IIFE module pattern — no build step'],
            ['Charts','Chart.js 4.4.2','CDN via Bosch proxy, local vendor fallback'],
            ['File Parsing','XLSX.js 0.18.5','In-browser CSV and Excel parsing'],
            ['Proxy','Apache mod_proxy',`ProxyPass /iip/api/ → ${ic('http://127.0.0.1:3001/api/')}`],
          ])+
          h2('Request Flow')+
          cb('Browser  →  Apache :443  →  FastAPI/Uvicorn :3001 (localhost only)  →  PostgreSQL :5432 (localhost only)')+
          callout('note','Ports','Only port 443 is externally accessible. FastAPI (3001) and PostgreSQL (5432) are bound to localhost and never exposed directly.');
        }
      },

      'whats-new':{
        crumbs:['IIP','Overview',"What's New"], title:"What's New — v1.0.0",
        content(){
          return h1("What's New")+

          `<div style="margin-bottom:30px">`+
          `<div style="display:flex;align-items:center;gap:10px;margin-bottom:12px"><span style="font-size:19px;font-weight:700;color:var(--text-primary)">v1.0.0</span>${badge('Current','#198038')}<span style="font-size:12px;color:var(--text-tertiary)">May 12, 2026</span></div>`+
          h3('Official v1.0.0 Release')+
          ul([
            strong('Production release — v1.0.0')+' — Full PostgreSQL-backed platform with 26-table relational schema, 60+ REST API endpoints across 5 routers, and FastAPI 0.115.5 backend.',
            strong('Database')+' — Live PostgreSQL 13 on '+ic('iip_db')+' with '+ic('3,716 cases')+', '+ic('1,613 weekly tracker entries')+', '+ic('36 team members')+', and '+ic('1,159 audit log entries')+'.',
            strong('API version updated')+' — FastAPI app and '+ic('/api/health')+' endpoint now report v1.0.0.',
          ])+
          h3('Core Features')+
          ul([
            strong('Case Dashboards')+' — Overview, Team Cases, Member Dashboard, Performance Metrics, Customer Cases, Closed Cases, Created Cases.',
            strong('Weekly Tracker')+' — PostgreSQL-backed tracker synced across all users. Full CRUD on weekly case entries with comments, categories, and grayout state.',
            strong('RFE Tracking')+' — IBM Ideas pipeline with per-RFE notes, target releases, and case links stored in '+ic('ibm_ideas')+' and '+ic('rfe_annotations')+' tables.',
            strong('Admin Portal')+' — Team configuration, owner reassignment, ELM upgrades, escalation contacts, audit log, and app settings — all backed by dedicated DB tables.',
            strong('Saved Searches')+' — Per-dashboard saved filter sets stored in '+ic('saved_searches')+' table.',
            strong('Security')+' — bcrypt password hashing ('+ic('admin_credentials')+' table), server-side session tokens ('+ic('admin_sessions')+' table), security question-based password reset.',
          ])+
          `</div>`+

          `<div style="margin-bottom:30px">`+
          `<div style="display:flex;align-items:center;gap:10px;margin-bottom:12px"><span style="font-size:19px;font-weight:700;color:var(--text-primary)">v2.0.3</span><span style="font-size:12px;color:var(--text-tertiary)">March 24, 2026</span></div>`+
          h3('Data Sync — All Users See Same Data')+
          ul([
            strong('RFE Tracking fully shared')+' — notes, target releases, and CSV data now written to PostgreSQL via '+ic('/api/store-public/:key')+'. No admin token needed. Changes are visible to all users within 60 seconds.',
            strong('Investigate archive — browser local')+' — '+ic('ibm_investigate_archive_v1')+' is stored in localStorage only (not synced to DB in v2). Archive is per-machine.',
            strong('Latest file wins on re-upload')+' — uploading a newer IBM export now replaces the active case set exactly (no more ghost cases from old uploads bleeding through). Historical files remain additive for Weekly Tracker only.',
          ])+
          h3('Boot Experience')+
          ul([
            strong('No more upload screen flash')+' — upload screen starts hidden in HTML. Users with data in DB see only the dark blue loading spinner → dashboard.',
            strong('Branded boot loader')+' — loading spinner now matches the dark blue app theme instead of a plain grey overlay.',
          ])+
          h3('Bug Fixes')+
          ul([
            strong('Documentation blank page fixed')+' — overlay now mounts on '+ic('.main-area')+' as '+ic('position:absolute')+', completely avoiding the stacking context issues caused by '+ic('overflow:hidden')+' on parent elements.',
            strong('Team Cases crash fixed')+' — '+ic('updateCount()')+' was called but never defined in team.js. Removed.',
            strong('System Architecture and Storage pages blank')+' — '+ic('strong()')+' and '+ic('h3()')+' helper functions were missing from documentation.js. Added.',
          ])+
          `</div>`+

          h2('Version History')+
          tbl(['Version','Date','Highlight'],[
            ['v1.0.0 '+badge('Current','#198038'),'May 12 2026','Official v1.0.0 — 26-table PostgreSQL schema, 60+ API endpoints, full production release'],
            ['v2.0.3','Mar 24 2026','Server Recovery & Full-Stack Stability'],
            ['v2.0.0','Mar 23 2026','Production Release: bcrypt, Helmet.js, logging, 47 tests'],
            ['v1.0.3','Mar 23 2026','RFE+Investigate shared via DB, latest-file-wins upload, boot loader fix, documentation fixed, team.js crash fixed'],
            ['v1.0.2+ interim','Mar 23 2026','Full shared-state sync via PostgreSQL: boot hydration, localStorage interceptor, 3 new bulk API endpoints, SSE push'],
            ['v1.0.2','Mar 20 2026','Security hardening: API token auth, key allowlist, CORS restriction, rate limiting'],
            ['v1.0.1','Mar 2026','PostgreSQL backend: '+ic('iip_db')+' created, Node.js REST API, Apache ProxyPass, IIPStore rewrite'],
            ['v1.0.0','Jan 2026','Initial release: RFE Tracking, Weekly Tracker, Admin Portal overhaul, CSV merge'],
          ])+
          `<div style="border-top:1px solid var(--border-subtle);padding-top:14px;font-size:13px;color:var(--text-tertiary)">Developer: Kabelesh K &nbsp;·&nbsp; Team: BD/TOA-ETS5</div>`;
        }
      },

      'architecture':{
        crumbs:['IIP','Overview','System Architecture'], title:'System Architecture',
        content(){
          return h1('System Architecture')+meta('2026-05-12','v1.0.0')+
          p('IIP is a three-tier application on a single RHEL9 server. Apache serves static files and proxies all '+ ic('/iip/api/')+ ' requests to the FastAPI process. PostgreSQL stores '+strong('all shared application state')+'. Browser localStorage is used as a fast local cache only — it is hydrated from PostgreSQL on every page load, so every user always sees the same data.')+
          h2('Tiers')+
          tbl(['Tier','Component','Address / Path'],[
            ['Frontend','Static HTML + JS + CSS served by Apache',ic('https://rb-alm-01-d8.de.bosch.com/iip/')],
            ['API','FastAPI 0.115.5 + Uvicorn (systemd: iip-fastapi)',ic('http://127.0.0.1:3001')+' (internal)'],
            ['Database','PostgreSQL',ic('localhost:5432')+' — db: '+ic('iip_db')],
          ])+
          h2('REST API — FastAPI (main.py)')+
          p('60+ endpoints across 5 routers. Apache proxies '+ic('/iip/api/*')+' → '+ic('127.0.0.1:3001')+' via ProxyPass. Both '+ic('/api/*')+' and '+ic('/iip/api/*')+' paths are registered.')+
          h3('Core / Health (main.py)')+
          tbl(['Method','Endpoint','Auth','Description'],[
            ['GET',ic('/api/health'),'None','DB check + version + SSE client count + db_latency_ms'],
            ['GET',ic('/api/events'),'None','SSE stream — instant push to all browsers on data change'],
          ])+
          h3('Auth Router (routers/auth.py)')+
          tbl(['Method','Endpoint','Auth','Description'],[
            ['GET',ic('/api/auth/status'),'None','Check if a session token is still valid'],
            ['POST',ic('/api/auth'),'None','Login — returns session token'],
            ['POST',ic('/api/auth/logout'),'Session Token','Revoke session token'],
            ['POST',ic('/api/auth/set-password'),'Session Token','Set or change admin password'],
            ['POST',ic('/api/auth/security-questions'),'Session Token','Save security questions and answers'],
            ['GET',ic('/api/auth/security-questions'),'None','Get questions (answers never returned)'],
            ['POST',ic('/api/auth/reset-via-security'),'None','Verify answers + reset password; returns new token'],
          ])+
          h3('Cases & Weekly Tracker Router (routers/db_cases.py)')+
          tbl(['Method','Endpoint','Auth','Description'],[
            ['GET',ic('/api/cases'),'None','Paginated case list with optional filters'],
            ['GET',ic('/api/cases/distinct-products'),'None','All unique product values'],
            ['GET',ic('/api/cases/performance-summary'),'None','All performance-tagged cases with work items'],
            ['GET',ic('/api/cases/archive'),'None','All-time case archive enriched with comments'],
            ['GET',ic('/api/cases/nonperf-summary'),'None','Non-performance cases for a customer prefix'],
            ['GET',ic('/api/cases/{case_number}'),'None','Full case detail including weekly history'],
            ['GET',ic('/api/cases/{case_number}/wednesday-comments'),'None','Wednesday comments for a case'],
            ['PATCH',ic('/api/cases/{case_number}/wednesday-comments'),'Session Token','Upsert wednesday comment'],
            ['GET',ic('/api/cases/{case_number}/slot-days'),'None','Slot day overrides for a case'],
            ['PATCH',ic('/api/cases/{case_number}/slot-days'),'Session Token','Upsert slot day override'],
            ['PATCH',ic('/api/cases/{case_number}/availability'),'Session Token','Set performance case availability'],
            ['PATCH',ic('/api/cases/{case_number}/performance-tag'),'Session Token','Tag perf/non-perf + work item'],
            ['PATCH',ic('/api/cases/{case_number}/owner'),'Session Token','Reassign case owner'],
            ['POST',ic('/api/upload/cases'),'Session Token','Upload IBM Support Case listing CSV'],
            ['GET',ic('/api/uploads'),'None','List all file uploads with status'],
            ['GET',ic('/api/uploads/fingerprint-check'),'None','Check if case fingerprint already uploaded'],
            ['PATCH',ic('/api/uploads/{upload_id}/fingerprint'),'Session Token','Save case fingerprint'],
            ['GET',ic('/api/uploads/{upload_id}'),'None','Get single upload status'],
            ['GET',ic('/api/weekly/{year}'),'None','All week summaries for a year'],
            ['GET',ic('/api/weekly/{year}/{week}'),'None','Cases for a specific week (CW01–CW53)'],
            ['PATCH',ic('/api/weekly/{year}/{week}/{case_number}'),'None','Sync comment + category; run duplicate detection'],
            ['DELETE',ic('/api/weekly/{year}/{week}/{case_number}'),'Session Token','Remove case from a tracker week'],
            ['POST',ic('/api/weekly/{year}/{week}'),'Session Token','Add a case to a tracker week'],
            ['GET',ic('/api/weekly-tracker'),'None','All weekly closed cases grouped by year/week'],
            ['GET',ic('/api/wt-categories'),'None','Weekly tracker categories from DB'],
            ['POST',ic('/api/wt-categories'),'Session Token','Save weekly tracker categories (admin)'],
            ['GET',ic('/api/wt-history'),'None','Load weekly tracker case history from DB'],
            ['POST',ic('/api/wt-history'),'None','Save a history entry to DB'],
            ['DELETE',ic('/api/wt-history/{entry_id}'),'Session Token','Delete a single history entry'],
            ['DELETE',ic('/api/wt-history'),'Session Token','Delete ALL history (admin)'],
            ['GET',ic('/api/wt-comments'),'None','All weekly tracker comments (case→comment)'],
            ['GET',ic('/api/reopened'),'None','All reopened cases grouped by case'],
            ['POST',ic('/api/reopened/sync'),'None','Sync cross-week reopened cases to DB'],
            ['POST',ic('/api/grayout-bulk'),'None','Bulk-fetch DB grayout states'],
            ['GET',ic('/api/grayout/{case_number}/{week}/{year}'),'None','Fetch DB grayout state for one case/week/year'],
            ['GET',ic('/api/ideas'),'None','List IBM Ideas'],
            ['GET',ic('/api/ideas/{idea_reference}'),'None','Idea detail with linked cases'],
            ['GET',ic('/api/user-data/rfe-meta'),'None','Load RFE tracking metadata'],
            ['PUT',ic('/api/user-data/rfe-meta'),'None','Save RFE tracking metadata'],
            ['GET',ic('/api/user-data/tracker-meta'),'None','Load performance tracker meta (built from cases)'],
            ['PUT',ic('/api/user-data/tracker-meta'),'None','Save UI-only tracker state'],
            ['GET',ic('/api/rfe-data'),'None','RFE data from ibm_ideas table for frontend'],
            ['GET',ic('/api/data-version'),'None','Latest successful upload timestamp (Unix ms)'],
            ['GET',ic('/api/admin/dashboard-stats'),'None','Admin overview — all stats in one call'],
            ['GET',ic('/api/admin/reassign-log'),'None','Reassignment history from audit_log'],
            ['GET',ic('/api/team'),'None','Team members list'],
            ['GET',ic('/api/alm-lines'),'None','ALM lines with contacts'],
            ['GET',ic('/api/ibm-contacts'),'None','IBM directory contacts'],
            ['GET',ic('/api/escalation-contacts'),'None','Escalation contacts'],
            ['GET',ic('/api/audit'),'None','Recent audit log entries'],
          ])+
          h3('Admin Router (routers/admin.py)')+
          tbl(['Method','Endpoint','Auth','Description'],[
            ['GET',ic('/api/admin/bootstrap'),'Session Token','Full bootstrap data for admin portal'],
            ['GET',ic('/api/admin/team-members'),'Session Token','List all team members'],
            ['POST',ic('/api/admin/team-members'),'Session Token','Create team member'],
            ['PUT',ic('/api/admin/team-members/{id}'),'Session Token','Update team member'],
            ['DELETE',ic('/api/admin/team-members/{id}'),'Session Token','Delete team member'],
            ['GET/POST/PUT/DELETE',ic('/api/admin/escalation-contacts'),'Session Token','Escalation contacts CRUD'],
            ['GET/POST/PUT/DELETE',ic('/api/admin/ibm-contacts'),'Session Token','IBM contacts CRUD'],
            ['GET/POST/PUT/DELETE',ic('/api/admin/alm-lines'),'Session Token','ALM lines CRUD'],
            ['GET/POST/PUT/DELETE',ic('/api/admin/elm-upgrades'),'Session Token','ELM upgrade entries CRUD'],
            ['GET',ic('/api/admin/audit-log'),'Session Token','Audit log entries'],
            ['POST',ic('/api/admin/audit-log'),'Session Token','Write audit log entry'],
            ['GET',ic('/api/admin/app-settings'),'Session Token','Read app settings'],
            ['PUT',ic('/api/admin/app-settings'),'Session Token','Write app settings'],
          ])+
          h3('Store / Config Router (routers/store.py)')+
          tbl(['Method','Endpoint','Auth','Description'],[
            ['GET',ic('/api/store'),'None','All cases count from DB'],
            ['GET',ic('/api/store/cases-count'),'None','Case count only'],
            ['GET',ic('/api/config'),'None','Team config from DB'],
            ['GET',ic('/api/v2/config'),'None','Team config v2'],
            ['GET',ic('/api/team-config'),'None','Full team config object'],
            ['GET',ic('/api/team-members'),'None','Public team member list'],
            ['GET',ic('/api/customer-products'),'None','Customer-specific product list'],
            ['PUT',ic('/api/customer-products'),'Session Token','Update customer products'],
            ['GET',ic('/api/elm-upgrades'),'None','ELM upgrade entries (public read)'],
          ])+
          h3('Saved Searches Router (routers/saved_searches.py)')+
          tbl(['Method','Endpoint','Auth','Description'],[
            ['GET',ic('/api/saved-searches'),'None','List saved searches for a dashboard'],
            ['POST',ic('/api/saved-searches'),'None','Create a saved search'],
            ['DELETE',ic('/api/saved-searches/{id}'),'None','Delete a saved search'],
            ['POST',ic('/api/saved-searches/{id}/use'),'None','Increment use count + update last_used'],
          ])+
          h2('Key Source Files')+
          tbl(['File','Purpose'],[
            [ic('backend/main.py'),'FastAPI app — 19 REST endpoints, asyncpg pool, SSE broadcast, CORS, startup/shutdown lifecycle'],
            [ic('backend/routers/db_cases.py'),'Cases + Weekly Tracker router — 40+ endpoints covering cases, uploads, weekly tracker, reopened, ideas, grayout, wt-history'],
            [ic('backend/routers/admin.py'),'Admin router — team members, ALM lines, ELM upgrades, contacts, audit log, app settings CRUD'],
            [ic('backend/routers/store.py'),'Store/config router — cases count, team config, customer products'],
            [ic('backend/routers/saved_searches.py'),'Saved searches router — per-dashboard saved filter sets'],
            [ic('backend/routers/auth.py'),'Auth router — login, logout, set-password, security-questions, reset-via-security'],
            [ic('backend/requirements.txt'),'Python dependencies — fastapi, uvicorn, asyncpg, passlib, bcrypt, python-dotenv'],
            [ic('backend/.env'),'DB credentials + config (never commit, never deploy in a zip)'],
            [ic('js/modules/data/storage.js'),ic('IIPStore')+' v2.1 — routes reads/writes to PostgreSQL or localStorage; public write for RFE/Investigate'],
            [ic('js/modules/data/dynamic-config.js'),'DynamicConfig — team config stored under '+ic('ibm_team_config_v1_cache')],
            [ic('js/modules/admin/admin.js'),'Admin auth — session management, password handling'],
            [ic('js/data/app-data.js'),'AppData — static team data, ALM lines, IBM product catalogue (3.6 MB, pre-gzipped)'],
            [ic('js/dashboards/*.js'),'One file per tab'],
            [ic('js/app.js'),'Application shell — always loads last'],
          ])+
          h2('Script Load Order')+
          p(ic('app.js')+' is always last. Order matters — earlier scripts expose globals that later ones depend on.')+
          ol([
            ic('app-data.js')+' — AppData',
            ic('utils.js')+' — Utils',
            ic('dynamic-config.js')+' — DynamicConfig',
            ic('config.js')+' — legacy constants',
            ic('contacts.js')+' — Contacts',
            ic('storage.js')+' — IIPStore',
            ic('data.js')+' — Data module',
            'UI and platform modules (Modal, IIPRouter, etc.)',
            'Dashboard JS files',
            ic('app.js')+' — application shell',
          ])+
          callout('warning','Load Order',ic('app.js')+' must be last. A dashboard referencing '+ic('Data.teamCases()')+' or '+ic('IIPStore')+' before their files have loaded will throw a ReferenceError.');
        }
      },

      /* ── GETTING STARTED ─────────────────────────────── */
      'prerequisites':{
        crumbs:['IIP','Getting Started','Prerequisites'], title:'Prerequisites',
        content(){
          return h1('Prerequisites')+meta('2026-05-12','v1.0.0')+
          callout('tip','End Users — Nothing to Install','If you are a team member just using IIP, open the app in any browser on the Bosch intranet. No installation needed. This page is for developers and admins setting up or maintaining the server.')+

          h2('Server Requirements')+
          tbl(['Component','Requirement','Notes'],[
            ['OS','RHEL9 (Rocky Linux 9 compatible)','Tested on RHEL9. SELinux enabled by default — configuration required.'],
            ['Python','Python 3.9+','System Python or a managed installation. Used for FastAPI backend.'],
            ['PostgreSQL','PostgreSQL 13+','Primary database for all shared state.'],
            ['Apache','Apache 2.4 + mod_ssl + mod_proxy','Web server, TLS termination, and reverse proxy.'],
            ['pip','pip 21+','For installing Python dependencies into the virtual environment.'],
            ['Firewall','Port 443 (HTTPS) open','Only externally accessible port. 3001 and 5432 are localhost-only.'],
            ['SSL Certificate','Bosch-signed cert + key + CA chain','Required for HTTPS. Provided by Bosch IT.'],
          ])+

          h2('Network Requirements')+
          tbl(['Requirement','Detail'],[
            ['Bosch Intranet / VPN','Required to access '+ic('https://rb-alm-01-d8.de.bosch.com/iip/')],
            ['Server SSH access','Required for deployment — SSH to '+ic('si0vm14401.de.bosch.com')],
            ['PostgreSQL','localhost:5432 — not externally accessible'],
            ['FastAPI','127.0.0.1:3001 — not externally accessible'],
          ])+

          h2('Python Dependencies')+
          p('All dependencies are declared in '+ic('backend/requirements.txt')+'.')+
          tbl(['Package','Version','Purpose'],[
            ['fastapi','0.115.5','Web framework — routes, validation, CORS'],
            ['uvicorn','latest','ASGI server — runs the FastAPI app'],
            ['asyncpg','latest','Async PostgreSQL driver'],
            ['python-dotenv','latest','Loads .env file into environment variables'],
            ['passlib[bcrypt]','latest','Password hashing'],
            ['bcrypt','latest','bcrypt backend for passlib'],
            ['httpx','latest','Async HTTP client (internal use)'],
            ['python-multipart','latest','Form/file upload parsing'],
          ])+

          h2('Database Schema')+
          p('IIP uses a fully normalized PostgreSQL schema with 26 tables. Run '+ic('psql iip_db -f schema/iip_schema.sql')+' to initialize.')+
          tbl(['Table','Rows (live)','Purpose'],[
            [ic('cases'),'3,716','Active IBM support cases — primary case store'],
            [ic('case_status_history'),'20,000','Per-upload status snapshots for reopen detection'],
            [ic('weekly_closed_cases'),'1,613','Weekly tracker case entries with comments + categories'],
            [ic('audit_log'),'1,159','All admin actions with before/after values'],
            [ic('mv_reopened_cases'),'75','Materialized view — cases closed then reopened'],
            [ic('team_members'),'36','Team member roster with name, email, team, status'],
            [ic('weekly_reopened_sync'),'30','Cross-week reopened case sync from browser'],
            [ic('alm_lines'),'21','ALM line contacts (customer, line manager, case responsible)'],
            [ic('app_settings'),'16','Key-value app settings (slaClosureDays, etc.)'],
            [ic('case_grayout_state'),'16','Per-case/week grayout state for weekly tracker'],
            [ic('uploads'),'10','File upload history with status, hash, record count'],
            [ic('admin_credentials'),'—','Bcrypt-hashed admin password (username + password_hash)'],
            [ic('admin_sessions'),'—','Active session tokens with expiry timestamps'],
            [ic('security_questions'),'—','Admin security Q&A for password reset'],
            [ic('saved_searches'),'—','Per-dashboard saved filter sets'],
            [ic('ibm_ideas'),'—','IBM Ideas (RFE) data imported from CSV'],
            [ic('rfe_annotations'),'—','Per-idea internal notes, tags, target release'],
            [ic('idea_case_links'),'—','Many-to-many: ideas ↔ cases'],
            [ic('elm_upgrades'),'—','ELM version upgrade history'],
            [ic('escalation_contacts'),'—','Escalation contact groups'],
            [ic('ibm_contacts'),'—','IBM directory contacts by group'],
            [ic('duplicate_references'),'—','Detected duplicate case pairs'],
            [ic('performance_wednesday_comments'),'—','Per-case weekly comments for performance tracking'],
            [ic('performance_slot_days'),'—','Performance case availability slot overrides'],
            [ic('wt_case_history'),'—','Weekly tracker case change history (audit trail)'],
            [ic('error_log'),'—','Frontend and backend error log'],
          ])+
          h3('Views')+
          tbl(['View','Purpose'],[
            [ic('v_reopened_cases'),'Reopened cases with full closure history and week labels'],
            [ic('v_weekly_summary'),'Week-by-week summary: total closed, reopened, duplicate, RFE, performance, team counts'],
            [ic('v_duplicate_cases'),'Duplicate case pairs with original/duplicate details'],
          ])+

          h2('Environment Variables (.env)')+
          p('The backend reads configuration from '+ic('backend/.env')+'. This file must exist on the server before starting the service.')+
          tbl(['Variable','Example','Description'],[
            [ic('DB_HOST'),ic('localhost'),'PostgreSQL host'],
            [ic('DB_PORT'),ic('5432'),'PostgreSQL port'],
            [ic('DB_NAME'),ic('iip_db'),'Database name'],
            [ic('DB_USER'),ic('iip_user'),'Database user'],
            [ic('DB_PASSWORD'),ic('••••••••'),'Database password — never commit this'],
            [ic('API_PORT'),ic('3001'),'FastAPI listen port (internal)'],
            [ic('CORS_ORIGIN'),ic('https://rb-alm-01-d8.de.bosch.com'),'Allowed CORS origin for browser requests'],
            [ic('IIP_ADMIN_TOKEN'),ic('generated-hex-string'),'Static admin token for write API calls'],
          ])+
          callout('warning','Security','Never commit the .env file. Never include it in deployment zips. It must only exist on the production server at '+ic('/var/www/html/iip/backend/.env')+'.');
        }
      },

      'installation':{
        crumbs:['IIP','Getting Started','Installation & Setup'], title:'Installation & Setup',
        adminOnly: true,
        content(){
          return h1('Installation & Setup')+meta('2026-05-12','v1.0.0')+
          callout('note','Admin Only','This page covers full server setup. For routine deployments, see Operations → Deploying Updates.')+

          h2('Step 1 — Install System Packages')+
          cb('# RHEL9 — install all required packages:\nsudo dnf install -y httpd mod_ssl python3 python3-pip postgresql-server postgresql-contrib\n\n# Start and enable PostgreSQL:\nsudo postgresql-setup --initdb\nsudo systemctl enable postgresql\nsudo systemctl start postgresql\n\n# Start and enable Apache:\nsudo systemctl enable httpd\nsudo systemctl start httpd')+

          h2('Step 2 — Set Up PostgreSQL')+
          cb('# Create database user and database:\nsudo -u postgres psql -c "CREATE USER iip_user WITH PASSWORD \'your-secure-password\';"\nsudo -u postgres psql -c "CREATE DATABASE iip_db OWNER iip_user;"\nsudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE iip_db TO iip_user;"\n\n# Edit pg_hba.conf — change ident to md5 for 127.0.0.1:\nsudo nano /var/lib/pgsql/data/pg_hba.conf\n# Change: host all all 127.0.0.1/32 ident\n# To:     host all all 127.0.0.1/32 md5\n\nsudo systemctl restart postgresql\n\n# Verify connection:\npsql -h 127.0.0.1 -U iip_user -d iip_db -c "SELECT 1;"')+

          h2('Step 3 — Create the Database Schema')+
          p('Run the full schema file (26 tables, indexes, views, triggers):')+
          cb('psql -h 127.0.0.1 -U iip_user -d iip_db -f schema/iip_schema.sql\n\n# Verify tables created:\npsql -h 127.0.0.1 -U iip_user -d iip_db -c "\\dt"')+

          h2('Step 4 — Deploy App Files')+
          cb('# From Windows, run the one-command deploy:\nbash sync-and-deploy.sh rbadmin_app1 si0vm14401.de.bosch.com /var/www/html/iip\n\n# Or manually on the server:\nmkdir -p /var/www/html/iip\ncd /tmp && unzip iip.zip\ncp -r iip/* /var/www/html/iip/\nchown -R apache:apache /var/www/html/iip/\nchmod -R 755 /var/www/html/iip/')+

          h2('Step 5 — Create .env File')+
          cb('cat > /var/www/html/iip/backend/.env << \'EOF\'\nDB_HOST=localhost\nDB_PORT=5432\nDB_NAME=iip_db\nDB_USER=iip_user\nDB_PASSWORD=your-secure-password\nAPI_PORT=3001\nCORS_ORIGIN=https://rb-alm-01-d8.de.bosch.com\nIIP_ADMIN_TOKEN=$(openssl rand -hex 32)\nEOF\n\n# Secure the file:\nchown root:apache /var/www/html/iip/backend/.env\nchmod 640 /var/www/html/iip/backend/.env')+

          h2('Step 6 — Set Up Python Virtual Environment')+
          cb('cd /var/www/html/iip/backend\npython3 -m venv .venv\nsource .venv/bin/activate\npip install --upgrade pip\npip install -r requirements.txt\ndeactivate')+

          h2('Step 7 — Create systemd Service')+
          cb('sudo nano /etc/systemd/system/iip-fastapi.service')+
          p('Paste the following content:')+
          cb('[Unit]\nDescription=IIP FastAPI Backend\nAfter=network.target postgresql.service\n\n[Service]\nType=simple\nUser=apache\nWorkingDirectory=/var/www/html/iip/backend\nEnvironmentFile=/var/www/html/iip/backend/.env\nExecStart=/var/www/html/iip/backend/.venv/bin/uvicorn main:app --host 127.0.0.1 --port 3001\nRestart=always\nRestartSec=5\n\n[Install]\nWantedBy=multi-user.target')+
          cb('# Enable and start the service:\nsudo systemctl daemon-reload\nsudo systemctl enable iip-fastapi\nsudo systemctl start iip-fastapi\n\n# Verify it is running:\nsudo systemctl status iip-fastapi\ncurl http://127.0.0.1:3001/api/health')+

          h2('Step 8 — Configure Apache')+
          cb('sudo nano /etc/httpd/conf.d/rb-alm-01-d8.conf')+
          p('Key directives required:')+
          cb('# Disable default ssl.conf first:\nmv /etc/httpd/conf.d/ssl.conf /etc/httpd/conf.d/ssl.conf.bak\n\n# Key vhost directives:\n# ProxyPass /iip/api/ http://127.0.0.1:3001/api/\n# ProxyPassReverse /iip/api/ http://127.0.0.1:3001/api/\n# See Operations → RHEL9 + Apache Setup for the full vhost config.')+

          h2('Step 9 — Configure SELinux & Firewall')+
          cb('# Allow Apache to proxy to FastAPI:\nsudo setsebool -P httpd_can_network_connect on\n\n# Open HTTPS in firewall:\nsudo firewall-cmd --permanent --add-service=https\nsudo firewall-cmd --reload\n\n# Restore SELinux context:\nsudo restorecon -Rv /var/www/html/iip/')+

          h2('Step 10 — Restart and Verify')+
          cb('sudo systemctl restart httpd\nsudo systemctl restart iip-fastapi\n\n# Full verification:\ncurl -k https://rb-alm-01-d8.de.bosch.com/iip/api/health\n# Expected: {"status":"ok","db":"connected",...}')+
          steps([
            'Open '+ic('https://rb-alm-01-d8.de.bosch.com/iip/')+'in a browser.',
            'The app should load with the dark blue boot screen.',
            'Open the browser console (F12) — zero red errors.',
            'Click Admin Portal → you should see the password setup dialog.',
            'Set an admin password and the API admin token from your .env file.',
            'Upload a CSV file — data should load across all dashboards.',
          ])+
          callout('tip','Deployment After Setup','For all future deployments, just run '+ic('bash sync-and-deploy.sh rbadmin_app1 si0vm14401.de.bosch.com /var/www/html/iip')+' from Windows. No need to repeat the setup steps.');
        }
      },

      'access':{
        crumbs:['IIP','Getting Started','Accessing the Platform'], title:'Accessing the Platform',
        content(){
          return h1('Accessing the Platform')+meta('March 20, 2026','v1.0.1')+
          callout('tip','Team Members — Nothing to Install',`Open ${ic('https://rb-alm-01-d8.de.bosch.com/iip/')} on the Bosch intranet. Core case data lives in PostgreSQL on the server.`)+
          h2('Requirements')+
          tbl(['Requirement','Detail'],[
            ['Network','Bosch intranet or VPN'],
            ['Browser','Chrome, Firefox, or Edge (modern version)'],
            ['Account','No login needed for normal use. Admin Portal requires the admin password.'],
            ['Server access','SSH to '+ic('rb-alm-01-d8.de.bosch.com')+'— required only for operations tasks'],
          ])+
          h2('Server Quick Reference')+
          tbl(['Item','Value'],[
            ['App URL',ic('https://rb-alm-01-d8.de.bosch.com/iip/')],
            ['App root',ic('/var/www/html/iip/')],
            ['Backend',ic('/var/www/html/iip/backend/')],
            ['Apache vhost',ic('/etc/httpd/conf.d/rb-alm-01-d8.conf')],
            ['API (internal)',ic('http://127.0.0.1:3001')],
            ['API systemd service',ic('iip-fastapi')],
            ['PostgreSQL',ic('localhost:5432')+' — db: '+ic('iip_db')+', user: '+ic('iip_user')],
          ]);
        }
      },

      'first-upload':{
        crumbs:['IIP','Getting Started','Your First Upload'], title:'Your First Upload',
        content(){
          return h1('Your First Upload')+meta('March 20, 2026','v1.0.1')+
          h2('Step 1 — Export from IBM Support Portal')+
          steps([
            'Go to '+ic('mysupport.ibm.com')+' → Cases → Case Listing.',
            'Filter by account: '+ic('881812')+' (primary) or '+ic('284926')+' (secondary).',
            'Click Export → CSV. <strong>Do not rename the file</strong> — the IBM-generated date in the filename controls routing inside IIP.',
          ])+
          h2('Step 2 — Upload to IIP')+
          steps([
            'Open '+ic('https://rb-alm-01-d8.de.bosch.com/iip/')+'.',
            'Drag the CSV onto the upload drop zone, or click Choose File.',
            'IIP parses the file in-browser, then saves case data to PostgreSQL via the REST API.',
            'The app reloads automatically with your cases.',
          ])+
          h2('Filename Date Routing')+
          tbl(['Filename Date','Routed To','Notes'],[
            ["Today's date",'Main case store','Normal import — updates '+ic('ibm_cases_raw_v1')+'in PostgreSQL'],
            ['Older date','Weekly Tracker','Routed to '+ic('ibm_wtracker_YYYY')+' — synced to PostgreSQL via IIPStore v2.0 interceptor'],
          ])+
          callout('warning','Never Rename the File','The IBM-generated filename contains the export date. Renaming causes wrong routing. Use the original name until after upload.')+
          h2('Import Behaviour')+
          ul([
            '<strong>Merge, not replace</strong> — cases are upserted by Case Number. Admin overrides (reassignment, performance tags) are preserved.',
            '<strong>Fingerprinting</strong> — re-uploading the identical file is a no-op.',
            'File size limit: 32 MB (FastAPI payload limit in '+ic('main.py')+').',
            'Supported formats: '+ic('.csv')+', '+ic('.xlsx')+', '+ic('.xls')+', '+ic('.xlsm')+'.',
          ]);
        }
      },

      'navigation':{
        crumbs:['IIP','Getting Started','Navigating the Interface'], title:'Navigating the Interface',
        content(){
          return h1('Navigating the Interface')+meta('March 20, 2026','v1.0.1')+
          h2('Sidebar Sections')+
          tbl(['Section','Purpose'],[
            ['Overview','KPI cards, status donut, owner workload, trend line'],
            ['Team Cases','Full case queue with multi-dimension filters, bulk actions, CSV export'],
            ['Member Dashboard','Per-engineer health scores and case breakdowns'],
            ['Performance','Resolution velocity, SLA metrics, performance tagging, reassignment'],
            ['Customer Cases','Cases filtered to the configured customer account'],
            ['Closed / Created','Closure trend and inbound volume charts'],
            ['Weekly Tracker','Week-by-week closed-case register'],
            ['RFE Tracking','Enhancement request pipeline'],
            ['Investigate','All-time case archive full-text search'],
            ['Admin Portal','Config, data management, reassignment'],
            ['Documentation','This page'],
          ])+
          h2('URL Hash Navigation')+
          p('Every tab updates the browser URL hash. Bookmarks work.')+
          tbl(['Hash','Destination'],[
            [ic('#overview'),'Overview'],[ic('#team'),'Team Cases'],[ic('#members'),'Member Dashboard'],
            [ic('#performance'),'Performance'],[ic('#customer'),'Customer Cases'],
            [ic('#closed'),'Closed Cases'],[ic('#created'),'Created Cases'],
            [ic('#weekly'),'Weekly Tracker'],[ic('#rfe'),'RFE Tracking'],
            [ic('#investigate'),'Investigate'],[ic('#documentation'),'Documentation'],[ic('#admin'),'Admin Portal'],
          ])+
          h2('Keyboard Shortcuts')+
          callout('tip','Full reference','See Tools & Features → Keyboard Shortcuts for the complete list.')+
          tbl(['Shortcut','Action'],[
            [ic('Ctrl+K'),'Open Command Palette'],
            [ic('/'),'Focus Global Search bar'],
            [ic('?'),'Toggle Keyboard Shortcuts panel'],
            [ic('Ctrl+L'),'Start Guided Tour'],
            [ic('1')+'–'+ic('9'),'Navigate to dashboard tab (1=Overview … 9=Investigate)'],
            [ic('Esc'),'Close modal, overlay, command palette, or search'],
          ]);
        }
      },

      'boot-sequence':{
        crumbs:['IIP','Getting Started','Boot Sequence'], title:'Boot Sequence',
        content(){
          return h1('Boot Sequence')+meta('March 23, 2026','v1.0.3')+
          p('The exact startup sequence from page load to interactive dashboard.')+
          h2('Phase 1 — HTML Head (synchronous)')+
          ol([
            ic('window.__APP_BASE__')+' set by inline base-path detection.',
            'IBM Plex fonts requested (non-blocking).',
            ic('loadScript()')+' starts Chart.js from CDN (async), then XLSX.js.',
            'CSS files load in order: variables → base → layout → components → features → mobile.',
          ])+
          h2('Phase 2 — Scripts Load')+
          ol([
            ic('app-data.js → utils.js → dynamic-config.js → config.js → contacts.js'),
            ic('storage.js')+' — IIPStore initialises; protocol is '+ic('https:')+' so mode = '+ic('"server"'),
            ic('data.js')+' — Data module ready',
            'UI modules and platform modules load',
            'Dashboard files load, then '+ic('app.js')+' last',
          ])+
          h2('Phase 3 — DOMContentLoaded')+
          ol([
            ic('App.init()')+' called.',
            ic('IIPStore.hydrateFromDB()')+' — pulls ALL shared keys from PostgreSQL into localStorage in 3 parallel requests (bulk-get, wtracker prefix, admin prefix). Every user gets identical, up-to-date data before any dashboard renders.',
            ic('DynamicConfig.load()')+' reads '+ic('ibm_team_config_v1_cache')+' from localStorage.',
            ic('Contacts.refresh()')+' and '+ic('Data.refreshTeamIndex()')+' hydrate from config.',
            'Admin session checked: if '+ic('sessionStorage.getItem("ibm_admin_session_v1") === "1"')+', admin mode enabled.',
            ic('_tryRestoreFromServer()')+' starts.',
          ])+
          h2('Phase 4 — Data Restore')+
          ol([
            'Check '+ic('sessionStorage["ibm_cases_raw_v1"]')+' — same-tab fast cache, avoids a network round-trip on F5.',
            'If empty: '+ic('GET /api/cases')+' — fetches all cases directly from the PostgreSQL cases table.',
            'Apply overrides: '+ic('IIPStore.getOverrides()')+' → '+ic('GET /api/store/ibm_cases_overrides_v1')+'.',
            'Cache result in sessionStorage, call '+ic('_showAppWithRows(rows)')+'.',
            'If '+ic('/api/cases')+' fails: fall back to '+ic('IIPStore.getCases()')+' from hydrated localStorage.',
            'No cases anywhere → show upload screen. '+ic('window._iipAppReady = true')+' unblocks the hash router.',
          ])+
          h2('Phase 5 — App Ready')+
          ol([
            ic('App._renderCurrentTab()')+' renders the last active tab.',
            'Hash router activates — deep links now work.',
            'Idle timer starts (30 min).',
          ])+
          callout('note','sessionStorage is a performance cache only',ic('sessionStorage["ibm_cases_raw_v1"]')+' is populated from PostgreSQL on first load and cleared when the tab closes. It exists to avoid a round-trip on every tab switch within the same browser session. It is not persistent storage.');
        }
      },

      /* ── DASHBOARDS ───────────────────────────────────── */
      'dash-overview':{
        crumbs:['IIP','Dashboards','Overview Dashboard'], title:'Overview Dashboard',
        content(){
          return h1('Overview Dashboard')+meta('March 20, 2026','v1.0.1')+
          p('The command centre — 7 zones giving the team pulse at a glance with minimal scrolling.')+
          h2('KPI Cards')+
          tbl(['Card','Formula','Data Source'],[
            ['Total Cases','COUNT(teamCases())','All statuses'],
            ['Open Cases','COUNT(status ≠ Closed)','teamCases()'],
            ['Stale Cases','COUNT(open AND idle ≥ 5 days)','Today − Updated date'],
            ['Closed (7d)','COUNT(Closed Date within 7 days)','Closed Date preferred, Updated fallback'],
            ['Customer Open','COUNT(customerCases() open)','Customer account filter'],
          ])+
          callout('info','Trend Arrows','Each KPI card compares the current value to the equivalent value for the prior 7-day window.')+
          h2('Charts')+
          tbl(['Chart','Data','Interaction'],[
            ['Status Donut','Open case distribution by status','Click segment → filters case table'],
            ['Product Breakdown','Open cases by product (top 12)','Click bar → filters case table'],
            ['Owner Workload','Active + stale per engineer','Click bar → filter to owner'],
            ['Trend Line','Monthly created vs closed','Toggle 3M / 6M / 12M'],
          ])+
          h2('Stale Alert Panel')+
          p('Lists the top stale open cases (idle ≥ 5 days) with owner, idle days, and direct IBM portal links.');
        }
      },

      'dash-team':{
        crumbs:['IIP','Dashboards','Team Cases'], title:'Team Cases',
        content(){
          return h1('Team Cases')+meta('March 20, 2026','v1.0.1')+
          p('Primary operational workspace — multi-dimension filters over the full active case queue.')+
          h2('Filters')+
          tbl(['Filter','Type','Notes'],[
            ['Owner','Dropdown with search','Short name display; type to filter'],
            ['Status','Select','Includes virtual groups: In Progress (All), Closed (All)'],
            ['Days Since Update','Select','3+, 5+, 10+, 20+ day thresholds'],
            ['Free Text','Input','Searches Case Number, Title, and Owner simultaneously'],
          ])+
          p('Filter state is persisted by StateManager and survives tab switches.')+
          h2('Table Columns')+
          tbl(['Column','Sortable','Notes'],[
            ['Case Number','Yes','Links to IBM support portal'],
            ['Title','Yes','Full title on hover'],
            ['Status','Yes','Colour-coded badge'],
            ['Owner','Yes','Short display name'],
            ['Product','Yes','—'],
            ['Age (days)','Yes','Red > 30d, orange > 14d'],
            ['Last Updated','Yes','Red if idle ≥ 5 days'],
          ])+
          h2('Bulk Actions')+
          ul([
            '<strong>Send Reminder Email</strong> — opens a mailto with the filtered owner\'s stale case list.',
            '<strong>Export CSV</strong> — downloads the current filtered view as UTF-8 CSV.',
          ]);
        }
      },

      'dash-members':{
        crumbs:['IIP','Dashboards','Member Dashboard'], title:'Member Dashboard',
        content(){
          return h1('Member Dashboard')+meta('March 20, 2026','v1.0.1')+
          p('Per-engineer workload visibility with a composite Health Score.')+
          h2('Health Score Formula')+
          callout('info','Formula','Health = 100 − (StaleRatio × 40 + AwaitRatio × 30 + LoadDeviation × 30). Range 0–100. Higher is healthier.')+
          tbl(['Component','Weight','Calculation'],[
            ['Stale Case Ratio','40 %','Stale open cases ÷ total open cases for this member'],
            ['Awaiting Feedback Ratio','30 %','"Awaiting your feedback" cases ÷ total open'],
            ['Load Deviation','30 %','abs(member open − team mean open) ÷ team mean open'],
          ])+
          tbl(['Score','Colour','Meaning'],[
            ['≥ 70','Green','Healthy — well balanced, responsive'],
            ['50–69','Amber','Moderate — review stale or awaiting cases'],
            ['< 50','Red','Needs attention — overloaded or high stale ratio'],
          ])+
          h2('Interactions')+
          ul([
            'Click a member card to expand and see their full case list.',
            'Sort cards by Active, Health, Stale, Closed, or Awaiting.',
            'Filter by name using the search input.',
          ]);
        }
      },

      'dash-performance':{
        crumbs:['IIP','Dashboards','Performance Metrics'], title:'Performance Metrics',
        content(){
          return h1('Performance Metrics')+meta('March 20, 2026','v1.0.1')+
          p('Resolution velocity, SLA tracking, performance case tagging, and owner reassignment.')+
          h2('Core Metrics')+
          tbl(['Metric','Formula'],[
            ['Avg Resolution Time','Mean(Closed Date − Created) for closed cases in the window'],
            ['Median Resolution Time','Median of same dataset — robust to outliers'],
            ['Closure Rate','Closed ÷ Created in the same period × 100 (target ≥ 95 %)'],
            ['SLA Adherence','% of closed cases resolved within '+ic('slaClosureDays')+' (default 30, Admin-configurable)'],
          ])+
          h2('Performance Case Tagging')+
          p('Tag a case as performance-related, assign an ALM instance (e.g. '+ic('ALM-06-P CCM')+'), and link a CLM work item number. Tags are stored in localStorage under '+ic('ibm_tracker_persist_v1')+'.')+
          callout('note','Admin Only','Tagging and reassignment require an active admin session.');
        }
      },

      'dash-customer':{
        crumbs:['IIP','Dashboards','Customer Cases'], title:'Customer Cases',
        content(){
          return h1('Customer Cases')+meta('March 20, 2026','v1.0.1')+
          p('A filtered view of cases scoped to the configured customer account number. Uses the same '+ic('ibm_cases_raw_v1')+' dataset from PostgreSQL, filtered to the '+ic('customerAccountId')+' set in DynamicConfig.')+
          ul([
            'Default account: '+ic('881812')+' — configurable in Admin Portal → App Identity → '+ic('customerAccountId')+'.',
            'Customer-specific products defined via '+ic('customerProducts')+' in DynamicConfig.',
          ]);
        }
      },

      'dash-closed':{
        crumbs:['IIP','Dashboards','Closed Cases'], title:'Closed Cases',
        content(){
          return h1('Closed Cases')+meta('March 20, 2026','v1.0.1')+
          p('Closure trend analysis — charts and a sortable table of all closed cases in the active dataset.')+
          ul([
            '<strong>Closure Trend Line</strong> — cases closed per month; toggle 3M / 6M / 12M.',
            '<strong>Closure by Owner</strong> — bar chart per engineer.',
            '<strong>Closure by Product</strong> — breakdown by product line.',
          ])+
          callout('info','Date Fallback','Closed Date field is used where present. Falls back to Updated date if Closed Date is absent.');
        }
      },

      'dash-created':{
        crumbs:['IIP','Dashboards','Created Cases'], title:'Created Cases',
        content(){
          return h1('Created Cases')+meta('March 20, 2026','v1.0.1')+
          p('Inbound volume analysis — cases by creation date, product, and account.')+
          ul([
            'Time window filter: 30d / 90d / 6M / 12M / All.',
            'Charts: created per month, by product, by account.',
            'Full sortable table of all cases in the filtered window.',
          ]);
        }
      },

      'dash-weekly':{
        crumbs:['IIP','Dashboards','Weekly Tracker'], title:'Weekly Tracker',
        content(){
          return h1('Weekly Tracker')+meta('March 20, 2026','v1.0.1')+
          p('A week-by-week register of closed cases used for sprint reviews and weekly reporting.')+
          h2('Data Sources')+
          tbl(['Source','Notes'],[
            ['XLSM upload (CW-named sheets)','Primary source — Excel sheets named by calendar week e.g. CW10'],
            ['Historical CSV','CSV files with an older filename date route here automatically'],
            [ic('enrichFromCases()'),'Called 400 ms after import — enriches tracker from '+ic('ibm_cases_raw_v1')],
          ])+
          h2('Storage')+
          p('Weekly tracker data is stored in localStorage under '+ic('ibm_wtracker_YYYY')+' (one key per year) on the machine accessing the app. Comments are stored under '+ic('ibm_wtracker_comments_v1')+'. Both are synced to the server via IIPStore ('+ic('TRACKER_COMMENTS')+' key) when a comment is saved.')+
          callout('tip','Shared across all users',ic('ibm_wtracker_YYYY')+' data is now synced to PostgreSQL via IIPStore v2.0. Every user who opens the app gets the same Weekly Tracker data automatically on page load — no manual import/export needed.');
        }
      },

      'dash-rfe':{
        crumbs:['IIP','Dashboards','RFE Tracking'], title:'RFE Tracking',
        content(){
          return h1('RFE Tracking')+meta('March 23, 2026','v1.0.3')+
          p('Enhancement request pipeline — upload RFE CSV data, track delivery status, add internal notes and target releases.')+
          h2('Storage')+
          tbl(['Key','Storage','Contains','Written by'],
          [
            [ic('ibm_rfe_tracking_v1'),'PostgreSQL','RFE CSV rows','Any user — public write endpoint'],
            [ic('ibm_rfe_tracking_metadata_v1'),'PostgreSQL','Per-RFE notes, target release, tags','Any user — public write endpoint'],
            [ic('ibm_rfe_tracking_last_update'),'PostgreSQL','Timestamp of last RFE import','Admin Portal import'],
          ])+
          callout('tip','Shared across all users — v1.0.3','RFE data and metadata are stored in PostgreSQL via the '+ic('/api/store-public/:key')+' endpoint. No admin token needed. Every user\'s notes and target release edits are immediately visible to all users.')+
          h2('Views')+
          tbl(['View','Description'],
          [
            ['Table','Sortable list of all RFEs with vote count, state chip, product, complete flag, and dates'],
            ['Analytics','Workflow state breakdown, top-5 by votes, product distribution'],
          ])+
          h2('Detail Modal')+
          p('Click any row to open the detail modal. You can set a '+strong('Target Release')+' and add '+strong('Internal Notes')+' with author and timestamp. Notes are shared — all team members see them.')
        }
      },

      'dash-investigate':{
        crumbs:['IIP','Dashboards','Investigate'], title:'Investigate',
        content(){
          return h1('Investigate')+meta('March 23, 2026','v1.0.3')+
          p('Three-tab tool: '+strong('Case Investigation AI')+' (similarity search), '+strong('Support Intelligence')+' (pattern analysis), and '+strong('Archive Search')+' (all-time case lookup).')+
          h2('Storage')+
          tbl(['Key','Storage','Contains'],
          [
            [ic('ibm_investigate_archive_v1'),'PostgreSQL','All-time case archive keyed by Case Number — shared across all users'],
          ])+
          callout('tip','Shared — v1.0.3','The investigate archive is stored in PostgreSQL via the public write endpoint. Every user shares the same growing archive. Cases are never dropped — every upload adds to it.')+
          h2('How It Builds')+
          p('Every CSV/XLSX import calls '+ic('DashInvestigate.archiveCases(rows)')+', which upserts rows into '+ic('ibm_investigate_archive_v1')+' by Case Number. '+ic('_setArchive()')+' writes to localStorage AND syncs to PostgreSQL via '+ic('IIPStore.set()')+'. On boot, '+ic('_getArchive()')+' reads from '+ic('IIPStore.getSync()')+' which is hydrated from DB.')+
          h2('Case Investigation AI')+
          p('Paste any error message, stack trace, or log snippet. The engine extracts error codes, IBM product names, and keywords, then scores all archived cases by token overlap similarity and returns the top 15 matches.')+
          h2('Support Intelligence')+
          p('Auto-generated insights from the archive: known issue clusters, top error codes, recurring keywords, case volume prediction, and product incident heatmap.')+
          h2('Archive Search')+
          p('Live search across all '+strong('2,000+')+ ' archived cases. Searches Case Number, Title, Owner, Product, Status. Cases with discussion notes show a 💬 badge.')
        }
      },

      /* ── ADMINISTRATION ───────────────────────────────── */
      'admin-portal':{
        crumbs:['IIP','Administration','Admin Portal'], title:'Admin Portal',
        content(){
          return h1('Admin Portal')+meta('March 20, 2026','v1.0.1')+
          p('Role-gated area accessible via the sidebar. Implemented in '+ic('js/modules/admin/admin.js')+'.')+
          h2('Authentication')+
          steps([
            'Click '+ic('Admin Portal')+' in the sidebar.',
            'Enter the admin password (set during first-time Admin Portal access).',
            'On success: '+ic('Data.setAdminMode(true)')+' is called and '+ic('sessionStorage.setItem("ibm_admin_session_v1","1")')+' is set.',
            'Session ends automatically when the browser tab closes.',
          ])+
          callout('note','Session Scope','Admin sessions are tab-scoped (sessionStorage). Opening IIP in a new tab requires re-authentication.')+
          h2('Admin Sections')+
          tbl(['Section','Purpose'],[
            ['Team and App Configuration','Team members, app title, customer account, ALM lines, name aliases, SLA targets'],
            ['App Identity and Settings','App title, team name, customer account ID, defect base URL — includes Change Password button'],
            ['IBM ELM Directory','IBM engineer contact information'],
            ['Data Management','Clear all data, download backup, view import log'],
            ['Performance Tagging','Tag cases as performance-related, assign ALM instance, link CLM work item'],
            ['Owner Reassignment','Bulk-reassign open cases between owners with audit log'],
          ]);
        }
      },

      'admin-config':{
        crumbs:['IIP','Administration','Team Configuration'], title:'Team Configuration',
        content(){
          return h1('Team Configuration')+meta('March 20, 2026','v1.0.1')+
          p('Configuration is managed by '+ic('DynamicConfig')+' — reads and writes to localStorage under the key '+ic('ibm_team_config_v1_cache')+'. Merges with static defaults from AppData for any field not explicitly saved.')+
          callout('info','DynamicConfig cache',ic('DynamicConfig')+' uses localStorage as a fast read cache ('+ic('ibm_team_config_v1_cache')+'). The authoritative copy is in PostgreSQL under '+ic('ibm_team_config_v1')+' and is hydrated on every page load. Saving config in Admin Portal writes to both localStorage and PostgreSQL.')+
          h2('Configuration Fields')+
          tbl(['Field','Type','Description'],[
            [ic('appTitle'),'String','App title in sidebar header and browser tab'],
            [ic('teamName'),'String','Team identifier shown under the logo'],
            [ic('customerAccountId'),'String','Default IBM customer account for Customer Cases tab (default: '+ic('881812')+')'],
            [ic('teamMembers'),'String[]','Overrides AppData.teamMembers when set'],
            [ic('nameAliases'),'Object','Maps CSV owner name variants to canonical display names'],
            [ic('defectBaseUrl'),'String','Base URL for CLM work item deep links'],
            [ic('slaTargetPct'),'Number','SLA target percentage (default 80)'],
            [ic('slaClosureDays'),'Number','SLA window in days (default 30)'],
            [ic('customerProducts'),'String[]','Products scoped to the customer account'],
            [ic('almLines'),'Object[]','ALM line definitions with responsible mappings'],
          ]);
        }
      },

      'admin-tagging':{
        crumbs:['IIP','Administration','Performance Tagging'], title:'Performance Tagging',
        content(){
          return h1('Performance Tagging')+meta('March 20, 2026','v1.0.1')+
          p('Tag open cases as performance-related, assign to an ALM instance, and link a CLM work item ID. Tags survive re-uploads because they are stored separately from the CSV data.')+
          steps([
            'Log in to Admin Portal.',
            'Navigate to Performance Metrics — the Tagging panel is collapsible at the top.',
            'Find the case using search/filter.',
            'Set Instance (e.g. '+ic('ALM-06-P CCM')+') and optionally a Work Item ID.',
            'Click Tag — stored immediately in localStorage under '+ic('ibm_tracker_persist_v1')+'.',
          ])+
          callout('note','Storage',ic('ibm_tracker_persist_v1')+' is routed through IIPStore → PostgreSQL in server mode. Performance tags, reassign log, and owner overrides all persist in PostgreSQL.');
        }
      },

      'admin-reassign':{
        crumbs:['IIP','Administration','Owner Reassignment'], title:'Owner Reassignment',
        content(){
          return h1('Owner Reassignment')+meta('March 20, 2026','v1.0.1')+
          p('Bulk-reassign open cases from one owner to another. Reassignments persist across all future CSV uploads.')+
          steps([
            'Log in to Admin Portal.',
            'Go to Performance Metrics → Owner Reassignment (collapsible panel).',
            'Select source owner (current) and target owner (new).',
            'Optionally filter to specific cases.',
            'Click Reassign — affected cases receive an '+ic('_ownerOverride: true')+' flag stored in PostgreSQL via '+ic('ibm_tracker_persist_v1')+'.',
          ])+
          callout('note','Survives Re-uploads','The '+ic('_ownerOverride')+' flag in '+ic('ibm_tracker_persist_v1')+' is checked during every CSV merge. The reassigned owner is preserved regardless of what the IBM export shows.')+
          p('All reassignments are logged with timestamp, old owner, new owner, and case details in the '+ic('reassignLog')+' array inside '+ic('ibm_tracker_persist_v1')+'.');
        }
      },

      'admin-password':{
        crumbs:['IIP','Administration','Admin Password'], title:'Admin Password',
        adminOnly: true,
        content(){
          return h1('Admin Password')+meta('March 23, 2026','v1.0.3')+
          callout('note','Storage',`The admin password is stored in browser localStorage under ${ic('ibm_admin_pwd_v1')} and synced to PostgreSQL via the shared-state system. On first-time access, users are prompted to create a password. There is no default password.`)+
          callout('tip','v1.0.3 Fix','A double-encoding bug in v1.0.2+ caused passwords to be stored with extra JSON quotes after DB hydration, making login fail on new browsers. v1.0.3 fixes both the storage layer and the read layer — existing users are migrated automatically on next login.')+
          h2('First-Time Setup')+
          steps([
            'Click '+ic('Admin Portal')+' in the sidebar.',
            'The setup dialog appears — enter a new password (minimum 8 characters).',
            'Optionally enter the API Admin Token shown in the server console (enables authenticated writes to PostgreSQL).',
            'Click Set Password — stored in localStorage on this browser.',
          ])+
          h2('Change Password via Admin Portal')+
          steps([
            'Log in to Admin Portal.',
            'Expand Team and App Configuration → App Identity and Settings.',
            'Click the Change Password button.',
            'Enter current password, new password (min 8 chars), confirm.',
            'Click Save Password — stored immediately in localStorage.',
          ])+
          h2('Reset Password (Emergency)')+
          callout('warning','Admin Only','Password reset via browser console should only be performed by authorized administrators.')+
          p('If locked out, an administrator with browser console access can reset:')+
          cb('// Open F12 Console on the IIP app:\nlocalStorage.removeItem(\'ibm_admin_pwd_v1\');\n// Refresh — the first-time setup dialog will appear.')+
          h2('Quick Reference')+
          tbl(['Item','Value'],[
            ['Storage','localStorage under key '+ic('ibm_admin_pwd_v1')],
            ['Default password','None — must be set on first access'],
            ['Minimum length','8 characters'],
            ['Session key',ic('ibm_admin_session_v1')+' in sessionStorage — clears on tab close'],
            ['Change via','Admin Portal → App Identity and Settings → Change Password'],
            ['Emergency reset','Browser console: '+ic("localStorage.removeItem('ibm_admin_pwd_v1')")],
          ]);
        }
      },

      'admin-data':{
        crumbs:['IIP','Administration','Data Management'], title:'Data Management',
        adminOnly: true,
        content(){
          return h1('Data Management')+meta('March 23, 2026','v1.0.3')+
          h2('Clear All Data')+
          p('Admin Portal → Data Management → Clear All Data removes all IIPStore keys from PostgreSQL AND clears all app-related localStorage keys on the current machine.')+
          callout('warning','Irreversible','This removes all case data, tracker entries, RFE data, overrides, and config. Take a backup first.')+
          h2('Download Backup')+
          p('Admin Portal → Data Management → Download Backup exports a JSON of all PostgreSQL '+ic('iip_kv')+' keys plus key localStorage entries on the current machine. Store this file securely.')+
          h2('PostgreSQL Direct Wipe')+
          cb('sudo -u postgres psql -d iip_db -c "DELETE FROM iip_kv;"')+
          h2('PostgreSQL Backup')+
          cb('sudo -u postgres pg_dump iip_db > /backup/iip_db_$(date +%Y%m%d).sql')+
          h2('Restore')+
          cb('sudo -u postgres psql iip_db < /backup/iip_db_20260320.sql')+
          h2('Import Log')+
          p('The last 50 import operations are stored under '+ic('ibm_import_log_v1')+' in localStorage on the client that did the import. View via Admin Portal → Data Management → Import Log.');
        }
      },

      /* ── OPERATIONS ───────────────────────────────────── */
      'ops-stack':{
        crumbs:['IIP','Operations','Server Stack'], title:'Server Stack',
        adminOnly: true,
        content(){
          return h1('Server Stack')+meta('March 20, 2026','v1.0.1')+
          h2('Health Check')+
          cb('sudo systemctl status iip-fastapi\nsudo systemctl status postgresql | grep Active\nsudo systemctl status httpd | grep Active\ncurl -k https://rb-alm-01-d8.de.bosch.com/iip/api/health')+
          h2('Files and Paths')+
          tbl(['Item','Path'],[
            ['App root',ic('/var/www/html/iip/')],
            ['Backend dir',ic('/var/www/html/iip/backend/')],
            ['API entry point',ic('/var/www/html/iip/backend/main.py')],
            ['Python venv',ic('/var/www/html/iip/backend/.venv/')],
            ['DB credentials',ic('/var/www/html/iip/backend/.env')],
            ['systemd service',ic('/etc/systemd/system/iip-fastapi.service')],
            ['Apache vhost',ic('/etc/httpd/conf.d/rb-alm-01-d8.conf')],
            ['PostgreSQL data dir',ic('/var/lib/pgsql/data/')],
            ['pg_hba.conf',ic('/var/lib/pgsql/data/pg_hba.conf')],
            ['Apache error log',ic('/var/log/httpd/rb-alm-01-d8_error.log')],
            ['API logs',ic('sudo journalctl -u iip-fastapi -f')],
          ])+
          h2('Service Commands')+
          tbl(['Task','Command'],[
            ['Check API status',ic('sudo systemctl status iip-fastapi')],
            ['Restart API',ic('sudo systemctl restart iip-fastapi')],
            ['Stop API',ic('sudo systemctl stop iip-fastapi')],
            ['View API logs (live)',ic('sudo journalctl -u iip-fastapi -f')],
            ['View API logs (last 50)',ic('sudo journalctl -u iip-fastapi -n 50')],
            ['Restart PostgreSQL',ic('sudo systemctl restart postgresql')],
            ['Restart Apache',ic('sudo systemctl restart httpd')],
            ['Check SELinux proxy bool',ic('getsebool httpd_can_network_connect')],
            ['Enable SELinux proxy bool',ic('sudo setsebool -P httpd_can_network_connect on')],
          ]);
        }
      },

      'ops-deploy':{
        crumbs:['IIP','Operations','Deploying Updates'], title:'Deploying Updates',
        adminOnly: true,
        content(){
          return h1('Deploying Updates')+meta('2026-05-12','v1.0.0')+
          p('IIP uses a one-command deploy script. Frontend is static HTML/JS/CSS (no build step). Backend is FastAPI (Python) managed by systemd.')+
          callout('tip','v1.0.0 — Current Deploy','Use '+ic('sync-and-deploy.sh')+' for all deployments. It syncs Windows → Linux, restarts FastAPI, and verifies.')+
          h2('v1.0.0 Deploy (Current)')+
          cb('# One-command deploy from Windows:\nbash sync-and-deploy.sh root rb-alm-01-d8.de.bosch.com /var/www/html/iip\n\n# What it does:\n# 1. SCP syncs all files from Windows → Linux\n# 2. Restarts FastAPI backend (systemctl restart iip-fastapi)\n# 3. Reloads Apache config\n# 4. Runs health check to verify')+
          h2('API Deploy (backend Python changes)')+
          cb('# After editing backend Python files:\nsudo systemctl restart iip-fastapi\n# Verify:\ncurl http://127.0.0.1:3001/api/health\n# Expected: {"status":"ok","db":"connected",...}')+
          h2('Deploy a Full Bundle')+
          cb('cd /tmp && unzip iip_new.zip\ncp -r iip/* /var/www/html/iip/\nchown -R apache:apache /var/www/html/iip/\nchmod -R 755 /var/www/html/iip/')+
          callout('warning','Never Overwrite .env',ic('/var/www/html/iip/backend/.env')+' contains the database password. Do not include it in deployable zips or version control. Always keep it only on the server.')+
          h2('Hard Refresh Users')+
          p('After any frontend file change, users must hard-refresh to get the new JS. Either notify them or add a cache-busting comment to '+ic('index.html')+'.')+
          cb('# User instruction:\nWindows/Linux : Ctrl + Shift + R\nMac           : Cmd + Shift + R')+
          h2('Rollback a File')+
          cb('cp /var/www/html/iip/js/modules/data/storage.js.bak \\\n   /var/www/html/iip/js/modules/data/storage.js\n# Then hard-refresh browsers');
        }
      },

      /* ── DEPLOYMENT HISTORY (Admin-Only) ─────────────── */
      'ops-deploy-history':{
        crumbs:['IIP','Operations','Deployment History'], title:'Deployment History',
        adminOnly: true,
        content(){
          return h1('Deployment History')+meta('2026-05-12','v1.0.0')+
          callout('note','Admin Only','This page records every deployment performed, the exact steps taken, and the rollback procedure for each version.')+


          h2('v1.0.0 — Official Production Release (2026-05-12)')+
          badge('Current','#198038')+
          p('<strong>Deployed by:</strong> Kabilesh K &nbsp;|&nbsp; <strong>Server:</strong> '+ic('si0vm14401 / rb-alm-01-d8.de.bosch.com'))+

          h3('Changes')+
          tbl(['Area','Change'],[
            ['Backend','Security question-based password reset (3 new endpoints)'],
            ['Backend','API version updated to 1.0.0 in FastAPI app + /api/health'],
            ['Frontend','Custom div-based dropdown for security questions modal (replaced native select)'],
            ['Frontend','6 new admin-only developer documentation pages'],
            ['Frontend','What\'s New and Version History updated to v1.0.0'],
            ['Project','21 files removed (5 .sh, 14 .md, 1 .json, 1 .yml)'],
            ['Project','README.md added with full project reference'],
          ])+

          h3('Files Modified')+
          tbl(['File','Change'],[
            [ic('backend/routers/auth.py'),'Added security-questions and reset-via-security endpoints'],
            [ic('backend/models.py'),'Added SecurityQuestionSetupRequest, SecurityQuestionResetRequest'],
            [ic('backend/main.py'),'Version bumped to 1.0.0'],
            [ic('js/app.js'),'AppVersion bumped to 1.0.0'],
            [ic('js/modules/ui/modal.js'),'showSetupSecurityQuestions() with custom dropdown'],
            [ic('js/modules/admin/admin.js'),'_showForgotPasswordModal() rewritten for security questions'],
            [ic('js/modules/ui/whats-new.js'),'v1.0.0 changelog entry added'],
            [ic('js/dashboards/documentation.js'),'6 developer doc pages, version refs updated'],
            [ic('js/dashboards/admin-dash.js'),'Security Questions button added'],
            [ic('css/features/modals.css'),'Modal z-index fixes for dropdown'],
            [ic('README.md'),'Created — project overview, structure, API reference'],
          ])+

          h2('v2.0.3 — Server Recovery Build (2026-03-24)')+
          p('<strong>Deployed by:</strong> Kabilesh K &nbsp;|&nbsp; <strong>Server:</strong> '+ic('si0vm14401 / rb-alm-01-d8.de.bosch.com')+' &nbsp;|&nbsp; <strong>Downtime:</strong> ~2 hours (full backend rebuild)')+

          h3('Root Causes')+
          tbl(['Component','Problem','Fix'],[
            ['FastAPI / venv','Python venv missing or corrupted after server migration','Rebuild: python3 -m venv .venv && pip install -r requirements.txt'],
            ['PostgreSQL','iip_db database did not exist','CREATE DATABASE iip_db + schema reload'],
            ['PostgreSQL','iip_user did not exist','CREATE USER iip_user + GRANT privileges'],
            ['Apache','ProxyPass was /api/ instead of /iip/api/','Updated vhost conf to ProxyPass /iip/api/'],
            ['Apache','Missing SPA rewrite rules','Added RewriteBase /iip/ + index.html fallback'],
            ['SELinux','File access denied','setenforce 0 + SELINUX=disabled'],
            ['Frontend','storage.js: duplicate const API_BASE before use strict','Rewrote IIFE opening — one var API_BASE after use strict'],
            ['Frontend','admin.js: no API_BASE (loads before app.js)','Added var API_BASE inside Admin IIFE'],
            ['Frontend','dynamic-config.js: double-slash in API URL','Fixed API_BASE pattern + corrected fetch path'],
            ['Frontend','app.js: duplicate API_BASE blocks','Stripped all, inserted one clean global declaration'],
            ['Frontend','app.js: admin guard bypassed when Admin=undefined','Hardened guard — always blocks if not admin'],
            ['CSP','connect-src blocked Chart.js source maps','Added cdn.jsdelivr.net to connect-src in .htaccess'],
          ])+

          h3('Files Modified')+
          tbl(['File','Change'],[
            [ic('backend/main.py'),'Full rewrite to FastAPI; CORS, SSE, asyncpg pool, 19 endpoints'],
            [ic('backend/.env'),'DB_HOST, DB_NAME, DB_USER, DB_PASSWORD, API_PORT=3001, CORS_ORIGIN set'],
            [ic('/etc/systemd/system/iip-fastapi.service'),'Created — systemd service for FastAPI'],
            [ic('js/app.js'),'v2.0.3 bump, API_BASE fixed, admin guard hardened, onclick quote fix'],
            [ic('js/modules/data/storage.js'),'Duplicate API_BASE removed, use strict first, all constants dynamic'],
            [ic('js/modules/admin/admin.js'),'Own API_BASE added (loads before app.js)'],
            [ic('js/modules/data/dynamic-config.js'),'API_BASE double-slash fixed, fetch path corrected'],
            [ic('js/modules/ui/whats-new.js'),'v2.0.3 changelog entry added'],
            [ic('js/dashboards/documentation.js'),'Updated to v2.0.3, recovery docs added, proxy path corrected'],
            [ic('.htaccess'),'connect-src cdn.jsdelivr.net added'],
            [ic('/etc/httpd/conf.d/rb-alm-01-d8.conf'),'ProxyPass /iip/api/, SPA rewrite rules, SSL certs'],
          ])+

          h3('Deployment Steps (Executed)')+
          steps([
            'Backend: stopped old service, rebuilt Python venv: '+ic('cd /var/www/html/iip/backend && python3 -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt'),
            'DB: '+ic("sudo -u postgres psql -c \"CREATE USER iip_user WITH PASSWORD '...';\""),
            'DB: '+ic('sudo -u postgres psql -c "CREATE DATABASE iip_db OWNER iip_user;"'),
            'DB schema: '+ic('psql -h 127.0.0.1 -U iip_user -d iip_db -c "CREATE TABLE IF NOT EXISTS iip_kv (id SERIAL PRIMARY KEY, key TEXT NOT NULL UNIQUE, value JSONB, updated_at TIMESTAMPTZ DEFAULT NOW());"'),
            'Service: '+ic('sudo systemctl daemon-reload && sudo systemctl enable iip-fastapi && sudo systemctl start iip-fastapi'),
            'Apache: '+ic('systemctl restart httpd'),
            'Frontend: '+ic('bash deploy_clean.sh  # fixes all 4 JS files idempotently'),
          ])+

          h3('Post-Deployment Verification')+
          steps([
            'API health: '+ic('curl -s https://rb-alm-01-d8.de.bosch.com/iip/api/health | python3 -m json.tool'),
            'Browser console: ZERO red errors (no SyntaxError, no IIPStore undefined)',
            'Click Admin Portal → password prompt must appear',
            'Upload a CSV → data loads across all dashboards',
            'Check '+ic('[IIPStore] v2.1 ready')+' in console',
          ])+

          `<div style="border-top:2px solid var(--border-mid);margin:36px 0 28px"></div>`+
          h2('v1.0.3 — Bug Fixes and Tour Improvement (March 23, 2026)')+
          badge('Current','#198038')+
          p('<strong>Deployed by:</strong> Admin &nbsp;|&nbsp; <strong>Server:</strong> '+ic('rb-alm-01-d8.de.bosch.com')+' &nbsp;|&nbsp; <strong>Downtime:</strong> None (frontend files only — no server restart needed)')+

          h3('Files Changed')+
          tbl(['File','Change'],[
            [ic('js/modules/data/storage.js'),'v2.1 — infinite recursion fix; hydration fallback for old server; _hydrating guard; primitive string encoding fix; write-only sync for admins'],
            [ic('js/modules/admin/admin.js'),'_getLsPwd() handles both encoded and plain password formats — auto-migration on login'],
            [ic('js/dashboards/app-tour.js'),'Light-only redesign — no blur, no dark mode; 45% overlay; cleaner spotlight and tooltip'],
            [ic('js/dashboards/weekly-tracker.js'),'Admin-only: History/Reopened tabs, Availability editing, Edit/Delete buttons, bulk actions'],
            [ic('js/dashboards/performance.js'),'Admin-only: Availability status editing in case detail panel'],
            [ic('js/dashboards/documentation.js'),'This file — full v1.0.3 release notes and updated all sections'],
          ])+

          h3('Deployment Steps')+
          steps([
            'Copy 5 files to server (no zip needed — individual file copy):',
            ic('cp storage.js    /var/www/html/iip/js/modules/data/storage.js'),
            ic('cp admin.js      /var/www/html/iip/js/modules/admin/admin.js'),
            ic('cp app-tour.js   /var/www/html/iip/js/dashboards/app-tour.js'),
            ic('cp weekly-tracker.js /var/www/html/iip/js/dashboards/weekly-tracker.js'),
            ic('cp performance.js    /var/www/html/iip/js/dashboards/performance.js'),
            ic('cp documentation.js  /var/www/html/iip/js/dashboards/documentation.js'),
            'No server restart needed — all frontend changes.',
            'Ask users to hard-refresh: '+ic('Ctrl+Shift+R'),
          ])+

          h3('Post-Deployment Verification')+
          steps([
            'Open Admin Portal and log in with existing password — should work without "Incorrect password" error.',
            'Press '+ic('Ctrl+L')+' — tour should open with light tooltip, no blur, visible app behind overlay.',
            'Open app in incognito — all data (RFE, Weekly Tracker, Performance) should load from DB.',
            'Check console: should see '+ic('[IIPStore] v2.1 ready')+' and '+ic('Boot hydration complete')+' — NO stack overflow errors.',
            'Verify admin-only: log in as non-admin, confirm History/Reopened tabs are hidden in Weekly Tracker.',
          ])+

          h3('v1.0.3 Rollback')+
          steps([
            'Restore previous storage.js: '+ic('cp /var/www/html/iip/js/modules/data/storage.js.bak /var/www/html/iip/js/modules/data/storage.js'),
            'Admin password: if login fails after rollback, run in console: '+ic("localStorage.removeItem('ibm_admin_pwd_v1')"),
            'Hard-refresh browser: '+ic('Ctrl+Shift+R'),
          ])+

          `<div style="border-top:2px solid var(--border-mid);margin:36px 0 28px"></div>`+

          h2('v1.0.2 — Security Hardening (March 20, 2026)')+
          badge('Current','#198038')+
          p('<strong>Deployed by:</strong> Admin &nbsp;|&nbsp; <strong>Server:</strong> '+ic('rb-alm-01-d8.de.bosch.com')+' &nbsp;|&nbsp; <strong>Downtime:</strong> ~5 minutes (API restart only)')+

          h3('Pre-Deployment Steps')+
          steps([
            'SSH to server: '+ic('ssh rbadmin_app1@si0vm14401.de.bosch.com'),
            'Backup PostgreSQL: '+ic('sudo -u postgres pg_dump iip_db > /backup/iip_db_pre_v102_$(date +%Y%m%d_%H%M).sql'),
            'Backup current app: '+ic('cp -r /var/www/html/iip /var/www/html/iip_backup_v101'),
            'Save live .env: '+ic('cp /var/www/html/iip/backend/.env /tmp/.env.production.bak'),
            'Stop API: '+ic('sudo systemctl stop iip-fastapi'),
          ])+

          h3('Deployment Steps')+
          steps([
            'Upload zip to server: '+ic('scp iip-v1.0.2-deploy.zip rbadmin_app1@si0vm14401.de.bosch.com:/tmp/'),
            'Extract: '+ic('cd /tmp && mkdir -p iip-v102-staging && unzip iip-v1.0.2-deploy.zip -d iip-v102-staging'),
            'Remove placeholder .env from staging: '+ic('rm /tmp/iip-v102-staging/backend/.env'),
            'Copy new files over live app: '+ic('cp -r /tmp/iip-v102-staging/* /var/www/html/iip/'),
            'Restore real .env: '+ic('cp /tmp/.env.production.bak /var/www/html/iip/backend/.env'),
            'Generate admin token: '+ic('openssl rand -hex 32'),
            'Add token to .env: '+ic("echo 'IIP_ADMIN_TOKEN=<generated-token>' >> /var/www/html/iip/backend/.env"),
            'Add CORS origin: '+ic("echo 'CORS_ORIGIN=https://rb-alm-01-d8.de.bosch.com' >> /var/www/html/iip/backend/.env"),
            'Install Python deps: '+ic('cd /var/www/html/iip/backend && source .venv/bin/activate && pip install -r requirements.txt'),
            'Fix permissions: '+ic('sudo chown -R apache:apache /var/www/html/iip/ && sudo chmod -R 755 /var/www/html/iip/'),
            'Protect .env: '+ic('sudo chmod 640 /var/www/html/iip/backend/.env && sudo chown root:apache /var/www/html/iip/backend/.env'),
            'Start API: '+ic('sudo systemctl start iip-fastapi'),
            
          ])+

          h3('Post-Deployment Verification')+
          steps([
            'Health check: '+ic('curl -k https://rb-alm-01-d8.de.bosch.com/api/health')+' → expected: '+ic('{"ok":true,"db":"connected",...}'),
            'Read test: '+ic('curl -k https://rb-alm-01-d8.de.bosch.com/api/store/ibm_cases_raw_v1 | head -c 200')+' → should return case data',
            'Write WITHOUT token: '+ic('curl -k -X POST .../api/store/ibm_import_log_v1 -H "Content-Type: application/json" -d \'{"value":"test"}\'')+' → expected: '+ic('"Forbidden: invalid or missing admin token."'),
            'Write WITH token: '+ic('curl -k -X POST .../api/store/ibm_import_log_v1 -H "Content-Type: application/json" -H "X-IIP-Admin-Token: <token>" -d \'{"value":"deploy_test"}\'')+' → expected: '+ic('{"ok":true}'),
            'Unknown key test: POST to '+ic('/api/store/random_bad_key')+' → expected: '+ic('"Key ... is not in the allowed key list."'),
            'Rate limit test: 31 rapid POST requests → last ones return '+ic('"Rate limit exceeded."'),
          ])+

          h3('Browser-Side Setup (First Admin Login)')+
          steps([
            'Open '+ic('https://rb-alm-01-d8.de.bosch.com/iip/')+' and press '+ic('Ctrl+Shift+R')+' to hard-refresh.',
            'Open F12 Console and run: '+ic("localStorage.removeItem('ibm_admin_pwd_v1'); localStorage.removeItem('ibm_admin_token_v1');"),
            'Click Admin Portal in sidebar — the Admin Setup dialog appears.',
            'Set a new password (min 8 characters) and paste the API Admin Token from Step 6 above.',
            'Click Set Password — you are now logged in as admin.',
            'Verify: Documentation → Operations pages show full content. In incognito, same pages show "Admin Access Required".',
            'Verify: CSV upload works (check Network tab for 200 OK on POST to '+ic('/api/store/ibm_cases_raw_v1')+').',
          ])+

          h3('v1.0.2 Rollback Procedure')+
          callout('warning','Rollback','Use this if v1.0.2 causes issues. Restores v1.0.1 completely.')+
          steps([
            'Stop API: '+ic('sudo systemctl stop iip-fastapi'),
            'Restore app files: '+ic('rm -rf /var/www/html/iip && cp -r /var/www/html/iip_backup_v101 /var/www/html/iip'),
            'Fix permissions: '+ic('sudo chown -R apache:apache /var/www/html/iip/ && sudo chmod -R 755 /var/www/html/iip/'),
            'Restore DB (if needed): '+ic('sudo -u postgres psql iip_db < /backup/iip_db_pre_v102_YYYYMMDD_HHMM.sql'),
            'Start API: '+ic('sudo systemctl start iip-fastapi'),
            'Verify: '+ic('curl -k https://rb-alm-01-d8.de.bosch.com/api/health'),
          ])+

          `<div style="border-top:2px solid var(--border-mid);margin:36px 0 28px"></div>`+

          h2('v1.0.1 — PostgreSQL Backend Integration (March 2026)')+
          badge('Superseded','#6929c4')+
          p('<strong>Summary:</strong> Core case data migrated from localStorage to PostgreSQL. FastAPI (Python) REST API introduced.')+

          h3('Deployment Steps Performed')+
          steps([
            'Installed PostgreSQL 13 on RHEL9: '+ic('sudo dnf install postgresql-server && sudo postgresql-setup --initdb'),
            'Created database and user: '+ic("sudo -u postgres psql -c \"CREATE DATABASE iip_db;\" && sudo -u postgres psql -c \"CREATE USER iip_user WITH PASSWORD '...';\""),
            'Created '+ic('iip_kv')+' table: '+ic('CREATE TABLE iip_kv (id SERIAL PRIMARY KEY, key TEXT NOT NULL UNIQUE, value JSONB, updated_at TIMESTAMPTZ DEFAULT NOW());'),
            'Changed '+ic('pg_hba.conf')+' from '+ic('ident')+' to '+ic('md5')+' for 127.0.0.1 connections, then: '+ic('sudo systemctl restart postgresql'),
            'Deployed '+ic('backend/main.py')+' (FastAPI) and '+ic('.env')+' to '+ic('/var/www/html/iip/backend/'),
            'Set up Python venv and installed dependencies: '+ic('cd /var/www/html/iip/backend && python3 -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt'),
            'Deployed FastAPI backend: set up systemd service iip-fastapi and enabled on boot (see Getting Started → Installation)',
            'Configured Apache ProxyPass: added '+ic('ProxyPass /api/ http://127.0.0.1:3001/api/')+' to vhost config.',
            'Enabled SELinux proxy: '+ic('sudo setsebool -P httpd_can_network_connect on'),
            'Restarted Apache: '+ic('sudo systemctl restart httpd'),
            'Deployed updated frontend files ('+ic('storage.js')+', dashboards, '+ic('app.js')+').',
            'Verified: '+ic('curl -k https://rb-alm-01-d8.de.bosch.com/api/health')+' returned '+ic('{"ok":true}'),
          ])+

          h3('v1.0.1 Rollback Procedure')+
          steps([
            'Stop API: '+ic('sudo systemctl stop iip-fastapi && sudo systemctl disable iip-fastapi'),
            'Restore pre-PostgreSQL app files from backup.',
            'The app will revert to localStorage-only mode ('+ic('file://')+' or '+ic('https:')+' without the API will fall back to localStorage via '+ic('storage.js')+').',
            'Remove Apache ProxyPass lines and restart: '+ic('sudo systemctl restart httpd'),
          ])+

          `<div style="border-top:2px solid var(--border-mid);margin:36px 0 28px"></div>`+

          h2('v1.0.0 — Initial Release (January 2026)')+
          badge('Superseded','#6929c4')+
          p('<strong>Summary:</strong> First production deployment. RFE Tracking, Weekly Tracker, Admin Portal, CSV merge with conflict resolution.')+

          h3('Deployment Steps Performed')+
          steps([
            'Installed Apache 2.4 on RHEL9: '+ic('sudo dnf install -y httpd mod_ssl && sudo systemctl enable httpd'),
            'Deployed SSL certificates to '+ic('/etc/ssl/certs/'),
            'Created vhost config at '+ic('/etc/httpd/conf.d/rb-alm-01-d8.conf')+' with HTTPS redirect, SSL engine, security headers.',
            'Disabled default ssl.conf: '+ic('mv /etc/httpd/conf.d/ssl.conf /etc/httpd/conf.d/ssl.conf.bak'),
            'Deployed app files to '+ic('/var/www/html/iip/'),
            'Set permissions: '+ic('chown -R apache:apache /var/www/html/iip/ && chmod -R 755 /var/www/html/iip/'),
            'Configured firewall: '+ic('firewall-cmd --permanent --add-service=https && firewall-cmd --reload'),
            'Started Apache: '+ic('sudo systemctl start httpd'),
            'Verified: opened '+ic('https://rb-alm-01-d8.de.bosch.com/iip/')+' in browser — app loaded successfully.',
          ])+

          h3('v1.0.0 Rollback Procedure')+
          steps([
            'This was the initial deployment. Rollback = remove the app entirely.',
            ic('rm -rf /var/www/html/iip'),
            ic('sudo systemctl stop httpd')+' (if no other sites hosted).',
          ]);
        }
      },

      'ops-postgres':{
        crumbs:['IIP','Operations','PostgreSQL Reference'], title:'PostgreSQL Reference',
        adminOnly: true,
        content(){
          return h1('PostgreSQL Reference')+meta('March 23, 2026','v1.0.3')+
          h2('Database Info')+
          tbl(['Item','Value'],[
            ['Version','PostgreSQL 13.23'],
            ['Database',ic('iip_db')],
            ['User',ic('iip_user')],
            ['Host / Port',ic('localhost:5432')],
            ['Auth method',ic('md5')],
            ['Schema','26 tables, 88 indexes, 3 views — see '+ic('schema/iip_schema.sql')],
          ])+
          h2('Live Row Counts')+
          cb(`-- Connect:\nsudo -u postgres psql -d iip_db\n-- or use the ./db.sh shortcut in /opt/IBM/IIP\n\n-- Row counts for all tables:\nSELECT relname AS table, n_live_tup AS rows\nFROM pg_stat_user_tables ORDER BY n_live_tup DESC;`)+
          h2('Useful Queries')+
          cb(`-- Count active cases:\nSELECT COUNT(*) FROM cases;\n\n-- Cases by owner:\nSELECT owner_name, COUNT(*) FROM cases\nWHERE is_active = true GROUP BY owner_name ORDER BY 2 DESC;\n\n-- Weekly tracker entries this year:\nSELECT week_label, COUNT(*) FROM weekly_closed_cases\nWHERE year = EXTRACT(YEAR FROM NOW())\nGROUP BY week_label ORDER BY week_label;\n\n-- Recent uploads:\nSELECT filename, upload_date, record_count, status\nFROM uploads ORDER BY upload_date DESC LIMIT 10;\n\n-- Recent audit log:\nSELECT action, entity_type, entity_id, admin_user, change_date\nFROM audit_log ORDER BY change_date DESC LIMIT 20;\n\n-- Active admin sessions:\nSELECT username, created_at, expires_at FROM admin_sessions\nWHERE expires_at > NOW();\n\n-- DB size:\nSELECT pg_size_pretty(pg_database_size('iip_db'));`)+
          h2('Connection String (for manual testing)')+
          cb('psql -h 127.0.0.1 -U iip_user -d iip_db\n# password: (see .env file on server — never stored in documentation)');
        }
      },

      'ops-rhel9':{
        crumbs:['IIP','Operations','RHEL9 + Apache Setup'], title:'RHEL9 + Apache HTTPS Setup',
        adminOnly: true,
        content(){
          return h1('RHEL9 + Apache HTTPS Setup')+meta('March 20, 2026','v1.0.1')+
          callout('note','Production host',`${ic('rb-alm-01-d8.de.bosch.com')} — RHEL9, Apache 2.4.62. App URL: ${ic('https://rb-alm-01-d8.de.bosch.com/iip/')}`)+
          h2('Required SSL Files')+
          tbl(['File','Purpose'],[
            [ic('cert_rb-alm-01-d8.de.bosch.com_20250416.pem'),'Server certificate'],
            [ic('rb-alm-01-d8.de.bosch.com_20250416.key'),'Private key'],
            [ic('RB_CA_RSA_combined.pem'),'Bosch CA chain'],
          ])+
          h2('Step 1 — Install Apache')+
          cb('sudo dnf install -y httpd mod_ssl\nsudo systemctl enable httpd')+
          h2('Step 2 — Deploy App Files')+
          cb('mkdir -p /var/www/html/iip\ncd /tmp && unzip iip.zip\ncp -r iip/* /var/www/html/iip/\nchown -R apache:apache /var/www/html/iip\nchmod -R 755 /var/www/html/iip')+
          h2('Step 3 — Key File Permissions')+
          cb('chown root:apache /etc/ssl/certs/rb-alm-01-d8.de.bosch.com_20250416.key\nchmod 640 /etc/ssl/certs/rb-alm-01-d8.de.bosch.com_20250416.key')+
          h2('Step 4 — Disable Default ssl.conf')+
          p('The default '+ic('ssl.conf')+' references a non-existent placeholder cert and hijacks port 443:')+
          cb('mv /etc/httpd/conf.d/ssl.conf /etc/httpd/conf.d/ssl.conf.bak')+
          callout('warning','Move the SSL global directives','The '+ic('Listen 443 https')+', SSLSessionCache, and related directives that lived in ssl.conf must be declared at the top of your vhost config — see Step 5.')+
          h2('Step 5 — Vhost Config')+
          cb(`# /etc/httpd/conf.d/rb-alm-01-d8.conf\nListen 443 https\nSSLPassPhraseDialog exec:/usr/libexec/httpd-ssl-pass-dialog\nSSLSessionCache         shmcb:/run/httpd/sslcache(512000)\nSSLSessionCacheTimeout  300\nSSLRandomSeed startup file:/dev/urandom  256\nSSLRandomSeed connect builtin\nSSLCryptoDevice builtin\n\n<VirtualHost *:80>\n  ServerName rb-alm-01-d8.de.bosch.com\n  RewriteEngine On\n  RewriteRule ^(.*)$ https://%{HTTP_HOST}$1 [R=301,L]\n</VirtualHost>\n\n<VirtualHost *:443>\n  ServerName rb-alm-01-d8.de.bosch.com\n  DocumentRoot /var/www/html\n  SSLEngine on\n  SSLCertificateFile      /etc/ssl/certs/cert_rb-alm-01-d8.de.bosch.com_20250416.pem\n  SSLCertificateKeyFile   /etc/ssl/certs/rb-alm-01-d8.de.bosch.com_20250416.key\n  SSLCertificateChainFile /etc/ssl/certs/RB_CA_RSA_combined.pem\n  SSLProtocol             all -SSLv3 -TLSv1 -TLSv1.1\n  SSLCipherSuite          ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384\n  SSLHonorCipherOrder     on\n\n  # Proxy /iip/api/ to FastAPI\n  # Requires: setsebool -P httpd_can_network_connect on\n  ProxyPreserveHost On\n  ProxyPass        /iip/api/ http://127.0.0.1:3001/api/\n  ProxyPassReverse /iip/api/ http://127.0.0.1:3001/api/\n\n  <Directory /var/www/html/iip>\n    Options -Indexes +FollowSymLinks\n    AllowOverride All\n    Require all granted\n  </Directory>\n\n  Header always set X-Content-Type-Options "nosniff"\n  Header always set X-Frame-Options "SAMEORIGIN"\n  Header always set Strict-Transport-Security "max-age=31536000; includeSubDomains"\n\n  ErrorLog  /var/log/httpd/rb-alm-01-d8_error.log\n  CustomLog /var/log/httpd/rb-alm-01-d8_access.log combined\n</VirtualHost>`)+
          h2('Step 6 — Firewall and SELinux')+
          cb('firewall-cmd --permanent --add-service=http\nfirewall-cmd --permanent --add-service=https\nfirewall-cmd --reload\n\n# Required for Apache → FastAPI proxy:\nsetsebool -P httpd_can_network_connect on\nrestorecon -Rv /var/www/html/iip')+
          h2('Step 7 — Start and Verify')+
          cb('httpd -t                    # must return: Syntax OK\nsystemctl restart httpd\nss -tlnp | grep 443\ncurl -k https://rb-alm-01-d8.de.bosch.com/iip/')+
          h2('Known Pitfalls')+
          tbl(['Symptom','Cause','Fix'],[
            [ic('httpd -t')+': localhost.crt not found','Default ssl.conf has non-existent placeholder cert',ic('mv ssl.conf ssl.conf.bak')],
            ['Port 443 not listening',ic('Listen 443 https')+' was inside disabled ssl.conf','Add SSL globals to top of your vhost file'],
            ['503 on /iip/api/ routes','SELinux blocks Apache-to-FastAPI proxy',ic('setsebool -P httpd_can_network_connect on')],
          ]);
        }
      },

      'ops-pm2':{
        crumbs:['IIP','Operations','systemd Service'], title:'systemd Service (iip-fastapi)',
        adminOnly: true,
        content(){
          return h1('systemd Service — iip-fastapi')+meta('2026-05-12','v1.0.0')+
          p('The FastAPI backend runs as a systemd service named '+ic('iip-fastapi')+'. systemd keeps it alive, auto-restarts on crash, and starts it automatically on server reboot.')+
          h2('Daily Operations')+
          tbl(['Task','Command'],[
            ['Check status',ic('sudo systemctl status iip-fastapi')],
            ['Restart API',ic('sudo systemctl restart iip-fastapi')],
            ['Stop API',ic('sudo systemctl stop iip-fastapi')],
            ['Start API',ic('sudo systemctl start iip-fastapi')],
            ['View live logs',ic('sudo journalctl -u iip-fastapi -f')],
            ['View last 50 log lines',ic('sudo journalctl -u iip-fastapi -n 50')],
            ['Enable on boot',ic('sudo systemctl enable iip-fastapi')],
          ])+
          h2('.env File')+
          cb('# /var/www/html/iip/backend/.env\nDB_HOST=localhost\nDB_PORT=5432\nDB_NAME=iip_db\nDB_USER=iip_user\nDB_PASSWORD=<set-on-server-only>\nAPI_PORT=3001\nCORS_ORIGIN=https://rb-alm-01-d8.de.bosch.com\nIIP_ADMIN_TOKEN=<generated-on-first-start>')+
          h2('Virtual Environment')+
          p('The FastAPI backend uses a Python virtual environment at '+ic('backend/.venv/')+'. Dependencies are installed from '+ic('requirements.txt')+'.')+
          cb('# Install / reinstall dependencies:\ncd /var/www/html/iip/backend\npython3 -m venv .venv\nsource .venv/bin/activate\npip install -r requirements.txt')+
          callout('warning','Keep .env on the server only','.env contains the database password. Do not commit or include it in a deployment zip.');
        }
      },

      'ops-security':{
        crumbs:['IIP','Operations','Security Model'], title:'Security Model',
        adminOnly: true,
        content(){
          return h1('Security Model')+meta('March 20, 2026','v1.0.2')+
          h2('Network')+
          tbl(['Control','Detail'],[
            ['TLS','TLS 1.2+ enforced; TLS 1.0 and 1.1 disabled in Apache vhost'],
            ['Cipher suite','ECDHE-ECDSA-AES256-GCM-SHA384, ECDHE-RSA-AES256-GCM-SHA384'],
            ['Port exposure','Port 443 only — FastAPI/Uvicorn (3001) and PostgreSQL (5432) are localhost-bound'],
            ['Certificate','Bosch-signed; chain: '+ic('RB_CA_RSA_combined.pem')],
            ['CORS','Restricted to production origin '+ic('https://rb-alm-01-d8.de.bosch.com')+' (v1.0.2)'],
          ])+
          h2('API Security (v1.0.2)')+
          tbl(['Control','Detail'],[
            ['Write authentication',ic('X-IIP-Admin-Token')+' header required for all POST/DELETE requests'],
            ['Key allowlist','Only known '+ic('IIPStore.KEYS')+' are accepted; unknown keys rejected with HTTP 400'],
            ['Rate limiting','120 reads/min, 30 writes/min per IP — in-memory rate limiter'],
            ['Payload limit','10 MB max (reduced from 50 MB)'],
            ['Security headers',ic('X-Content-Type-Options: nosniff')+', '+ic('X-Frame-Options: DENY')+', '+ic('Cache-Control: no-store')+' on all API responses'],
            ['Error handling','No stack traces exposed in production; structured JSON error responses'],
          ])+
          h2('Application')+
          tbl(['Control','Detail'],[
            ['Admin auth','Password in localStorage (no default — must be set on first access). Session in sessionStorage (tab-scoped).'],
            ['Admin token','API write token stored in localStorage and passed via '+ic('IIPStore.setAdminToken()')+' on login'],
            ['Data read access','All intranet users share read access to case data (GET requests are unauthenticated)'],
            ['Documentation gating','Operations and sensitive admin doc pages require admin login (v1.0.2)'],
            ['Directory listing',ic('Options -Indexes')+' blocks Apache directory listing'],
            ['Security headers','X-Content-Type-Options, X-Frame-Options, HSTS set in Apache vhost'],
          ])+
          h2('Credential Storage Summary')+
          tbl(['Credential','Where Stored'],[
            ['DB password',ic('.env')+' file on server only — never in source, docs, or browser'],
            ['API admin token',ic('.env')+' on server ('+ic('IIP_ADMIN_TOKEN')+') + '+ic('localStorage["ibm_admin_token_v1"]')+' on admin browsers'],
            ['Admin password',ic('localStorage["ibm_admin_pwd_v1"]')+' on each client browser (no default)'],
            ['Admin session',ic('sessionStorage["ibm_admin_session_v1"]')+' — cleared on tab close'],
          ]);
        }
      },

      'ops-backup':{
        crumbs:['IIP','Operations','Backup and Restore'], title:'Backup and Restore',
        adminOnly: true,
        content(){
          return h1('Backup and Restore')+meta('March 20, 2026','v1.0.1')+
          h2('What Needs Backing Up')+
          tbl(['Data','Lives In','Backup Method'],[
            ['Case data, overrides, tracker persist, tracker comments',ic('PostgreSQL iip_kv'),'pg_dump or Admin Portal download'],
            ['Team config (DynamicConfig)',ic('localStorage ibm_team_config_v1_cache'),'Admin Portal download'],
            ['Admin password',ic('localStorage ibm_admin_pwd_v1'),'Admin Portal download'],
            ['Weekly tracker years',ic('localStorage ibm_wtracker_YYYY'),'Admin Portal export'],
            ['RFE data and metadata',ic('localStorage ibm_rfe_tracking_v1/_metadata_v1'),'Admin Portal download'],
            ['Investigate archive',ic('localStorage ibm_investigate_archive_v1'),'Admin Portal export'],
          ])+
          h2('PostgreSQL Backup')+
          cb('sudo -u postgres pg_dump iip_db > /backup/iip_db_$(date +%Y%m%d).sql')+
          h2('PostgreSQL Restore')+
          cb('sudo systemctl stop iip-fastapi\nsudo -u postgres psql iip_db < /backup/iip_db_20260320.sql\nsudo systemctl start iip-fastapi')+
          h2('Admin Portal Backup')+
          p('Admin Portal → Data Management → Download Backup. This JSON file includes all '+ic('iip_kv')+' PostgreSQL keys plus key localStorage entries from the current machine.')+
          callout('tip','Regular backups','Schedule a daily pg_dump cron to protect against server data loss. The Admin Portal download is a complementary application-level snapshot but does not replace a full database backup.');
        }
      },

      /* ── REFERENCE ────────────────────────────────────── */
      'ref-storage':{
        crumbs:['IIP','Reference','Storage — What Lives Where'], title:'Storage — What Lives Where',
        content(){
          return h1('Storage — What Lives Where')+meta('March 23, 2026','v1.0.3')+
          p('IIP uses a two-layer storage system. PostgreSQL is the shared source of truth — '+strong('every user always sees the same data')+'because localStorage is hydrated from PostgreSQL on every page load via '+ic('IIPStore.hydrateFromDB()')+'.')+
          callout('tip','v2.0 — All shared keys in DB','As of v2.0, the localStorage interceptor ensures every write from any dashboard automatically propagates to PostgreSQL. New browsers always boot with full data.')+
          h2('PostgreSQL — iip_kv (shared across all users, ~25+ keys)')+
          tbl(['Key','Contains','Updated When'],[
            [ic('ibm_cases_raw_v1'),'All IBM case rows — active team dataset','Every CSV / XLSX upload'],
            [ic('ibm_cases_overrides_v1'),'Admin field overrides keyed by case number','Admin override save'],
            [ic('ibm_reopened_cases_v1'),'Reopened case entries','Reopen workflow'],
            [ic('ibm_tracker_persist_v1'),'Performance tags, owner overrides, reassign log, case detail logs','Any tracker/admin change'],
            [ic('ibm_team_config_v1'),'Team configuration (SLA targets, account IDs, aliases)','Admin config save'],
            [ic('ibm_wtracker_comments_v1'),'Weekly Tracker comment map: case number → comment string','Comment saved in Tracker'],
            [ic('ibm_wtracker_history'),'Full audit trail of all comment and status changes','Every Tracker edit'],
            [ic('ibm_wtracker_linkmap_v1'),'Paste-captured hyperlink map per case in Tracker','Link pasted in Tracker'],
            [ic('ibm_wtracker_YYYY')+'  (e.g. '+ic('ibm_wtracker_2026')+')','Weekly Tracker rows for each calendar year','Any Tracker row change'],
            [ic('ibm_rfe_tracking_v1'),'RFE CSV rows imported from IBM','RFE import / Admin Portal'],
            [ic('ibm_rfe_tracking_metadata_v1'),'Per-RFE metadata: notes, tags, target release','RFE row edit'],
            [ic('ibm_rfe_tracking_last_update'),'Timestamp of last RFE import','RFE import'],
            [ic('ibm_perf_comments_v1'),'Performance case Wednesday update comments','Performance detail save'],
            [ic('ibm_investigate_archive_v1'),'All-time permanent case archive keyed by case number','Every Excel upload'],
            [ic('ibm_import_log_v1'),'Import fingerprint and metadata log (last 50)','Every import'],
            [ic('admin-perf-cases'),'List of case numbers tagged as Performance cases','Admin Portal tagging'],
            [ic('admin-non-perf-cases'),'Case numbers explicitly removed from Performance tag','Admin Portal tagging'],
            [ic('admin-perf-meta'),'Performance case metadata: WI number, instance, category','Admin/Performance save'],
            [ic('admin-cfg')+' / '+ic('admin-members')+' / '+ic('admin-emails'),'Team config & member data from app-data.js upload','Admin Portal upload'],
            [ic('admin-alm')+' / '+ic('admin-customers')+' / '+ic('admin-ibm-dir'),'ALM responsible table, customer contacts, IBM directory','Admin Portal upload'],
            [ic('admin-change-history'),'Audit trail of all admin actions','Any admin action'],
            [ic('ibm_admin_pwd_v1'),'Admin password (hashed)','Admin password change'],
          ])+
          h2('Browser localStorage (device-local — UI preferences only)')+
          callout('info','Only non-shared UI state is local','As of v2.0, all data is synced to DB. localStorage is only used for per-user UI preferences that should NOT be shared.')+
          tbl(['Key','Contains','Notes'],[
            [ic('ibm_team_config_v1_cache'),'DynamicConfig cache — fast local read','Refreshed from DB on load'],
            [ic('iip_sidebar_collapsed'),'Sidebar expand/collapse state','Per-user UI preference'],
            [ic('iip_onb_state_v1'),'Onboarding / guided tour completion state','Per-user preference'],
            [ic('iip_proficiency_v1'),'User proficiency level tracking','Per-user only'],
            [ic('ibm_admin_session_v1'),'Admin login session flag','Cleared on tab close'],
          ])+
          h2('Browser sessionStorage (tab-scoped, ephemeral)')+
          tbl(['Key','Value','Lifetime'],[
            [ic('ibm_cases_raw_v1'),'Same-tab fast cache — copy of PostgreSQL data','Until tab closes'],
            [ic('ibm_admin_session_v1'),ic('"1"')+' when admin is logged in','Until tab closes'],
            [ic('iip_perf_tagging_open'),'Performance Tagging panel expand state','Until tab closes'],
            [ic('iip_perf_reassign_open'),'Owner Reassignment panel expand state','Until tab closes'],
          ]);
        }
      },

      'ref-iipstore':{
        crumbs:['IIP','Reference','IIPStore API'], title:'IIPStore API',
        content(){
          return h1('IIPStore API')+meta('March 23, 2026','v1.0.3')+
          p(ic('window.IIPStore')+' is the storage adapter defined in '+ic('js/modules/data/storage.js')+'. When the page runs on '+ic('http:')+' or '+ic('https:')+' it routes all reads and writes through the REST API to PostgreSQL. On '+ic('file://')+' it falls back to localStorage. The public API is identical in both modes.')+
          h2('Mode Detection')+
          cb(`// Open browser console (F12) and run:\nIIPStore.mode           // 'server' in production (https)\nIIPStore.isServerMode() // true in production`)+
          h2('KEYS Constant')+
          cb(`IIPStore.KEYS = {\n  CASES_RAW:        'ibm_cases_raw_v1',\n  CASES_OVERRIDES:  'ibm_cases_overrides_v1',\n  REOPENED_CASES:   'ibm_reopened_cases_v1',\n  TRACKER_PERSIST:  'ibm_tracker_persist_v1',\n  TEAM_CONFIG:      'ibm_team_config_v1',\n  TRACKER_COMMENTS: 'ibm_wtracker_comments_v1',\n  IMPORT_LOG:       'ibm_import_log_v1',\n  RFE_DATA:         'ibm_rfe_tracking_v1',         // v2.0\n  RFE_META:         'ibm_rfe_tracking_metadata_v1', // v2.0\n  INVESTIGATE:      'ibm_investigate_archive_v1',   // v2.0\n  PERF_COMMENTS:    'ibm_perf_comments_v1',          // v2.0\n}`)+
          h2('Full Method Reference')+
          tbl(['Method','Returns','Notes'],[
            [ic('IIPStore.set(key, value)'),'Promise<boolean>','Writes to localStorage immediately, then async to DB. Never blocks UI.'],
            [ic('IIPStore.get(key)'),'Promise<any|null>','Reads localStorage (hydrated from DB on boot). Falls back to DB fetch if empty.'],
            [ic('IIPStore.getSync(key)'),'any|null','Synchronous localStorage read only. Use where async is impossible.'],
            [ic('IIPStore.remove(key)'),'Promise<void>','Removes from localStorage and async-deletes from DB.'],
            [ic('IIPStore.hydrateFromDB()'),'Promise<void>','v2.0 — Pulls all shared keys from DB into localStorage. Called once at boot.'],
            [ic('IIPStore.isShared(key)'),'boolean','v2.0 — Returns true if key is synced to DB (shared across users).'],
            [ic('IIPStore.getCases()'),'Promise<Array|null>','Shorthand: get(CASES_RAW). Returns array or null.'],
            [ic('IIPStore.setCases(rows)'),'Promise<boolean>','Shorthand: set(CASES_RAW, rows)'],
            [ic('IIPStore.getOverrides()'),'Promise<Object>','Shorthand: get(CASES_OVERRIDES). Returns {} if absent.'],
            [ic('IIPStore.setOverrides(ov)'),'Promise<boolean>','Shorthand: set(CASES_OVERRIDES, ov)'],
            [ic('IIPStore.getReopened()'),'Promise<Array>','Shorthand: get(REOPENED_CASES). Returns [] if absent.'],
            [ic('IIPStore.setReopened(arr)'),'Promise<boolean>','Shorthand: set(REOPENED_CASES, arr)'],
          ])+
          h2('Error Handling')+
          p('All async methods catch network errors. On failure they log a '+ic('[IIPStore]')+' warning to the console and fall back to localStorage for reads. The app stays usable from the sessionStorage cache if the API is temporarily unreachable.');
        }
      },

      'ref-rest-api':{
        crumbs:['IIP','Reference','REST API Endpoints'], title:'REST API Endpoints',
        content(){
          return h1('REST API Endpoints')+meta('2026-05-12','v1.0.0')+
          `<div style="display:flex;gap:7px;margin-bottom:16px;flex-wrap:wrap">`+badge('FastAPI 0.115.5')+' '+badge('Python + asyncpg + PostgreSQL','#198038')+`</div>`+
          p('FastAPI server defined in '+ic('backend/main.py')+', bound to '+ic('127.0.0.1:3001')+'. Apache proxies all '+ic('/iip/api/*')+' requests from port 443.')+
          callout('info','Auth','Protected endpoints require the '+ic('X-IIP-Admin-Token')+' header (value = active session token from POST /api/auth). Both '+ic('/api/*')+' and '+ic('/iip/api/*')+' path prefixes work — Apache registers both.')+
          h2('Base Health & Events')+
          tbl(['Method','Endpoint','Auth','Description'],[
            ['GET',ic('/api/health'),'None','DB check — returns version, env, db_latency_ms, cases_count, sse_clients'],
            ['GET',ic('/api/events'),'None','Server-Sent Events stream for real-time data-updated push'],
          ])+
          h2('Cases')+
          tbl(['Method','Endpoint','Auth','Description'],[
            ['GET',ic('/api/cases'),'None','Paginated case list — query params: owner, status, product, search, limit, offset'],
            ['GET',ic('/api/cases/distinct-products'),'None','All unique product values in the cases table'],
            ['GET',ic('/api/cases/performance-summary'),'None','All perf-tagged cases with work items and availability'],
            ['GET',ic('/api/cases/archive'),'None','All-time case archive enriched with wednesday comments'],
            ['GET',ic('/api/cases/nonperf-summary'),'None','Non-performance team cases for a customer prefix'],
            ['GET',ic('/api/cases/{case_number}'),'None','Full case detail including weekly history'],
            ['PATCH',ic('/api/cases/{case_number}/performance-tag'),'Session Token','Tag perf/non-perf + work item in one transaction'],
            ['PATCH',ic('/api/cases/{case_number}/owner'),'Session Token','Reassign case owner (writes audit log)'],
            ['PATCH',ic('/api/cases/{case_number}/availability'),'Session Token','Set performance case availability'],
            ['GET/PATCH',ic('/api/cases/{case_number}/wednesday-comments'),'None / Session Token','Read or upsert weekly wednesday comment'],
            ['GET/PATCH',ic('/api/cases/{case_number}/slot-days'),'None / Session Token','Read or upsert slot day overrides'],
          ])+
          h2('Uploads')+
          tbl(['Method','Endpoint','Auth','Description'],[
            ['POST',ic('/api/upload/cases'),'Session Token','Upload IBM Support Case listing CSV; triggers SSE broadcast'],
            ['GET',ic('/api/uploads'),'None','List all file uploads with status and metadata'],
            ['GET',ic('/api/uploads/{id}'),'None','Single upload status'],
            ['GET',ic('/api/uploads/fingerprint-check'),'None','Check if case fingerprint already uploaded (dedup)'],
            ['PATCH',ic('/api/uploads/{id}/fingerprint'),'Session Token','Save case fingerprint to upload record'],
          ])+
          h2('Weekly Tracker')+
          tbl(['Method','Endpoint','Auth','Description'],[
            ['GET',ic('/api/weekly-tracker'),'None','All weekly closed cases grouped by year/week'],
            ['GET',ic('/api/weekly/{year}'),'None','All week summaries for a year'],
            ['GET',ic('/api/weekly/{year}/{week}'),'None','Cases for a specific week (CW01–CW53)'],
            ['PATCH',ic('/api/weekly/{year}/{week}/{case}'),'None','Sync comment + category; run duplicate detection'],
            ['POST',ic('/api/weekly/{year}/{week}'),'Session Token','Add a case to a tracker week'],
            ['DELETE',ic('/api/weekly/{year}/{week}/{case}'),'Session Token','Remove a case from a tracker week'],
            ['GET/POST',ic('/api/wt-categories'),'None / Session Token','Get or save weekly tracker categories'],
            ['GET/POST',ic('/api/wt-history'),'None','Weekly tracker case change history'],
            ['DELETE',ic('/api/wt-history/{id}'),'Session Token','Delete a history entry'],
            ['GET',ic('/api/wt-comments'),'None','All tracker comments (case→comment map)'],
          ])+
          h2('Grayout & Reopened')+
          tbl(['Method','Endpoint','Auth','Description'],[
            ['POST',ic('/api/grayout-bulk'),'None','Bulk-fetch grayout states for (case, week, year) combos'],
            ['GET',ic('/api/grayout/{case}/{week}/{year}'),'None','Single grayout state'],
            ['GET',ic('/api/reopened'),'None','All reopened cases grouped by case'],
            ['POST',ic('/api/reopened/sync'),'None','Sync localStorage-detected cross-week reopened cases'],
          ])+
          h2('RFE / Ideas')+
          tbl(['Method','Endpoint','Auth','Description'],[
            ['GET',ic('/api/ideas'),'None','List IBM Ideas from ibm_ideas table'],
            ['GET',ic('/api/ideas/{idea_reference}'),'None','Idea detail with linked cases'],
            ['GET',ic('/api/rfe-data'),'None','RFE data from ibm_ideas formatted for frontend'],
            ['GET',ic('/api/user-data/rfe-meta'),'None','Load RFE annotations (notes, tags, target release)'],
            ['PUT',ic('/api/user-data/rfe-meta'),'None','Save RFE annotations'],
          ])+
          h2('Performance Tracker Meta')+
          tbl(['Method','Endpoint','Auth','Description'],[
            ['GET',ic('/api/user-data/tracker-meta'),'None','Performance tracker meta — built live from cases table'],
            ['PUT',ic('/api/user-data/tracker-meta'),'None','Save UI-only tracker state (history, logs, overrides)'],
          ])+
          h2('Team & Contacts')+
          tbl(['Method','Endpoint','Auth','Description'],[
            ['GET',ic('/api/team'),'None','Team members list'],
            ['GET',ic('/api/alm-lines'),'None','ALM lines with contact details'],
            ['GET',ic('/api/ibm-contacts'),'None','IBM directory contacts'],
            ['GET',ic('/api/escalation-contacts'),'None','Escalation contact groups'],
            ['GET',ic('/api/elm-upgrades'),'None','ELM upgrade history (public read)'],
            ['GET',ic('/api/data-version'),'None','Latest successful upload timestamp (Unix ms)'],
          ])+
          h2('Admin CRUD')+
          tbl(['Method','Endpoint','Auth','Description'],[
            ['GET',ic('/api/admin/bootstrap'),'Session Token','Full admin portal bootstrap data'],
            ['GET/POST/PUT/DELETE',ic('/api/admin/team-members'),'Session Token','Team member CRUD'],
            ['GET/POST/PUT/DELETE',ic('/api/admin/escalation-contacts'),'Session Token','Escalation contact CRUD'],
            ['GET/POST/PUT/DELETE',ic('/api/admin/ibm-contacts'),'Session Token','IBM contact CRUD'],
            ['GET/POST/PUT/DELETE',ic('/api/admin/alm-lines'),'Session Token','ALM line CRUD'],
            ['GET/POST/PUT/DELETE',ic('/api/admin/elm-upgrades'),'Session Token','ELM upgrade CRUD'],
            ['GET/POST',ic('/api/admin/audit-log'),'Session Token','Read or write audit log'],
            ['GET/PUT',ic('/api/admin/app-settings'),'Session Token','Read or write app settings'],
            ['GET',ic('/api/admin/dashboard-stats'),'None','Admin overview — all stats in one call'],
            ['GET',ic('/api/admin/reassign-log'),'None','Reassignment history from audit_log'],
          ])+
          h2('Config & Store')+
          tbl(['Method','Endpoint','Auth','Description'],[
            ['GET',ic('/api/config')+' / '+ic('/api/v2/config'),'None','Team config from app_settings + team_members'],
            ['GET',ic('/api/team-config'),'None','Full team config object'],
            ['GET',ic('/api/store'),'None','Cases count from DB'],
            ['GET',ic('/api/store/cases-count'),'None','Case count only'],
            ['GET/PUT',ic('/api/customer-products'),'None / Session Token','Customer product list'],
          ])+
          h2('Saved Searches')+
          tbl(['Method','Endpoint','Auth','Description'],[
            ['GET',ic('/api/saved-searches'),'None','List saved searches (filter by dashboard query param)'],
            ['POST',ic('/api/saved-searches'),'None','Create saved search'],
            ['DELETE',ic('/api/saved-searches/{id}'),'None','Delete saved search'],
            ['POST',ic('/api/saved-searches/{id}/use'),'None','Record usage — increments use_count'],
          ])+
          h2('Auth')+
          tbl(['Method','Endpoint','Auth','Description'],[
            ['GET',ic('/api/auth/status'),'None','Validate session token'],
            ['POST',ic('/api/auth'),'None','Login — returns session token'],
            ['POST',ic('/api/auth/logout'),'Session Token','Revoke session'],
            ['POST',ic('/api/auth/set-password'),'Session Token','Set or change admin password'],
            ['GET/POST',ic('/api/auth/security-questions'),'None / Session Token','Read questions or save Q&A'],
            ['POST',ic('/api/auth/reset-via-security'),'None','Verify answers + reset password'],
          ])+
          h2('Examples')+
          cb('# Health check:\ncurl -k https://rb-alm-01-d8.de.bosch.com/iip/api/health\n\n# Read a value:\ncurl -k https://rb-alm-01-d8.de.bosch.com/iip/api/store/ibm_cases_raw_v1\n\n# Write (requires token):\ncurl -k -X POST https://rb-alm-01-d8.de.bosch.com/iip/api/store/ibm_import_log_v1 \\\n  -H \"Content-Type: application/json\" \\\n  -H "X-IIP-Admin-Token: <your-token>" \\\n  -d \'{"value":"test"}\'\n\n# Login:\ncurl -k -X POST https://rb-alm-01-d8.de.bosch.com/iip/api/auth \\\n  -H "Content-Type: application/json" \\\n  -d \'{"password":"<admin-password>"}\''+
          `\n`)+
          callout('note','Internal Only','Port 3001 is bound to 127.0.0.1. All external API calls go through Apache on port 443 via ProxyPass.');
        }
      },

      'ref-auth-api':{
        crumbs:['IIP','Reference','Auth API'], title:'Auth API',
        content(){
          return h1('Auth API')+meta('2026-05-12','v1.0.0')+
          p('Authentication is handled by '+ic('backend/routers/auth.py')+'. Passwords are hashed with bcrypt (passlib). Session tokens are generated server-side and stored in memory. Password reset uses security questions.')+
          h2('Login')+
          cb('POST /api/auth\nBody: {"password": "<admin-password>"}\nResponse: {"ok": true, "token": "<session-token>"}')+
          h2('Logout')+
          cb('POST /api/auth/logout\nHeader: X-IIP-Admin-Token: <session-token>\nResponse: {"ok": true}')+
          h2('Set / Change Password')+
          cb('POST /api/auth/set-password\nHeader: X-IIP-Admin-Token: <session-token>\nBody: {"password": "<new-password>"}\nResponse: {"ok": true}')+
          h2('Security Questions Setup')+
          cb('# Save security questions (admin only):\nPOST /api/auth/security-questions\nHeader: X-IIP-Admin-Token: <session-token>\nBody: {"q1": "Question 1", "a1": "answer1", "q2": "Question 2", "a2": "answer2"}\nResponse: {"ok": true}\n\n# Get questions (public, answers never returned):\nGET /api/auth/security-questions\nResponse: {"ok": true, "configured": true, "questions": {"q1": "...", "q2": "..."}}')+
          h2('Reset Password via Security Questions')+
          cb('POST /api/auth/reset-via-security\nBody: {"q1": "Question 1", "a1": "answer1", "q2": "Question 2", "a2": "answer2", "newPassword": "<new-password>"}\nResponse: {"ok": true, "token": "<new-session-token>"}')+
          h2('Security Notes')+
          ul([
            'Session tokens are stored in server memory — they are invalidated on service restart.',
            'Passwords are hashed with bcrypt (passlib) before storage in PostgreSQL.',
            'Admin token ('+ic('X-IIP-Admin-Token')+') is used for both session tokens and the static API write token.',
            'There is no default password — it must be set via Admin Portal on first access.',
          ]);
        }
      },

      'ref-csv':{
        crumbs:['IIP','Reference','CSV Column Reference'], title:'CSV Column Reference',
        content(){
          return h1('CSV Column Reference')+meta('March 20, 2026','v1.0.1')+
          p('Column names from IBM support portal exports. Names are case-sensitive.')+
          tbl(['Column','Used For'],[
            ['Case Number','Primary key for all merge and lookup operations'],
            ['Title','Displayed in all tables and modals'],
            ['Status','Status badge, filter groups, closed detection'],
            ['Owner','Name alias normalisation, owner filter, workload charts'],
            ['Product','Product filter, breakdown chart, auto-detection via APP_KEYWORDS'],
            ['Component','Secondary classification, shown in detail modal'],
            ['Severity','Case detail modal display'],
            ['Customer number','Customer Cases tab filter; account routing'],
            ['Created','Age calculation, Created Cases chart'],
            ['Updated','Stale detection (idle days), trend line'],
            ['Closed Date','Closure rate, Weekly Tracker enrichment, trend charts'],
            ['Resolution','Case detail and Investigate display'],
          ]);
        }
      },

      'ref-metrics':{
        crumbs:['IIP','Reference','Metrics Definitions'], title:'Metrics Definitions',
        content(){
          return h1('Metrics Definitions')+meta('March 20, 2026','v1.0.1')+
          tbl(['Metric','Definition'],[
            ['Stale Case','Open case where Today − Updated ≥ 5 calendar days'],
            ['Age','Today − Created date, in calendar days'],
            ['Resolution Time','Closed Date − Created date (calendar days). Falls back to Updated if Closed Date is absent.'],
            ['Avg Resolution Time','Arithmetic mean of resolution times for all closed cases in the dataset'],
            ['Closure Rate','Closed cases ÷ Created cases in same window × 100 %'],
            ['SLA Adherence','% of closed cases resolved within '+ic('slaClosureDays')+' days (default 30, Admin-configurable)'],
            ['Health Score','100 − (StaleRatio×40 + AwaitRatio×30 + LoadDeviation×30). Per-member. Range 0–100.'],
            ['Load Deviation','abs(member open count − team mean open count) ÷ team mean open count'],
            ['Awaiting Feedback','Cases with status "Awaiting your feedback"'],
          ]);
        }
      },

      'ref-shortcuts':{
        crumbs:['IIP','Tools & Features','Keyboard Shortcuts'], title:'Keyboard Shortcuts',
        content(){
          return h1('Keyboard Shortcuts')+meta('March 23, 2026','v1.0.3')+
          p('All shortcuts are global (active from any tab) unless noted. Shortcuts are disabled while typing in an input field.')+
          h2('Navigation')+
          tbl(['Shortcut','Action'],[
            [ic('1')+'–'+ic('9'),'Jump to dashboard: 1=Overview, 2=Team Cases, 3=Members, 4=Customer Cases, 5=Closed, 6=Performance, 7=Weekly Tracker, 8=Created Cases, 9=Investigate'],
            [ic('← Arrow'),'Previous dashboard tab (cycles left)'],
            [ic('→ Arrow'),'Next dashboard tab (cycles right)'],
          ])+
          h2('Tools')+
          tbl(['Shortcut','Action'],[
            [ic('Ctrl+K'),'Open Command Palette — search commands, navigate to any tab, run actions'],
            [ic('/'),'Focus the Global Search bar — search cases by number, title, owner, status, or product'],
            [ic('?'),'Toggle the Keyboard Shortcuts help panel'],
            [ic('Ctrl+L'),'Start the 21-step Guided Tour'],
            [ic('A'),'Open the AI Assistant panel'],
          ])+
          h2('General')+
          tbl(['Shortcut','Action'],[
            [ic('Esc'),'Close modal, overlay, command palette, or dismiss focused search'],
            [ic('Enter'),'Confirm the focused action (modal button, search result, palette item)'],
          ]);
        }
      },

      /* ── TROUBLESHOOTING ──────────────────────────────── */
      'ts-faq':{
        crumbs:['IIP','Troubleshooting','FAQs'], title:'Frequently Asked Questions',
        content(){
          const faqs=[
            ['Where is my case data stored?',`All shared data is in PostgreSQL (db ${ic('iip_db')}) across 26 normalized tables — including cases, weekly_closed_cases, rfe_annotations, ibm_ideas, wt_case_history, audit_log, and more. Browser localStorage is a local read cache only, hydrated from PostgreSQL on every page load (v2.0+).`],
            ['Can I use IIP on multiple devices?',`Yes — as of v2.0 all shared data (cases, RFE tracking, Weekly Tracker, Performance, Investigate archive, admin config) is stored in PostgreSQL and hydrated on every page load. Every user on every device sees the same data automatically.`],
            ['What happens if I clear browser cache?',`All shared data (cases, RFE, Weekly Tracker, Performance, Investigate archive) is stored in PostgreSQL and will be automatically re-hydrated from the server on next page load. You only lose personal UI preferences (sidebar state, tour completion, proficiency level).`],
            ['Why did my cases disappear after a new upload?','IIP removes cases not in the uploaded CSV. Always upload the full export — not a date-filtered or account-filtered subset.'],
            ['How do reassignments survive re-uploads?',`Reassignments store an ${ic('_ownerOverride: true')} flag in ${ic('ibm_tracker_persist_v1')} (PostgreSQL). The CSV merge logic reads this flag and preserves the reassigned owner.`],
            ['What happens if the API server goes down?','IIPStore catches errors and falls back to sessionStorage. The app stays readable for the current session. Writes will silently fall back to localStorage. Run '+ic('sudo systemctl restart iip-fastapi')+' to restore.'],
            ['Charts are blank / Chart.js won\'t load.','Check the browser console for CDN errors. Copy Chart.js to '+ic('js/vendor/chart.umd.min.js')+' for offline use — '+ic('loadScript()')+' falls back to the vendor file automatically.'],
            ['Admin Portal won\'t accept my password.',`v1.0.3 fixed a double-encoding bug that caused this. After updating to v1.0.3, existing passwords are auto-migrated on next login. If still failing: check ${ic("localStorage.getItem('ibm_admin_pwd_v1')")} — if it has extra quotes like ${ic('"mypassword"')} you have the old encoding. Fix: ${ic("localStorage.removeItem('ibm_admin_pwd_v1')")} and reload to reset.`],
            ['How do I wipe all data and start fresh?','Admin Portal → Data Management → Clear All Data. For server-side data, use psql: DELETE FROM cases; DELETE FROM weekly_closed_cases; etc. For the browser, clear localStorage via DevTools → Application → Local Storage.'],
          ];
          return h1('Frequently Asked Questions')+
          faqs.map(([q,a])=>`<details style="border:1px solid var(--border-subtle);border-radius:6px;background:var(--bg-layer);margin-bottom:9px;overflow:hidden"><summary style="font-weight:600;font-size:14px;color:var(--text-primary);padding:12px 16px;cursor:pointer;list-style:none;display:flex;justify-content:space-between;align-items:center">${q}<span style="font-size:18px;color:var(--text-tertiary);flex-shrink:0;font-weight:300;line-height:1">+</span></summary><div style="padding:11px 16px 13px;color:var(--text-secondary);font-size:13.5px;line-height:1.7;border-top:1px solid var(--border-subtle)">${a}</div></details>`).join('');
        }
      },

      'ts-issues':{
        crumbs:['IIP','Troubleshooting','Common Issues and Fixes'], title:'Common Issues and Fixes',
        content(){
          return h1('Common Issues and Fixes')+meta('March 23, 2026','v1.0.3')+
          p('Run the full health check first:')+
          cb('sudo systemctl status iip-fastapi\nsystemctl status postgresql | grep Active\ncurl -k https://rb-alm-01-d8.de.bosch.com/iip/api/health')+
          h2('Apache 503 on /iip/api/ Routes')+
          tbl(['',''],[ ['Cause','SELinux blocks Apache from making outbound connections to FastAPI'],['Fix',ic('sudo setsebool -P httpd_can_network_connect on')+' then '+ic('sudo systemctl restart httpd')],['Verify',ic('getsebool httpd_can_network_connect')+' must show '+ic('on')] ])+
          h2('API Error: Ident Authentication Failed')+
          tbl(['',''],[ ['Cause',ic('pg_hba.conf')+' has '+ic('ident')+' instead of '+ic('md5')+' for 127.0.0.1'],['Fix','Edit '+ic('/var/lib/pgsql/data/pg_hba.conf')+': change ident to md5 for the 127.0.0.1 lines, then '+ic('sudo systemctl restart postgresql')],['Verify',ic('psql -h 127.0.0.1 -U iip_user -d iip_db -c "SELECT 1;"')+' should succeed'] ])+
          h2('iip-fastapi Service Shows Failed Status')+
          ul([
            ic('sudo journalctl -u iip-fastapi -n 50')+' — look for missing .env, DB connection error, import errors, or port conflict.',
            ic('ls -la /var/www/html/iip/backend/.env')+' — confirm the file exists.',
            ic('ss -tlnp | grep 3001')+' — confirm the port is free.',
            ic('ls /var/www/html/iip/backend/.venv/bin/python')+' — confirm venv is set up.',
          ])+
          h2('API Unavailable After Reboot')+
          ul([
            ic('sudo systemctl is-enabled iip-fastapi')+' — should show '+ic('enabled')+'. If not: '+ic('sudo systemctl enable iip-fastapi')+'.',
            'Then start it: '+ic('sudo systemctl start iip-fastapi')+'.',
          ])+
          h2('File Upload Fails')+
          ul([
            'Supported formats: '+ic('.csv')+', '+ic('.xlsx')+', '+ic('.xls')+', '+ic('.xlsm')+'.',
            'Files over 32 MB rejected (FastAPI payload limit).',
            'Check DevTools → Network for a failed POST to '+ic('/iip/api/upload/cases')+'.',
          ])+
          h2('Dashboard Renders Blank')+
          ul([
            'Check DevTools Console for JS errors.',
            'Verify data exists: '+ic('curl -k https://rb-alm-01-d8.de.bosch.com/iip/api/cases?limit=5')+'.',
            'Chart.js CDN may have failed — copy to vendor folder as fallback.',
          ])+
          h2('Admin Portal Rejects Password')+
          ul([
            'Password is in localStorage on the current browser under '+ic('ibm_admin_pwd_v1')+'.',
            'Check: '+ic("localStorage.getItem('ibm_admin_pwd_v1')")+' in the browser console.',
            'Reset: '+ic("localStorage.removeItem('ibm_admin_pwd_v1')")+' then reload — first-time setup dialog will appear.',
          ])+
          h2('App Tour Shows Dark / Blurred Screen')+
          ul([
            'This was a bug in v1.0.2 — update to v1.0.3 for the fixed light-only tour.',
            'If still dark after update: hard-refresh with '+ic('Ctrl+Shift+R')+' to clear cached JS.',
            'The tour overlay is intentionally semi-transparent (45%) so you can see the app behind it.',
          ])+
          h2('Console Error: Maximum call stack size exceeded')+
          ul([
            'This was the storage.js infinite recursion bug fixed in v1.0.3.',
            'Symptom: App freezes or crashes immediately on load after storage.js update.',
            'Fix: deploy '+ic('storage.js')+' v2.1 and hard-refresh.',
            'Root cause: interceptor was calling '+ic('IIPStore.set()')+' which called '+ic('localStorage.setItem()')+' which triggered the interceptor again.',
          ])+
          h2('httpd -t: Cannot Open Certificate')+
          ul([
            'Default ssl.conf is still active and references a non-existent placeholder cert.',
            ic('mv /etc/httpd/conf.d/ssl.conf /etc/httpd/conf.d/ssl.conf.bak')+' then restart Apache.',
          ]);
        }
      },

      'ts-limits':{
        crumbs:['IIP','Troubleshooting','Limits and Performance'], title:'Limits and Performance',
        content(){
          return h1('Limits and Performance')+meta('March 20, 2026','v1.0.1')+
          h2('Storage Limits')+
          tbl(['Store','Limit','Notes'],[
            ['PostgreSQL iip_kv','No practical limit','Server disk — typically well under 1 GB'],
            ['Browser localStorage','5–10 MB per origin (browser-dependent)','Affects RFE, Investigate archive, Weekly Tracker, DynamicConfig'],
            ['File upload','32 MB','FastAPI payload limit in '+ic('main.py')],
            ['Import log',ic('ibm_import_log_v1')+' trimmed to 50 entries','Oldest entries removed automatically'],
          ])+
          h2('Render Performance vs Dataset Size')+
          tbl(['Case Count','Render Time','Notes'],[
            ['< 1,000','< 100 ms','Optimal'],
            ['1,000–5,000','100–500 ms','Typical production (~3,716 rows currently)'],
            ['5,000–10,000','0.5–2 s','Use date-range filters before switching to chart tabs'],
            ['> 10,000','2 s+','Filter aggressively; avoid rendering all charts at once'],
          ])+
          h2('Check DB Size')+
          cb(`sudo -u postgres psql -d iip_db -c "SELECT pg_size_pretty(pg_database_size('iip_db'));"\n\n-- Per-table breakdown:\nsudo -u postgres psql -d iip_db -c \\\n  "SELECT relname, pg_size_pretty(pg_total_relation_size(relid)) FROM pg_catalog.pg_statio_user_tables ORDER BY pg_total_relation_size(relid) DESC;"`)
        }
      },

      /* ── NEW: ADMIN ACCESS GUIDE (Admin-Only) ────────── */
      'admin-access-guide':{
        crumbs:['IIP','Administration','Access Guide'], title:'Admin Access Guide',
        adminOnly: true,
        content(){
          return h1('Admin Access Guide')+meta('March 20, 2026','v1.0.2')+
          callout('warning','Confidential','This page contains sensitive infrastructure details. Do not share outside the admin team.')+

          h2('Database Access')+
          h3('Connection Details')+
          tbl(['Item','Value'],[
            ['Host', ic('localhost')+' (server-local only)'],
            ['Port', ic('5432')],
            ['Database', ic('iip_db')],
            ['User', ic('iip_user')],
            ['Auth Method', ic('md5')],
            ['Password', 'Stored in '+ic('/var/www/html/iip/backend/.env')+' on the server. Never in source or documentation.'],
          ])+
          h3('How to Connect')+
          steps([
            'SSH to '+ic('rb-alm-01-d8.de.bosch.com')+' using your Bosch LDAP credentials.',
            'Connect as postgres superuser: '+ic('sudo -u postgres psql -d iip_db'),
            'Or connect as app user: '+ic('psql -h 127.0.0.1 -U iip_user -d iip_db')+' — enter the password from the '+ic('.env')+' file.',
            'Run '+ic('\\dt')+' to list tables. The primary table is '+ic('iip_kv')+'.',
            'Run '+ic('SELECT key, updated_at FROM iip_kv ORDER BY updated_at DESC;')+' to see all stored keys.',
          ])+
          h3('Credential Security Best Practices')+
          ul([
            '<strong>Never hardcode passwords</strong> in source code, documentation, or deployment scripts.',
            'The '+ic('.env')+' file must only exist on the production server at '+ic('/var/www/html/iip/backend/.env')+'.',
            'Rotate the DB password quarterly: update '+ic('.env')+', then '+ic('sudo systemctl restart iip-fastapi')+'.',
            'If using version control, add '+ic('.env')+' to '+ic('.gitignore')+' immediately.',
            'For automated deployments, use environment variables or a secrets manager — never include '+ic('.env')+' in zip files.',
          ])+
          h3('Useful Database Queries')+
          cb('-- Count cases in dataset:\nSELECT jsonb_array_length(value) FROM iip_kv WHERE key=\'ibm_cases_raw_v1\';\n\n-- DB size:\nSELECT pg_size_pretty(pg_database_size(\'iip_db\'));\n\n-- Per-key storage sizes:\nSELECT key, pg_size_pretty(length(value::text)) AS sz\n  FROM iip_kv ORDER BY length(value::text) DESC;\n\n-- Backup:\nsudo -u postgres pg_dump iip_db > /backup/iip_db_$(date +%Y%m%d).sql\n\n-- Restore:\nsudo systemctl stop iip-fastapi\nsudo -u postgres psql iip_db < /backup/iip_db_YYYYMMDD.sql\nsudo systemctl start iip-fastapi')+

          h2('Backend Access')+
          h3('Running the Backend')+
          steps([
            'SSH to the server.',
            'Navigate to '+ic('/var/www/html/iip/backend/')+'.',
            'Ensure '+ic('.env')+' exists with valid DB credentials and '+ic('IIP_ADMIN_TOKEN')+'.',
            'Start: '+ic('sudo systemctl start iip-fastapi')+'.',
            'Verify: '+ic('curl http://127.0.0.1:3001/api/health')+' → should return '+ic('{"status":"ok","db":"connected",...}')+'.',
          ])+
          h3('Required Configuration')+
          tbl(['File','Purpose','Notes'],[
            [ic('.env'), 'Database credentials, API port, admin write token, CORS origin', 'Must be present before starting'],
            [ic('main.py'), 'FastAPI app entry point — routers, CORS, SSE, lifecycle', 'Modify only for global middleware changes'],
            [ic('routers/cases.py'), 'Cases endpoints', 'GET/POST cases, upload-cases, merge-cases'],
            [ic('routers/store.py'), 'KV store endpoints', 'CRUD on iip_kv, bulk operations, public write'],
            [ic('routers/auth.py'), 'Auth endpoints', 'Login, logout, set-password, OTP reset'],
            [ic('requirements.txt'), 'Python dependencies', ic('pip install -r requirements.txt')+' in venv if packages are missing'],
          ])+
          h3('Admin Operations')+
          tbl(['Task','Command'],[
            ['Check API status', ic('sudo systemctl status iip-fastapi')],
            ['Restart API', ic('sudo systemctl restart iip-fastapi')],
            ['View logs (live)', ic('sudo journalctl -u iip-fastapi -f')],
            ['View last 50 log lines', ic('sudo journalctl -u iip-fastapi -n 50')],
            ['Check DB connectivity', ic('curl -k https://rb-alm-01-d8.de.bosch.com/iip/api/health')],
            ['Write test (requires token)', ic('curl -k -X POST https://rb-alm-01-d8.de.bosch.com/iip/api/store/ibm_import_log_v1 -H "Content-Type: application/json" -H "X-IIP-Admin-Token: <your-token>" -d \'{"value":"test"}\'')],
            ['Wipe all data', ic('sudo -u postgres psql -d iip_db -c "DELETE FROM iip_kv;"')],
            ['Backup DB', ic('sudo -u postgres pg_dump iip_db > /backup/iip_db_$(date +%Y%m%d).sql')],
          ])+

          h2('Frontend Access')+
          h3('Running Locally')+
          steps([
            'Copy the '+ic('iip/')+' folder to your machine.',
            'Open '+ic('index.html')+' directly in a browser ('+ic('file://')+' protocol).',
            'In file mode, IIPStore falls back to localStorage — no server needed for viewing.',
            'To test with API: activate the venv and run '+ic('uvicorn main:app --reload')+' locally with a local PostgreSQL instance.',
          ])+
          h3('Deploying Updates')+
          steps([
            'Make changes locally in Windows: '+ic('C:\\Users\\bxe1cob\\Videos\\iip\\')+'.',
            'Run one-command deploy: '+ic('bash sync-and-deploy.sh rbadmin_app1 si0vm14401.de.bosch.com /var/www/html/iip')+'.',
            'If only backend Python code changed: '+ic('sudo systemctl restart iip-fastapi')+'.',
            'If only frontend files changed: no restart needed.',
            'Hard-refresh in browser: '+ic('Ctrl+Shift+R')+'.',
          ])+
          callout('warning','Never Overwrite .env',ic('/var/www/html/iip/backend/.env')+' contains the database password and API admin token. Do not include it in deployable zips. Always keep it only on the server.')+
          h3('Admin-Specific UI Capabilities')+
          ul([
            '<strong>Performance Tagging</strong> — tag cases as performance-related, link CLM work items.',
            '<strong>Owner Reassignment</strong> — bulk reassign cases between owners.',
            '<strong>Team Configuration</strong> — modify team members, aliases, SLA targets.',
            '<strong>Data Management</strong> — clear all data, download/restore backups.',
            '<strong>Change Password</strong> — update the admin login password.',
            '<strong>Documentation — Operations pages</strong> — server stack, deploy, PostgreSQL, systemd, security, backup pages are admin-only.',
          ]);
        }
      },

      /* ── NEW: END-TO-END APPLICATION FLOWCHART ───────── */
      'e2e-flowchart':{
        crumbs:['IIP','Overview','Application Flowchart'], title:'End-to-End Application Flowchart',
        content(){
          return h1('End-to-End Application Flowchart')+meta('March 20, 2026','v1.0.2')+
          p('Visual flow of every major operation in IIP — from user action to database and back.')+

          h2('1. Page Load Flow')+
          cb(
'User opens https://rb-alm-01-d8.de.bosch.com/iip/\n'+
'  │\n'+
'  ├─► Apache :443 (TLS termination)\n'+
'  │     ├─► Serves index.html + static JS/CSS files\n'+
'  │     └─► Returns to browser\n'+
'  │\n'+
'  ├─► Browser: Scripts load in order\n'+
'  │     app-data.js → utils.js → dynamic-config.js → config.js\n'+
'  │     → contacts.js → storage.js → data.js → UI modules\n'+
'  │     → dashboard files → app.js (LAST)\n'+
'  │\n'+
'  ├─► App.init() fires on DOMContentLoaded\n'+
'  │     ├─► DynamicConfig.load() ← localStorage\n'+
'  │     ├─► Admin session check  ← sessionStorage\n'+
'  │     └─► _tryRestoreFromServer()\n'+
'  │           ├─► Check sessionStorage cache (fast path)\n'+
'  │           └─► If empty: IIPStore.getCases()\n'+
'  │                 └─► GET /api/store/ibm_cases_raw_v1\n'+
'  │                       └─► Apache ProxyPass → FastAPI :3001\n'+
'  │                             └─► PostgreSQL SELECT\n'+
'  │                                   └─► Response → Render')+

          h2('2. CSV Upload Flow')+
          cb(
'User drags CSV onto upload zone\n'+
'  │\n'+
'  ├─► Browser: XLSX.js parses file in-memory\n'+
'  │     ├─► Filename date routing:\n'+
'  │     │     Today → Main case store (PostgreSQL)\n'+
'  │     │     Older → Weekly Tracker (localStorage)\n'+
'  │     │\n'+
'  │     ├─► Merge with existing (upsert by Case Number)\n'+
'  │     │     ├─► Preserve _ownerOverride flags\n'+
'  │     │     ├─► Apply name alias normalization\n'+
'  │     │     └─► Fingerprint dedup check\n'+
'  │     │\n'+
'  │     └─► IIPStore.setCases(mergedRows)\n'+
'  │           └─► POST /api/store/ibm_cases_raw_v1\n'+
'  │                 Headers: X-IIP-Admin-Token\n'+
'  │                 └─► Apache → FastAPI → PostgreSQL UPSERT\n'+
'  │\n'+
'  ├─► IIPStore.setOverrides(overrides) → PostgreSQL\n'+
'  ├─► DashInvestigate.archiveCases() → localStorage\n'+
'  └─► App reloads dashboard with new data')+

          h2('3. Admin Authentication Flow')+
          cb(
'User clicks "Admin Portal" in sidebar\n'+
'  │\n'+
'  ├─► admin.js → showLoginModal()\n'+
'  │     ├─► First time? → Setup dialog (set password + API token)\n'+
'  │     └─► Returning? → Login dialog\n'+
'  │           └─► Compare against localStorage[ibm_admin_pwd_v1]\n'+
'  │\n'+
'  ├─► On success:\n'+
'  │     ├─► Data.setAdminMode(true)\n'+
'  │     ├─► IIPStore.setAdminToken(token) — enables API writes\n'+
'  │     ├─► sessionStorage[ibm_admin_session_v1] = "1"\n'+
'  │     └─► App.renderTab("admin")\n'+
'  │\n'+
'  └─► On F5 refresh:\n'+
'        └─► admin.js.init() checks sessionStorage\n'+
'              If "1" → restore admin mode + token')+

          h2('4. REST API Endpoint Map (Key Endpoints)')+
          tbl(['Method','Endpoint','Auth','Purpose'],[
            ['GET',  ic('/api/health'),              'None',          'Health check — version, DB, SSE client count'],
            ['GET',  ic('/api/events'),              'None',          'SSE stream for real-time push'],
            ['POST', ic('/api/upload/cases'),        'Session Token', 'Upload CSV — stores to cases table'],
            ['GET',  ic('/api/cases'),               'None',          'Paginated case list with filters'],
            ['PATCH',ic('/api/cases/{n}/performance-tag'), 'Session Token', 'Tag case as performance + work item'],
            ['PATCH',ic('/api/cases/{n}/owner'),     'Session Token', 'Reassign case owner (audit logged)'],
            ['GET',  ic('/api/weekly-tracker'),      'None',          'All weekly tracker data'],
            ['PATCH',ic('/api/weekly/{y}/{w}/{n}'),  'None',          'Update weekly comment + category'],
            ['GET',  ic('/api/admin/bootstrap'),     'Session Token', 'Full admin portal bootstrap'],
            ['POST', ic('/api/auth'),                'None',          'Login — returns session token'],
            ['POST', ic('/api/auth/reset-via-security'), 'None',      'Reset password via security questions'],
          ])+
          p('See Reference → REST API Endpoints for the full list of 60+ endpoints.')+

          h2('5. Data Storage Map')+
          cb(
'┌─────────────────────────────────────────────────────┐\n'+
'│             PostgreSQL (iip_db — 26 tables)         │\n'+
'│             Shared across all users                 │\n'+
'│                                                     │\n'+
'│  cases (3,716 rows)      ← Active IBM support cases  │\n'+
'│  weekly_closed_cases     ← Weekly tracker entries    │\n'+
'│  case_status_history     ← Upload snapshots (20k)   │\n'+
'│  team_members (36)       ← Team roster              │\n'+
'│  audit_log (1,159)       ← All admin actions        │\n'+
'│  ibm_ideas / rfe_annot.  ← RFE tracking             │\n'+
'│  saved_searches          ← Per-dashboard filters    │\n'+
'│  admin_credentials       ← Bcrypt password hash     │\n'+
'│  admin_sessions          ← Active session tokens    │\n'+
'│  security_questions      ← Password reset Q&A       │\n'+
'│  uploads (10)            ← Import history           │\n'+
'└─────────────────────────────────────────────────────┘\n'+
'\n'+
'┌─────────────────────────────────────────────────────┐\n'+
'│          localStorage (per-browser, device-local)   │\n'+
'│                                                     │\n'+
'│  ibm_team_config_v1_cache ← DynamicConfig           │\n'+
'│  ibm_admin_pwd_v1         ← Admin password           │\n'+
'│  ibm_admin_token_v1       ← API admin token          │\n'+
'│  ibm_rfe_tracking_v1      ← RFE CSV data (cache)    │\n'+
'│  ibm_investigate_archive  ← All-time case archive    │\n'+
'│  ibm_wtracker_YYYY        ← Weekly tracker rows      │\n'+
'└─────────────────────────────────────────────────────┘\n'+
'\n'+
'┌─────────────────────────────────────────────────────┐\n'+
'│       sessionStorage (per-tab, ephemeral)           │\n'+
'│                                                     │\n'+
'│  ibm_cases_raw_v1         ← Fast cache (avoids API) │\n'+
'│  ibm_admin_session_v1     ← Admin logged-in flag    │\n'+
'│  ibm_admin_token_session  ← Token for this session  │\n'+
'└─────────────────────────────────────────────────────┘')+

          h2('6. Network Architecture')+
          cb(
'┌──────────────┐   HTTPS :443   ┌──────────────────┐\n'+
'│   Browser    │ ◄────────────► │  Apache 2.4      │\n'+
'│  (Intranet)  │                │  (TLS, vhost)    │\n'+
'└──────────────┘                └────────┬─────────┘\n'+
'                                         │\n'+
'                     ┌──────────────┬─────┘\n'+
'                     │ Static files │ /iip/api/* (ProxyPass)\n'+
'                     ▼              ▼\n'+
'               /var/www/html/    FastAPI :3001\n'+
'                  iip/           (localhost only)\n'+
'                                    │\n'+
'                                    ▼\n'+
'                              PostgreSQL :5432\n'+
'                              (localhost only)\n'+
'                              db: iip_db\n'+
'                              26 normalized tables\n'+
'\n'+
'  External ports: 443 only\n'+
'  Internal: 3001 (FastAPI/Uvicorn), 5432 (PG) — localhost-bound');
        }
      },

      /* ── TOOLS & FEATURES ─────────────────────────────── */
      'cmd-palette':{
        crumbs:['IIP','Tools & Features','Command Palette'], title:'Command Palette',
        content(){
          return h1('Command Palette')+meta('March 23, 2026','v1.0.3')+
          `<div style="display:flex;gap:7px;margin-bottom:16px;flex-wrap:wrap">`+badge('Ctrl+K')+`</div>`+
          p('The Command Palette is a keyboard-first launcher that gives you instant access to every dashboard, action, and tool — without leaving the keyboard.')+
          callout('tip','How to open','Press '+ic('Ctrl+K')+'(or click the Search & Commands button in the header). Start typing to filter commands. Use arrow keys to move through results. Press '+ic('Enter')+'to execute, '+ic('Esc')+'to close.')+
          h2('Available Commands')+
          tbl(['Group','Command','What It Does'],[
            ['Navigate',ic('Overview Dashboard'),'Jump to the Overview KPI dashboard'],
            ['Navigate',ic('Team Cases'),'Jump to the Team Cases workspace'],
            ['Navigate',ic('Member Dashboard'),'Jump to the Member workload dashboard'],
            ['Navigate',ic('Customer Cases'),'Jump to the Customer Cases tab'],
            ['Navigate',ic('Closed Cases'),'Jump to Closed Cases trend charts'],
            ['Navigate',ic('Created Cases'),'Jump to Created Cases intake charts'],
            ['Navigate',ic('Performance Analytics'),'Jump to the Performance tracker'],
            ['Navigate',ic('Weekly Tracker'),'Jump to the Weekly Tracker'],
            ['Navigate',ic('Case Investigation'),'Jump to the Investigate archive search'],
            ['Navigate',ic('RFE Tracking'),'Jump to the RFE pipeline'],
            ['Navigate',ic('Information & Help'),'Jump to the Information & contacts page'],
            ['Actions',ic('Focus Search Bar'),'Put keyboard focus in the Global Search bar'],
            ['Actions',ic('Open AI Assistant'),'Open the floating AI chat panel'],
            ['Actions',ic('Reload Data File'),'Open the file upload dialog to reload case data'],
            ['Actions',ic('Open New IBM Case'),'Open mysupport.ibm.com in a new tab'],
            ['Help',ic('Keyboard Shortcuts Help'),'Open the Keyboard Shortcuts reference panel'],
            ['Help',ic('Start Guided Tour'),'Start the 21-step interactive app tour'],
          ])+
          h2('Keyboard Navigation Inside the Palette')+
          tbl(['Key','Action'],[
            [ic('↑ ↓ Arrow'),'Move selection up or down through the list'],
            [ic('Enter'),'Execute the selected command'],
            [ic('Esc'),'Close the palette without executing'],
            ['Click','Click any command row to execute it'],
          ])+
          callout('note','Search highlight','Typed characters are highlighted in matching command labels, making it easy to see why a result matched.');
        }
      },

      'global-search':{
        crumbs:['IIP','Tools & Features','Global Search'], title:'Global Search',
        content(){
          return h1('Global Search')+meta('March 23, 2026','v1.0.3')+
          `<div style="display:flex;gap:7px;margin-bottom:16px;flex-wrap:wrap">`+badge('/ key')+`</div>`+
          p('Global Search lets you instantly find any case in the loaded dataset by number, title, owner, status, or product — from any page, without navigating to a specific dashboard.')+
          callout('tip','How to open','Press '+ic('/')+'from anywhere in the app (not while typing in an input). Focus moves to the search bar in the header. Start typing to see live results. Press '+ic('Esc')+'to clear and close.')+
          h2('Search Fields')+
          tbl(['Field','Example Input'],[
            ['Case Number',ic('TS015...')+' — matches any case whose number starts with the typed string'],
            ['Title','Any word in the case title (case-insensitive)'],
            ['Owner','Engineer first or last name'],
            ['Status',ic('waiting')+', '+ic('closed')+', '+ic('awaiting')+'etc.'],
            ['Product',ic('CCM')+', '+ic('QM')+', '+ic('IHS')+'etc.'],
          ])+
          h2('Result Cards')+
          p('Each result shows: case number (blue for open, grey for closed), severity badge (S1–S4), truncated title, owner short name, and current status. Up to 12 results are shown.')+
          h2('Keyboard Navigation in Results')+
          tbl(['Key','Action'],[
            [ic('↓ Arrow'),'Move focus into the results list'],
            [ic('↑ ↓ Arrow'),'Move between result rows'],
            [ic('Enter'),'Open the Case Detail modal for the selected result'],
            [ic('Esc'),'Clear search and close results'],
          ])+
          callout('info','Case Detail Modal','Clicking or pressing Enter on a result opens a full case detail modal with all fields, action buttons, and navigation shortcuts.');
        }
      },

      'guided-tour':{
        crumbs:['IIP','Tools & Features','Guided Tour'], title:'Guided Tour',
        content(){
          return h1('Guided Tour')+meta('March 23, 2026','v1.0.3')+
          `<div style="display:flex;gap:7px;margin-bottom:16px;flex-wrap:wrap">`+badge('Ctrl+L')+' '+badge('21 steps')+`</div>`+
          p('The Guided Tour walks you through every major feature of IIP with a spotlight overlay. Each step highlights a specific UI element and explains what it does and how to use it.')+
          callout('tip','How to start','Press '+ic('Ctrl+L')+' from anywhere in the app, or run '+ic('Start Guided Tour')+'from the Command Palette ('+ic('Ctrl+K')+').')+
          h2('Tour Design')+
          ul([
            '<strong>Light mode only</strong> — the tooltip is always white (#ffffff), visible in any system theme.',
            '<strong>No blur</strong> — the backdrop-filter blur is intentionally removed so you can see and interact with the live app behind the spotlight.',
            '<strong>Overlay opacity 45%</strong> — dark enough to focus attention, light enough to read the interface.',
            '<strong>21 steps</strong> — covers every dashboard, every tool, and key workflows.',
          ])+
          h2('Tour Coverage')+
          tbl(['Step Range','Area'],[
            ['Steps 1–3','Header tools: Global Search, Command Palette, Shortcuts panel'],
            ['Steps 4–6','Core dashboards: Overview, Team Cases, Member Dashboard'],
            ['Steps 7–9','Data dashboards: Customer Cases, Closed, Created'],
            ['Steps 10–12','Power tools: Performance, Weekly Tracker, Investigate'],
            ['Steps 13–15','Platform features: RFE Tracking, Guided Tour itself, How It Works'],
            ['Steps 16–18','Admin tools: Admin Portal, upload flow, data management'],
            ['Steps 19–21','Tips: Keyboard navigation, status bar, wrap-up'],
          ])+
          h2('Navigation During the Tour')+
          tbl(['Control','Action'],[
            ['Next button','Advance to the next step'],
            ['← Back button','Go back one step'],
            ['✕ button or Esc','Exit the tour at any time'],
            ['Progress bar','Shows current step out of 21'],
          ]);
        }
      },

      /* ── REFERENCE — SSE ──────────────────────────────── */
      'ref-sse':{
        crumbs:['IIP','Reference','Real-time Updates (SSE)'], title:'Real-time Updates — Server-Sent Events',
        content(){
          return h1('Real-time Updates (SSE)')+meta('March 23, 2026','v1.0.3')+
          `<div style="display:flex;gap:7px;margin-bottom:16px;flex-wrap:wrap">`+badge('FastAPI main.py')+' '+badge('EventSource API')+`</div>`+
          p('IIP uses Server-Sent Events (SSE) to push instant notifications to all open browser sessions whenever a user uploads new case data. There is no polling delay — other users see a refresh prompt within milliseconds.')+
          h2('How It Works')+
          ol([
            'On page load, the browser opens a persistent HTTP connection to '+ic('GET /api/events')+'.',
            'When any user uploads a CSV/XLSX ('+ic('POST /api/cases')+'), the server broadcasts a '+ic('data-updated')+'event to every connected client.',
            'Each browser receives the event and shows a non-intrusive refresh banner: "New data available — click to reload."',
            'The uploading tab is excluded from the notification (it already has the new data).',
            'If the connection drops, the browser automatically reconnects after 5 seconds.',
          ])+
          h2('Event Payload')+
          cb('// Browser receives:\nevent: data-updated\ndata: {"versionTs": 1742920800000}\n\n// versionTs is the Unix timestamp of the upload.\n// Used to deduplicate: the uploading tab skips the banner\n// if data.versionTs matches its own upload timestamp.')+
          h2('Fallback Behaviour')+
          p('If the browser does not support '+ic('EventSource')+' (very unlikely in modern browsers), or if '+ic('IIPStore')+'detects it is running in file:// mode, SSE is disabled and the app falls back to the existing periodic re-sync that runs every time the tab becomes visible.')+
          h2('Endpoint Reference')+
          tbl(['Item','Value'],[
            ['Endpoint',ic('GET /api/events')],
            ['Protocol','HTTP/1.1 with '+ic('Content-Type: text/event-stream')],
            ['Auth','None required (read-only push)'],
            ['Reconnect','Browser auto-reconnects; server retries after 5 s on error'],
            ['Events',ic('connected')+'(on open), '+ic('data-updated')+'(on new upload)'],
          ])+
          callout('note','File mode','SSE is disabled when running from '+ic('file://')+'(local development without a server). The check is in '+ic('IIPStore.isFileMode()')+'.');
        }
      },

      /* ═══════════════════════════════════════════════════════
         DEVELOPER DOCUMENTATION — Admin-only technical reference
         ═══════════════════════════════════════════════════════ */

      'dev-security-qa':{
        crumbs:['IIP','Developer Docs','Security Questions & Password Reset'],
        title:'Security Questions & Password Reset',
        adminOnly:true,
        content(){
          return h1('Security Questions & Password Reset')+meta('2026-05-12','v1.0.0')+
          p('Admin password resets are secured using user-configured security questions. Answers are stored in the PostgreSQL database and verified on every password reset attempt. This document explains the complete data flow and persistence model.')+

          h2('Database Storage')+
          p('Security questions are stored in the '+ic('security_questions')+' table (one row per admin, columns: username, q1, a1, q2, a2):')+
          cb('{\n  "q1": "What is your mother\'s maiden name?",\n  "a1": "smith",              // stored lowercased\n  "q2": "What was your first pet\'s name?",\n  "a2": "fluffy"               // stored lowercased\n}')+
          p('The '+ic('a1')+' and '+ic('a2')+' answers are stored '+strong('lowercased')+'for case-insensitive matching. Questions are stored as-is (not hashed).')+

          h2('Complete Data Flow')+
          h3('1. Admin Saves Security Questions')+
          ol([
            'Admin logs in via '+ic('POST /api/auth')+' with password → receives '+ic('X-IIP-Admin-Token'),
            'Admin navigates to Admin Portal → clicks "Security Questions" button',
            'Admin selects 2 questions from dropdown and enters answers',
            'Frontend calls '+ic('POST /api/auth/security-questions')+' with:'+
            cb('{\n  "q1": "What is your mother\'s maiden name?",\n  "a1": "Smith",\n  "q2": "What was your first pet\'s name?",\n  "a2": "Fluffy"\n}')+
            'Backend receives request with header '+ic('X-IIP-Admin-Token'),
            'Backend validates token (must be logged-in admin)',
            'Backend '+strong('lowercases answers')+': '+ic('a1 = "smith"')+', '+ic('a2 = "fluffy"'),
            'Backend UPSERTS into '+ic('security_questions')+' table: '+ic('username, q1, a1, q2, a2')+' columns',
            'Data persisted to PostgreSQL ✓',
          ])+

          h3('2. User Resets Password via Questions')+
          ol([
            'User on login page clicks "Reset via Security Question"',
            'Frontend calls '+ic('GET /api/auth/security-questions')+' (no auth required)',
            'Backend returns questions '+strong('WITHOUT answers')+':'+
            cb('{\n  "ok": true,\n  "configured": true,\n  "questions": {\n    "q1": "What is your mother\'s maiden name?",\n    "q2": "What was your first pet\'s name?"\n  }\n}')+
            'User enters their answers and new password (min 8 chars)',
            'Frontend calls '+ic('POST /api/auth/reset-via-security')+' with:'+
            cb('{\n  "a1": "smith",\n  "a2": "fluffy",\n  "newPassword": "NewSecurePass123"\n}')+
            'Backend fetches stored questions from '+ic('security_questions')+' table',
            'Backend compares answers '+strong('case-insensitively')+':'+
            'If '+ic('a1.lower() == stored_a1.lower()')+' AND '+ic('a2.lower() == stored_a2.lower()')+' → proceed',
            'Backend hashes new password with bcrypt',
            'Backend UPSERTS into '+ic('admin_credentials')+': '+ic('password_hash')+' column',
            'Backend creates new session token and returns it',
            'User is logged in ✓',
          ])+

          h2('Data Persistence Across Sessions')+
          p('Security questions are stored in PostgreSQL, which means:')+
          ul([
            strong('Persistence')+'  — Questions remain in the database until the admin changes them. No expiration.',
            strong('Cross-session') +' — Any browser can retrieve and use the stored questions.',
            strong('Cross-device') +' — A user on a different computer can reset their password using the same questions.',
            strong('Durability')   +' — Database backups protect the questions from loss.',
          ])+

          h2('Verification SQL')+
          p('To verify questions are stored in the database:')+
          cb('SELECT username, q1, q2, updated_at FROM security_questions;')+
          p('Example output:')+
          cb('username | q1                              | q2\n─────────┼─────────────────────────────────┼──────────────────\nadmin    | What is your mother\'s maiden... | What was your first pet...')+

          h2('API Endpoints')+
          tbl(['Endpoint','Method','Auth','Purpose'],[
            [ic('/api/auth/security-questions'),'GET','None','Fetch questions (no answers) — used on reset page'],
            [ic('/api/auth/security-questions'),'POST','Admin Token','Save security questions and answers'],
            [ic('/api/auth/reset-via-security'),'POST','None','Verify answers + reset password; returns new token'],
          ])+

          h2('Source Code')+
          p('Key files:')+
          ul([
            ic('backend/routers/auth.py')+' — All three endpoints (lines 164–208)',
            ic('js/modules/ui/modal.js')+' — '+ic('showSetupSecurityQuestions()')+' function',
            ic('js/modules/admin/admin.js')+' — '+ic('_showForgotPasswordModal()')+' reset flow',
          ])+

          h2('Security Notes')+
          callout('warning','Answer Storage','Answers are '+strong('NOT hashed')+' — they are stored as plaintext in the DB (lowercased). This is by design: unlike passwords, security questions are memorable recovery mechanisms, not secrets. The real secret is the password itself, which is always hashed.')+
          callout('tip','Best Practice','Encourage admins to choose questions whose answers are not publicly guessable (avoid maiden names, pet names, or other public biographical data if possible). Good questions: custom secrets, memorable dates, or phrases known only to them.')+
          callout('note','Case-Insensitive Matching','All answer comparisons use case-insensitive logic: '+ic('a1.strip().lower() == stored.get("a1", "")')+'  This means "Smith", "smith", "SMITH" are all valid.');
        }
      },

      'dev-setup':{
        crumbs:['IIP','Developer Docs','Developer Setup'],
        title:'Developer Setup & Workflow',
        adminOnly:true,
        content(){
          return h1('Developer Setup & Workflow')+meta('2026-05-12','v1.0.0')+
          p('This guide covers setting up the IIP codebase for local development and deployment to production.')+

          h2('Repository Structure')+
          p('IIP is '+strong('not a Git repository')+'. Code is synced manually between Windows (development) and Linux (production).')+
          ul([
            strong('Windows (Dev):')+' '+ic('C:\\Users\\bxe1cob\\Videos\\iip\\'),
            strong('Linux (Prod):')+' '+ic('/var/www/html/iip')+'  on RHEL9 server',
          ])+

          h2('Directory Layout')+
          cb('iip/\n├── backend/               ← FastAPI Python app\n│   ├── main.py            ← FastAPI server, health + SSE + router wiring\n│   ├── routers/           ← db_cases, admin, auth, store, saved_searches\n│   ├── models.py          ← Pydantic request/response models\n│   ├── database.py        ← asyncpg pool, migrations\n│   ├── auth.py            ← Password hashing, session tokens\n│   ├── requirements.txt    ← Dependencies (fastapi, asyncpg, passlib, bcrypt)\n│   ├── .env               ← DB credentials (NEVER COMMIT)\n│   └── .env.example       ← Template for .env\n├── frontend/\n│   ├── index.html         ← Main entry point\n│   ├── css/               ← Stylesheets by feature\n│   ├── js/\n│   │   ├── app.js         ← Shell & router (load last)\n│   │   ├── modules/       ← Feature modules (storage, admin, UI)\n│   │   ├── dashboards/    ← One file per tab\n│   │   └── app-data.js    ← Team config, ALM catalogue\n│   └── fonts/             ← IBM Plex (embedded)\n├── sync-and-deploy.sh     ← ONE-COMMAND deploy script\n└── SYNC_AND_DEPLOY.md     ← Deploy guide\n')+

          h2('Development Stack')+
          tbl(['Layer','Tech','Version'],[
            ['Frontend','Vanilla JavaScript (ES6+)','—'],
            ['Build','None (no build step)','—'],
            ['Backend','FastAPI','0.115.5'],
            ['Server','Uvicorn (ASGI)','—'],
            ['Database','PostgreSQL','13+'],
            ['Async Driver','asyncpg','0.29+'],
            ['Auth','passlib + bcrypt','—'],
            ['Web Server','Apache 2.4','—'],
          ])+

          h2('Key Credentials & Config')+
          p('Never commit '+ic('.env')+'! Copy '+ic('.env.example')+'and fill in:')+
          cb('DB_HOST=localhost\nDB_PORT=5432\nDB_NAME=iip_db\nDB_USER=iip_user\nDB_PASSWORD=K@bilesh2026          # ← Real password in production\nDB_SSL=false\nCORS_ORIGIN=https://rb-alm-01-d8.de.bosch.com\nAPI_PORT=3001\nLOG_LEVEL=info\nNODE_ENV=development')+

          h2('Deploying Changes')+
          h3('From Windows to Linux')+
          steps([
            'Make changes in '+ic('C:\\Users\\bxe1cob\\Videos\\iip\\'),
            'Run: '+ic('bash sync-and-deploy.sh root rb-alm-01-d8.de.bosch.com /var/www/html/iip'),
            'Enter SSH password when prompted',
            'Wait for sync to complete (files copied, backend restarted)',
            'Verify: '+ic('curl https://rb-alm-01-d8.de.bosch.com/iip/api/health'),
          ])+

          h2('Running Locally (No Server)')+
          p('To run the full stack on Windows for development:')+
          steps([
            'Start PostgreSQL (local or Docker)',
            'Create database: '+ic('CREATE DATABASE iip_db;'),
            'Run schema: '+ic('psql iip_db < backend/schema.sql'),
            'Install Python deps: '+ic('pip install -r backend/requirements.txt'),
            'Start FastAPI: '+ic('uvicorn backend.main:app --reload --port 3001'),
            'Open '+ic('file:///C:/Users/bxe1cob/Videos/iip/frontend/index.html')+' in browser',
          ])+
          callout('warning','File Mode','When running from '+ic('file://')+'without a server, many features are disabled: database sync, SSE, admin auth, data persistence. Good for UI testing only.')+

          h2('Common Development Commands')+
          tbl(['Task','Command'],[
            ['Run local backend','uvicorn backend.main:app --reload --port 3001'],
            ['View backend logs','journalctl -u iip-fastapi -f  (on server)'],
            ['Check API health','curl http://127.0.0.1:3001/api/health'],
            ['Query PostgreSQL','psql iip_db'],
            ['Restart backend (server)','systemctl restart iip-fastapi'],
            ['View frontend console','F12 in browser → Console tab'],
          ])+

          h2('Deployment Pipeline')+
          p('Full end-to-end flow:')+
          ol([
            'Developer edits files in Windows (iip/)',
            'Runs '+ic('sync-and-deploy.sh'),
            'Script SCP syncs all files to Linux',
            'Apache picks up HTML/CSS/JS changes immediately',
            'Backend systemd service is restarted (new Python loaded)',
            'PostgreSQL connection pool refreshed',
            'New version live on '+ic('https://rb-alm-01-d8.de.bosch.com/iip/'),
          ])+

          h2('Database Migrations')+
          p('PostgreSQL schema is managed manually (no ORM migrations). To add tables:')+
          steps([
            'Edit '+ic('backend/schema.sql')+'or '+ic('backend/database.py'),
            'Run on local PostgreSQL for testing',
            'Document the change',
            'Deploy via '+ic('sync-and-deploy.sh')+'(migrations auto-run on restart)',
          ]);
        }
      },

      'dev-auth':{
        crumbs:['IIP','Developer Docs','Authentication'],
        title:'Authentication Architecture',
        adminOnly:true,
        content(){
          return h1('Authentication Architecture')+meta('2026-05-12','v1.0.0')+
          p('IIP uses a custom session-based authentication system. Admin password is hashed with bcrypt; session tokens are stored in the database and validated on every protected request.')+

          h2('Authentication Flow')+
          h3('Login (POST /api/auth)')+
          ol([
            'Frontend sends: '+ic('{ "password": "mypassword" }'),
            'Backend fetches admin password hash from '+ic('admin_credentials')+' table',
            'Backend compares hash with bcrypt.verify()',
            'If match: backend creates session token (random string) and stores in '+ic('admin_sessions')+' table',
            'Backend returns: '+ic('{ "ok": true, "token": "abc123def456..." }'),
            'Frontend stores token in localStorage as '+ic('ibm_admin_token_v1'),
          ])+

          h3('Authenticated Requests')+
          p('Every protected API call (POST/DELETE to '+ic('/api/store')+', '+ic('/api/auth/set-password')+', etc.) requires:')+
          cb('GET /api/protected-endpoint\nX-IIP-Admin-Token: abc123def456...')+
          p('Backend validates token exists and is not expired in '+ic('admin_sessions')+' table.')+

          h3('Logout (POST /api/auth/logout)')+
          ol([
            'Frontend sends X-IIP-Admin-Token header',
            'Backend deletes the token row from '+ic('admin_sessions'),
            'Token is now invalid for all future requests',
          ])+

          h2('Session Storage')+
          p('Sessions are stored in PostgreSQL table '+ic('admin_sessions')+'(columns: token PK, username, created_at, expires_at):')+
          cb('-- Check active sessions:\nSELECT token, username, created_at, expires_at\nFROM admin_sessions WHERE expires_at > NOW();\n\n-- Clean expired:\nDELETE FROM admin_sessions WHERE expires_at < NOW();')+

          h2('Token Validation Pseudocode')+
          cb('async def is_valid_session(conn, token: str):\n  if not token:\n    return False\n  row = await conn.fetchrow(\n    "SELECT * FROM iip_sessions WHERE token=$1",\n    token\n  )\n  if not row:\n    return False\n  if row["expires_at"] < NOW():\n    await conn.execute("DELETE FROM iip_sessions WHERE token=$1", token)\n    return False\n  return True')+

          h2('Password Hashing')+
          p('Passwords are hashed with bcrypt (via passlib) and stored in the '+ic('admin_credentials')+' table:')+
          ul([
            strong('Cost factor')+': 12 rounds (configurable in '+ic('backend/auth.py')+')',
            strong('Comparison')+': Always use '+ic('passlib.context.CryptContext.verify()')+'  Never compare raw strings',
            strong('Storage')+': Hashes stored in '+ic('admin_credentials')+' table (username + password_hash columns)',
          ])+

          h2('Security Features')+
          ul([
            strong('No plaintext passwords')+' — all stored as bcrypt hashes',
            strong('Per-session tokens')+' — each login creates a new unique token',
            strong('Token expiration')+' — sessions expire after 24 hours (configurable)',
            strong('Database validation')+' — every request checks token against database (no local caching)',
            strong('Logout revocation')+' — logout immediately invalidates token in database',
          ])+

          h2('Protected Endpoints')+
          tbl(['Endpoint','Required Header'],[
            [ic('POST /api/auth/set-password'),ic('X-IIP-Admin-Token')],
            [ic('POST /api/auth/security-questions'),ic('X-IIP-Admin-Token')],
            [ic('DELETE /api/auth/logout'),ic('X-IIP-Admin-Token')],
            [ic('POST /api/store/:key'),ic('X-IIP-Admin-Token')],
            [ic('DELETE /api/store/:key'),ic('X-IIP-Admin-Token')],
            [ic('POST /api/store-bulk-set'),ic('X-IIP-Admin-Token')],
          ])+

          h2('Source Code')+
          ul([
            ic('backend/auth.py')+' — password hashing, session create/validate/revoke',
            ic('backend/routers/auth.py')+' — endpoints',
            ic('js/modules/admin/admin.js')+' — login flow, token storage',
            ic('js/modules/data/storage.js')+' — IIPStore reads token from localStorage',
          ]);
        }
      },

      'dev-database':{
        crumbs:['IIP','Developer Docs','Database'],
        title:'Database Schema Reference',
        adminOnly:true,
        content(){
          return h1('Database Schema')+meta('2026-05-12','v1.0.0')+
          p('All shared application state is stored in PostgreSQL. This document provides a complete schema reference for developers and admins.')+

          h2('Connection')+
          cb('Host: localhost (or si0vm14401.de.bosch.com on server)\nPort: 5432\nDatabase: iip_db\nUser: iip_user\nPassword: [see .env]')+

          h2('Core Tables (26 total)')+
          p('Full schema at '+ic('schema/iip_schema.sql')+'. Key tables:')+

          tbl(['Table','Key Columns','Purpose'],[
            [ic('cases'),'case_number (PK), status, owner_name, severity, product, is_performance_case, is_active','Active IBM support cases'],
            [ic('case_status_history'),'case_number, upload_id, upload_date, status','Per-upload status for reopen detection'],
            [ic('weekly_closed_cases'),'case_number, week_number, year, week_label, owner, comments, category','Weekly tracker entries'],
            [ic('audit_log'),'action, entity_type, entity_id, old_value, new_value, admin_user, change_date','All admin actions'],
            [ic('team_members'),'name (unique), email, team, status, display_name','Team roster'],
            [ic('uploads'),'filename, file_type, upload_date, status, record_count, case_fingerprint','Upload history'],
            [ic('admin_credentials'),'username (PK), password_hash','Bcrypt-hashed admin password'],
            [ic('admin_sessions'),'token (PK), username, created_at, expires_at','Active session tokens (24h TTL)'],
            [ic('security_questions'),'username (PK), q1, a1, q2, a2','Admin security Q&A for password reset'],
            [ic('alm_lines'),'alm_line (PK), customer_contact, line_manager, case_responsible, ...','ALM line contact details'],
            [ic('app_settings'),'key (PK), value, description, updated_at','App-level settings (slaClosureDays, etc.)'],
            [ic('saved_searches'),'id, dashboard, name, query (jsonb), is_shared, use_count','Per-dashboard saved filter sets'],
            [ic('ibm_ideas'),'idea_reference (PK), idea_name, product, workflow_state, vote_count','IBM Ideas (RFE)'],
            [ic('rfe_annotations'),'idea_reference (PK), notes, tags, target_release','Internal RFE annotations'],
            [ic('elm_upgrades'),'id, elm_version, ifix_version, upgrade_date, notes','ELM upgrade history'],
            [ic('escalation_contacts'),'id, group_name, name, email','Escalation contact groups'],
            [ic('ibm_contacts'),'id, group_name, name, email','IBM directory contacts'],
            [ic('duplicate_references'),'duplicate_case_number, original_case_number (unique)','Detected duplicate cases'],
            [ic('performance_wednesday_comments'),'case_number, date_key (unique), comment','Weekly wednesday comments'],
            [ic('performance_slot_days'),'case_number, year, month, slot_index, day_of_week (unique)','Performance slot overrides'],
            [ic('case_grayout_state'),'case_number, week, year (PK), is_grayed, later_week','Cross-week grayout state'],
            [ic('weekly_reopened_sync'),'case_number, week, year (PK), closed_date, status','Cross-week reopened sync'],
            [ic('wt_case_history'),'id, case_number, week, year, status_before, status_after, seed_id (unique)','WT change audit trail'],
            [ic('error_log'),'id, occurred_at, message, stack, context','Frontend and backend errors'],
          ])+

          h2('Sessions & Credentials')+
          p('Admin sessions use the '+ic('admin_sessions')+' table (not a separate iip_sessions table):')+
          cb('-- Active sessions:\nSELECT username, created_at, expires_at FROM admin_sessions WHERE expires_at > NOW();\n\n-- Admin credentials (password hash only, never plaintext):\nSELECT username, created_at FROM admin_credentials;')+

          h2('Useful Queries')+
          h3('View all active cases')+
          cb('SELECT case_number, owner_name, status, product, age_days\nFROM cases WHERE is_active = true ORDER BY age_days DESC LIMIT 20;')+

          h3('Check admin password')+
          cb('SELECT key, value FROM iip_kv WHERE key = \'admin_pwd_hash\';')+

          h3('Check security questions')+
          cb('SELECT username, q1, q2, updated_at FROM security_questions;')+

          h3('View active sessions')+
          cb('SELECT token, created_at, expires_at FROM iip_sessions\nWHERE expires_at > NOW()\nORDER BY created_at DESC;')+

          h3('Clean expired sessions')+
          cb('DELETE FROM iip_sessions WHERE expires_at < NOW();')+

          h2('Data Backup')+
          p('To backup PostgreSQL:')+
          cb('pg_dump iip_db -h localhost -U iip_user > iip_backup.sql')+
          p('To restore:')+
          cb('psql iip_db -h localhost -U iip_user < iip_backup.sql')+

          h2('Monitoring')+
          p('Check database size:')+
          cb('SELECT pg_database.datname,\n       pg_size_pretty(pg_database_size(pg_database.datname)) AS size\nFROM pg_database\nWHERE datname = \'iip_db\';')+

          h2('Performance Notes')+
          ul([
            'Index on '+ic('iip_kv.key')+' is automatic (PRIMARY KEY)',
            'JSON queries use JSONB (faster than TEXT)',
            'No table joins needed — all data is denormalized in '+ic('iip_kv'),
            'For large datasets (>100k cases), consider partitioning '+ic('ibm_cases_raw_v1')+' by year',
          ]);
        }
      },

      'dev-deployment':{
        crumbs:['IIP','Developer Docs','Deployment'],
        title:'Deployment & Server Ops',
        adminOnly:true,
        content(){
          return h1('Deployment & Server Operations')+meta('2026-05-12','v1.0.0')+
          p('Complete deployment guide for getting changes from development Windows machine to production RHEL9 server.')+

          h2('Quick Deploy')+
          p('Fastest way to deploy:')+
          cb('bash sync-and-deploy.sh root rb-alm-01-d8.de.bosch.com /var/www/html/iip')+
          p('This is a one-liner that:')+
          ol([
            'SCP syncs all files from Windows → Linux',
            'Restarts FastAPI backend systemd service',
            'Reloads Apache configuration',
            'Verifies deployment with health check',
          ])+

          h2('Server Details')+
          tbl(['Item','Value'],[
            ['Hostname',ic('si0vm14401.de.bosch.com')],
            ['OS','RHEL9 (Red Hat Enterprise Linux 9)'],
            ['SSH User',ic('rbadmin_app1')],
            ['App Directory',ic('/var/www/html/iip')],
            ['Web Server','Apache 2.4 (systemd service)'],
            ['Backend Process','iip-fastapi (systemd service)'],
            ['Database','PostgreSQL 13+ (systemd service)'],
            ['URL (External)',ic('https://rb-alm-01-d8.de.bosch.com/iip/')],
            ['URL (Internal)',ic('http://127.0.0.1:3001')],
          ])+

          h2('Systemd Services')+
          tbl(['Service','Command','Purpose'],[
            [ic('iip-fastapi'),'systemctl restart iip-fastapi','Restart FastAPI backend'],
            [ic('postgresql'),'systemctl status postgresql','Check DB status'],
            [ic('httpd'),'systemctl restart httpd','Reload Apache config'],
          ])+

          h2('Common Deployment Tasks')+
          h3('Deploy backend code only')+
          cb('rsync -avz --exclude=node_modules --exclude=__pycache__ \\\n  C:\\Users\\bxe1cob\\Videos\\iip\\backend/ \\\n  rbadmin_app1@si0vm14401.de.bosch.com:/var/www/html/iip/backend/')+

          h3('Deploy frontend only')+
          cb('rsync -avz \\\n  C:\\Users\\bxe1cob\\Videos\\iip\\frontend/ \\\n  rbadmin_app1@si0vm14401.de.bosch.com:/var/www/html/iip/frontend/')+

          h3('Check backend health')+
          cb('curl -k https://rb-alm-01-d8.de.bosch.com/iip/api/health')+

          h3('View real-time backend logs')+
          cb('ssh rbadmin_app1@si0vm14401.de.bosch.com \\\n  "journalctl -u iip-fastapi -f"')+

          h2('Apache Configuration')+
          p('Apache config file:')+
          cb('cat /etc/httpd/conf.d/rb-alm-01-d8.conf')+
          p('Key directives:')+
          cb('ProxyPass /iip/api/ http://127.0.0.1:3001/api/ nocanon\nProxyPassReverse /iip/api/ http://127.0.0.1:3001/api/\nProxyPreserveHost On')+

          h2('Troubleshooting Deployments')+
          h3('Backend not responding')+
          steps([
            'Check service status: '+ic('systemctl status iip-fastapi'),
            'View logs: '+ic('journalctl -u iip-fastapi -n 50'),
            'Restart service: '+ic('systemctl restart iip-fastapi'),
            'Check if port 3001 is listening: '+ic('ss -tlnp | grep 3001'),
          ])+

          h3('Database connection error')+
          steps([
            'Check PostgreSQL is running: '+ic('systemctl status postgresql'),
            'Test connection: '+ic('psql -h localhost -U iip_user -d iip_db'),
            'Check .env credentials in '+ic('/var/www/html/iip/backend/.env'),
            'Restart backend: '+ic('systemctl restart iip-fastapi'),
          ])+

          h3('Frontend not updating')+
          steps([
            'Check files were synced: '+ic('ls -la /var/www/html/iip/frontend/'),
            'Clear browser cache: '+ic('Ctrl+Shift+R')+'  or disable caching in Dev Tools',
            'Reload Apache: '+ic('systemctl reload httpd'),
            'Check Apache logs: '+ic('tail -50 /var/log/httpd/error_log'),
          ])+

          h2('Rollback Procedure')+
          p('If a deployment breaks production:')+
          ol([
            'SSH to server: '+ic('ssh rbadmin_app1@si0vm14401.de.bosch.com'),
            'Revert code from Git or backup: '+ic('cd /var/www/html/iip && git checkout HEAD~1')+'  (if Git available)',
            'Restart backend: '+ic('systemctl restart iip-fastapi'),
            'Reload Apache: '+ic('systemctl reload httpd'),
            'Verify: '+ic('curl https://rb-alm-01-d8.de.bosch.com/iip/api/health'),
          ])+

          h2('Performance Monitoring')+
          h3('Check backend CPU/memory')+
          cb('top -p $(systemctl show -p MainPID --value iip-fastapi)')+

          h3('Check database size')+
          cb('psql iip_db -c "SELECT pg_size_pretty(pg_database_size(\'iip_db\'));"')+

          h3('Monitor case uploads')+
          cb('tail -f /var/www/html/iip/backend/app.log | grep "POST /api/cases"')+

          h2('Deployment Checklist')+
          ul([
            '✓ All changes committed / backed up',
            '✓ Run '+ic('bash sync-and-deploy.sh'),
            '✓ Health check passes: '+ic('curl /api/health'),
            '✓ Frontend loads without console errors (F12)',
            '✓ Admin can log in',
            '✓ Users can view dashboards',
            '✓ Data sync works (upload a test case)',
          ]);
        }
      },

      'dev-debugging':{
        crumbs:['IIP','Developer Docs','Debugging'],
        title:'Debugging & Troubleshooting Guide',
        adminOnly:true,
        content(){
          return h1('Debugging & Troubleshooting')+meta('2026-05-12','v1.0.0')+
          p('Practical debugging techniques for common IIP issues.')+

          h2('Frontend Debugging')+
          h3('Open Developer Tools')+
          cb('Windows/Linux: F12 or Ctrl+Shift+I\nMac: Cmd+Opt+I')+

          h3('Check Console for Errors')+
          ol([
            'Open Dev Tools (F12)',
            'Click "+Console+" tab',
            'Look for red error messages',
            'Click error to see stack trace',
          ])+
          p('Common errors:')+
          ul([
            ic('ReferenceError: Data is not defined')+' — app-data.js failed to load or Data module crashed',
            ic('TypeError: Cannot read property of undefined')+' — accessing null/undefined object',
            ic('CORS error')+' — frontend trying to call backend with wrong origin',
          ])+

          h3('Inspect DOM Elements')+
          ol([
            'Right-click on element → Inspect',
            'Look at computed styles (Styles tab)',
            'Check if element is hidden (display:none, visibility:hidden)',
            'Check z-index and stacking context',
          ])+

          h3('Network Tab')+
          ol([
            'Open Dev Tools → Network tab',
            'Reload page (Ctrl+R)',
            'Look for failed requests (red, status 404/500)',
            'Click request to see full URL, headers, response body',
          ])+
          p('Check for:')+
          ul([
            'API requests returning 401 (auth required)',
            'API requests returning 500 (server error)',
            'Static files (CSS, JS) returning 404',
          ])+

          h2('Backend Debugging')+
          h3('Check FastAPI Logs')+
          cb('# On server\njournalctl -u iip-fastapi -f\n\n# Follow in real-time\njournalctl -u iip-fastapi -n 100 --follow')+

          h3('Test API Endpoint')+
          cb('# Health check\ncurl http://127.0.0.1:3001/api/health\n\n# Get cases\ncurl http://127.0.0.1:3001/api/cases\n\n# With admin token\ncurl -H "X-IIP-Admin-Token: abc123" http://127.0.0.1:3001/api/store-public/ibm_rfe_tracking_v1')+

          h3('Enable Debug Logging')+
          p('Edit '+ic('backend/main.py')+' and set '+ic('LOG_LEVEL=debug')+' in '+ic('.env')+'Then restart:')+
          cb('systemctl restart iip-fastapi\njournalctl -u iip-fastapi -f')+

          h3('Database Queries')+
          cb('# Connect to database\npsql iip_db -h localhost -U iip_user\n\n# List tables and row counts:\nSELECT relname, n_live_tup FROM pg_stat_user_tables ORDER BY n_live_tup DESC;\n\n# Recent cases:\nSELECT case_number, owner_name, status FROM cases WHERE is_active=true LIMIT 10;')+

          h2('Common Issues & Fixes')+
          h3('Issue: "Admin token invalid"')+
          p(strong('Problem:')+'  '+ic('X-IIP-Admin-Token header not being sent')+' or token expired')+
          steps([
            'Open Dev Tools Console',
            'Check token exists: '+ic('localStorage.getItem("ibm_admin_token_v1")'),
            'If empty or null: re-login via Admin Portal',
            'If present: check expiration in '+ic('iip_sessions')+' table',
          ])+

          h3('Issue: "Cases not appearing"')+
          p(strong('Problem:')+'  '+ic('iip_cases_raw_v1')+' key is empty or malformed')+
          steps([
            'Query database: '+ic('SELECT key, LENGTH(value::text) FROM iip_kv WHERE key = \'ibm_cases_raw_v1\';'),
            'If 0 bytes: upload a CSV file via admin panel',
            'If >100K bytes: check browser console for parsing errors',
          ])+

          h3('Issue: "Dropdown behind modal"')+
          p(strong('Problem:')+'  Native '+ic('<select>')+' z-index issue due to '+ic('backdrop-filter')+' stacking context')+
          steps([
            'Replace native '+ic('<select>')+' with custom div-based dropdown',
            'Use '+ic('position:absolute')+' and '+ic('z-index:9999'),
            'Render dropdown inside modal DOM (not outside)',
            'Example in '+ic('js/modules/ui/modal.js')+': '+ic('showSetupSecurityQuestions()'),
          ])+

          h3('Issue: "SSE not connecting"')+
          p(strong('Problem:')+'  '+ic('GET /api/events')+' failing or browser doesn\'t support EventSource')+
          steps([
            'Check browser supports EventSource (all modern browsers do)',
            'Open Dev Tools → Network → find '+ic('GET /api/events')+' request',
            'Should see '+ic('Content-Type: text/event-stream'),
            'Status should be 200 (streaming)',
            'If 404 or 500: check backend is running',
          ])+

          h2('Performance Profiling')+
          h3('Frontend Performance')+
          cb('Open Dev Tools → Performance tab\nClick Record (red circle)\nInteract with app\nClick Stop\nAnalyze flame chart')+

          h3('Backend Performance')+
          cb('# Check slow queries\necho "SELECT query, calls, mean_time FROM pg_stat_statements ORDER BY mean_time DESC;" | psql iip_db')+

          h2('Remote Debugging')+
          p('To debug on the production server:')+
          steps([
            'SSH in: '+ic('ssh rbadmin_app1@si0vm14401.de.bosch.com'),
            'Tail backend logs: '+ic('journalctl -u iip-fastapi -f'),
            'Open another terminal and run: '+ic('curl https://rb-alm-01-d8.de.bosch.com/iip/api/health'),
            'Watch logs for request details',
          ])+

          h2('Memory Leaks')+
          p('If backend memory grows over time:')+
          ol([
            'Check active sessions: '+ic('SELECT COUNT(*) FROM admin_sessions WHERE expires_at > NOW();'),
            'Clean expired: '+ic('DELETE FROM admin_sessions WHERE expires_at < NOW();'),
            'Restart service: '+ic('systemctl restart iip-fastapi'),
            'Monitor memory: '+ic('watch -n 2 "ps aux | grep iip-fastapi"'),
          ]);
        }
      },

    };

    const DEFAULT_PAGE = 'platform-overview';

    /* ── Sidebar HTML ───────────────────────────────────── */
    function buildSidebar() {
      return NAV.map((grp, gi) => {
        const isFirst = gi === 0;
        const items = grp.items.map(item =>
          `<a class="doc-link" data-page="${item.id}" href="#">${item.label}</a>`
        ).join('');
        return `<div class="doc-grp">
          <button class="doc-grp-btn" data-grp="${grp.id}">
            <span class="doc-grp-ico">${ICON[grp.icon]}</span>
            <span class="doc-grp-lbl">${grp.label}</span>
            <span class="doc-grp-chev" style="transform:rotate(${isFirst?90:0}deg)">${ICON.chevron}</span>
          </button>
          <div class="doc-grp-items" style="display:${isFirst?'block':'none'}">${items}</div>
        </div>`;
      }).join('');
    }

    /* ── Breadcrumb HTML ─────────────────────────────────── */
    function buildCrumbs(crumbs) {
      return `<nav class="doc-crumbs">${crumbs.map((c, i) =>
        i < crumbs.length - 1
          ? `<span class="doc-crumb-seg">${c}</span><span class="doc-crumb-sep">›</span>`
          : `<span class="doc-crumb-cur">${c}</span>`
      ).join('')}</nav>`;
    }

    /* ── Render a page ────────────────────────────────────── */
    function _isAdminUser() {
      return (typeof Data !== 'undefined') && Data.isAdmin();
    }

    function showPage(id) {
      const sec = SECTIONS[id] || SECTIONS[DEFAULT_PAGE];
      const main = document.getElementById('doc-main');
      if (!main) return;

      // Admin-only page gating
      if (sec.adminOnly && !_isAdminUser()) {
        main.innerHTML = `<div style="max-width:860px">
          ${buildCrumbs(sec.crumbs)}
          <article>
            ${h1(sec.title)}
            ${callout('warning','Admin Access Required','This page contains sensitive infrastructure details and is restricted to administrators. Please log in via the Admin Portal to view this content.')}
            <div style="margin-top:18px">
              <button onclick="if(typeof Admin!=='undefined')Admin.showLoginModal();" class="btn btn-primary btn-sm" style="cursor:pointer">Log in as Admin</button>
            </div>
          </article>
          <div class="doc-footer">
            <span>IBM Case Intelligence Platform · BD/TOA-ETS5 · Internal</span>
          </div>
        </div>`;
        return;
      }

      let pageContent;
      try {
        pageContent = sec.content();
      } catch(e) {
        console.error('[Doc] content() error for', id, e);
        pageContent = `<div style="color:var(--red);padding:20px;font-family:var(--font-mono);font-size:12px">
          <strong>Page render error:</strong> ${e.message}<br>
          <small>Check browser console for details.</small>
        </div>`;
      }

      main.innerHTML = `<div style="max-width:860px">
        ${buildCrumbs(sec.crumbs)}
        <article>${pageContent}</article>
        <div class="doc-footer">
          <span>IBM Case Intelligence Platform · BD/TOA-ETS5 · Internal</span>
        </div>
      </div>`;
      // Mark active link
      document.querySelectorAll('.doc-link').forEach(a => {
        a.classList.toggle('doc-active', a.dataset.page === id);
      });
      // Scroll content to top
      const scroller = document.querySelector('.doc-body') || document.getElementById('doc-main');
      if (scroller) scroller.scrollTop = 0;
    }

    /* ── Search ───────────────────────────────────────────── */
    function runSearch(q) {
      q = (q || '').toLowerCase().trim();
      if (!q) { showPage(DEFAULT_PAGE); return; }
      const hits = [];
      Object.keys(SECTIONS).forEach(id => {
        const s = SECTIONS[id];
        const haystack = (s.title + ' ' + s.crumbs.join(' ')).toLowerCase();
        let body = '';
        try { body = s.content().replace(/<[^>]+>/g,' ').toLowerCase(); } catch(_) {}
        if (haystack.indexOf(q) !== -1 || body.indexOf(q) !== -1) hits.push(s);
      });
      const main = document.getElementById('doc-main');
      if (!main) return;
      if (!hits.length) {
        main.innerHTML = `<div style="max-width:860px"><p style="color:var(--text-tertiary);font-size:14px;margin-top:24px">No results for <strong>${q}</strong>.</p></div>`;
        return;
      }
      main.innerHTML = `<div style="max-width:860px">
        <p style="font-size:14px;font-weight:600;color:var(--text-primary);margin:0 0 14px">${hits.length} result${hits.length>1?'s':''} for "${q}"</p>
        ${hits.map(h=>`<div class="doc-hit" data-page="${Object.keys(SECTIONS).find(k=>SECTIONS[k]===h)}">
          <div style="font-weight:600;font-size:14px;color:var(--text-primary)">${h.title}</div>
          <div style="font-size:12px;color:var(--text-tertiary);margin-top:3px">${h.crumbs.join(' › ')}</div>
        </div>`).join('')}
      </div>`;
    }

    /* ── Wire events ─────────────────────────────────────── */
    function wireEvents() {
      // Nav links
      document.querySelectorAll('.doc-link').forEach(a => {
        a.addEventListener('click', ev => { ev.preventDefault(); showPage(a.dataset.page); });
      });
      // Group toggles
      document.querySelectorAll('.doc-grp-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          const items = btn.nextElementSibling;
          const chev  = btn.querySelector('.doc-grp-chev');
          const open  = items.style.display !== 'none';
          items.style.display = open ? 'none' : 'block';
          if (chev) chev.style.transform = open ? 'rotate(0deg)' : 'rotate(90deg)';
        });
      });
      // Search
      const inp = document.getElementById('doc-search');
      if (inp) {
        inp.addEventListener('input', () => {
          const v = inp.value.trim();
          if (v.length > 1) runSearch(v);
          else if (!v) showPage(DEFAULT_PAGE);
        });
        inp.addEventListener('keydown', ev => {
          if (ev.key === 'Escape') { inp.value = ''; showPage(DEFAULT_PAGE); }
        });
      }
      // Search result clicks
      const main = document.getElementById('doc-main');
      if (main) {
        main.addEventListener('click', ev => {
          const hit = ev.target.closest('.doc-hit');
          if (hit) showPage(hit.dataset.page);
        });
      }
      // Keep doc-shell left aligned with sidebar width (collapsed vs expanded)
      _watchSidebarCollapse();
    }

    function _watchSidebarCollapse() {
      // No-op: sidebar offset no longer needed since overlay is
      // position:absolute inside .main-content, not fixed on viewport.
    }

    /* ── Styles ───────────────────────────────────────────── */
    function injectCSS() {
      // Always remove and re-inject so stale styles from previous versions don't persist
      const existing = document.getElementById('doc-css');
      if (existing) existing.remove();
      const s = document.createElement('style');
      s.id = 'doc-css';
      s.textContent = `
        /* Doc overlay — absolute inside .main-area, clears 52px top-header */
        #doc-overlay {
          position: absolute;
          top: 52px;
          left: 0;
          right: 0;
          bottom: 0;
          z-index: 50;
          display: flex;
        }
        .doc-shell {
          width: 100%; height: 100%;
          display: flex;
          overflow: hidden;
          background: var(--bg-page, #f0f2f5);
          font-family: var(--font-sans, 'IBM Plex Sans', sans-serif);
        }
        /* Collapsed sidebar — shift overlay left edge */
        body.sidebar-collapsed #doc-overlay { left: 0; }
        .doc-sidebar {
          width:234px; flex-shrink:0; display:flex; flex-direction:column;
          background:var(--bg-ui,#fff); border-right:1px solid var(--border-subtle,#e4e7ed);
          overflow:hidden;
        }
        .doc-sidebar-top {
          padding:15px 15px 11px; border-bottom:1px solid var(--border-subtle); flex-shrink:0;
        }
        .doc-sidebar-label {
          font-size:10.5px; font-weight:700; color:var(--ibm-blue-50,#0f62fe);
          text-transform:uppercase; letter-spacing:.9px; margin-bottom:9px;
        }
        .doc-search-wrap { position:relative; }
        .doc-search-ico {
          position:absolute; left:8px; top:50%; transform:translateY(-50%);
          color:var(--text-tertiary); pointer-events:none;
        }
        #doc-search {
          width:100%; padding:6px 8px 6px 27px; font-size:12.5px;
          font-family:var(--font-sans,'IBM Plex Sans',sans-serif);
          border:1px solid var(--border-mid,#d0d3da); border-radius:5px;
          background:var(--bg-layer,#f4f4f4); color:var(--text-primary);
          outline:none; box-sizing:border-box; transition:border-color .14s;
        }
        #doc-search:focus { border-color:var(--ibm-blue-50,#0f62fe); background:var(--bg-ui,#fff); }
        #doc-search::placeholder { color:var(--text-tertiary); }
        .doc-nav { flex:1; overflow-y:auto; padding:6px 0 16px; scrollbar-width:thin; scrollbar-color:var(--border-mid) transparent; }
        .doc-grp-btn {
          width:100%; display:flex; align-items:center; gap:8px; padding:7px 14px;
          background:none; border:none; cursor:pointer; text-align:left;
          color:var(--text-secondary); transition:background .1s;
        }
        .doc-grp-btn:hover { background:var(--bg-hover,#eef1f6); }
        .doc-grp-ico { color:var(--text-tertiary); flex-shrink:0; }
        .doc-grp-lbl { flex:1; font-size:11.5px; font-weight:700; text-transform:uppercase; letter-spacing:.5px; }
        .doc-grp-chev { color:var(--text-tertiary); transition:transform .17s ease; flex-shrink:0; }
        .doc-link {
          display:block; padding:5px 14px 5px 34px; font-size:13px;
          color:var(--text-secondary); text-decoration:none;
          border-left:2px solid transparent; line-height:1.45;
          transition:background .1s, color .1s;
        }
        .doc-link:hover { background:var(--bg-hover,#eef1f6); color:var(--text-primary); }
        .doc-link.doc-active {
          background:var(--ibm-blue-10,#edf5ff); color:var(--ibm-blue-60,#0043ce);
          border-left-color:var(--ibm-blue-50,#0f62fe); font-weight:600;
        }
        .doc-body {
          flex:1; overflow-y:auto; padding:30px 40px 52px;
          scrollbar-width:thin; scrollbar-color:var(--border-mid) transparent;
        }
        .doc-crumbs { display:flex; align-items:center; gap:4px; margin-bottom:18px; flex-wrap:wrap; }
        .doc-crumb-seg { font-size:12px; color:var(--text-tertiary); }
        .doc-crumb-sep { font-size:12px; color:var(--text-tertiary); margin:0 2px; }
        .doc-crumb-cur { font-size:12px; color:var(--ibm-blue-50,#0f62fe); font-weight:600; }
        .doc-footer {
          margin-top:52px; padding-top:14px; border-top:1px solid var(--border-subtle);
          font-size:12px; color:var(--text-tertiary);
        }
        .doc-hit {
          border:1px solid var(--border-subtle); border-radius:6px; padding:12px 15px;
          margin-bottom:8px; background:var(--bg-ui); cursor:pointer; transition:background .1s;
        }
        .doc-hit:hover { background:var(--bg-hover,#eef1f6); }
      `;
      document.head.appendChild(s);
    }

    /* ── render() — entry point ─────────────────────────── */
    function render() {
      const container = document.getElementById('tab-documentation');
      if (!container) return;
      injectCSS();

      // Remove any previous overlay
      const prev = document.getElementById('doc-overlay');
      if (prev) prev.remove();

      // Mount on .main-area — height:100vh, overflow:hidden, position:relative.
      // Use top:52px to clear the fixed top-header.
      // This is the only reliable approach given the stacking context constraints.
      const mountPoint = document.querySelector('.main-area') || document.body;
      mountPoint.style.position = 'relative';

      const overlay = document.createElement('div');
      overlay.id = 'doc-overlay';
      overlay.style.cssText = 'display:flex;position:absolute;top:52px;left:0;right:0;bottom:0;z-index:50;';

      overlay.innerHTML = `
        <div class="doc-shell">
          <aside class="doc-sidebar">
            <div class="doc-sidebar-top">
              <div class="doc-sidebar-label">IIP Docs</div>
              <div class="doc-search-wrap">
                <span class="doc-search-ico">${ICON.search}</span>
                <input id="doc-search" type="search" placeholder="Search..." autocomplete="off">
              </div>
            </div>
            <nav class="doc-nav">${buildSidebar()}</nav>
          </aside>
          <div class="doc-body"><div id="doc-main"></div></div>
        </div>`;

      mountPoint.appendChild(overlay);
      container.innerHTML = '';

      showPage(DEFAULT_PAGE);
      wireEvents();
    }

    return { render };
  })();

  if (typeof window !== 'undefined') window.DashDocumentation = DashDocumentation;
}());


