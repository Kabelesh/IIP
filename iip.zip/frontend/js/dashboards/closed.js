/* ============================================================
   js/dashboards/closed.js  —  Closed Cases + Created Cases
   ============================================================ */

/* ── Shared CSS variable resolver (used by DashClosed and DashCreated) ── */
function _cssClr(v) {
  try { return getComputedStyle(document.documentElement).getPropertyValue(v).trim() || v; }
  catch(e) { return v; }
}

const DashClosed = (() => {
  /* ── Loading state helper ─────────────────────────────────────
     Usage: _setLoading(true) before data fetch, _setLoading(false) after.
     Applies .is-loading class to the dashboard root element.
  ────────────────────────────────────────────────────────────── */
  function _setLoading(active) {
    const el = document.getElementById('content-area') || document.body;
    el.classList.toggle('dashboard-loading', active);
    // Show/hide skeleton shimmer on tables
    document.querySelectorAll('.table-wrap, .dash-table').forEach(t => {
      t.classList.toggle('skeleton-loading', active);
    });
  }

  // Resolve CSS variable for Chart.js canvas context
  /* _cssClr defined at module scope below — accessible to both DashClosed and DashCreated */


  let _year = "", _month = "", _fromDate = "", _toDate = "", _lastDays = "";
  let _ownerFilter = "";
  let _customerFilter = "";
  let _tableRef = null;

  function render() {
    const el = document.getElementById("tab-closed");
    if (!el) return;
    // Destroy any live Chart instances before replacing the canvas elements,
    // otherwise Chart.js event listeners on detached canvases fire afterEvent
    // on a partially-torn-down chart and throw "Cannot read 'handleEvent'".
    el.querySelectorAll("canvas").forEach(c => {
      try { const ch = (typeof Chart !== "undefined" && Chart.getChart) ? Chart.getChart(c) : null; if (ch) ch.destroy(); } catch(e) {}
    });
    _tableRef = null; // reset so drawAll creates a fresh table instance
    el.innerHTML = `
      <div class="kpi-row" id="closed-kpi-row"></div>
      <div class="filter-bar mt-5">
        ${yearSelect("cl-year",_year)} ${monthSelect("cl-month",_month)}
        <div class="filter-group">
          <span class="filter-label">From</span>
          <input id="cl-from" type="date" class="form-input form-input-sm w-140" value="${_fromDate}"/>
        </div>
        <div class="filter-group">
          <span class="filter-label">To</span>
          <input id="cl-to" type="date" class="form-input form-input-sm w-140" value="${_toDate}"/>
        </div>
        <div class="filter-group">
          <span class="filter-label">Last N Days</span>
          <input id="cl-lastdays" type="number" class="form-input form-input-sm w-80" placeholder="e.g. 30" value="${_lastDays}"/>
        </div>
        <div class="filter-group">
          <span class="filter-label">Customer Number</span>
          <select id="cl-customer" class="form-select" style="min-width:140px">
            <option value="">All</option>
            ${[...new Set(Data.closedTeamCases().map(r => r["Customer number"] || "").filter(Boolean))].sort()
              .map(cn => `<option value="${cn}" ${_customerFilter===cn?"selected":""}>${cn}</option>`).join("")}
          </select>
        </div>
        <button id="cl-clear" class="btn btn-ghost btn-sm">Clear</button>
      </div>

      <!-- Charts grid -->
      <div class="grid-3 mt-5" id="cl-charts-grid">
        <div class="tile">
          <div class="section-title mt-0">Monthly Closed</div>
          <div class="chart-canvas-wrap chart-md"><canvas id="chart-closed-monthly"></canvas></div>
        </div>
        <div class="tile">
          <div class="section-title mt-0">Weekly Closed (Last 12w)</div>
          <div class="chart-canvas-wrap chart-md"><canvas id="chart-closed-weekly"></canvas></div>
        </div>
        <div class="tile">
          <div class="section-title mt-0">Yearly Closed</div>
          <div class="chart-canvas-wrap chart-md"><canvas id="chart-closed-yearly"></canvas></div>
          <div id="chart-yearly-legend" style="display:flex;flex-wrap:wrap;gap:4px 12px;justify-content:center;padding:6px 4px 0;font-size:11px;font-family:'IBM Plex Sans',sans-serif;"></div>
        </div>
      </div>

      <div class="tile mt-5">
        <div class="section-title">Owner vs Closed Cases Count</div>
        <div class="chart-canvas-wrap" style="height:350px"><canvas id="chart-closed-owners"></canvas></div>
      </div>
      <div class="tile mt-5">
        <div id="tbl-closed" data-title="Closed Cases"></div>
      </div>
    `;
    bindClosedFilters();
    try { drawAll(); } catch(e) {
      console.warn("[DashClosed] render error:", e);
      // Fallback: still render the table even if charts fail
      try {
        const tblEl = document.getElementById("tbl-closed");
        const cases = Data.closedTeamCases();
        if (tblEl && cases.length) Table.render(tblEl, cases, { showActions: false });
        else if (tblEl) tblEl.innerHTML = '<div style="padding:40px;text-align:center;color:var(--text-tertiary)">No closed cases found. Upload a CSV/Excel file to get started.</div>';
      } catch(e2) {}
    }
  }

  function filtered() {
    const today = new Date();
    return Data.closedTeamCases().filter(r => {
      // Use Closed Date only — never Updated (Updated ≠ closed date).
      // If Closed Date is absent fall back to Created purely for year/month
      // bucketing, but mark this as a data-quality gap, not a filter pass.
      const d = Utils.parseDate(r["Closed Date"]) || Utils.parseDate(r.Created);
      if (_year  && (!d || String(d.getFullYear()) !== _year)) return false;
      if (_month && (!d || String(d.getMonth()+1).padStart(2,"0") !== _month)) return false;
      if (_fromDate && (!d || d < new Date(_fromDate))) return false;
      if (_toDate   && (!d || d > new Date(_toDate + "T23:59:59"))) return false;
      if (_lastDays && _lastDays > 0) {
        const cutoff = new Date(today); cutoff.setDate(today.getDate() - parseInt(_lastDays, 10));
        if (!d || d < cutoff) return false;
      }
      if (_customerFilter) {
        const cf = _customerFilter.trim().toLowerCase();
        const cn = (r["Customer number"] || "").toLowerCase();
        if (!cn.includes(cf)) return false;
      }
      return true;
    });
  }

  function drawAll(ownerFilter) {
    if (ownerFilter !== undefined) _ownerFilter = ownerFilter;
    const cases = filtered();
    const tableData = _ownerFilter ? cases.filter(r => r.Owner === _ownerFilter) : cases;

    renderClosedKPIs(cases);

    // When Last N Days is active: auto-populate From/To/Year/Month to reflect the range
    const clLastDaysMode = !!(_lastDays && parseInt(_lastDays,10) > 0);
    const clGrid = document.getElementById("cl-charts-grid");
    if (clGrid) clGrid.style.display = clLastDaysMode ? "none" : "";
    if (clLastDaysMode) {
      const n = parseInt(_lastDays, 10);
      const toD   = new Date();
      const fromD = new Date(); fromD.setDate(toD.getDate() - n);
      const pad = v => String(v).padStart(2,"0");
      const toStr   = toD.getFullYear()+"-"+pad(toD.getMonth()+1)+"-"+pad(toD.getDate());
      const fromStr = fromD.getFullYear()+"-"+pad(fromD.getMonth()+1)+"-"+pad(fromD.getDate());
      const fromEl = document.getElementById("cl-from"); if (fromEl) fromEl.value = fromStr;
      const toEl   = document.getElementById("cl-to");   if (toEl)   toEl.value   = toStr;
      // Set year to the from-date year; set month to from-date month
      const yrEl = document.getElementById("cl-year");
      if (yrEl) yrEl.value = String(fromD.getFullYear());
      const moEl = document.getElementById("cl-month");
      if (moEl) moEl.value = pad(fromD.getMonth()+1);
    }

    if (!clLastDaysMode) { try { drawTrendCharts(cases); } catch(e) { console.warn("[DashClosed] drawTrendCharts error:", e); } }

    try {
      Charts.ownerBar("chart-closed-owners", Utils.ownerCounts(cases), {
        color: _cssClr("--chart-2"),
        onClick: name => {
          drawAll(name === _ownerFilter ? "" : name);
          document.getElementById("tbl-closed")?.scrollIntoView({ behavior:"smooth", block:"start" });
        }
      });
    } catch(e) { console.warn("[DashClosed] ownerBar error:", e); }

    const tblClosedEl = document.getElementById("tbl-closed");
    if (_tableRef) {
      _tableRef.refresh(tableData);
    } else {
      _tableRef = Table.render(tblClosedEl, tableData, {
      showActions: false,
      defaultSortKey: "Closed Date",
      defaultSortDir: 1,
      columns: [
        { key:"Case Number", label:"Case Number", class:"col-case-num",
          render: row => {
            const perfIcon = (typeof Data !== "undefined" && Data.isMarkedPerformance && Data.isMarkedPerformance(row["Case Number"]))
              ? `<span title="Performance Case" style="color:var(--red);margin-right:4px;display:inline-flex;align-items:center;vertical-align:middle"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg></span>`
              : "";
            const cn = Utils.escHtml(row["Case Number"]);
            return `${perfIcon}<span class="case-number-copy" data-cn="${cn}" title="Click to copy" style="cursor:pointer;color:#2563eb;font-weight:600;font-family:var(--font-mono)">${cn}</span>`;
          }},
        { key:"Owner", label:"Owner", class:"col-owner",
          render: row => Utils.escHtml(Utils.shortName(row.Owner)) },
        { key:"Status", label:"Status",
          render: row => Utils.statusBadge(row.Status) },
        { key:"Product", label:"Product", class:"col-product",
          render: row => `<span title="${Utils.escHtml(row.Product)}">${Utils.escHtml(row.Product)}</span>` },
        { key:"Customer number", label:"Customer #", class:"col-date text-mono",
          render: row => Utils.escHtml(row["Customer number"] || "—") },
        { key:"Closed Date", label:"Closed Date", class:"col-date",
          sortValue: row => { const d = Utils.parseDate(row["Closed Date"]); return d ? d.getTime() : 0; },
          render: row => Utils.fmtDateShort(row["Closed Date"]) },
        { key:"Updated", label:"Updated", class:"col-stale",
          render: row => {
            const d    = Utils.parseDate(row.Updated);
            const days = Utils.daysDiff(d);
            return `<span style="color:${days>=5?_cssClr("--red"):_cssClr("--text-tertiary")}">${Utils.fmtDateShort(row.Updated)}</span>`
                 + (days >= 5 ? ` <span class="stale-days">(+${days}d)</span>` : "");
          }},
        { key:"Severity", label:"Severity", class:"col-sev",
          render: row => {
            const s = String(row.Severity||"").trim();
            const col = s.startsWith("1") ? _cssClr("--red") : s.startsWith("2") ? _cssClr("--orange") : s.startsWith("3") ? _cssClr("--yellow") : _cssClr("--text-tertiary");
            return `<span style="font-weight:700;color:${col};font-family:var(--font-mono)">${Utils.escHtml(s||"—")}</span>`;
          }},
        { key:"Age", label:"Age (days)", class:"col-age text-mono",
          render: row => {
            const a = parseInt(row.Age||"0", 10);
            return `<span style="font-family:var(--font-mono);color:${a>30?_cssClr("--red"):a>14?_cssClr("--orange"):_cssClr("--text-tertiary")}">${a > 0 ? a + "d" : "—"}</span>`;
          }},
        { key:"Title", label:"Title", class:"col-title", sortable:false,
          render: row => `<span title="${Utils.escHtml(row.Title)}">${Utils.escHtml(row.Title)}</span>` }
      ]
    });
    }
  }

  function drawTrendCharts(cases) {
    const byMonth = {}, byWeek = {}, byYear = {};
    cases.forEach(r => {
      const d = Utils.parseDate(r["Closed Date"]) || Utils.parseDate(r.Updated);
      if (!d) return;
      const mKey = `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}`;
      byMonth[mKey] = (byMonth[mKey] || 0) + 1;
      const wKey = isoWeekKey(d);
      byWeek[wKey] = (byWeek[wKey] || 0) + 1;
      const yKey = String(d.getFullYear());
      byYear[yKey] = (byYear[yKey] || 0) + 1;
    });

    // Monthly — gradient area chart
    const allMonths = Object.keys(byMonth).sort().slice(-18);
    _drawAreaChart("chart-closed-monthly",
      allMonths.map(k => k.slice(5) + "/" + k.slice(0,4)),
      allMonths.map(k => byMonth[k]),
      label => {
        const [mm, yyyy] = label.split("/");
        _fromDate = yyyy+"-"+mm+"-01";
        const lastDay = new Date(parseInt(yyyy), parseInt(mm), 0).getDate();
        _toDate = yyyy+"-"+mm+"-"+String(lastDay).padStart(2,"0");
        _year = yyyy; _month = mm; _lastDays = "";
        ["cl-year","cl-month","cl-from","cl-to","cl-lastdays"].forEach(id => {
          const el = document.getElementById(id);
          if (!el) return;
          if (id==="cl-year") el.value = yyyy;
          else if (id==="cl-month") el.value = mm;
          else if (id==="cl-from") el.value = _fromDate;
          else if (id==="cl-to") el.value = _toDate;
          else el.value = "";
        });
        _ownerFilter = ""; drawAll();
        document.getElementById("tbl-closed")?.scrollIntoView({ behavior:"smooth", block:"start" });
      });

    // Weekly — gradient rounded bars (blue → teal)
    const allWeeks = Object.keys(byWeek).sort().slice(-12);
    _drawGradientBars("chart-closed-weekly",
      allWeeks.map(k => k.replace("W","W")),
      allWeeks.map(k => byWeek[k]),
      label => {
        const wkKey = allWeeks.find(k => k === label) || label;
        if (!wkKey) return;
        const [yr, wn] = wkKey.split("-W");
        const jan1 = new Date(parseInt(yr), 0, 1);
        const startOfWk = new Date(jan1);
        startOfWk.setDate(jan1.getDate() + (parseInt(wn)-1)*7 - jan1.getDay());
        const endOfWk = new Date(startOfWk); endOfWk.setDate(startOfWk.getDate()+6);
        const fmt = d => d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"00")+"-"+String(d.getDate()).padStart(2,"00");
        _fromDate = fmt(startOfWk); _toDate = fmt(endOfWk);
        _year = ""; _month = ""; _lastDays = "";
        ["cl-year","cl-month","cl-lastdays"].forEach(id => { const el=document.getElementById(id); if(el) el.value=""; });
        const fromEl=document.getElementById("cl-from"); if(fromEl) fromEl.value=_fromDate;
        const toEl=document.getElementById("cl-to"); if(toEl) toEl.value=_toDate;
        _ownerFilter = ""; drawAll();
        document.getElementById("tbl-closed")?.scrollIntoView({ behavior:"smooth", block:"start" });
      });

    // Yearly — polar area chart
    const allYears = Object.keys(byYear).sort();
    _drawPolarArea("chart-closed-yearly",
      allYears,
      allYears.map(k => byYear[k]),
      label => {
        _year = label; _month = ""; _fromDate = ""; _toDate = ""; _lastDays = "";
        ["cl-year","cl-month","cl-from","cl-to","cl-lastdays"].forEach(id => {
          const el=document.getElementById(id); if (!el) return;
          el.value = id==="cl-year" ? label : "";
        });
        _ownerFilter = ""; drawAll();
        document.getElementById("tbl-closed")?.scrollIntoView({ behavior:"smooth", block:"start" });
      });
  }

  function isoWeekKey(d) {
    // Sunday-based week numbering (W01 = week containing Jan 1).
    // Matches _isoWeek() in weekly-tracker.js so Dec 28-31 stays in the same year as Jan 1.
    const yr = d.getFullYear();
    const jan1Day = new Date(yr, 0, 1).getDay(); // 0=Sun
    const w1Sun = new Date(yr, 0, 1 - jan1Day);  // Sunday on or before Jan 1
    const target = new Date(yr, d.getMonth(), d.getDate());
    if (target < w1Sun) return isoWeekKey(new Date(yr - 1, 11, 31));
    const wk = Math.floor((target - w1Sun) / (7 * 86400000)) + 1;
    return `${yr}-W${String(wk).padStart(2, "0")}`;
  }

  /* ── Area chart: smooth gradient fill (monthly trend) ─── */
  function _drawAreaChart(canvasId, labels, data, onPointClick) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;
    if (typeof Chart === "undefined") { setTimeout(() => _drawAreaChart(canvasId, labels, data, onPointClick), 200); return; }
    try { const ex = Chart.getChart ? Chart.getChart(canvas) : null; if (ex) ex.destroy(); } catch(e) {}

    const ctx2d = canvas.getContext("2d");
    const grad = ctx2d.createLinearGradient(0, 0, 0, canvas.offsetHeight || 220);
    grad.addColorStop(0,   "rgba(69,137,255,0.38)");
    grad.addColorStop(0.6, "rgba(69,137,255,0.10)");
    grad.addColorStop(1,   "rgba(69,137,255,0.00)");

    try { new Chart(canvas, {
      type: "line",
      data: {
        labels,
        datasets: [{
          data,
          borderColor: "#4589FF",
          backgroundColor: grad,
          borderWidth: 2.5,
          pointRadius: data.length > 12 ? 2 : 4,
          pointHoverRadius: 6,
          pointBackgroundColor: "#4589FF",
          pointBorderColor: "#fff",
          pointBorderWidth: 2,
          tension: 0.4,
          fill: true
        }]
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: "#fff", borderColor: _cssClr("--border-subtle"), borderWidth: 1,
            titleColor: _cssClr("--text-primary"), bodyColor: _cssClr("--text-secondary"),
            callbacks: { label: item => ` ${item.raw} cases — click to filter` }
          }
        },
        scales: {
          x: { grid: { display: false }, border: { display: false }, ticks: { color: _cssClr("--text-tertiary"), font: { size: 10 }, maxRotation: 45 } },
          y: { grid: { color: "rgba(0,0,0,0.05)", drawTicks: false }, border: { display: false },
               ticks: { color: _cssClr("--text-tertiary"), font: { size: 11 }, padding: 8 }, beginAtZero: true }
        },
        onClick: onPointClick ? (evt, elements) => {
          if (elements.length) {
            const label = labels[elements[0].index];
            setTimeout(() => { try { onPointClick(label); } catch(e) { console.warn("[DashClosed] Area chart onClick:", e); } }, 0);
          }
        } : undefined
      }
    }); } catch(e) { console.warn("[DashClosed] Area chart error:", e); }
    if (onPointClick) canvas.style.cursor = "pointer";
  }

  /* ── Gradient rounded bars: blue → teal (weekly) ────── */
  function _drawGradientBars(canvasId, labels, data, onBarClick) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;
    if (typeof Chart === "undefined") { setTimeout(() => _drawGradientBars(canvasId, labels, data, onBarClick), 200); return; }
    try { const ex = Chart.getChart ? Chart.getChart(canvas) : null; if (ex) ex.destroy(); } catch(e) {}

    const n = labels.length;
    const colors = labels.map((_, i) => {
      const t = n > 1 ? i / (n - 1) : 0;
      const r = Math.round(0x45 + (0x00 - 0x45) * t);
      const g = Math.round(0x89 + (0xBE - 0x89) * t);
      const b = Math.round(0xFF + (0x65 - 0xFF) * t);
      return `rgba(${r},${g},${b},0.85)`;
    });

    try { new Chart(canvas, {
      type: "bar",
      data: {
        labels,
        datasets: [{
          data,
          backgroundColor: colors,
          hoverBackgroundColor: colors.map(c => c.replace("0.85","1")),
          borderRadius: 7,
          borderSkipped: false
        }]
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: "#fff", borderColor: _cssClr("--border-subtle"), borderWidth: 1,
            titleColor: _cssClr("--text-primary"), bodyColor: _cssClr("--text-secondary"),
            callbacks: { label: item => ` ${item.raw} cases — click to filter` }
          }
        },
        scales: {
          x: { grid: { display: false }, border: { display: false }, ticks: { color: _cssClr("--text-tertiary"), font: { size: 10 }, maxRotation: 0 } },
          y: { grid: { color: "rgba(0,0,0,0.05)", drawTicks: false }, border: { display: false },
               ticks: { color: _cssClr("--text-tertiary"), font: { size: 11 }, padding: 8 }, beginAtZero: true }
        },
        onClick: onBarClick ? (evt, elements) => {
          if (elements.length) {
            const label = labels[elements[0].index];
            setTimeout(() => { try { onBarClick(label); } catch(e) { console.warn("[DashClosed] Gradient bars onClick:", e); } }, 0);
          }
        } : undefined
      }
    }); } catch(e) { console.warn("[DashClosed] Gradient bars error:", e); }
    if (onBarClick) canvas.style.cursor = "pointer";
  }

  /* ── Modern donut chart with stable HTML legend (yearly comparison) ─────────── */
  function _drawPolarArea(canvasId, labels, data, onClick) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;
    if (typeof Chart === "undefined") { setTimeout(() => _drawPolarArea(canvasId, labels, data, onClick), 200); return; }
    try { const ex = Chart.getChart ? Chart.getChart(canvas) : null; if (ex) ex.destroy(); } catch(e) {}

    const palette = ["#4589FF","#42BE65","#8A3FFC","#F1C21B","#FF832B","#33B1FF","#FA4D56","#08BDBA"];
    const total = data.reduce((s, v) => s + v, 0);
    // Track visibility state per index (all visible initially)
    const visible = labels.map(() => true);
    let visibleTotal = total;

    // Centre-text plugin — draws visibleTotal inside the donut hole (updates on toggle)
    const centerTextPlugin = {
      id: "donutCenter",
      afterDraw(chart) {
        const { ctx, chartArea: { left, right, top, bottom } } = chart;
        const cx = (left + right) / 2;
        const cy = (top + bottom) / 2;
        ctx.save();
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.font = `700 ${Math.max(18, Math.min(26, (right - left) * 0.13))}px 'IBM Plex Sans',sans-serif`;
        ctx.fillStyle = _cssClr("--text-primary") || "#161616";
        ctx.fillText(visibleTotal.toLocaleString(), cx, cy - 8);
        ctx.font = `400 11px 'IBM Plex Sans',sans-serif`;
        ctx.fillStyle = _cssClr("--text-tertiary") || "#6f6f6f";
        ctx.fillText("Total Cases", cx, cy + 12);
        ctx.restore();
      }
    };

    let chartInst;
    try { chartInst = new Chart(canvas, {
      type: "doughnut",
      data: {
        labels,
        datasets: [{
          data,
          backgroundColor: labels.map((_, i) => palette[i % palette.length] + "dd"),
          borderColor: labels.map((_, i) => palette[i % palette.length]),
          borderWidth: 2.5,
          hoverBackgroundColor: labels.map((_, i) => palette[i % palette.length]),
          hoverBorderWidth: 0,
          hoverOffset: 8
        }]
      },
      plugins: [centerTextPlugin],
      options: {
        responsive: true, maintainAspectRatio: false,
        cutout: "62%",
        animation: { animateRotate: true, animateScale: false, duration: 700, easing: "easeOutQuart" },
        interaction: { mode: "nearest", intersect: true },
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: "#fff", borderColor: _cssClr("--border-subtle"), borderWidth: 1,
            titleColor: _cssClr("--text-primary"), bodyColor: _cssClr("--text-secondary"),
            padding: 10, cornerRadius: 8,
            callbacks: {
              label: item => {
                const pct = total ? ((item.raw / total) * 100).toFixed(1) : 0;
                return `  ${item.raw} cases (${pct}%) — click to filter`;
              }
            }
          }
        },
        ...(onClick ? { onClick: (evt, elements) => { if (elements.length) { const _l = labels[elements[0].index]; setTimeout(() => { try { onClick(_l); } catch(e){} }, 0); } } } : {})
      }
    }); } catch(e) { console.warn("[DashClosed] Donut chart error:", e); }

    // ── Custom stable HTML legend (never reflows the canvas) ──
    const legendEl = document.getElementById("chart-yearly-legend");
    if (legendEl && chartInst) {
      legendEl.innerHTML = labels.map((lbl, i) => {
        const color = palette[i % palette.length];
        return `<span data-idx="${i}" style="display:inline-flex;align-items:center;gap:4px;cursor:pointer;user-select:none;white-space:nowrap;">
          <span class="yl-swatch" style="display:inline-block;width:10px;height:10px;border-radius:2px;background:${color};flex-shrink:0;"></span>
          <span class="yl-text" style="color:${_cssClr("--text-primary")||"#161616"};">${lbl} (${data[i].toLocaleString()})</span>
        </span>`;
      }).join("");

      legendEl.querySelectorAll("span[data-idx]").forEach(item => {
        item.addEventListener("click", () => {
          const i = parseInt(item.dataset.idx);
          visible[i] = !visible[i];
          chartInst.toggleDataVisibility(i);
          visibleTotal = data.reduce((s, v, idx) => s + (visible[idx] ? v : 0), 0);
          chartInst.update();
          // Update swatch + text style in-place (no reflow)
          const swatch = item.querySelector(".yl-swatch");
          const text   = item.querySelector(".yl-text");
          const color  = palette[i % palette.length];
          swatch.style.background   = visible[i] ? color : "transparent";
          swatch.style.border       = visible[i] ? "none" : `1.5px solid ${color}`;
          text.style.color          = visible[i] ? (_cssClr("--text-primary")||"#161616") : (_cssClr("--text-tertiary")||"#6f6f6f");
          text.style.textDecoration = visible[i] ? "none" : "line-through";
        });
      });
    }

    if (onClick) canvas.style.cursor = "pointer";
  }

  function bindClosedFilters() {
    document.getElementById("cl-year")?.addEventListener("change", e => { _year=e.target.value; _ownerFilter=""; drawAll(); });
    document.getElementById("cl-month")?.addEventListener("change", e => { _month=e.target.value; _ownerFilter=""; drawAll(); });
    document.getElementById("cl-from")?.addEventListener("change", e => { _fromDate=e.target.value; _year=""; _month=""; document.getElementById("cl-year").value=""; document.getElementById("cl-month").value=""; _ownerFilter=""; drawAll(); });
    document.getElementById("cl-to")?.addEventListener("change", e => { _toDate=e.target.value; _year=""; _month=""; document.getElementById("cl-year").value=""; document.getElementById("cl-month").value=""; _ownerFilter=""; drawAll(); });
    document.getElementById("cl-lastdays")?.addEventListener("input", e => { _lastDays=e.target.value; _year=""; _month=""; _fromDate=""; _toDate=""; ["cl-year","cl-month","cl-from","cl-to"].forEach(id => { const el=document.getElementById(id); if(el) el.value=""; }); _ownerFilter=""; drawAll(); });
    document.getElementById("cl-customer")?.addEventListener("change", e => { _customerFilter=e.target.value; _ownerFilter=""; drawAll(); });
    document.getElementById("cl-clear")?.addEventListener("click", () => {
      _year=""; _month=""; _fromDate=""; _toDate=""; _lastDays=""; _ownerFilter=""; _customerFilter=""; _customerFilter="";
      ["cl-year","cl-month","cl-from","cl-to","cl-lastdays","cl-customer"].forEach(id => { const el=document.getElementById(id); if(el) el.value=""; });
      StateManager.clearFiltersForDashboard("closed");
      drawAll();
    });
  }

  function renderClosedKPIs(cases) {
    const row = document.getElementById("closed-kpi-row");
    if (!row) return;
    const today = new Date();
    const acc02 = cases.filter(r => (r["Customer number"]||"").replace(/^0+/,"").startsWith("2"));
    const acc08 = cases.filter(r => (r["Customer number"]||"").includes(Data.customerAccountId()));
    const closedByIbm = cases.filter(r => r.Status === "Closed by IBM");
    const closedByClient = cases.filter(r => r.Status === "Closed by Client");
    const closed7d = cases.filter(r => {
      const d = Utils.parseDate(r["Closed Date"]) || Utils.parseDate(r.Updated);
      return d && (today - d) / 86400000 <= 7;
    });
    const avgAge = cases.length > 0
      ? Math.round(cases.reduce((sum, r) => sum + (parseInt(r.Age || "0", 10)), 0) / cases.length)
      : 0;
    row.innerHTML = [
      kpi("Total Closed", cases.length,  ""),
      kpi("Closed (Last 7d)", closed7d.length, "kpi-green"),
      kpi("02 Account",   acc02.length,  "kpi-blue"),
      kpi("08 Account",   acc08.length,  "kpi-purple"),
      kpi("Avg Days", avgAge + "d", "kpi-yellow"),
    ].join("");
  }

  function kpi(label, value, cls) {
    return `<div class="kpi-card ${cls}"><div class="kpi-label">${label}</div><div class="kpi-value">${value}</div></div>`;
  }

  /* ── Shared filter helpers (self-contained so closed.js has no external deps) ── */
  function yearSelect(id, selected) {
    const yearsFromData = (() => {
      try {
        const all = Data.allCases();
        const ySet = new Set();
        all.forEach(r => {
          // Only include years that have actual closed cases
          const CLOSED_STATUSES = new Set(["Closed by IBM","Closed by Client","Closed - Archived","Cancelled"]);
          if (!CLOSED_STATUSES.has(r.Status || "")) return;
          const v = (r["Closed Date"] || r["Updated"] || "").trim();
          if (!v) return;
          const d = Utils.parseDate(v);
          if (d && !isNaN(d)) ySet.add(d.getFullYear());
        });
        return [...ySet].sort();
      } catch(e) { return [2023, 2024, 2025, 2026]; }
    })();
    const opts = yearsFromData.map(y =>
      `<option value="${y}" ${String(y)===String(selected)?"selected":""}>${y}</option>`).join("");
    return `<div class="filter-group"><span class="filter-label">Year</span>
      <select id="${id}" class="form-select w-100">
        <option value="">All</option>${opts}</select></div>`;
  }

  function monthSelect(id, selected) {
    const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    const opts = months.map((m,i) => {
      const v = String(i+1).padStart(2,"0");
      return `<option value="${v}" ${v===selected?"selected":""}>${m}</option>`;
    }).join("");
    return `<div class="filter-group"><span class="filter-label">Month</span>
      <select id="${id}" class="form-select w-100">
        <option value="">All</option>${opts}</select></div>`;
  }


    return { render };
})();
