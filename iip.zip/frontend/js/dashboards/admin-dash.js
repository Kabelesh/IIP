/* ============================================================
   js/dashboards/admin-dash.js  —  Admin Console
   ============================================================ */
const DashAdmin = (() => {
  // On file://, use sessionStorage to avoid the empty-namespace isolation issue.

  /* ── Loading state helper ─────────────────────────────────────
     Usage: _setLoading(true) before data fetch, _setLoading(false) after.
     Applies .is-loading class to the dashboard root element.
  ────────────────────────────────────────────────────────────── */
  function _setLoading(active) {
    const el = document.getElementById('content-area') || document.body;
    el.classList.toggle('dashboard-loading', active);
    // Show/hide skeleton shimmer on tables
    document.querySelectorAll('.table-wrap, .dash-table').forEach(t => {
      t.classList.toggle('skeleton-loading', active);
    });
  }


  let _search        = "";
  let _historySearch = "";
  let _auditLogRows  = []; // DB-sourced rows; populated when history panel loads
  let _bulkSource    = "";
  let _bulkTarget    = "";
  let _adminDirty    = false; // F13: tracks unsaved admin changes
  let _xlsxImportRows = []; // Excel reassignment import rows — module scope so render() doesn't reset it
  let _bulkCaseFilter = "active"; // "all" | "active" | "closed"

  // F13: Show/hide orange dot on Admin nav item when unsaved changes exist
  function _setDirty(isDirty) {
    _adminDirty = isDirty;
    const navBtn = document.getElementById("nav-admin-portal");
    if (!navBtn) return;
    let dot = navBtn.querySelector(".admin-dirty-dot");
    if (isDirty) {
      if (!dot) {
        dot = document.createElement("span");
        dot.className = "admin-dirty-dot";
        dot.style.cssText = "display:inline-block;width:7px;height:7px;background:var(--orange);border-radius:50%;margin-left:4px;vertical-align:middle";
        dot.title = "Unsaved admin changes";
        navBtn.appendChild(dot);
      }
    } else {
      dot?.remove();
    }
  }

  /* ── Single-colour SVG icon set ─────────────────────── */
  const IC = {
    tag:    `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.59 13.41l-7.17 7.17a2 2 0 01-2.83 0L2 12V2h10l8.59 8.59a2 2 0 010 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/></svg>`,
    reassign:`<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 014-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 01-4 4H3"/></svg>`,
    search: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>`,
    history:`<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>`,
    undo:   `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 102.13-9.36L1 10"/></svg>`,
    redo:   `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 11-2.12-9.36L23 10"/></svg>`,
    trash:  `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>`,
    plus:   `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>`,
    upload: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>`,
    chevron:`<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>`,
    dot:    `<svg width="8" height="8" viewBox="0 0 8 8"><circle cx="4" cy="4" r="3" fill="currentColor"/></svg>`,
    arrow:  `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>`,
    perf:   `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>`,
    check:  `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>`,
    select: `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="4" height="4" rx="1"/><rect x="3" y="10" width="4" height="4" rx="1"/><rect x="3" y="17" width="4" height="4" rx="1"/><line x1="10" y1="5" x2="21" y2="5"/><line x1="10" y1="12" x2="21" y2="12"/><line x1="10" y1="19" x2="21" y2="19"/></svg>`,
    shield:`<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>`,
    warn:  `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>`,
    save:  `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>`,
    close: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>`,
    link:  `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 007.54.54l3-3a5 5 0 00-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 00-7.54-.54l-3 3a5 5 0 007.07 7.07l1.71-1.71"/></svg>`,
    download:`<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="3" x2="12" y2="15"/></svg>`,
    pkg:    `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="16.5" y1="9.4" x2="7.5" y2="4.21"/><path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 002 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>`,
  };

  const DEFECT_BASE_URL = (typeof Config !== "undefined" && Config.DEFECT_BASE_URL) ? Config.DEFECT_BASE_URL : "";

  function adminWiLink(raw) {
    if (!raw) return "";
    const s = raw.trim();
    // URL with id= param
    const urlM = s.match(/[?&#]id=(\d+)/i);
    if (urlM) return _wiTag(urlM[1], "defect");
    // Task NNNNN
    const taskM = s.match(/^Task\s*(\d+)$/i);
    if (taskM) return _wiTag(taskM[1], "task");
    // Defect NNNNN
    const defM = s.match(/(?:Defect\s*|defect\s*)(\d+)/i);
    if (defM) return _wiTag(defM[1], "defect");
    // Plain number
    if (/^\d+$/.test(s)) return _wiTag(s, "defect");
    return `<span class="text-meta">${Utils.escHtml(s)}</span>`;
  }

  function _wiTag(id, type) {
    const isTask = type === "task";
    const bg     = isTask ? "var(--purple-bg)"    : "var(--ibm-blue-10)";
    const fg     = isTask ? "var(--purple)"        : "var(--ibm-blue-50)";
    const border = isTask ? "rgba(105,41,196,0.2)" : "rgba(15,98,254,0.2)";
    const label  = isTask ? `T.${id}` : `D.${id}`;
    const title  = isTask ? `Open Task ${id} in CCM` : `Open Defect ${id} in CCM`;
    return `<a href="${DEFECT_BASE_URL}${id}" target="_blank"
      style="font-size:10px;color:${fg};font-family:var(--font-mono);font-weight:600;text-decoration:none;
             background:${bg};padding:1px 5px;border-radius:var(--radius-xs);border:1px solid ${border}"
      title="${title}">${Utils.escHtml(label)}</a>`;
  }

  /* ── Toast — delegates to IIPToast (unified toast system) ── */
  function showToast(msg, type, title) {
    type = type || "success";
    // F13: Clear dirty indicator on successful saves
    if (type === "success") _setDirty(false);

    // Map legacy "danger" to IIPToast "error"
    const iipType = type === "danger" ? "error" : type;

    if (typeof IIPToast !== "undefined") {
      const defaultTitles = { success:"Saved", error:"Error", warning:"Warning", info:"Info" };
      IIPToast.show(title || defaultTitles[iipType] || "Notice", msg, iipType);
      return;
    }

    // Fallback (IIPToast not yet loaded)
    let container = document.getElementById("atl-toast-container");
    if (!container) {
      container = document.createElement("div");
      container.id = "atl-toast-container";
      container.style.cssText = "position:fixed;bottom:24px;right:24px;z-index:9999;display:flex;flex-direction:column;gap:8px;pointer-events:none";
      document.body.appendChild(container);
    }
    const toast = document.createElement("div");
    toast.style.cssText = `display:flex;align-items:center;gap:10px;padding:11px 16px;
      background:var(--bg-ui);border:1px solid var(--border-subtle);
      border-radius:var(--radius-md);box-shadow:var(--shadow-md);
      font-size:13px;font-weight:500;pointer-events:auto;max-width:340px;`;
    toast.innerHTML = `<span class="flex-1">${msg}</span>`;
    container.appendChild(toast);
    setTimeout(() => { toast.style.opacity="0"; toast.style.transition="opacity .3s"; setTimeout(() => toast.remove(), 300); }, 3000);
  }

  /* F51: Persistent error banner for failed saves — stays until dismissed */
  function showSaveBanner(msg, retryFn) {
    const existingBanner = document.getElementById('admin-save-error-banner');
    if (existingBanner) existingBanner.remove();
    const banner = document.createElement('div');
    banner.id = 'admin-save-error-banner';
    banner.style.cssText = 'position:fixed;top:0;left:0;right:0;z-index:9998;padding:10px 20px;background:var(--red);color:#fff;font-size:13px;font-weight:500;display:flex;align-items:center;gap:12px;box-shadow:0 2px 12px rgba(0,0,0,.3)';
    banner.innerHTML = `
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" style="flex-shrink:0"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
      <span class="flex-1">${msg}</span>
      ${retryFn ? `<button id="admin-banner-retry" aria-label="Retry connection" class="btn btn-overlay btn-sm">Retry</button>` : ''}
      <button id="admin-banner-dismiss" aria-label="Dismiss notification" class="btn-remove" style="background:transparent;color:#fff" title="Dismiss">×</button>
    `;
    document.body.appendChild(banner);
    document.getElementById('admin-banner-dismiss')?.addEventListener('click', () => banner.remove());
    if (retryFn) document.getElementById('admin-banner-retry')?.addEventListener('click', async () => { banner.remove(); await retryFn(); });
  }

  /* F51: Wraps DC.save — shows persistent red banner on failure */
  async function _dcSave(payload, retryFn) {
    const DC = (typeof DynamicConfig !== "undefined") ? DynamicConfig : null;
    if (!DC) return;
    try {
      await DC.save(payload);
      /* Clear any lingering save error banner on success */
      document.getElementById('admin-save-error-banner')?.remove();
    } catch (err) {
      showSaveBanner(`⚠ Save failed — server unreachable. Your changes are stored locally but not synced. (${err.message || 'Network error'})`, retryFn);
      throw err; /* Re-throw so callers can opt-out of success toast */
    }
  }

  // ── Upload and restore app-data.js ─────────────────────────────────────────
  function _uploadAppDataJs(file) {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const content = e.target.result;

        // Create a sandbox to execute the file and extract AppData
        let appDataObj = null;
        try {
          // Use Function constructor so the file's `const AppData` lives in its own scope
          const extractFn = new Function(`${content}\nreturn (typeof AppData !== "undefined") ? AppData : null;`);
          appDataObj = extractFn();
        } catch (evalErr) {
          // If eval fails, try JSON extraction fallback
          throw new Error(`Failed to parse file: ${evalErr.message}`);
        }

        if (!appDataObj || typeof appDataObj !== "object") {
          throw new Error("Invalid app-data.js format — could not extract AppData object");
        }

        const AD = (typeof AppData !== "undefined") ? AppData : null;
        if (!AD) {
          throw new Error("AppData not available in application");
        }

        // Restore configuration
        if (appDataObj.config && typeof appDataObj.config === "object") {
          Object.assign(AD.config, appDataObj.config);
          localStorage.setItem("admin-cfg", JSON.stringify(AD.config));
        }

        // Restore team members and emails
        if (appDataObj.teamMembers && Array.isArray(appDataObj.teamMembers)) {
          AD.teamMembers.length = 0;
          appDataObj.teamMembers.forEach(m => AD.teamMembers.push(m));
        }

        if (appDataObj.teamEmails && typeof appDataObj.teamEmails === "object") {
          Object.keys(AD.teamEmails).forEach(k => delete AD.teamEmails[k]);
          Object.assign(AD.teamEmails, appDataObj.teamEmails);
        }

        // Restore expertise connect
        if (appDataObj.expertiseConnect && Array.isArray(appDataObj.expertiseConnect)) {
          AD.expertiseConnect.length = 0;
          appDataObj.expertiseConnect.forEach(m => AD.expertiseConnect.push(m));
        }

        // Restore escalation contacts
        if (appDataObj.bdEscalation && Array.isArray(appDataObj.bdEscalation)) {
          AD.bdEscalation.length = 0;
          appDataObj.bdEscalation.forEach(m => AD.bdEscalation.push(m));
        }

        if (appDataObj.teamLead && Array.isArray(appDataObj.teamLead)) {
          AD.teamLead.length = 0;
          appDataObj.teamLead.forEach(m => AD.teamLead.push(m));
        }

        // Restore customer contacts
        if (appDataObj.customerContacts && Array.isArray(appDataObj.customerContacts)) {
          AD.customerContacts.length = 0;
          appDataObj.customerContacts.forEach(c => AD.customerContacts.push(c));
        }

        // Restore ALM responsible
        if (appDataObj.almResponsible && Array.isArray(appDataObj.almResponsible)) {
          AD.almResponsible.length = 0;
          appDataObj.almResponsible.forEach(r => AD.almResponsible.push(r));
        }

        // Restore IBM directory
        if (appDataObj.ibmDirectory && typeof appDataObj.ibmDirectory === "object") {
          Object.keys(AD.ibmDirectory).forEach(k => delete AD.ibmDirectory[k]);
          Object.assign(AD.ibmDirectory, appDataObj.ibmDirectory);
        }

        // Restore performance case tags
        if (appDataObj.performanceCases && Array.isArray(appDataObj.performanceCases)) {
          if (typeof Data !== "undefined" && Data.setPerfCaseNums) {
            Data.setPerfCaseNums(appDataObj.performanceCases);
          }
        }

        if (appDataObj.nonPerformanceCases && Array.isArray(appDataObj.nonPerformanceCases)) {
          if (typeof Data !== "undefined" && Data.setNonPerfCaseNums) {
            Data.setNonPerfCaseNums(appDataObj.nonPerformanceCases);
          }
        }

        if (appDataObj.performanceMeta && typeof appDataObj.performanceMeta === "object") {
          if (typeof Data !== "undefined" && Data.setPerformanceMeta) {
            // setPerformanceMeta(caseNum, patch) — must iterate, not pass whole map
            Object.entries(appDataObj.performanceMeta).forEach(([cn, meta]) => {
              Data.setPerformanceMeta(cn, meta);
            });
          }
        }

        // Restore Performance Dashboard case detail logs (wednesdayComments, caseInfo)
        if (appDataObj.performanceDashboardComments && typeof appDataObj.performanceDashboardComments === "object") {
          // Restore into live Data module so persistence flows through IIPStore
          if (typeof Data !== "undefined" && Data.setCaseDetailLog) {
            Object.entries(appDataObj.performanceDashboardComments).forEach(([cn, log]) => {
              Data.setCaseDetailLog(cn, log);
            });
          }
          // Also write to ibm_perf_comments_v1 for backward compatibility
          localStorage.setItem("ibm_perf_comments_v1", JSON.stringify(appDataObj.performanceDashboardComments));
        }

        // Restore audit & change history
        if (appDataObj.changeHistory && Array.isArray(appDataObj.changeHistory)) {
          if (typeof Data !== "undefined" && Data.restoreChangeHistory) {
            Data.restoreChangeHistory(appDataObj.changeHistory);
          }
        }

        // Restore all dashboard data (Weekly Tracker, Info, Knowledge Base, Safety Audit, etc.)
        if (appDataObj.allDashboardData && typeof appDataObj.allDashboardData === "object") {
          try {
            Object.entries(appDataObj.allDashboardData).forEach(([key, value]) => {
              if (key && value) {
                localStorage.setItem(key, value);
              }
            });
          } catch (e) {
            console.warn("Could not restore some dashboard data:", e);
          }
        }

        // Restore RFE tracking data (explicit named section takes priority over allDashboardData blob)
        if (appDataObj.rfeData && typeof appDataObj.rfeData === "object") {
          try {
            if (appDataObj.rfeData.rows) {
              const rows = typeof appDataObj.rfeData.rows === "string"
                ? appDataObj.rfeData.rows : JSON.stringify(appDataObj.rfeData.rows);
              localStorage.setItem("ibm_rfe_tracking_v1", rows);
            }
            if (appDataObj.rfeData.metadata) {
              const meta = typeof appDataObj.rfeData.metadata === "string"
                ? appDataObj.rfeData.metadata : JSON.stringify(appDataObj.rfeData.metadata);
              localStorage.setItem("ibm_rfe_tracking_metadata_v1", meta);
            }
            if (appDataObj.rfeData.lastUpdate) {
              localStorage.setItem("ibm_rfe_tracking_last_update", appDataObj.rfeData.lastUpdate);
            }
            if (typeof DashRFEAdvanced !== "undefined" && DashRFEAdvanced.loadRFEData) {
              try { DashRFEAdvanced.render(); } catch(e) {}
            }
          } catch(e) { console.warn("Could not restore RFE data:", e); }
        }

        // Restore owner reassignment log (explicit named section)
        if (appDataObj.reassignLog && Array.isArray(appDataObj.reassignLog)) {
          try {
            // Merge into ibm_tracker_persist_v1 so Data module picks it up
            const persistRaw = localStorage.getItem("ibm_tracker_persist_v1");
            const persist = persistRaw ? JSON.parse(persistRaw) : {};
            persist.reassignLog = appDataObj.reassignLog;
            localStorage.setItem("ibm_tracker_persist_v1", JSON.stringify(persist));
            // Live restore into Data module if available
            if (typeof Data !== "undefined" && Data.restoreReassignLog) {
              Data.restoreReassignLog(appDataObj.reassignLog);
            }
          } catch(e) { console.warn("Could not restore reassign log:", e); }
        }

        // Refresh dashboards
        if (typeof DashPerformance !== "undefined") DashPerformance.render();
        render();

        showToast("✓ app-data.js imported — all settings, dashboards, comments, and data restored!", "success");
      } catch (err) {
        showToast(`Import failed: ${err.message}`, "danger");
      }
    };
    reader.onerror = () => {
      showToast("Error reading file", "danger");
    };
    reader.readAsText(file);
  }

  // ── Generate and download an updated app-data.js ─────────────────────────
  async function _downloadAppDataJs() {
    const DC = (typeof DynamicConfig !== "undefined") ? DynamicConfig : null;
    const AD = (typeof AppData !== "undefined") ? AppData : null;
    if (!DC || !AD) { showToast("Cannot generate — app not fully loaded.", "error"); return; }

    const cfg      = DC.appConfig        ? DC.appConfig()        : AD.config;
    const members  = DC.teamMembers      ? DC.teamMembers()      : AD.teamMembers;
    const emails   = DC.teamEmails       ? DC.teamEmails()       : AD.teamEmails;
    const expConn  = DC.expertiseConnect ? DC.expertiseConnect() : AD.expertiseConnect;
    const bdEsc    = DC.bdEscalation    ? DC.bdEscalation()     : AD.bdEscalation;
    const tLead    = DC.teamLead        ? DC.teamLead()         : AD.teamLead;
    const custCont = DC.customerContacts? DC.customerContacts() : AD.customerContacts;
    const almResp  = DC.almResponsible  ? DC.almResponsible()   : AD.almResponsible;
    const ibmDir   = DC.ibmDirectory    ? DC.ibmDirectory()     : AD.ibmDirectory;

    const q = s => JSON.stringify(s == null ? "" : s);

    const membersLines = members.map(m => `    ${q(m)},`).join("\n");
    const emailLines   = Object.entries(emails).map(([k,v]) => `    ${q(k)}: ${q(v)},`).join("\n");
    const expLines     = expConn.map(c => `    { name: ${q(c.name)}, email: ${q(c.email)} },`).join("\n");
    const bdLines      = bdEsc.map(c => `    { name: ${q(c.name)}, email: ${q(c.email)} },`).join("\n");
    const leadLines    = tLead.map(c => `    { name: ${q(c.name)}, email: ${q(c.email)} },`).join("\n");
    const ccLines      = custCont.map(c =>
      `    { line: ${q(c.line)}, names: ${q(c.names)},\n      emails: ${q(c.emails||"")} },`
    ).join("\n\n");
    const almLines     = almResp.map(r =>
      `    { alm: ${q(r.alm)}, bd: ${q(r.bd||"")}, bdEmail: ${q(r.bdEmail||"")}, ibm: ${q(r.ibm||"")}, ibmEmail: ${q(r.ibmEmail||"")}, proxy: ${q(r.proxy||"")}, proxyEmail: ${q(r.proxyEmail||"")} },`
    ).join("\n");
    const ibmDirStr    = Object.entries(
      typeof ibmDir === "object" && !Array.isArray(ibmDir) ? ibmDir : {}
    ).map(([group, contacts]) => {
      const cl = (contacts||[]).map(c => `        { name: ${q(c.name)}, email: ${q(c.email||"")} },`).join("\n");
      return `    ${q(group)}: [\n${cl}\n    ],`;
    }).join("\n");

    // Export performance case tags and comments
    const perfCaseNums = Data.getPerfCaseNums ? Data.getPerfCaseNums() : [];
    const nonPerfCaseNums = Data.getNonPerfCaseNums ? Data.getNonPerfCaseNums() : [];
    const perfMeta = Data.performanceMeta ? Data.performanceMeta() : {};
    const perfMetaStr = Object.entries(perfMeta).map(([cn, meta]) => {
      const parts = [];
      if (meta.instance) parts.push(`instance: ${q(meta.instance)}`);
      if (meta.workItem) parts.push(`workItem: ${q(meta.workItem)}`);
      if (meta.category) parts.push(`category: ${q(meta.category)}`);
      if (meta.availability) parts.push(`availability: ${q(meta.availability)}`);
      return `    ${q(cn)}: { ${parts.join(", ")} },`;
    }).join("\n");

    // Get Performance Dashboard case detail logs (wednesdayComments, caseInfo, availability)
    // Primary source: live Data module which stores caseDetailLogs in ibm_tracker_persist_v1
    let perfDashboardComments = {};
    try {
      if (typeof Data !== "undefined" && Data.getCaseDetailLog) {
        const allCandidates = Data.performanceCandidates ? Data.performanceCandidates() : [];
        const allNums = new Set([
          ...perfCaseNums,
          ...nonPerfCaseNums,
          ...allCandidates.map(r => r["Case Number"]).filter(Boolean)
        ]);
        allNums.forEach(cn => {
          const log = Data.getCaseDetailLog(cn);
          if (log) perfDashboardComments[cn] = log;
        });
      }
      // Fallback: read directly from ibm_tracker_persist_v1 in localStorage
      if (!Object.keys(perfDashboardComments).length) {
        const raw = localStorage.getItem("ibm_tracker_persist_v1");
        if (raw) {
          const parsed = JSON.parse(raw);
          if (parsed && parsed.caseDetailLogs) perfDashboardComments = parsed.caseDetailLogs;
        }
      }
    } catch (e) {
      // localStorage or Data module might not be accessible
    }
    const perfCommentsStr = Object.entries(perfDashboardComments).map(([cn, log]) => {
      return `    ${q(cn)}: ${q(JSON.stringify(log))},`;
    }).join("\n");

    // Export audit & change history
    const changeHistory = Data.changeHistory ? Data.changeHistory() : [];
    const historyStr = changeHistory.map(ch => {
      const parts = [];
      parts.push(`id: ${q(ch.id)}`);
      parts.push(`caseNumber: ${q(ch.caseNumber)}`);
      parts.push(`field: ${q(ch.field)}`);
      parts.push(`oldValue: ${q(ch.oldValue)}`);
      parts.push(`newValue: ${q(ch.newValue)}`);
      parts.push(`updatedBy: ${q(ch.updatedBy)}`);
      parts.push(`timestamp: ${q(ch.timestamp)}`);
      return `    { ${parts.join(", ")} },`;
    }).join("\n");

    // Export all dashboard data (Weekly Tracker, Info, Knowledge Base, Safety Audit, etc.)
    const allDashboardData = {};
    const keysToBackup = [
      // Weekly Tracker
      "ibm_wtracker_comments_v1", "ibm_wtracker_history", "ibm_wtracker_linkmap_v1",
      "ibm_wtracker_seeded_v5",
      // Info Dashboard
      "ibm_tracker_info_v1",
      // Knowledge Base
      "ibm_knowledge_base_v2",
      // Safety Audit
      "ibm_safety_audit_v1",
      // Case data
      "ibm_cases_overrides_v1", "ibm_reopened_cases_v1",
      // Performance persistence (case detail logs, meta, owner overrides + reassignLog)
      "ibm_tracker_persist_v1",
      // Team config (both keys)
      "ibm_team_config_v1", "ibm_team_config_v1_cache",
      // RFE Tracking — uploaded CSV data + per-row metadata + last update timestamp
      "ibm_rfe_tracking_v1", "ibm_rfe_tracking_metadata_v1", "ibm_rfe_tracking_last_update",
    ];

    try {
      // Get prefixed keys (like ibm_wtracker_YYYY)
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key && (key.startsWith("ibm_wtracker_") || key.startsWith("ibm_cases_raw_"))) {
          const val = localStorage.getItem(key);
          if (val) allDashboardData[key] = val;
        }
      }
      // Get specific keys
      keysToBackup.forEach(key => {
        const val = localStorage.getItem(key);
        if (val) allDashboardData[key] = val;
      });
    } catch (e) {
      // localStorage might not be accessible in all contexts
    }
    // ── Explicit RFE data extraction (for named section in output) ─────────
    // ── RFE data: fetch from DB first, fall back to localStorage ────────
    let rfeRows = [];
    let rfeMeta = {};
    let rfeLastUpdate = "";
    try {
      const _rfeBase = window.API_BASE_V2 || "/iip/api/v2";
      const _rfeTok  = (typeof Admin !== "undefined" && Admin.getToken) ? Admin.getToken() : "";
      const _rfeResp = await fetch(`${_rfeBase}/rfe-data`, {
        headers: _rfeTok ? { "x-iip-admin-token": _rfeTok } : {}
      });
      if (_rfeResp.ok) {
        const _rfeData = await _rfeResp.json();
        if (Array.isArray(_rfeData) && _rfeData.length) {
          rfeRows = _rfeData;
          rfeLastUpdate = new Date().toISOString();
        }
      }
    } catch(e) {
      // fallback: localStorage
      try {
        const rfeRaw = localStorage.getItem("ibm_rfe_tracking_v1");
        if (rfeRaw) rfeRows = JSON.parse(rfeRaw);
        const rfeMetaRaw = localStorage.getItem("ibm_rfe_tracking_metadata_v1");
        if (rfeMetaRaw) rfeMeta = JSON.parse(rfeMetaRaw);
        rfeLastUpdate = localStorage.getItem("ibm_rfe_tracking_last_update") || "";
      } catch(e2) {}
    }
    const rfeDataStr = `    rows: ${q(JSON.stringify(rfeRows))},
    metadata: ${q(JSON.stringify(rfeMeta))},
    lastUpdate: ${q(rfeLastUpdate)},`;

    // ── Reassign log: fetch from DB audit_log first, fall back to localStorage
    let reassignLogArr = [];
    try {
      const _rlTok = (typeof Admin !== "undefined" && Admin.getToken) ? Admin.getToken() : "";
      if (_rlTok) {
        const _rlResp = await fetch("/iip/api/admin/audit-log?action=reassign&limit=2000", {
          headers: { "x-iip-admin-token": _rlTok }
        });
        if (_rlResp.ok) {
          const _rlData = await _rlResp.json();
          if (Array.isArray(_rlData)) {
            reassignLogArr = _rlData
              .filter(r => r.action === "reassign")
              .map(r => ({
                caseNum:  r.entity_id  || "",
                oldOwner: r.old_value  || "",
                newOwner: r.new_value  || "",
                title:    r.notes      || "",
                ts:       r.change_date|| "",
              }));
          }
        }
      }
    } catch(e) {
      // fallback: localStorage
      try {
        const persistRaw = localStorage.getItem("ibm_tracker_persist_v1");
        if (persistRaw) {
          const parsed = JSON.parse(persistRaw);
          if (Array.isArray(parsed.reassignLog)) reassignLogArr = parsed.reassignLog;
        }
      } catch(e2) {}
    }
    const reassignLogStr = reassignLogArr.map(r => {
      return `    { caseNum: ${q(r.caseNum)}, oldOwner: ${q(r.oldOwner)}, newOwner: ${q(r.newOwner)}, title: ${q(r.title||"")}, ts: ${q(r.ts||"")} },`;
    }).join("\n");

    const allDashboardDataStr = Object.entries(allDashboardData).map(([k, v]) => {
      return `    ${q(k)}: ${q(v)},`;
    }).join("\n");

    const now = new Date().toISOString().slice(0,10);
    const js = `/* ================================================================
   js/data/app-data.js  —  IBM Case Intelligence Platform
   AUTO-GENERATED ${now} from Admin Portal. Replace frontend/js/data/app-data.js.
   ================================================================ */
const AppData = (() => {
  const config = {
    teamName:      ${q(cfg.teamName      || "BD/TOA-ETS5")},
    appTitle:      ${q(cfg.appTitle      || "IBM Cases")},
    appSubtitle:   ${q(cfg.appSubtitle   || "IBM Case Intelligence Platform")},
    defectBaseUrl: ${q(cfg.defectBaseUrl || "")},
    idleTimeoutMs:  30 * 60 * 1000,
    idleWarningMs:  27 * 60 * 1000,
    tablePageSize:  50,
    persistKeyTracker: "ibm_tracker_persist_v1",
    persistKeyKB:      "ibm_knowledge_base_v2",
    persistKeyCases:   "ibm_cases_raw_v1",
  };
  const teamMembers = [
${membersLines}
  ];
  const teamEmails = {
${emailLines}
  };
  const expertiseConnect = [
${expLines}
  ];
  const bdEscalation = [
${bdLines}
  ];
  const teamLead = [
${leadLines}
  ];
  const customerContacts = [
${ccLines}
  ];
  const almResponsible = [
${almLines}
  ];
  const ibmDirectory = {
${ibmDirStr}
  };
  const performanceCases = [
    ${perfCaseNums.map(cn => q(cn)).join(",\n    ")}
  ];
  const nonPerformanceCases = [
    ${nonPerfCaseNums.map(cn => q(cn)).join(",\n    ")}
  ];
  const performanceMeta = {
${perfMetaStr}
  };
  const performanceDashboardComments = {
${perfCommentsStr}
  };
  const changeHistory = [
${historyStr}
  ];
  const rfeData = {
${rfeDataStr}
  };
  const reassignLog = [
${reassignLogStr}
  ];
  const allDashboardData = {
${allDashboardDataStr}
  };
  return Object.freeze({ config, teamMembers, teamEmails, expertiseConnect, bdEscalation, teamLead, customerContacts, almResponsible, ibmDirectory, performanceCases, nonPerformanceCases, performanceMeta, performanceDashboardComments, changeHistory, rfeData, reassignLog, allDashboardData });
})();
`;
    const blob = new Blob([js], { type: "text/javascript" });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement("a");
    a.href = url; a.download = "app-data.js";
    document.body.appendChild(a); a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast("\u2705 app-data.js downloaded with complete backup of all app data — settings, dashboards, comments, and audit trail.", "success");
  }

  // ── Generate and download updated weekly-tracker.js with all localStorage data baked in ──
  function _downloadTrackerSeedJs() {
    const STORE_PREFIX = "ibm_wtracker_";

    // Collect ALL tracker years from localStorage
    const allData = {};
    try {
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key && key.startsWith(STORE_PREFIX) && /ibm_wtracker_\d{4}$/.test(key)) {
          const yr = key.replace(STORE_PREFIX, "");
          try {
            const raw = localStorage.getItem(key);
            if (raw) {
              const parsed = JSON.parse(raw);
              if (parsed && typeof parsed === "object") {
                // Clean each row: strip internal flags, keep useful fields only
                const cleaned = {};
                Object.entries(parsed).forEach(([wk, rows]) => {
                  if (!Array.isArray(rows) || !rows.length) return;
                  cleaned[wk] = rows.map(r => {
                    const out = {};
                    ["id","caseNumber","owner","title","customerNumber","product",
                     "severity","status","age","closedDate","comments","category",
                     "created","solutionDate","country","availability"].forEach(f => {
                      if (r[f] !== undefined && r[f] !== null) out[f] = r[f];
                    });
                    return out;
                  }).filter(r => r.caseNumber); // skip rows with no case number
                });
                if (Object.keys(cleaned).length) allData[yr] = cleaned;
              }
            }
          } catch(e) {}
        }
      }
    } catch(e) {
      showToast("Could not read tracker data from localStorage.", "error");
      return;
    }

    if (!Object.keys(allData).length) {
      showToast("No Weekly Tracker data found in localStorage to export.", "warning");
      return;
    }

    // Count total entries
    let totalRows = 0;
    Object.values(allData).forEach(yr => Object.values(yr).forEach(wk => totalRows += wk.length));

    // Read current weekly-tracker.js header and everything after the seed
    // We only need to replace the _WT_SEED constant and bump SEEDED_KEY version
    const now  = new Date().toISOString().slice(0, 10);
    const seedVersion = "v_" + now.replace(/-/g, "");  // e.g. v_20260315

    // Generate the new seed JSON — compact but readable per year
    const seedLines = Object.entries(allData)
      .sort(([a],[b]) => parseInt(a)-parseInt(b))
      .map(([yr, weeks]) => "  " + JSON.stringify(yr) + ": " + JSON.stringify(weeks))
      .join(",\n");

    const seedBlock = "const _WT_SEED = {\n" + seedLines + "\n};";

    // We need to replace two things in weekly-tracker.js:
    // 1. The _WT_SEED block
    // 2. The SEEDED_KEY string (to force re-seed on fresh deploys)
    // Since we can't read the current file from JS, we generate a patcher script
    // instead — a tiny Node.js script the user runs once to patch weekly-tracker.js

    const patcherScript = `#!/usr/bin/env node
// =============================================================
// IIP Weekly Tracker Seed Patcher — AUTO-GENERATED ${now}
// Run this ONCE after downloading:
//   node patch-tracker-seed.js
// Then deploy the updated weekly-tracker.js to your server.
// =============================================================
const fs   = require("fs");
const path = require("path");

const TRACKER_FILE = path.join(__dirname, "frontend", "js", "dashboards", "weekly-tracker.js");

if (!fs.existsSync(TRACKER_FILE)) {
  console.error("ERROR: Could not find", TRACKER_FILE);
  console.error("Make sure you run this script from the IIP project root folder.");
  process.exit(1);
}

let code = fs.readFileSync(TRACKER_FILE, "utf8");

// 1. Replace _WT_SEED block
const seedStart = code.indexOf("const _WT_SEED = {");
const seedEnd   = code.indexOf("\n};\n", seedStart) + 4;
if (seedStart === -1 || seedEnd < seedStart) {
  console.error("ERROR: Could not locate _WT_SEED in weekly-tracker.js");
  process.exit(1);
}

const newSeed = ${JSON.stringify(seedBlock)};
code = code.slice(0, seedStart) + newSeed + code.slice(seedEnd);

// 2. Bump SEEDED_KEY so fresh deploys always re-seed from the new data
code = code.replace(/const SEEDED_KEY\s*=\s*"[^"]+";/, 'const SEEDED_KEY    = "ibm_wtracker_seeded_${seedVersion}";');

fs.writeFileSync(TRACKER_FILE, code, "utf8");
console.log("✅ weekly-tracker.js updated successfully!");
console.log("   Seed data: ${Object.keys(allData).join(", ")} (${totalRows} total entries)");
console.log("   SEEDED_KEY bumped to: ibm_wtracker_seeded_${seedVersion}");
console.log("\nYou can now deploy the updated frontend/ folder to your server.");
`;

    // Download the patcher script
    const blob = new Blob([patcherScript], { type: "text/javascript" });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement("a");
    a.href = url; a.download = "patch-tracker-seed.js";
    document.body.appendChild(a); a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    showToast(
      `✅ patch-tracker-seed.js downloaded — run it once with Node.js to bake ${totalRows} tracker entries into weekly-tracker.js.`,
      "success"
    );
  }

  /* ── KPI card ── */
  function kpiCard(label, value, cls) {
    return `<div class="kpi-card ${cls}">
      <div class="kpi-label">${label}</div>
      <div class="kpi-value">${value}</div>
    </div>`;
  }

  /* ── Card wrapper ── */
  function card(titleIcon, title, badge, bodyHtml) {
    const badgeHtml = badge !== undefined
      ? `<span style="background:var(--bg-layer-2);color:var(--text-secondary);font-size:11px;font-weight:600;padding:1px 8px;border-radius:var(--radius-md);border:1px solid var(--border-subtle);margin-left:6px">${badge}</span>`
      : "";
    return `<div class="tile mb-16">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;padding-bottom:12px;border-bottom:1px solid var(--border-subtle)">
        <div style="display:flex;align-items:center;gap:8px;font-size:14px;font-weight:600;color:var(--text-primary)">
          <span class="c-blue">${titleIcon}</span>${title}${badgeHtml}
        </div>
      </div>
      ${bodyHtml}
    </div>`;
  }

  /* ── Main render ── */
  
function _buildTeamTabOnly() {
  var DC = (typeof DynamicConfig !== "undefined") ? DynamicConfig : null;
  if (!DC) return "";
  var full = _renderTeamConfigCard();
  var tmp = document.createElement("div");
  tmp.innerHTML = full;
  var details = tmp.querySelectorAll("details");
  // indices 2,3,4,5 = Team Members, ALM, Escalation, IBM Directory
  var outer = tmp.firstElementChild ? tmp.firstElementChild.cloneNode(false) : document.createElement("div");
  [2,3,4,5].forEach(function(i){ if(details[i]) outer.appendChild(details[i].cloneNode(true)); });
  return outer.outerHTML;
}


function _buildConfigTabOnly() {
  var DC = (typeof DynamicConfig !== "undefined") ? DynamicConfig : null;
  if (!DC) return "";
  var full = _renderTeamConfigCard();
  var tmp = document.createElement("div");
  tmp.innerHTML = full;
  var details = tmp.querySelectorAll("details");
  // indices 0,1,6 = App Identity, WT Categories, Customer Products
  var outer = tmp.firstElementChild ? tmp.firstElementChild.cloneNode(false) : document.createElement("div");
  [0,1,6].forEach(function(i){ if(details[i]) outer.appendChild(details[i].cloneNode(true)); });
  return outer.outerHTML;
}

function _buildHistoryTabOnly() {
  // _renderTeamConfigCard stub — returns RFE section HTML directly
  return (
    '<div style="padding:12px">'
      + '<div style="display:flex;align-items:center;gap:16px;margin-bottom:10px">'
        + '<span style="font-size:13px;color:var(--text-secondary)">Total RFEs: '
          + '<strong id="rfe-total-count">...</strong>'
        + '</span>'
        + '<span id="rfe-last-updated" style="font-size:11px;color:var(--text-tertiary)">Loading…</span>'
      + '</div>'
      + '<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">'
        + '<label class="btn btn-primary btn-sm" style="cursor:pointer">'
          + 'Import CSV / Excel'
          + '<input id="rfe-import-csv" type="file" accept=".csv,.xlsx,.xls" style="display:none"/>'
        + '</label>'
        + '<button id="rfe-clear-data-btn" class="btn btn-ghost btn-sm" style="color:var(--red)">Clear all RFE data</button>'
      + '</div>'
      + '<div id="rfe-csv-import-status" style="display:none;margin-top:8px;font-size:12px"></div>'
    + '</div>'
  );
}
// _renderTeamConfigCard stub — original function was removed; callers are dead code
function _renderTeamConfigCard() { return '<div></div>'; }



// ── Admin v3 HTML builder (merged from admin-dash-v3-render-patch.js) ──────

function _buildAdminHTML() {
  // New single-page layout — overview dashboard + collapsed sections
  const SVG = {
    tag:     `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M20.59 13.41l-7.17 7.17a2 2 0 01-2.83 0L2 12V2h10l8.59 8.59a2 2 0 010 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/></svg>`,
    reassign:`<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 014-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 01-4 4H3"/></svg>`,
    people:  `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg>`,
    config:  `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="3"/><path d="M19.07 4.93l-1.41 1.41M22 12h-2M19.07 19.07l-1.41-1.41M12 22v-2M4.93 19.07l1.41-1.41M2 12h2M4.93 4.93l1.41 1.41"/></svg>`,
    history: `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>`,
    upload:  `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>`,
    check:   `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><polyline points="20 6 9 17 4 12"/></svg>`,
    rfe:     `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>`,
    audit:   `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>`,
    alm:     `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>`,
    product: `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/></svg>`,
    ibm:     `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16"/></svg>`,
    esc:     `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 8h1a4 4 0 010 8h-1"/><path d="M2 8h16v9a4 4 0 01-4 4H6a4 4 0 01-4-4V8z"/><line x1="6" y1="1" x2="6" y2="4"/><line x1="10" y1="1" x2="10" y2="4"/><line x1="14" y1="1" x2="14" y2="4"/></svg>`,
    wt:      `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>`,
    down:    `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><polyline points="6 9 12 15 18 9"/></svg>`,
    plus:    `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>`,
    search:  `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>`,
    save:    `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>`,
    warn:    `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>`,
    lock:    `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>`,
    trash:   `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/></svg>`,
    user:    `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>`,
    elm:     `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/><line x1="12" y1="14" x2="12" y2="18"/><line x1="10" y1="16" x2="14" y2="16"/></svg>`,
  };

  function sec(id, iconSvg, iconCls, title, subtitle, children) {
    return `
    <div class="adm-section collapsed" id="${id}">
      <div class="adm-section-header" onclick="(function(h){var s=h.closest('.adm-section');var wasCollapsed=s.classList.contains('collapsed');s.classList.toggle('collapsed');if(wasCollapsed){setTimeout(function(){s.scrollIntoView({behavior:'smooth',block:'start'});},120);};})(this)">
        <div class="adm-section-header-left">
          <div class="adm-section-icon ${iconCls}">${iconSvg}</div>
          <div>
            <div class="adm-section-title">${title}</div>
            ${subtitle ? `<div class="adm-section-subtitle">${subtitle}</div>` : ''}
          </div>
        </div>
        <div class="adm-section-header-right">
          <span class="adm-section-chevron">${SVG.down}</span>
        </div>
      </div>
      <div class="adm-section-body">${children}</div>
    </div>`;
  }

  // ── Overview dashboard ──────────────────────────────────────────
  const overviewHTML = `
  <div id="adm-overview" style="margin-bottom:20px">
    <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:16px" id="adm-stat-cards">
      <div class="kpi-card kpi-blue"><div class="kpi-label">Last upload</div><div class="kpi-value" id="adm-stat-upload" style="font-size:14px">—</div><div class="kpi-sub" id="adm-stat-upload-sub">loading…</div></div>
      <div class="kpi-card kpi-red"><div class="kpi-label">Performance tagged</div><div class="kpi-value" id="adm-stat-perf">—</div><div class="kpi-sub" id="adm-stat-nonperf-sub">loading…</div></div>
      <div class="kpi-card kpi-green"><div class="kpi-label">Active cases</div><div class="kpi-value" id="adm-stat-active">—</div><div class="kpi-sub">in current upload</div></div>
      <div class="kpi-card kpi-purple"><div class="kpi-label">Changes (7 days)</div><div class="kpi-value" id="adm-stat-changes">—</div><div class="kpi-sub" id="adm-stat-reassign-sub">loading…</div></div>
    </div>
  </div>`;

  // ── Perf tagging section ────────────────────────────────────────
  const perfHTML = `
    <div style="display:flex;gap:8px;margin-bottom:18px">
      <button id="mode-perf-btn" class="btn btn-danger btn-sm" style="font-weight:600">${SVG.tag} Performance</button>
      <button id="mode-nonperf-btn" class="btn btn-ghost btn-sm">${SVG.check} Non-Performance</button>
    </div>
    <div class="adm-sub-title">${SVG.plus} Add single case</div>
    <div class="adm-form-row" style="margin-bottom:16px">
      <div class="adm-form-group" style="max-width:220px">
        <label class="adm-form-label">Case number</label>
        <input id="single-case-num" name="single-case-num" type="text" class="form-input" placeholder="e.g. TS020514571"/>
      </div>
      <div class="adm-form-group" style="max-width:260px">
        <label class="adm-form-label">Work item <span style="font-weight:400;color:var(--text-tertiary)">(optional)</span></label>
        <input id="single-case-wi" name="single-case-wi" type="text" class="form-input" placeholder="e.g. Defect 12345"/>
      </div>
      <div style="display:flex;gap:6px;padding-bottom:1px">
        <button id="add-perf-btn" class="btn btn-danger btn-sm">+ Perf</button>
        <button id="add-nonperf-btn" class="btn btn-success btn-sm">+ Non-Perf</button>
      </div>
    </div>
    <details style="margin-bottom:16px">
      <summary style="font-size:12px;color:var(--text-secondary);cursor:pointer;padding:6px 0;list-style:none;display:flex;align-items:center;gap:6px">
        ${SVG.upload} <span>Bulk import / Excel</span>
      </summary>
      <div style="margin-top:12px;padding:12px;background:var(--bg-layer);border:1px solid var(--border-subtle);border-radius:var(--radius-sm)">
        <div class="adm-bulk-format-pills" style="margin-bottom:10px">
          <span class="adm-format-pill" style="background:var(--ibm-blue-10);color:var(--ibm-blue-50);border-color:rgba(15,98,254,.25)">TSXXXXXXXX</span>
          <span class="adm-format-pill" style="background:var(--purple-bg);color:var(--purple);border-color:rgba(105,41,196,.2)">Defect NNNNN TSXXXXXXXX</span>
          <span class="adm-format-pill" style="background:var(--teal-bg);color:var(--teal);border-color:rgba(0,125,121,.2)">Task NNNNN TSXXXXXXXX</span>
        </div>
        <textarea id="bulk-cases" name="bulk-cases" class="form-input" rows="4" style="width:100%;font-family:var(--font-mono);font-size:12px;resize:vertical;margin-bottom:10px" placeholder="Paste case numbers here, one per line…"></textarea>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          <button id="bulk-perf-btn" class="btn btn-danger btn-sm">${SVG.upload} Import as Performance</button>
          <button id="bulk-nonperf-btn" class="btn btn-success btn-sm">${SVG.upload} Import as Non-Performance</button>
          <button id="bulk-excel-btn" class="btn btn-secondary btn-sm">${SVG.upload} Import Excel</button>
          <input type="file" id="bulk-excel-input" style="display:none" accept=".xlsx,.xls"/>
        </div>
      </div>
    </details>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
      <div class="adm-chips-bar">
        <div class="adm-chips-header" onclick="this.nextElementSibling.style.display=this.nextElementSibling.style.display==='none'?'flex':'none'">
          <div class="adm-chips-title"><span style="color:var(--red)">${SVG.tag}</span> Performance cases</div>
          <span class="adm-section-count" style="background:var(--red-bg);color:var(--red);border-color:rgba(218,30,40,.2)" id="adm-perf-count-badge">0</span>
        </div>
        <div id="perf-nums-body" class="adm-chips-body" style="display:flex"></div>
      </div>
      <div class="adm-chips-bar">
        <div class="adm-chips-header" onclick="this.nextElementSibling.style.display=this.nextElementSibling.style.display==='none'?'flex':'none'">
          <div class="adm-chips-title"><span style="color:var(--green)">${SVG.check}</span> Non-performance cases</div>
          <span class="adm-section-count" style="background:var(--green-bg);color:var(--green);border-color:rgba(25,128,56,.2)" id="adm-nonperf-count-badge">0</span>
        </div>
        <div id="nonperf-nums-body" class="adm-chips-body" style="display:flex"></div>
      </div>
    </div>`;

  // ── Owner reassignment section ──────────────────────────────────
  const reassignHTML = `
    <div style="display:grid;grid-template-columns:1fr 1fr auto;gap:12px;align-items:end;margin-bottom:16px">
      <div style="position:relative">
        <label class="adm-form-label">Source owner</label>
        <input type="hidden" id="bulk-source"/>
        <div id="bulk-source-wrap" style="position:relative;margin-top:5px">
          <input type="text" id="bulk-source-display" placeholder="— Select owner —" autocomplete="off"
            class="form-input" style="width:100%;cursor:pointer;padding-right:28px" readonly/>
          <span style="position:absolute;right:8px;top:50%;transform:translateY(-50%);pointer-events:none;color:var(--text-secondary)">▾</span>
          <div id="bulk-source-dropdown" style="display:none;position:absolute;top:calc(100% + 2px);left:0;right:0;z-index:300;background:var(--bg-ui);border:1px solid var(--border-mid);border-radius:var(--radius-sm);box-shadow:0 4px 16px rgba(0,0,0,.14)">
            <div style="padding:6px 8px;border-bottom:1px solid var(--border-subtle)">
              <input type="text" id="bulk-source-search" placeholder="Search owner…" autocomplete="off"
                class="form-input" style="width:100%;font-size:12px;padding:6px 8px"/>
            </div>
            <div id="bulk-source-list" style="max-height:180px;overflow-y:auto"></div>
          </div>
        </div>
      </div>
      <div style="position:relative">
        <label class="adm-form-label">Target owner</label>
        <input type="hidden" id="bulk-target"/>
        <div id="bulk-target-wrap" style="position:relative;margin-top:5px">
          <input type="text" id="bulk-target-display" placeholder="— Select owner —" autocomplete="off"
            class="form-input" style="width:100%;cursor:pointer;padding-right:28px" readonly/>
          <span style="position:absolute;right:8px;top:50%;transform:translateY(-50%);pointer-events:none;color:var(--text-secondary)">▾</span>
          <div id="bulk-target-dropdown" style="display:none;position:absolute;top:calc(100% + 2px);left:0;right:0;z-index:300;background:var(--bg-ui);border:1px solid var(--border-mid);border-radius:var(--radius-sm);box-shadow:0 4px 16px rgba(0,0,0,.14)">
            <div style="padding:6px 8px;border-bottom:1px solid var(--border-subtle)">
              <input type="text" id="bulk-target-search" placeholder="Search owner…" autocomplete="off"
                class="form-input" style="width:100%;font-size:12px;padding:6px 8px"/>
            </div>
            <div id="bulk-target-list" style="max-height:180px;overflow-y:auto"></div>
          </div>
        </div>
      </div>
      <div style="display:flex;flex-direction:column;gap:4px">
        <label class="adm-form-label">Filter</label>
        <div style="display:flex;gap:4px;margin-top:5px">
          <button id="bulk-filter-active" class="btn btn-primary btn-sm" style="font-size:11px">Active</button>
          <button id="bulk-filter-closed" class="btn btn-ghost btn-sm" style="font-size:11px">Closed</button>
          <button id="bulk-filter-all"    class="btn btn-ghost btn-sm" style="font-size:11px">All</button>
        </div>
      </div>
    </div>
    <div style="margin-bottom:12px;border:1px solid var(--border-subtle);border-radius:var(--radius-sm);overflow:hidden">
      <select id="bulk-cases-list" multiple size="6" style="width:100%;padding:8px;font-size:12px;border:none;background:var(--bg-input);color:var(--text-primary);font-family:var(--font-sans)"></select>
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px">
      <button id="bulk-select-all" class="btn btn-secondary btn-sm">${SVG.check} Select all</button>
      <button id="bulk-reassign-selected" class="btn btn-primary btn-sm">${SVG.reassign} Reassign selected</button>
      <button id="bulk-reassign-all-source" class="btn btn-secondary btn-sm">${SVG.reassign} Reassign all from source</button>
    </div>
    <details style="margin-bottom:16px">
      <summary style="font-size:12px;color:var(--text-secondary);cursor:pointer;padding:6px 0;list-style:none;display:flex;align-items:center;gap:6px">
        ${SVG.upload} <span>Import from Excel</span>
      </summary>
      <div style="margin-top:10px;padding:12px;background:var(--bg-layer);border:1px solid var(--border-subtle);border-radius:var(--radius-sm)">
        <p class="adm-form-hint" style="margin-bottom:10px">Upload an Excel file with columns <code style="font-family:var(--font-mono);color:var(--ibm-blue-50)">Case Number</code> and <code style="font-family:var(--font-mono);color:var(--ibm-blue-50)">Case Owner</code></p>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          <label class="btn btn-secondary btn-sm cursor-p-fs12">
            ${SVG.upload} Choose Excel file
            <input id="bulk-excel-reassign-input" type="file" accept=".xlsx,.xls" style="display:none"/>
          </label>
          <button id="bulk-excel-reassign-apply" class="btn btn-primary btn-sm">${SVG.reassign} Apply import</button>
        </div>
      </div>
    </details>
    <div class="adm-sub-title" style="margin-bottom:8px">${SVG.search} Search cases &amp; reassign</div>
    <div class="form-input-group" style="margin-bottom:14px">
      <span class="input-icon">${SVG.search}</span>
      <input id="bulk-search" name="bulk-search" type="text" class="search-input" placeholder="Search by case number, title, or owner…"/>
    </div>
    <div class="adm-chips-bar" id="reassign-log-wrap">
      <div class="adm-chips-header" id="reassign-log-accordion-toggle">
        <div class="adm-chips-title">${SVG.reassign} Reassignment log</div>
        <span class="adm-section-count" id="reassign-log-count">0</span>
      </div>
      <div id="reassign-log-body" class="adm-chips-body" style="display:none"></div>
    </div>`;

  // ── Audit section ───────────────────────────────────────────────
  const auditHTML = `
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;gap:8px;flex-wrap:wrap">
      <div class="form-input-group" style="width:260px">
        <input id="history-search" name="history-search" type="text" class="search-input" style="height:32px" placeholder="Filter history…"/>
      </div>
      <div style="display:flex;gap:6px">
        <button id="history-export-btn" class="btn btn-primary btn-sm">Export Excel</button>
        <button id="history-clear-all-btn" class="btn btn-ghost btn-sm" style="color:var(--red)">Clear all</button>
      </div>
    </div>
    <div id="history-list" style="max-height:400px;overflow-y:auto"></div>`;

  // ── RFE section — extract inner content only (no duplicate heading) ──
  const rfeHTML = (function() {
    const tmp = document.createElement("div");
    tmp.innerHTML = _buildHistoryTabOnly();
    const det = tmp.querySelector("details");
    if (det) {
      const sum = det.querySelector("summary");
      if (sum) sum.remove();
      return '<div id="adm-rfe-container">' + det.innerHTML + '</div>';
    }
    return '<div id="adm-rfe-container">' + tmp.innerHTML + '</div>';
  })();

  // ── Team config sections (from existing _renderTeamConfigCard) ──
  // const teamConfigFull = _renderTeamConfigCard(); // removed — result was never used (dead code)

  return `
  <div class="admin-v3">

    ${overviewHTML}

    ${sec('adm-sec-perf',     SVG.tag,     'icon-red',    'Performance case tagging',   'Tag individual cases as Perf / Non-Perf', perfHTML)}
    ${sec('adm-sec-reassign', SVG.reassign, 'icon-blue',   'Owner reassignment',          'Move cases between owners', reassignHTML)}
    ${sec('adm-sec-team',     SVG.people,   'icon-blue',   'Team members',                'Manage team roster and display names', '<div id="adm-team-body"><div style="padding:12px;font-size:12px;color:var(--text-tertiary)">Loading…</div></div>')}
    ${sec('adm-sec-ibm',      SVG.ibm,      'icon-purple', 'IBM directory',               'IBM support contact names and emails', '<div id="adm-ibm-body"><div style="padding:12px;font-size:12px;color:var(--text-tertiary)">Loading…</div></div>')}
    ${sec('adm-sec-esc',      SVG.esc,      'icon-green',  'Escalation contacts',         'Expertise Connect, BD Escalation and Team Lead', '<div id="adm-esc-body"><div style="padding:12px;font-size:12px;color:var(--text-tertiary)">Loading…</div></div>')}
    ${sec('adm-sec-wt',       SVG.wt,       'icon-teal',   'Weekly tracker categories',   'Manage categories shown in tracker', '<div id="adm-wt-body"><div style="padding:12px;font-size:12px;color:var(--text-tertiary)">Loading…</div></div>')}
    ${sec('adm-sec-rfe',      SVG.rfe,      'icon-amber',  'IBM RFE tracking',            'Request for Enhancement data', rfeHTML)}
    ${sec('adm-sec-alm',      SVG.alm,      'icon-blue',   'ALM line details',            'Customer contacts and responsible persons per ALM line', '<div id="adm-alm-body"><div style="padding:12px;font-size:12px;color:var(--text-tertiary)">Loading…</div></div>')}
    ${sec('adm-sec-elm',      SVG.elm,      'icon-teal',   'ELM upgrade history',         'ELM version / iFix upgrade dates for post-upgrade case tracking', '<div id="adm-elm-body"><div style="padding:12px;font-size:12px;color:var(--text-tertiary)">Loading…</div></div>')}
    ${sec('adm-sec-products', SVG.product,  'icon-teal',   'Customer products',           'Product names shown in filters', '<div id="adm-products-body"><div style="padding:12px;font-size:12px;color:var(--text-tertiary)">Loading…</div></div>')}
    ${sec('adm-sec-appid',    SVG.config,   'icon-gray',   'App identity &amp; settings', 'App title, account ID, URL patterns', '<div id="adm-appid-body"><div style="padding:12px;font-size:12px;color:var(--text-tertiary)">Loading…</div></div>')}
    ${sec('adm-sec-audit',    SVG.audit,    'icon-blue',   'Audit &amp; change history',  'Full log of all admin actions', auditHTML)}

  </div>`;
}


function populateOwnerSelects() {
    const sourceHidden  = document.getElementById("bulk-source");
    const sourceDisplay = document.getElementById("bulk-source-display");
    const targetHidden  = document.getElementById("bulk-target");
    const targetDisplay = document.getElementById("bulk-target-display");
    if (!sourceDisplay || !targetDisplay) return;

    const ssSource = SearchableSelect.create({
        trigger: sourceDisplay, valueEl: sourceHidden,
        members: [], placeholder: '\u2014 Select owner \u2014',
        onSelect: function(v) { if (sourceHidden) sourceHidden.dispatchEvent(new Event('change', { bubbles: true })); }
    });
    const ssTarget = SearchableSelect.create({
        trigger: targetDisplay, valueEl: targetHidden,
        members: [], placeholder: '\u2014 Select owner \u2014',
        onSelect: function(v) { if (targetHidden) targetHidden.dispatchEvent(new Event('change', { bubbles: true })); }
    });

    function _build(apiMembers) {
        const active   = apiMembers.filter(m => (m.status || 'Active') === 'Active').sort((a,b) => a.name.localeCompare(b.name));
        const departed = apiMembers.filter(m => m.status === 'Departed').sort((a,b) => a.name.localeCompare(b.name));
        const toList = function(list, group) {
            return list.map(m => ({ value: m.name, label: m.display_name ? m.display_name + ' (' + m.name + ')' : m.name, group: group || '' }));
        };
        const members = [...toList(active, ''), ...toList(departed, 'Departed')];
        ssSource.setMembers(members);
        ssTarget.setMembers(members);
    }

    const tok = sessionStorage.getItem("ibm_admin_token_v1") || "";
    fetch("/iip/api/admin/team-members", { headers: { "x-iip-admin-token": tok } })
        .then(function(r) { return r.ok ? r.json() : Promise.reject(r.status); })
        .then(_build)
        .catch(function() {
            const all = (typeof Data !== "undefined" && Data.allCases) ? Data.allCases() : [];
            const owners = [...new Set(all.map(c => c.Owner || "").filter(Boolean))].sort();
            _build(owners.map(o => ({ name: o, status: 'Active' })));
        });
}

function render() {
    const el = document.getElementById("tab-admin");
    if (!el) return;

    const all = Data.allCases();

    el.innerHTML = _buildAdminHTML();
    populateOwnerSelects();
    // ── ELM upgrades loader ──
    (function _waitElm() {
      const tok = sessionStorage.getItem("ibm_admin_token_v1");
      if (!tok) { setTimeout(_waitElm, 300); return; }
      const elmBody = document.getElementById("adm-elm-body");
      if (!elmBody) return;
      elmBody.innerHTML = '<div style="padding:12px">'
        + '<div style="display:flex;gap:8px;margin-bottom:10px">'
        + '<button id="dc-add-elm" class="btn btn-ghost btn-sm">+ Add Entry</button>'
        + '<button id="dc-save-elm" class="btn btn-primary btn-sm">Save All</button>'
        + '</div>'
        + '<div style="overflow-x:auto;border:1px solid var(--border-subtle);border-radius:8px">'
        + '<table style="width:100%;border-collapse:collapse;font-size:12px">'
        + '<thead><tr style="background:var(--bg-layer);border-bottom:2px solid var(--border-subtle)">'
        + '<th style="padding:8px 10px;font-size:10px;font-weight:700;text-transform:uppercase;color:var(--text-tertiary)">ELM Version</th>'
        + '<th style="padding:8px 10px;font-size:10px;font-weight:700;text-transform:uppercase;color:var(--text-tertiary)">iFix Version</th>'
        + '<th style="padding:8px 10px;font-size:10px;font-weight:700;text-transform:uppercase;color:var(--text-tertiary)">Upgrade Date</th>'
        + '<th style="padding:8px 10px;font-size:10px;font-weight:700;text-transform:uppercase;color:var(--text-tertiary)">Notes</th>'
        + '<th style="padding:8px 10px;font-size:10px;font-weight:700;text-transform:uppercase;color:var(--text-tertiary);text-align:center">Actions</th>'
        + '</tr></thead>'
        + '<tbody id="dc-elm-tbody"><tr><td colspan="5" style="padding:12px;text-align:center;color:var(--text-tertiary)">Loading…</td></tr></tbody>'
        + '</table></div>'
        + '</div>';
      fetch("/iip/api/admin/elm-upgrades", { headers: { "x-iip-admin-token": tok } })
        .then(r => r.ok ? r.json() : Promise.reject(r.status))
        .then(rows => {
          const tbody = document.getElementById("dc-elm-tbody");
          if (!tbody) return;
          if (!rows.length) { tbody.innerHTML = '<tr><td colspan="5" style="padding:12px;text-align:center;color:var(--text-tertiary)">No ELM upgrade entries yet.</td></tr>'; return; }
          tbody.innerHTML = rows.map(r => '<tr style="border-bottom:1px solid var(--border-subtle)" data-id="' + (r.id||'') + '">'
            + '<td style="padding:6px 10px"><input class="form-input elm-version" style="width:100px;font-size:12px;font-family:var(--font-mono)" value="' + Utils.escHtml(r.elm_version||'') + '" placeholder="7.0.3"/></td>'
            + '<td style="padding:6px 10px"><input class="form-input elm-ifix" style="width:100px;font-size:12px;font-family:var(--font-mono)" value="' + Utils.escHtml(r.ifix_version||'') + '" placeholder="iFix001"/></td>'
            + '<td style="padding:6px 10px"><input class="form-input elm-date" type="date" style="font-size:12px" value="' + Utils.escHtml(r.upgrade_date||'') + '"/></td>'
            + '<td style="padding:6px 10px"><input class="form-input elm-notes" style="width:200px;font-size:12px" value="' + Utils.escHtml(r.notes||'') + '" placeholder="Notes"/></td>'
            + '<td style="padding:6px 8px;text-align:center"><button class="btn btn-ghost btn-sm elm-del-row" style="color:var(--red);padding:3px 8px">✕</button></td>'
            + '</tr>').join('');
          document.getElementById("dc-elm-tbody")?.addEventListener("click", async e => {
            if (!e.target.closest(".elm-del-row")) return;
            const tr = e.target.closest("tr"); const id = tr?.dataset.id;
            if (!id) { tr?.remove(); return; }
            const t = sessionStorage.getItem("ibm_admin_token_v1") || "";
            await fetch("/iip/api/admin/elm-upgrades/" + id, { method: "DELETE", headers: { "x-iip-admin-token": t } });
            tr.remove();
          });
        })
        .catch(e => {
          const tbody = document.getElementById("dc-elm-tbody");
          if (tbody) tbody.innerHTML = '<tr><td colspan="5" style="padding:12px;color:var(--red)">Failed to load (' + e + ')</td></tr>';
        });
      document.getElementById("dc-add-elm")?.addEventListener("click", () => {
        const tbody = document.getElementById("dc-elm-tbody");
        if (!tbody) return;
        const tr = document.createElement("tr");
        tr.dataset.id = ""; tr.style.borderBottom = "1px solid var(--border-subtle)";
        tr.innerHTML = '<td style="padding:6px 10px"><input class="form-input elm-version" style="width:100px;font-size:12px;font-family:var(--font-mono)" placeholder="7.0.3"/></td>'
          + '<td style="padding:6px 10px"><input class="form-input elm-ifix" style="width:100px;font-size:12px;font-family:var(--font-mono)" placeholder="iFix001"/></td>'
          + '<td style="padding:6px 10px"><input class="form-input elm-date" type="date" style="font-size:12px"/></td>'
          + '<td style="padding:6px 10px"><input class="form-input elm-notes" style="width:200px;font-size:12px" placeholder="Notes"/></td>'
          + '<td style="padding:6px 8px;text-align:center"><button class="btn btn-ghost btn-sm elm-del-row" style="color:var(--red);padding:3px 8px">✕</button></td>';
        tbody.insertBefore(tr, tbody.firstChild);
      });
      document.getElementById("dc-save-elm")?.addEventListener("click", async () => {
        const t = sessionStorage.getItem("ibm_admin_token_v1") || "";
        const rows = [...document.querySelectorAll("#dc-elm-tbody tr[data-id]")];
        let saved = 0;
        for (const tr of rows) {
          const id = tr.dataset.id;
          const body = {
            elm_version: tr.querySelector(".elm-version")?.value || "",
            ifix_version: tr.querySelector(".elm-ifix")?.value || "",
            upgrade_date: tr.querySelector(".elm-date")?.value || null,
            notes: tr.querySelector(".elm-notes")?.value || ""
          };
          if (!body.elm_version) continue;
          const url = id ? "/iip/api/admin/elm-upgrades/" + id : "/iip/api/admin/elm-upgrades";
          const method = id ? "PUT" : "POST";
          const r = await fetch(url, { method, headers: { "x-iip-admin-token": t, "Content-Type": "application/json" }, body: JSON.stringify(body) });
          if (r.ok) { const d = await r.json(); tr.dataset.id = d.id || id; saved++; }
        }
        showToast(saved + " ELM entries saved!", "success");
      });
    })();
    // ── App settings loader ──
    (function _waitApp() {
      const tok = sessionStorage.getItem("ibm_admin_token_v1");
      if (!tok) { setTimeout(_waitApp, 300); return; }
      const appBody = document.getElementById("adm-appid-body");
      if (!appBody) return;
      fetch("/iip/api/admin/app-settings", { headers: { "x-iip-admin-token": tok } })
        .then(r => r.ok ? r.json() : Promise.reject(r.status))
        .then(data => {
          const s = data.settings || {};
          appBody.innerHTML = '<div style="padding:16px;display:grid;grid-template-columns:1fr 1fr;gap:12px">'
            + Object.entries(s).filter(([k]) => !["customer_products","wt_categories","closed_statuses"].includes(k)).map(([k,v]) =>
              '<div><label style="font-size:11px;font-weight:600;color:var(--text-tertiary);text-transform:uppercase;display:block;margin-bottom:4px">' + k.replace(/_/g,' ') + '</label>'
              + '<input class="form-input app-setting-input" data-key="' + k + '" style="width:100%;font-size:12px" value="' + Utils.escHtml(v||'') + '"/></div>'
            ).join('')
            + '<div style="grid-column:1/-1;margin-top:8px"><button id="dc-save-app-settings" class="btn btn-primary btn-sm">Save Settings</button></div>'
            + '</div>';
          document.getElementById("dc-save-app-settings")?.addEventListener("click", async () => {
            const t = sessionStorage.getItem("ibm_admin_token_v1") || "";
            const updates = {};
            document.querySelectorAll(".app-setting-input").forEach(el => { updates[el.dataset.key] = el.value; });
            const r = await fetch("/iip/api/admin/app-settings", { method: "PUT", headers: { "x-iip-admin-token": t, "Content-Type": "application/json" }, body: JSON.stringify(updates) });
            if (r.ok) showToast("Settings saved!", "success"); else showToast("Save failed", "error");
          });
        })
        .catch(e => { appBody.innerHTML = '<div style="padding:12px;color:var(--red)">Failed to load app settings (' + e + ')</div>'; });
    })();

    function filterHistory(rows, query) {
      if (!query) return rows;
      var q = query.toLowerCase();
      return rows.filter(function(r) {
        return (r.caseNumber || "").toLowerCase().includes(q) ||
               (r.field      || "").toLowerCase().includes(q) ||
               (r.oldValue   || "").toLowerCase().includes(q) ||
               (r.newValue   || "").toLowerCase().includes(q) ||
               (r.updatedBy  || "").toLowerCase().includes(q);
      });
    }
    function renderHistory(rows) {
      if (!rows || !rows.length) return "<div style='padding:16px;text-align:center;color:var(--text-tertiary);font-size:12px'>No history entries found.</div>";
      return rows.map(function(r) {
        var ts = r.timestamp ? new Date(r.timestamp).toLocaleString() : "";
        var change = r.oldValue
          ? "<span style='color:var(--red)'>" + r.oldValue + "</span> → <span style='color:var(--green)'>" + r.newValue + "</span>"
          : r.newValue;
        return "<div style='padding:8px 12px;border-bottom:1px solid var(--border);font-size:12px'>"
          + "<div style='display:flex;justify-content:space-between;margin-bottom:2px'>"
          + "<span style='font-weight:600;color:var(--text-primary)'>" + (r.caseNumber || "—") + "</span>"
          + "<span style='color:var(--text-tertiary);font-size:11px'>" + ts + "</span></div>"
          + "<div style='color:var(--text-secondary)'><span style='color:var(--blue)'>" + r.field + "</span>"
          + (change ? " · " + change : "") + "</div>"
          + "<div style='color:var(--text-tertiary);margin-top:2px;font-size:11px'>by " + r.updatedBy + "</div></div>";
      }).join("");
    }
    // ── Render history list — load from DB audit_log (shared cache with renderReassignLog)
    const histList = document.getElementById("history-list");
    if (histList) {
      histList.innerHTML = '<div style="padding:16px;text-align:center;color:var(--text-tertiary);font-size:12px">Loading…</div>';
      // Cache the promise so renderReassignLog reuses the same fetch
      if (!window.__auditLogPromise) {
        const _aTok = (typeof Admin !== 'undefined' && Admin.getToken) ? Admin.getToken() : '';
        if (_aTok) {
          // Deferred: only fetch audit log when history section is first expanded
          const _histSection = histList.closest('.adm-section');
          const _loadAudit = () => {
            if (window.__auditLogPromise) return;
            window.__auditLogPromise = AdminAPIClient.getAuditLog(2000).catch(() => []);
            setTimeout(() => { delete window.__auditLogPromise; }, 30000);
            window.__auditLogPromise.then(rows => {
              const mapped = (Array.isArray(rows) ? rows : []).map(r => ({
                id: r.id, caseNumber: r.entity_id || '', field: r.action || '',
                oldValue: r.old_value || '', newValue: r.new_value || '',
                updatedBy: r.admin_user || 'Admin', timestamp: r.change_date || ''
              }));
              _auditLogRows = mapped;
              if (histList) histList.innerHTML = renderHistory(filterHistory(mapped));
            }).catch(() => { if (histList) histList.innerHTML = "<div style='padding:12px;color:var(--red);font-size:12px'>Failed to load audit log</div>"; });
          };
          if (_histSection && !_histSection.classList.contains('collapsed')) {
            _loadAudit();
          } else if (_histSection) {
            _histSection.querySelector('.adm-section-header')?.addEventListener('click', function _once() {
              this.removeEventListener('click', _once);
              setTimeout(_loadAudit, 100);
            });
          }
          window.__auditLogPromise = window.__auditLogPromise || Promise.resolve([]);
        } else {
          window.__auditLogPromise = Promise.resolve([]);
        }
      }
      window.__auditLogPromise.then(rows => {
          const mapped = (Array.isArray(rows) ? rows : []).map(r => ({
            id: r.id, caseNumber: r.entity_id || "", field: r.action || "",
            oldValue: r.old_value || "", newValue: r.new_value || "",
            updatedBy: r.admin_user || "Admin", timestamp: r.change_date || ""
          }));
          _auditLogRows = mapped; // cache for search handler
          if (histList) histList.innerHTML = renderHistory(filterHistory(mapped));
        })
        .catch(() => { if (histList) histList.innerHTML = "<div style='padding:12px;color:var(--red);font-size:12px'>Failed to load audit log</div>"; });
    }

    // ── Render perf/nonperf chips — loaded by _syncPerfFromDB below ─

    // -- RFE count from DB --
    (function _loadRfeCount() {
      var countEl = document.getElementById("rfe-total-count");
      var dateEl  = document.getElementById("rfe-last-updated");
      if (!countEl) return;
      var tok = (typeof Admin !== "undefined" && Admin.getToken) ? Admin.getToken() : "";
      fetch("/iip/api/v2/rfe-data", { headers: { "x-iip-admin-token": tok } })
        .then(function(r){ return r.json(); })
        .then(function(rows){
          var count = Array.isArray(rows) ? rows.length : 0;
          if (countEl) countEl.textContent = count;
          if (dateEl) {
            if (count > 0) {
              var latest = rows.reduce(function(a,b){ return ((b["Updated At"]||"") > (a["Updated At"]||"") ? b : a); }, rows[0]);
              var d = latest["Updated At"] ? new Date(latest["Updated At"]).toLocaleDateString() : "";
              dateEl.textContent = d ? "Last updated: " + d : count + " ideas loaded";
            } else { dateEl.textContent = "No RFE data imported yet"; }
          }
        })
        .catch(function(){
          if (countEl) countEl.textContent = "-";
          if (dateEl)  dateEl.textContent  = "Could not reach database";
        });
    }());

    // ── Load dashboard stats from DB ─────────────────────────────
    (async function _loadDashStats() {
      try {
        const tok  = (typeof Admin !== "undefined" && Admin.getToken) ? Admin.getToken() : "";
        const base = window.API_BASE_V2 || "/iip/api/v2";
        if (!tok) return;
        const res  = await fetch(`${base}/admin/dashboard-stats`, {
          headers: { "x-iip-admin-token": tok }
        });
        if (!res.ok) {
          // dashboard-stats not available — populate what we can from local Data
          const uploadEl  = document.getElementById("adm-stat-upload");
          const uploadSub = document.getElementById("adm-stat-upload-sub");
          const activeEl  = document.getElementById("adm-stat-active");
          const perfEl    = document.getElementById("adm-stat-perf");
          const perfSub   = document.getElementById("adm-stat-nonperf-sub");
          const chgEl     = document.getElementById("adm-stat-changes");
          const reSub     = document.getElementById("adm-stat-reassign-sub");
          const all       = Data.allCases ? Data.allCases() : [];
          const active    = all.filter(c => !(typeof Utils !== "undefined" && Utils.isClosed ? Utils.isClosed(c.Status) : false));
          if (uploadEl)  { uploadEl.textContent  = "—"; uploadEl.style.color = "var(--text-tertiary)"; }
          if (uploadSub) { uploadSub.textContent = all.length ? all.length.toLocaleString() + " records loaded" : "—"; }
          if (activeEl)  { activeEl.textContent  = active.length.toLocaleString(); }
          if (perfEl)    { perfEl.textContent    = (Data.getPerfCaseNums ? Data.getPerfCaseNums() : []).length.toLocaleString(); }
          if (perfSub)   { perfSub.textContent   = (Data.getNonPerfCaseNums ? Data.getNonPerfCaseNums() : []).length.toLocaleString() + " non-perf"; }
          if (chgEl)     { chgEl.textContent     = (Data.changeHistory ? Data.changeHistory() : []).length.toLocaleString(); }
          if (reSub)     { reSub.textContent     = "from local history"; }
          return;
        }
        const d = await res.json();

        // Stat cards
        const uploadEl    = document.getElementById("adm-stat-upload");
        const uploadSub   = document.getElementById("adm-stat-upload-sub");
        const perfEl      = document.getElementById("adm-stat-perf");
        const perfSub     = document.getElementById("adm-stat-nonperf-sub");
        const activeEl    = document.getElementById("adm-stat-active");
        const changesEl   = document.getElementById("adm-stat-changes");
        const reassignSub = document.getElementById("adm-stat-reassign-sub");

        if (uploadEl && d.last_upload) {
          const dt = new Date(d.last_upload.upload_date);
          const today = new Date();
          const isToday = dt.toDateString() === today.toDateString();
          uploadEl.textContent = isToday ? "Today" : dt.toLocaleDateString("en-GB", { day:"2-digit", month:"short" });
          uploadEl.style.color = d.last_upload.status === "success" ? "var(--green)" : "var(--red)";
          if (uploadSub) uploadSub.textContent = (d.last_upload.record_count || 0).toLocaleString() + " records · " + d.last_upload.status;
        }
        if (perfEl)    { perfEl.textContent    = (d.perf_count || 0).toLocaleString(); }
        if (perfSub)   { perfSub.textContent   = (d.non_perf_count || 0).toLocaleString() + " non-perf"; }
        if (activeEl)  { activeEl.textContent  = (d.active_cases || 0).toLocaleString(); }
        if (changesEl) { changesEl.textContent = (d.changes_7d || 0).toLocaleString(); }
        if (reassignSub) { reassignSub.textContent = (d.reassigns_week || 0) + " reassignments this week"; }


      } catch(e) {
        console.warn("[Admin] dashboard-stats failed:", e.message);
      }
    })();

    // ── Sync perf/non-perf from DB ───────────────────────────────
    (async function _syncPerfFromDB() {
      try {
        const base = window.API_BASE_V2 || "/iip/api/v2";
        const tok  = (typeof Admin !== "undefined" && Admin.getToken) ? Admin.getToken() : "";
        if (!tok) return; // skip if no admin token yet
        // Only load perf summary when stats section is visible
        const _statsEl = document.getElementById('adm-stat-perf');
        if (!_statsEl) return;
        const resp = await fetch(`${base}/cases/performance-summary`, {
          headers: tok ? { "x-iip-admin-token": tok } : {}
        });
        if (!resp.ok) {
          // Fallback: use counts already loaded in Data module
          const pb = document.getElementById("adm-perf-count-badge");
          const nb = document.getElementById("adm-nonperf-count-badge");
          const perfNums = Data.getPerfCaseNums ? Data.getPerfCaseNums() : [];
          const npNums   = Data.getNonPerfCaseNums ? Data.getNonPerfCaseNums() : [];
          if (pb) pb.textContent = perfNums.length;
          if (nb) nb.textContent = npNums.length;
          return;
        }
        const { performance_cases, non_performance_cases } = await resp.json();
        Data.setPerfCaseNums(performance_cases.map(p => p.case_number));
        performance_cases.forEach(p => {
          const wi = p.work_items && p.work_items[0] ? p.work_items[0].work_item : null;
          if (wi) Data.setPerformanceMeta(p.case_number, { workItem: wi, category: "performance" });
        });
        Data.setNonPerfCaseNums(non_performance_cases.map(p => p.case_number));
        // Pass already-fetched data — avoids 2 extra performance-summary calls
        renderPerfNums({ performance_cases, non_performance_cases });
        renderNonPerfNums({ performance_cases, non_performance_cases });
        const pb = document.getElementById("adm-perf-count-badge");
        const nb = document.getElementById("adm-nonperf-count-badge");
        if (pb) pb.textContent = performance_cases.length;
        if (nb) nb.textContent = non_performance_cases.length;
      } catch(e) {
        // Final fallback: show counts from Data module
        try {
          const pb = document.getElementById("adm-perf-count-badge");
          const nb = document.getElementById("adm-nonperf-count-badge");
          if (pb) pb.textContent = (Data.getPerfCaseNums ? Data.getPerfCaseNums() : []).length;
          if (nb) nb.textContent = (Data.getNonPerfCaseNums ? Data.getNonPerfCaseNums() : []).length;
        } catch(_) {}
      }
    })();

    // ── Auto-refresh perf counts on SSE events + periodic poll ─────
    async function _refreshPerfCounts() {
      try {
        const base = window.API_BASE_V2 || "/iip/api/v2";
        const tok  = (typeof Admin !== "undefined" && Admin.getToken) ? Admin.getToken() : "";
        const resp = await fetch(`${base}/cases/performance-summary`, {
          headers: tok ? { "x-iip-admin-token": tok } : {}
        });
        if (!resp.ok) return;
        const { performance_cases, non_performance_cases } = await resp.json();
        // Update Data module using correct API methods
        Data.setPerfCaseNums(performance_cases.map(p => p.case_number));
        Data.setNonPerfCaseNums(non_performance_cases.map(p => p.case_number));
        // Update perf metadata in bulk (avoids N x persist calls)
        const _perfMetaBulk = {};
        performance_cases.forEach(p => {
          const wi = p.work_items && p.work_items[0] ? p.work_items[0].work_item : null;
          _perfMetaBulk[p.case_number] = { workItem: wi || "", category: "performance" };
        });
        if (Object.keys(_perfMetaBulk).length) Data.setPerformanceMetaBulk(_perfMetaBulk);
        // Update badges directly from DB response
        const pb = document.getElementById("adm-perf-count-badge");
        const nb = document.getElementById("adm-nonperf-count-badge");
        if (pb) pb.textContent = performance_cases.length;
        if (nb) nb.textContent = non_performance_cases.length;
        // Re-render chips — pass pre-fetched data to avoid 2 extra fetches
        renderPerfNums({ performance_cases, non_performance_cases });
        renderNonPerfNums({ performance_cases, non_performance_cases });
      } catch(e) { console.warn("[Admin] _refreshPerfCounts failed:", e); }
    }

    // Wire SSE events — only once per admin session (guard prevents re-wiring on re-renders)
    if (!window.__adminPerfCountsWired) {
      window.__adminPerfCountsWired = true;
      // Debounced wrapper — collapses rapid SSE bursts into one call
      let _perfRefreshTimer = null;
      function _debouncedRefresh() {
        clearTimeout(_perfRefreshTimer);
        _perfRefreshTimer = setTimeout(_refreshPerfCounts, 500);
      }
      try {
        document.addEventListener("iip-data-updated",  _debouncedRefresh);
        document.addEventListener("iip-admin-updated", _debouncedRefresh);
        // Tab-change cleanup
        document.addEventListener("iip-tab-change", function h(e) {
          if (e.detail && e.detail.tab !== "admin") {
            document.removeEventListener("iip-tab-change", h);
            document.removeEventListener("iip-data-updated",  _debouncedRefresh);
            document.removeEventListener("iip-admin-updated", _debouncedRefresh);
            window.__adminPerfCountsWired = false;
          }
        });
      } catch(e) {}
    }

    // ── Lazy-load sections on first expand ───────────────────────
    function _lazySection(sectionId, loader) {
      // Load immediately on render
      loader();
    }

    // Team members lazy load — DISABLED (handled by Block 2 static HTML + Block 3 handlers)
    _lazySection("adm-sec-team", function() {
      const body = document.getElementById("adm-team-body");
      if (!body) return;
      const tok = sessionStorage.getItem("ibm_admin_token_v1") || (typeof Admin !== "undefined" && Admin.getToken ? Admin.getToken() : "");

      body.innerHTML = `
        <div style="padding:0 2px 4px 2px">
          <div style="border:1px solid var(--border-subtle);border-radius:8px;background:var(--bg-ui);width:100%">
            <table style="width:100%;border-collapse:collapse;font-size:12px;table-layout:fixed">
              <thead>
                <tr style="background:var(--bg-layer);border-bottom:2px solid var(--border-subtle)">
                  <th style="padding:9px 12px;text-align:left;font-size:10px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:var(--text-tertiary);width:16%">Name (from CSV)</th>
                  <th style="padding:9px 12px;text-align:left;font-size:10px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:var(--text-tertiary);width:16%">Display Name</th>
                  <th style="padding:9px 12px;text-align:left;font-size:10px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:var(--text-tertiary);width:28%">Email</th>
                  <th style="padding:9px 12px;text-align:left;font-size:10px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:var(--text-tertiary);width:13%">Team</th>
                  <th style="padding:9px 12px;text-align:left;font-size:10px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:var(--text-tertiary);width:11%">Status</th>
                  <th style="padding:9px 12px;text-align:center;font-size:10px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:var(--text-tertiary);width:8%">Actions</th>
                </tr>
              </thead>
              <tbody id="dc-members-tbody">
                <tr><td colspan="6" style="padding:24px;text-align:center;color:var(--text-tertiary);font-size:12px">Loading…</td></tr>
              </tbody>
            </table>
          </div>
          <div style="margin-top:12px;display:flex;align-items:center;gap:8px;flex-wrap:wrap">
            <button id="dc-add-member" class="btn btn-ghost btn-sm">+ Add Member</button>
            <button id="dc-save-members" class="btn btn-primary btn-sm">Save All Changes</button>
            <label class="btn btn-secondary btn-sm" style="cursor:pointer">Import Excel<input id="dc-import-members-xlsx" type="file" accept=".xlsx,.xls" style="display:none"/></label>
            <button id="dc-export-members-xlsx" class="btn btn-secondary btn-sm">Export Excel</button>
          </div>
        </div>`;

      // ── Zone helper: Active rows first, Departed rows second ──────────
      function _reorderZones() {
        var tb = document.getElementById("dc-members-tbody");
        if (!tb) return;
        var active   = [...tb.querySelectorAll("tr[data-member-id][data-status='Active']")];
        var departed = [...tb.querySelectorAll("tr[data-member-id][data-status='Departed']")];
        var hA = tb.querySelector(".dc-zone-hdr[data-zone='active']");
        var hD = tb.querySelector(".dc-zone-hdr[data-zone='departed']");
        if (!hA) {
          hA = document.createElement("tr"); hA.className = "dc-zone-hdr"; hA.dataset.zone = "active";
          hA.innerHTML = '<td colspan="6" style="padding:8px 14px;font-size:10px;font-weight:700;letter-spacing:.07em;text-transform:uppercase;color:var(--green);background:var(--bg-layer);border-top:1px solid var(--border-subtle);border-bottom:1px solid var(--border-subtle)"><span style=\"display:inline-block;width:6px;height:6px;border-radius:50%;background:currentColor;margin-right:7px;vertical-align:1px\"></span>Active <span class="dc-zone-cnt" style="font-weight:400;color:var(--text-tertiary);margin-left:3px"></span></td>';
        }
        if (!hD) {
          hD = document.createElement("tr"); hD.className = "dc-zone-hdr"; hD.dataset.zone = "departed";
          hD.innerHTML = '<td colspan="6" style="padding:8px 14px;font-size:10px;font-weight:700;letter-spacing:.07em;text-transform:uppercase;color:var(--text-tertiary);background:var(--bg-layer);border-top:1px solid var(--border-subtle);border-bottom:1px solid var(--border-subtle)"><span style=\"display:inline-block;width:6px;height:6px;border-radius:50%;background:var(--border-mid);margin-right:7px;vertical-align:1px\"></span>Departed <span class="dc-zone-cnt" style="font-weight:400;margin-left:3px"></span></td>';
        }
        var cA = hA.querySelector(".dc-zone-cnt"); if (cA) cA.textContent = "(" + active.length + ")";
        var cD = hD.querySelector(".dc-zone-cnt"); if (cD) cD.textContent = "(" + departed.length + ")";
        tb.appendChild(hA);
        active.forEach(function(r) { tb.appendChild(r); });
        tb.appendChild(hD);
        departed.forEach(function(r) { tb.appendChild(r); });
      }

      function _memberRow(m) {
        const id = m.id || "";
        const status = m.status || "Active";
        const statusOpts = ["Active","Departed"].map(s =>
          `<option value="${s}"${status===s?" selected":""}>${s}</option>`).join("");
        const teamColors = {
          Automation: "background:rgba(121,80,204,.1);color:#7950cc;border-color:rgba(121,80,204,.25)",
          Database:   "background:rgba(0,125,121,.1);color:var(--teal);border-color:rgba(0,125,121,.25)",
          German:     "background:rgba(15,98,254,.1);color:var(--ibm-blue-50);border-color:rgba(15,98,254,.25)",
          Operation:  "background:rgba(36,161,72,.1);color:var(--green);border-color:rgba(36,161,72,.25)",
          Tools:      "background:rgba(214,112,0,.1);color:var(--orange);border-color:rgba(214,112,0,.25)",
        };
        const ts = teamColors[m.team] || "background:var(--bg-layer-2);color:var(--text-secondary);border-color:var(--border-subtle)";
        const isActive = status === "Active";
        const ss = isActive ? "background:rgba(36,161,72,.08);color:var(--green);border-color:rgba(36,161,72,.25)" : "background:var(--bg-layer-2);color:var(--text-tertiary);border-color:var(--border-subtle)";
        return `<tr data-member-id="${Utils.escHtml(String(id))}" data-status="${Utils.escHtml(status)}" style="border-bottom:1px solid var(--border-subtle)">
          <td style="padding:6px 12px;width:16%;overflow:hidden"><input class="form-input dc-member-name" style="width:100%;min-width:0;font-size:12px;height:32px;box-sizing:border-box" data-field="name" value="${Utils.escHtml(m.name||"")}"/></td>
          <td style="padding:6px 12px;width:16%;overflow:hidden"><input class="form-input dc-member-display-name" style="width:100%;min-width:0;font-size:12px;height:32px;box-sizing:border-box" data-field="display_name" placeholder="${Utils.escHtml(m.name||"")}" value="${Utils.escHtml(m.display_name||"")}"/></td>
          <td style="padding:6px 12px;width:28%;overflow:hidden"><input class="form-input dc-member-email" style="width:100%;min-width:0;font-size:12px;height:32px;box-sizing:border-box;font-family:var(--font-mono)" data-field="email" value="${Utils.escHtml(m.email||"")}"/></td>
          <td style="padding:6px 12px;width:13%;overflow:hidden"><select class="form-select dc-member-team-input" style="width:100%" data-field="team"><option value="">-- Team --</option><option value="Automation"${m.team==="Automation"?" selected":""}>Automation</option><option value="Database"${m.team==="Database"?" selected":""}>Database</option><option value="German"${m.team==="German"?" selected":""}>German</option><option value="Operation"${m.team==="Operation"?" selected":""}>Operation</option><option value="Tools"${m.team==="Tools"?" selected":""}>Tools</option></select></td>
          <td style="padding:6px 12px;width:11%;overflow:hidden"><select class="form-select dc-member-status-select" style="width:100%" data-field="status">${statusOpts}</select></td>
          <td style="padding:6px 8px;width:8%;text-align:center;white-space:nowrap">
            <button class="btn btn-ghost member-save-row" data-id="${Utils.escHtml(String(id))}" title="Save" style="color:var(--green);width:32px;height:32px;padding:0;display:inline-flex;align-items:center;justify-content:center;font-size:16px;border-color:rgba(36,161,72,.3)">✓</button>
          </td>
        </tr>`;
      }

      // ── Fetch members from DB and populate table ──────────────────────
      window.__teamMembersPromise = fetch("/iip/api/admin/team-members", {
        headers: { "x-iip-admin-token": tok }
      })
        .then(function(r) { return r.ok ? r.json() : Promise.reject(r.status); })
        .then(function(data) {
          var members = Array.isArray(data) ? data : (data.members || []);
          var tb = document.getElementById("dc-members-tbody");
          if (!tb) return;
          tb.innerHTML = "";
          members.forEach(function(m) { tb.insertAdjacentHTML("beforeend", _memberRow(m)); });
          _reorderZones();
        })
        .catch(function(err) {
          var tb = document.getElementById("dc-members-tbody");
          if (tb) tb.innerHTML = "<tr><td colspan='6' style='padding:12px;color:var(--red);font-size:12px'>Failed to load team members (" + err + ")</td></tr>";
        });

      // ── Add Member button ─────────────────────────────────────────────
      body.addEventListener("click", function(e) {
        if (e.target.closest("#dc-add-member")) {
          var tb = document.getElementById("dc-members-tbody");
          if (!tb) return;
          var tr = document.createElement("tr");
          tr.dataset.memberId = ""; tr.dataset.status = "Active";
          tr.style.cssText = "height:44px;vertical-align:middle";
          tr.innerHTML = '<td style="padding:6px 10px;overflow:hidden"><input class="form-input dc-member-name" style="width:100%;box-sizing:border-box;font-size:12px;height:30px;font-weight:500;min-width:0" data-field="name" placeholder="Full name"/></td>'
            + '<td style="padding:6px 10px;overflow:hidden"><input class="form-input dc-member-display-name" style="width:100%;box-sizing:border-box;font-size:12px;height:30px;min-width:0" data-field="display_name" placeholder="Display name (optional)"/></td>'
            + '<td style="padding:6px 10px;overflow:hidden"><input class="form-input dc-member-email" style="width:100%;box-sizing:border-box;font-size:12px;height:30px;font-family:var(--font-mono);min-width:0" data-field="email" placeholder="email@example.com"/></td>'
            + '<td style="padding:6px 10px;overflow:hidden"><select class="form-select dc-member-team-input" style="width:100%" data-field="team"><option value="">— Team —</option><option>Automation</option><option>Database</option><option>German</option><option>Operation</option><option>Tools</option></select></td>'
            + '<td style="padding:6px 10px;overflow:hidden"><select class="form-select dc-member-status-select" style="width:100%" data-field="status"><option>Active</option><option>Departed</option></select></td>'
            + '<td style="padding:7px 10px;text-align:center;white-space:nowrap">'
            + '<button class="btn btn-ghost btn-xs member-save-row" data-id="" title="Save" style="color:var(--green);padding:4px 8px;border-color:rgba(36,161,72,.3)"><svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg></button>'
            + ' <button class="btn btn-ghost btn-xs member-cancel-row" data-id="" title="Cancel" style="color:var(--red);padding:4px 8px;border-color:rgba(218,30,40,.3);margin-left:3px"><svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button></td>';
          tb.insertBefore(tr, tb.firstChild);
          tr.querySelector("input").focus();
        }
        // Cancel new row
        if (e.target.closest(".member-cancel-row")) { e.target.closest("tr").remove(); return; }
        // Delete existing member
        var delBtn = e.target.closest(".member-del-row");
        if (delBtn) {
          var delId = delBtn.dataset.id;
          if (!delId || !window.confirm("Delete this member?")) return;
          var delTok = sessionStorage.getItem("ibm_admin_token_v1") || tok;
          fetch("/iip/api/admin/team-members/" + delId, { method: "DELETE", headers: { "x-iip-admin-token": delTok } })
            .then(function(r) {
              if (r.ok) { delBtn.closest("tr").remove(); _reorderZones(); showToast("Member deleted", "success"); try { if (typeof DynamicConfig !== "undefined") DynamicConfig.load(); } catch(ex) {} }
              else showToast("Delete failed", "danger");
            }).catch(function() { showToast("Delete failed", "danger"); });
          return;
        }
        // Save individual row
        var saveBtn = e.target.closest(".member-save-row");
        if (saveBtn) {
          var tr2 = saveBtn.closest("tr");
          var saveTok = sessionStorage.getItem("ibm_admin_token_v1") || tok;
          var rowId = saveBtn.dataset.id;
          var payload = {
            name: (tr2.querySelector("[data-field=name]") || {}).value || "",
            display_name: (tr2.querySelector("[data-field=display_name]") || {}).value || null,
            email: (tr2.querySelector("[data-field=email]") || {}).value || "",
            team: (tr2.querySelector("[data-field=team]") || {}).value || "",
            status: (tr2.querySelector("[data-field=status]") || {}).value || "Active"
          };
          if (!payload.name) { showToast("Name is required", "warning"); return; }
          var url2  = rowId ? "/iip/api/admin/team-members/" + rowId : "/iip/api/admin/team-members";
          var meth2 = rowId ? "PUT" : "POST";
          fetch(url2, { method: meth2, headers: { "Content-Type": "application/json", "x-iip-admin-token": saveTok }, body: JSON.stringify(payload) })
            .then(function(r2) { return r2.ok ? r2.json() : Promise.reject(r2.status); })
            .then(function(saved) {
              if (!rowId && saved.id) { saveBtn.dataset.id = saved.id; tr2.dataset.memberId = saved.id; }
              tr2.dataset.status = payload.status;
              _reorderZones();
              showToast("Member saved", "success");
              try { if (typeof DynamicConfig !== "undefined") DynamicConfig.load(); } catch(ex) {}
            })
            .catch(function() { showToast("Save failed", "danger"); });
        }
      });
    });



    // ── Team Members: Save ───────────────────────────────────────────────
    document.getElementById("dc-save-members")?.addEventListener("click", async () => {
      const tok = Admin.getToken();
      const rows = [];
      document.querySelectorAll("#dc-members-tbody tr").forEach(tr => {
        const name   = tr.querySelector(".dc-member-name")?.value?.trim()          || "";
        const displayName = tr.querySelector(".dc-member-display-name")?.value?.trim() || "";
        const email  = tr.querySelector(".dc-member-email")?.value?.trim()         || "";
        const team   = tr.querySelector(".dc-member-team-input")?.value?.trim()    || "";
        const status = tr.querySelector(".dc-member-status-select")?.value         || "Active";
        const id     = tr.dataset.id ? parseInt(tr.dataset.id) : null;
        if (!name) return;
        rows.push({ id, name, email, team, status, display_name: displayName || null });
      });
      if (!rows.length) { showToast("No members to save.", "warning"); return; }
      let saved = 0, failed = 0;
      for (const row of rows) {
        try {
          const url  = row.id ? `/iip/api/admin/team-members/${row.id}` : "/iip/api/admin/team-members";
          const meth = row.id ? "PUT" : "POST";
          const res  = await fetch(url, {
            method: meth,
            headers: { "Content-Type": "application/json", "x-iip-admin-token": tok },
            body: JSON.stringify({ name: row.name, email: row.email, team: row.team, status: row.status, display_name: row.display_name })
          });
          if (res.ok) saved++; else failed++;
        } catch(e) { failed++; }
      }
      const msg = failed ? `${saved} saved, ${failed} failed.` : `Saved ${saved} team members to database!`;
      showToast(msg, failed ? "warning" : "success");
      // Reload DynamicConfig so display name aliases + team list update across all dashboards
      try { if (typeof DynamicConfig !== "undefined") await DynamicConfig.load(); } catch(e) {}
      _refreshAllDashboards();
      render();

    });

    // ── ALM Lines: row HTML builder (defined once, used by loader / Add / Import) ──
    function _almRowHtmlInner(r) {
      const esc = function(v) { return Utils.escHtml(v || ""); };
      const autoEmail = function(inputCls, emailCls) {
        return 'oninput="(function(el){' +
          'var em=el.closest(\'tr\').querySelector(\'.' + emailCls + '\');' +
          'if(!em||em.dataset.manual===\'1\')return;' +
          'var name=el.value.trim();' +
          'var found=(typeof DynamicConfig!==\'undefined\'&&DynamicConfig.teamEmails?DynamicConfig.teamEmails()[name]:null)||\'\';' +
          'em.value=found;' +
          '})(this)"';
      };
      return '<td class="p-compact">'
        + '<input class="form-input dc-alm-line" aria-label="ALM line" style="width:96px;font-size:12px;font-family:var(--font-mono);font-weight:600"'
        + ' value="' + esc(r.alm_line) + '" placeholder="ALM-XX-P"/></td>'

        + '<td class="p-compact">'
        + '<input class="form-input dc-alm-names" aria-label="Customer contacts" style="width:150px;font-size:11px"'
        + ' value="' + esc(r.customer_contact) + '" placeholder="Name 1; Name 2"/></td>'

        + '<td class="p-compact">'
        + '<input class="form-input dc-alm-emails" aria-label="Customer emails" style="width:180px;font-size:11px;font-family:var(--font-mono)"'
        + ' value="' + esc(r.customer_email) + '" placeholder="email1@co.com;email2@co.com"/></td>'

        + '<td class="p-compact">'
        + '<input class="form-input dc-alm-bd filter-input-sm" aria-label="Line manager" value="' + esc(r.line_manager) + '"'
        + ' placeholder="Line Manager" ' + autoEmail('dc-alm-bd', 'dc-alm-bdemail') + '/></td>'

        + '<td class="p-compact">'
        + '<input class="form-input dc-alm-bdemail filter-input-mono" aria-label="Line manager email" value="' + esc(r.line_manager_email) + '"'
        + ' placeholder="bd-line@bosch.com" oninput="this.dataset.manual=this.value?\'1\':\'0\'"/></td>'

        + '<td class="p-compact">'
        + '<input class="form-input dc-alm-ibm filter-input-sm" aria-label="Case responsible" value="' + esc(r.case_responsible) + '"'
        + ' placeholder="Case Responsible" ' + autoEmail('dc-alm-ibm', 'dc-alm-ibmemail') + '/></td>'

        + '<td class="p-compact">'
        + '<input class="form-input dc-alm-ibmemail filter-input-mono" aria-label="Case responsible email" value="' + esc(r.case_responsible_email) + '"'
        + ' placeholder="name@de.bosch.com" oninput="this.dataset.manual=this.value?\'1\':\'0\'"/></td>'

        + '<td class="p-compact">'
        + '<input class="form-input dc-alm-proxy filter-input-sm" aria-label="Case responsible proxy" value="' + esc(r.case_responsible_proxy) + '"'
        + ' placeholder="Case Responsible Proxy" ' + autoEmail('dc-alm-proxy', 'dc-alm-proxyemail') + '/></td>'

        + '<td class="p-compact">'
        + '<input class="form-input dc-alm-proxyemail filter-input-mono" aria-label="Proxy email" value="' + esc(r.case_responsible_proxy_email) + '"'
        + ' placeholder="name@de.bosch.com" oninput="this.dataset.manual=this.value?\'1\':\'0\'"/></td>'

        + '<td class="p-compact-c" style="text-align:center">'
        + '<button class="btn btn-ghost btn-sm dc-remove-alm" title="Delete row" style="color:var(--red);padding:3px 7px">' + IC.trash + '</button></td>';
    }
    // Expose for Import Excel handler (called from change listener below)
    window._almRowHtml = function(r) { return _almRowHtmlInner(r); };

    // ── ALM Lines: DB load function — called on toggle open and after save ──
    function _loadAlmLines() { window._loadAlmLines = _loadAlmLines;
      var tbody = document.getElementById("dc-alm-tbody"); if (!tbody) return;
      tbody.innerHTML = '<tr><td colspan="10" style="padding:12px;text-align:center;color:var(--text-secondary);font-size:12px">Loading…</td></tr>';
      var tok = sessionStorage.getItem("ibm_admin_token_v1") || "";
      fetch("/iip/api/admin/alm-lines", { headers: { "x-iip-admin-token": tok } })
        .then(function(res) { return res.ok ? res.json() : Promise.reject(res.status + " " + res.statusText); })
        .then(function(lines) {
          var tbody = document.getElementById("dc-alm-tbody"); if (!tbody) return;
          if (!lines.length) {
            tbody.innerHTML = '<tr><td colspan="10" style="padding:12px;text-align:center;color:var(--text-secondary);font-size:12px">'
              + 'No ALM lines found. Click "+ Add ALM Line" to create one.</td></tr>';
          } else {
            tbody.innerHTML = "";
            lines.forEach(function(r, i) {
              var tr = document.createElement("tr");
              tr.dataset.alm   = r.alm_line;
              tr.dataset.isNew = "0";
              if (i % 2 === 0) tr.style.background = "var(--bg-layer)";
              tr.innerHTML = _almRowHtmlInner(r);
              tbody.appendChild(tr);
            });
          }
          var badge = document.getElementById("dc-alm-count-badge");
          if (badge) badge.textContent = lines.length + " lines";
        })
        .catch(function(err) {
          var tbody = document.getElementById("dc-alm-tbody"); if (!tbody) return;
          tbody.innerHTML = '<tr><td colspan="10" style="padding:12px;color:var(--danger);font-size:12px">'
            + 'Failed to load ALM lines (' + err + ') — check backend or token.</td></tr>';
          console.error("ALM lines load failed:", err);
        });
    }

    // Wire toggle listener — <details> is in DOM here since _wireTeamConfigEvents
    // is called via setTimeout after el.innerHTML is set.
    (function() {
      const almBody = document.getElementById("adm-alm-body");
      if (almBody && !document.getElementById("dc-alm-tbody")) {
        almBody.innerHTML = '<div style="padding:8px 12px 12px">'
          + '<div style="display:flex;gap:8px;margin-bottom:8px;flex-wrap:wrap;align-items:center">'
          + '<button id="dc-add-alm" class="btn btn-ghost btn-sm">+ Add ALM Line</button>'
          + '<button id="dc-save-alm" class="btn btn-primary btn-sm">Save All</button>'
          + '<label class="btn btn-secondary btn-sm" style="cursor:pointer">Import Excel<input id="dc-import-alm-xlsx" type="file" accept=".xlsx,.xls" style="display:none"/></label>'
          + '<button id="dc-export-alm-xlsx" class="btn btn-secondary btn-sm">Export Excel</button>'
          + '<span id="dc-alm-count-badge" style="font-size:11px;color:var(--text-tertiary)"></span>'
          + '</div>'
          + '<div style="overflow-x:auto;border:1px solid var(--border-subtle);border-radius:8px">'
          + '<table style="width:100%;border-collapse:collapse;font-size:12px">'
          + '<thead><tr style="background:var(--bg-layer);border-bottom:2px solid var(--border-subtle)">'
          + '<th style="padding:8px 10px;font-size:10px;font-weight:700;text-transform:uppercase;color:var(--text-tertiary);white-space:nowrap">ALM Line</th>'
          + '<th style="padding:8px 10px;font-size:10px;font-weight:700;text-transform:uppercase;color:var(--text-tertiary)">Customer Contact</th>'
          + '<th style="padding:8px 10px;font-size:10px;font-weight:700;text-transform:uppercase;color:var(--text-tertiary)">Customer Email</th>'
          + '<th style="padding:8px 10px;font-size:10px;font-weight:700;text-transform:uppercase;color:var(--text-tertiary)">Line Manager</th>'
          + '<th style="padding:8px 10px;font-size:10px;font-weight:700;text-transform:uppercase;color:var(--text-tertiary)">LM Email</th>'
          + '<th style="padding:8px 10px;font-size:10px;font-weight:700;text-transform:uppercase;color:var(--text-tertiary)">IBM Contact</th>'
          + '<th style="padding:8px 10px;font-size:10px;font-weight:700;text-transform:uppercase;color:var(--text-tertiary)">IBM Email</th>'
          + '<th style="padding:8px 10px;font-size:10px;font-weight:700;text-transform:uppercase;color:var(--text-tertiary)">Proxy</th>'
          + '<th style="padding:8px 10px;font-size:10px;font-weight:700;text-transform:uppercase;color:var(--text-tertiary)">Proxy Email</th>'
          + '<th style="padding:8px 10px;font-size:10px;font-weight:700;text-transform:uppercase;color:var(--text-tertiary);text-align:center">Actions</th>'
          + '</tr></thead>'
          + '<tbody id="dc-alm-tbody"><tr><td colspan="10" style="padding:12px;text-align:center;color:var(--text-tertiary);font-size:12px">Loading…</td></tr></tbody>'
          + '</table></div></div>';
      }
      _loadAlmLines();
    }());

    // ── ALM Lines: Add Row ───────────────────────────────────────────────
    document.getElementById("dc-add-alm")?.addEventListener("click", () => {
      const tbody = document.getElementById("dc-alm-tbody"); if (!tbody) return;
      // Clear placeholder row if present
      if (tbody.querySelector("tr:not([data-alm])")) tbody.innerHTML = "";
      const idx = tbody.rows.length;
      const tr = document.createElement("tr");
      tr.dataset.alm   = "";
      tr.dataset.isNew = "1";
      if (idx % 2 === 0) tr.style.background = "var(--bg-layer)";
      tr.innerHTML = _almRowHtmlInner({
        alm_line: "", customer_contact: "", customer_email: "",
        line_manager: "", line_manager_email: "",
        case_responsible: "", case_responsible_email: "",
        case_responsible_proxy: "", case_responsible_proxy_email: "",
      });
      tbody.appendChild(tr);
      tr.querySelector(".dc-alm-line")?.focus();
    });

    // ── ALM Lines: Remove Row (delegated — DELETE from DB if existing) ────
    document.getElementById("dc-alm-tbody")?.addEventListener("click", async e => {
      if (!e.target.classList.contains("dc-remove-alm")) return;
      const tr  = e.target.closest("tr");
      const key = tr?.dataset?.alm;
      const isNew = tr?.dataset?.isNew === "1";
      if (!key || isNew) { tr?.remove(); return; }  // unsaved row — just remove
      Modal.showConfirm({ title:"Remove ALM Line", message:`Remove ALM line "${key}" from the database?`, confirmLabel:"Remove", danger:true })
        .then(async ok => {
          if (!ok) return;
          const tok = sessionStorage.getItem("ibm_admin_token_v1") || "";
          try {
            const res = await fetch(`/iip/api/admin/alm-lines/${encodeURIComponent(key)}`, {
              method: "DELETE", headers: { "x-iip-admin-token": tok }
            });
            if (res.ok) {
              tr.remove();
              const badge = document.getElementById("dc-alm-count-badge");
              if (badge) {
                const cnt = document.querySelectorAll("#dc-alm-tbody tr[data-alm]").length;
                badge.textContent = cnt + " lines";
              }
              showToast(`ALM line "${key}" deleted.`, "info");
            } else {
              const err = await res.json().catch(() => ({}));
              showToast("Delete failed: " + (err.detail || res.status), "danger");
            }
          } catch(err) { showToast("Delete failed: " + err.message, "danger"); }
        });
    });

    // ── ALM Lines: Save (POST new / PUT existing — per row) ──────────────
    document.getElementById("dc-save-alm")?.addEventListener("click", async () => {
      const tbody = document.getElementById("dc-alm-tbody"); if (!tbody) return;
      const tok   = sessionStorage.getItem("ibm_admin_token_v1") || "";
      const trs   = [...tbody.querySelectorAll("tr[data-alm]")];
      if (!trs.length) { showToast("No ALM lines to save.", "warning"); return; }

      let saved = 0, failed = 0, skipped = 0;
      const errors = [];

      for (const tr of trs) {
        const origKey = tr.dataset.alm;
        const isNew   = tr.dataset.isNew === "1";
        const almLine = tr.querySelector(".dc-alm-line")?.value?.trim();
        if (!almLine) { skipped++; continue; }

        const payload = {
          customer_contact:            tr.querySelector(".dc-alm-names")?.value?.trim()      || null,
          customer_email:              tr.querySelector(".dc-alm-emails")?.value?.trim()     || null,
          line_manager:                tr.querySelector(".dc-alm-bd")?.value?.trim()         || null,
          line_manager_email:          tr.querySelector(".dc-alm-bdemail")?.value?.trim()    || null,
          case_responsible:            tr.querySelector(".dc-alm-ibm")?.value?.trim()        || null,
          case_responsible_email:      tr.querySelector(".dc-alm-ibmemail")?.value?.trim()   || null,
          case_responsible_proxy:      tr.querySelector(".dc-alm-proxy")?.value?.trim()      || null,
          case_responsible_proxy_email: tr.querySelector(".dc-alm-proxyemail")?.value?.trim() || null,
        };

        try {
          let res, savedRow;
          if (isNew) {
            // POST — create new
            res = await fetch("/iip/api/admin/alm-lines", {
              method: "POST",
              headers: { "Content-Type": "application/json", "x-iip-admin-token": tok },
              body: JSON.stringify({ alm_line: almLine, ...payload }),
            });
          } else {
            // PUT — update existing (use original key in URL in case alm_line field was edited)
            res = await fetch(`/iip/api/admin/alm-lines/${encodeURIComponent(origKey)}`, {
              method: "PUT",
              headers: { "Content-Type": "application/json", "x-iip-admin-token": tok },
              body: JSON.stringify(payload),
            });
          }

          if (res.ok) {
            savedRow = await res.json();
            // Stamp the row with the canonical key from server response
            tr.dataset.alm   = savedRow.alm_line;
            tr.dataset.isNew = "0";
            // Update the ALM line input to reflect canonical server value
            const lineInput = tr.querySelector(".dc-alm-line");
            if (lineInput) lineInput.value = savedRow.alm_line;
            saved++;
          } else {
            const body = await res.json().catch(() => ({}));
            errors.push(`${almLine}: ${body.detail || res.status}`);
            failed++;
          }
        } catch(err) {
          errors.push(`${almLine}: ${err.message}`);
          failed++;
        }
      }

      // Update badge
      const badge = document.getElementById("dc-alm-count-badge");
      if (badge) {
        const cnt = tbody.querySelectorAll("tr[data-alm]").length;
        badge.textContent = cnt + " lines";
      }

      // Sync DynamicConfig cache so Info Dashboard stays up to date, then reload table
      if (saved > 0) {
        try {
          const tok2 = sessionStorage.getItem("ibm_admin_token_v1") || "";
          const fresh = await fetch("/iip/api/admin/alm-lines", { headers: { "x-iip-admin-token": tok2 } });
          if (fresh.ok) {
            const lines = await fresh.json();
            const mapped = lines.map(r => ({
              alm:        r.alm_line,
              names:      r.customer_contact,
              emails:     r.customer_email,
              bd:         r.line_manager,
              bdEmail:    r.line_manager_email,
              ibm:        r.case_responsible,
              ibmEmail:   r.case_responsible_email,
              proxy:      r.case_responsible_proxy,
              proxyEmail: r.case_responsible_proxy_email,
            }));
            await _dcSave({ almResponsible: mapped, customerContacts: mapped.map(r => ({ line: r.alm, names: r.names, emails: r.emails })) });
            _refreshAllDashboards();
          }
        } catch(_) { /* cache sync is best-effort */ }
        // Reload the table from DB to reflect canonical server state
        _loadAlmLines();
      }

      if (failed === 0) {
        showToast(`Saved ${saved} ALM line${saved !== 1 ? "s" : ""} to database!`, "success");
      } else {
        showToast(`${saved} saved, ${failed} failed. ${errors.slice(0,2).join("; ")}`, "warning");
        console.error("ALM save errors:", errors);
      }
    });

    // ── Staff Replace ──────────────────────────────────────────────────────
    (function() {
      const btn    = document.getElementById("dc-staff-replace-btn");
      const panel  = document.getElementById("dc-staff-replace-panel");
      const selFrom = document.getElementById("dc-sr-from");
      const selTo   = document.getElementById("dc-sr-to");
      const preview = document.getElementById("dc-sr-preview");
      if (!btn || !panel) return;

      function _populateDropdowns() {
        const tok = sessionStorage.getItem("ibm_admin_token_v1") || "";
        selFrom.innerHTML = "<option value=''>-- Loading --</option>";
        selTo.innerHTML   = "<option value=''>-- Loading --</option>";
        fetch("/iip/api/admin/team-members", { headers: { "x-iip-admin-token": tok } })
          .then(r => r.ok ? r.json() : Promise.reject(r.status))
          .then(data => {
            const members  = Array.isArray(data) ? data : (data.members || []);
            const departed = members.filter(m => (m.status || "").toLowerCase() === "departed")
              .sort((a,b) => (a.name||"").localeCompare(b.name||""));
            const active   = members.filter(m => (m.status || "").toLowerCase() !== "departed")
              .sort((a,b) => (a.name||"").localeCompare(b.name||""));
            selFrom.innerHTML = "<option value=''>-- select person --</option>";
            departed.forEach(m => {
              const opt = document.createElement("option");
              opt.value = m.name; opt.dataset = {}; opt.dataset.email = m.email || ""; opt.textContent = (m.display_name || m.name);
              selFrom.appendChild(opt);
            });
            if (!departed.length) {
              const ph = document.createElement("option");
              ph.disabled = true; ph.textContent = "No departed members found";
              selFrom.appendChild(ph);
            }
            selTo.innerHTML = "<option value=''>-- select person --</option>";
            active.forEach(m => {
              const opt = document.createElement("option");
              opt.value = m.name; opt.dataset = {}; opt.dataset.email = m.email || ""; opt.textContent = (m.display_name || m.name);
              selTo.appendChild(opt);
            });
          })
          .catch(() => {
            selFrom.innerHTML = "<option value=''>Error loading members</option>";
            selTo.innerHTML   = "<option value=''>Error loading members</option>";
          });
      }

      btn.addEventListener("click", function() {
        const open = panel.style.display !== "none";
        panel.style.display = open ? "none" : "block";
        if (!open) { _populateDropdowns(); preview.textContent = ""; }
      });

      document.getElementById("dc-sr-cancel")?.addEventListener("click", function() {
        panel.style.display = "none";
      });

      function _updatePreview() {
        const from = selFrom.value.trim();
        if (!from) { preview.textContent = ""; return; }
        let count = 0;
        document.querySelectorAll("#dc-alm-tbody input.dc-alm-bd, #dc-alm-tbody input.dc-alm-ibm, #dc-alm-tbody input.dc-alm-proxy")
          .forEach(inp => { if (inp.value.trim().toLowerCase() === from.toLowerCase()) count++; });
        preview.innerHTML = count
          ? `<span style="color:var(--ibm-blue-60);font-weight:600">${count} field${count>1?"s":""}</span> will be updated. Click <b>Apply to All Rows</b> then <b>Save ALM Lines</b>.`
          : `<span style="color:var(--text-disabled)">No fields match "${from}"</span>`;
      }
      selFrom.addEventListener("change", _updatePreview);
      selTo.addEventListener("change", _updatePreview);

      document.getElementById("dc-sr-apply")?.addEventListener("click", function() {
        const from    = selFrom.value.trim();
        const to      = selTo.value.trim();
        const toEmail = selTo.options[selTo.selectedIndex] ? (selTo.options[selTo.selectedIndex].dataset.email || "") : "";
        let updated = 0;
        document.querySelectorAll("#dc-alm-tbody tr").forEach(tr => {
          const bdInp = tr.querySelector(".dc-alm-bd");
          const bdEmail = tr.querySelector(".dc-alm-bdemail");
          if (bdInp && bdInp.value.trim().toLowerCase() === from.toLowerCase()) {
            bdInp.value = to;
            if (bdEmail && (!bdEmail.dataset.manual || bdEmail.dataset.manual === "0")) bdEmail.value = toEmail;
            updated++;
          }
          const ibmInp = tr.querySelector(".dc-alm-ibm");
          const ibmEmail = tr.querySelector(".dc-alm-ibmemail");
          if (ibmInp && ibmInp.value.trim().toLowerCase() === from.toLowerCase()) {
            ibmInp.value = to;
            if (ibmEmail && (!ibmEmail.dataset.manual || ibmEmail.dataset.manual === "0")) ibmEmail.value = toEmail;
            updated++;
          }
          const proxyInp = tr.querySelector(".dc-alm-proxy");
          const proxyEmail = tr.querySelector(".dc-alm-proxyemail");
          if (proxyInp && proxyInp.value.trim().toLowerCase() === from.toLowerCase()) {
            proxyInp.value = to;
            if (proxyEmail && (!proxyEmail.dataset.manual || proxyEmail.dataset.manual === "0")) proxyEmail.value = toEmail;
            updated++;
          }
        });
        if (updated > 0) {
          showToast(`Replaced "${from}" with "${to}" in ${updated} field${updated>1?"s":""}. Click Save ALM Lines to persist.`, "success");
          preview.innerHTML = `<span style="color:var(--green);font-weight:600">✓ ${updated} field${updated>1?"s":""} updated.</span> Now click <b>Save ALM Lines</b>.`;
          _populateDropdowns();
        } else {
          showToast(`No rows found with "${from}".`, "warning");
        }
      });
    }());


    // ── Escalation Contacts: DB-driven load ───────────────────────────────
    (function () {
      const _base = (typeof API_BASE_V2 !== "undefined") ? API_BASE_V2 : "/iip/api/v2";
      const _adminBase = "/iip/api/admin";
      let _escLoaded = false;
      // Map group_name from DB → UI list id
      const GROUP_MAP = {
        "IBM Expertise Connect": "ec",
        "Expertise Connect":     "ec",
        "IBM Escalation":        "ec",
        "BD Escalation":         "bd",
        "Team Lead":             "tl",
      };
      const CLS_MAP = { ec: "dc-ec", bd: "dc-bd", tl: "dc-tl" };
      const CONTAINER_MAP = { ec: "dc-ec-list", bd: "dc-bd-list", tl: "dc-tl-list" };

      function _tok() { return sessionStorage.getItem("ibm_admin_token_v1") || ""; }

      function _renderEscList(key, contacts) {
        const el = document.getElementById(CONTAINER_MAP[key]);
        if (!el) return;
        const cls = CLS_MAP[key];
        el.innerHTML = contacts.map(c =>
          `<div style="display:flex;gap:6px;align-items:center;margin-bottom:6px" data-id="${c.id||''}">
            <input class="form-input ${cls}-name flex-1-fs12" aria-label="Contact name" placeholder="Name" value="${Utils.escHtml(c.name||'')}"/>
            <input class="form-input ${cls}-email flex-1-fs12" aria-label="Contact email" placeholder="Email" value="${Utils.escHtml(c.email||'')}"/>
            <button class="btn btn-ghost btn-sm" onclick="this.closest('[data-id]').remove()" style="color:var(--red);padding:3px 7px" title="Delete">${IC.trash}</button>
          </div>`
        ).join("");
      }

      function _loadEscFromDb() {
        if (_escLoaded) return;
        _escLoaded = true;
        // Inject full UI if not already present
        const escBody = document.getElementById("adm-esc-body");
        if (escBody && !document.getElementById("dc-ec-list")) {
          escBody.innerHTML = `<div style="padding:12px">
            <div style="margin-bottom:12px"><div style="font-size:11px;font-weight:700;text-transform:uppercase;color:var(--text-tertiary);margin-bottom:6px">Expertise Connect</div><div id="dc-ec-list"></div><button id="dc-add-ec" class="btn btn-ghost btn-sm" style="margin-top:4px">+ Add</button></div>
            <div style="margin-bottom:12px"><div style="font-size:11px;font-weight:700;text-transform:uppercase;color:var(--text-tertiary);margin-bottom:6px">BD Escalation</div><div id="dc-bd-list"></div><button id="dc-add-bd" class="btn btn-ghost btn-sm" style="margin-top:4px">+ Add</button></div>
            <div style="margin-bottom:12px"><div style="font-size:11px;font-weight:700;text-transform:uppercase;color:var(--text-tertiary);margin-bottom:6px">Team Lead</div><div id="dc-tl-list"></div><button id="dc-add-tl" class="btn btn-ghost btn-sm" style="margin-top:4px">+ Add</button></div>
            <button id="dc-save-esc" class="btn btn-primary btn-sm" style="margin-top:8px">Save All</button>
          </div>`;
        }
        ["ec","bd","tl"].forEach(k => {
          const el = document.getElementById(CONTAINER_MAP[k]);
          if (el) el.innerHTML = '<div style="font-size:12px;color:var(--text-tertiary);padding:4px">Loading…</div>';
        });
        if (!window.__escalationContactsPromise) {
          window.__escalationContactsPromise = fetch(_adminBase + "/escalation-contacts", { headers: { "x-iip-admin-token": _tok() } })
            .then(r => { if (!r.ok) { if (r.status === 403 && typeof Admin !== 'undefined') Admin.showLoginModal(); throw new Error(r.status); } return r.json(); });
          setTimeout(() => { delete window.__escalationContactsPromise; }, 30000);
        }
        window.__escalationContactsPromise
          .then(rows => {
            const grouped = { ec: [], bd: [], tl: [] };
            (Array.isArray(rows) ? rows : []).forEach(c => {
              const gn = (c.group_name || "").trim();
              const key = GROUP_MAP[gn] || (gn.toLowerCase().includes("expertise") ? "ec" : gn.toLowerCase().includes("bd") ? "bd" : "tl");
              if (grouped[key]) grouped[key].push(c);
            });
            Object.entries(grouped).forEach(([k, contacts]) => _renderEscList(k, contacts));
          })
          .catch(e => {
            console.warn("[Admin] escalation-contacts load failed:", e);
            ["ec","bd","tl"].forEach(k => {
              const el = document.getElementById(CONTAINER_MAP[k]);
              if (el) el.innerHTML = '<div style="font-size:12px;color:var(--danger);padding:4px">Load failed — check token</div>';
            });
          });
      }

      // Load after admin session is ready
      (function _waitEsc() {
        if (sessionStorage.getItem("ibm_admin_token_v1")) { _loadEscFromDb(); }
        else { setTimeout(_waitEsc, 300); }
      })();

      // Add buttons
      ["ec","bd","tl"].forEach(key => {
        document.getElementById("dc-add-" + key)?.addEventListener("click", () => {
          const el = document.getElementById(CONTAINER_MAP[key]);
          if (!el) return;
          const cls = CLS_MAP[key];
          const div = document.createElement("div");
          div.style.cssText = "display:flex;gap:6px;align-items:center;margin-bottom:6px";
          div.setAttribute("data-id","");
          div.innerHTML = `<input class="form-input ${cls}-name flex-1-fs12" aria-label="Contact name" placeholder="Name"/>
            <input class="form-input ${cls}-email flex-1-fs12" aria-label="Contact email" placeholder="Email"/>
            <button class="btn btn-ghost btn-sm" onclick="this.closest('[data-id]').remove()" style="color:var(--danger)">✕</button>`;
          el.appendChild(div);
        });
      });

      document.getElementById("dc-save-esc")?.addEventListener("click", async () => {
        const tok = _tok();
        // Collect current DB rows (with ids) so we can diff
        let existingRows = [];
        try {
          const r = await fetch(_adminBase + "/escalation-contacts", { headers: { "x-iip-admin-token": tok } });
          existingRows = await r.json();
        } catch(e) { console.warn("pre-save fetch failed", e); }

        const existingByGroup = {};
        // Also capture the original group_name per key so we preserve it on save
        const GROUP_NAME_FROM_DB = {};
        (existingRows || []).forEach(c => {
          const gn = (c.group_name || "").trim();
          const key = GROUP_MAP[gn] || "tl";
          if (!existingByGroup[key]) existingByGroup[key] = [];
          existingByGroup[key].push(c);
          // Use first seen group_name for that key as canonical
          if (!GROUP_NAME_FROM_DB[key]) GROUP_NAME_FROM_DB[key] = gn;
        });
        // Fallbacks if a group has no existing DB rows
        const GROUP_NAME = {
          ec: GROUP_NAME_FROM_DB["ec"] || "IBM Escalation",
          bd: GROUP_NAME_FROM_DB["bd"] || "BD Escalation",
          tl: GROUP_NAME_FROM_DB["tl"] || "Team Lead",
        };

        let saved = 0, errors = 0;
        for (const key of ["ec","bd","tl"]) {
          const container = document.getElementById(CONTAINER_MAP[key]);
          if (!container) continue;
          const cls = CLS_MAP[key];
          const uiRows = [...container.querySelectorAll("[data-id]")].map(div => ({
            id:    div.getAttribute("data-id") || "",
            name:  div.querySelector("." + cls + "-name")?.value?.trim() || "",
            email: div.querySelector("." + cls + "-email")?.value?.trim() || "",
          })).filter(c => c.name);

          const existingIds = new Set((existingByGroup[key] || []).map(c => String(c.id)));
          const uiIds       = new Set(uiRows.filter(c => c.id).map(c => c.id));

          // DELETE rows removed from UI
          for (const ex of (existingByGroup[key] || [])) {
            if (!uiIds.has(String(ex.id))) {
              try {
                await fetch(_adminBase + "/escalation-contacts/" + ex.id, { method: "DELETE", headers: { "x-iip-admin-token": tok } });
              } catch(e) { errors++; }
            }
          }

          for (const row of uiRows) {
            try {
              if (row.id && existingIds.has(row.id)) {
                // PUT (update existing)
                await fetch(_adminBase + "/escalation-contacts/" + row.id, {
                  method: "PUT",
                  headers: { "Content-Type": "application/json", "x-iip-admin-token": tok },
                  body: JSON.stringify({ group_name: GROUP_NAME[key], name: row.name, email: row.email }),
                });
              } else {
                // POST (new)
                await fetch(_adminBase + "/escalation-contacts", {
                  method: "POST",
                  headers: { "Content-Type": "application/json", "x-iip-admin-token": tok },
                  body: JSON.stringify({ group_name: GROUP_NAME[key], name: row.name, email: row.email }),
                });
              }
              saved++;
            } catch(e) { errors++; }
          }
        }

        // Reload from DB to get fresh ids
        _escLoaded = false;
        _loadEscFromDb();
        _refreshAllDashboards();
        showToast(errors ? `Saved with ${errors} error(s)` : "Escalation contacts saved!", errors ? "warning" : "success");
      });
    })();

    // ── IBM Directory: render groups ───────────────────────────────────────
    // ── IBM Directory: DB-driven load ────────────────────────────────────
    (function () {
      const _adminBase = "/iip/api/admin";
      let _ibmLoaded = false;
      function _tok() { return sessionStorage.getItem("ibm_admin_token_v1") || ""; }

      function _renderIbmDirGroups(rows) {
        const container = document.getElementById("dc-ibmdir-groups");
        if (!container) return;
        // Group by group_name
        const grouped = {};
        (rows || []).forEach(c => {
          const g = (c.group_name || "Ungrouped").trim();
          if (!grouped[g]) grouped[g] = [];
          grouped[g].push(c);
        });
        container.innerHTML = Object.entries(grouped).map(([group, contacts]) => {
          const rowsHtml = contacts.map(c =>
            `<div class="dc-ibmdir-row" data-id="${c.id||''}">
              <input class="form-input dc-ibmdir-name" value="${(c.name||'').replace(/"/g,'&quot;')}" placeholder="Name"/>
              <input class="form-input dc-ibmdir-email" value="${(c.email||'').replace(/"/g,'&quot;')}" placeholder="email@ibm.com"/>
              <button class="btn btn-ghost btn-row-del" title="Remove" onclick="this.closest('.dc-ibmdir-row').remove()">×</button>
            </div>`
          ).join("");
          return `<div class="dc-ibmdir-group" data-group="${group.replace(/"/g,'&quot;')}">
            <div class="dc-ibmdir-group-header">
              <input class="form-input dc-ibmdir-group-name" value="${group.replace(/"/g,'&quot;')}" placeholder="Group name"/>
              <button class="btn btn-ghost btn-remove-group" onclick="this.closest('.dc-ibmdir-group').remove()">Remove Group</button>
            </div>
            <div class="dc-ibmdir-rows">${rowsHtml}</div>
            <div class="dc-ibmdir-footer"><button class="btn btn-ghost btn-add-contact dc-add-ibmdir-row">+ Add Contact</button></div>
          </div>`;
        }).join("");

        // Wire + Add Contact buttons
        container.querySelectorAll(".dc-add-ibmdir-row").forEach(btn => {
          btn.onclick = () => {
            const rowsDiv = btn.closest(".dc-ibmdir-group").querySelector(".dc-ibmdir-rows");
            const div = document.createElement("div");
            div.className = "dc-ibmdir-row";
            div.style.cssText = "display:flex;gap:6px;margin-bottom:4px";
            div.setAttribute("data-id", "");
            div.innerHTML = `<input class="form-input dc-ibmdir-name" style="width:160px;font-size:12px" placeholder="Name"/>
              <input class="form-input dc-ibmdir-email" style="flex:1;font-size:12px;font-family:var(--font-mono)" placeholder="email@ibm.com"/>
              <button class="btn btn-ghost btn-sm" style="padding:3px 7px;font-size:13px;color:var(--danger)" onclick="this.closest('.dc-ibmdir-row').remove()">&times;</button>`;
            rowsDiv.appendChild(div);
          };
        });
      }

      function _loadIbmFromDb() {
        if (_ibmLoaded) return;
        _ibmLoaded = true;
        const ibmBody = document.getElementById("adm-ibm-body");
        if (ibmBody && !document.getElementById("dc-ibmdir-groups")) {
          ibmBody.innerHTML = '<div style="padding:12px"><div id="dc-ibmdir-groups"></div><div style="margin-top:10px;display:flex;gap:8px"><button id="dc-add-ibmdir-group" class="btn btn-ghost btn-sm">+ Add Group</button><button id="dc-save-ibmdir" class="btn btn-primary btn-sm">Save All</button></div></div>';
        }
        const container = document.getElementById("dc-ibmdir-groups");
        if (container) container.innerHTML = '<div style="font-size:12px;color:var(--text-tertiary);padding:6px">Loading\u2026</div>';
        if (!window.__ibmContactsPromise) {
          window.__ibmContactsPromise = fetch(_adminBase + "/ibm-contacts", { headers: { "x-iip-admin-token": _tok() } })
            .then(r => r.json());
          setTimeout(() => { delete window.__ibmContactsPromise; }, 30000);
        }
        window.__ibmContactsPromise
          .then(rows => _renderIbmDirGroups(rows))
          .catch(e => {
            console.warn("[Admin] ibm-contacts load failed:", e);
            const c = document.getElementById("dc-ibmdir-groups");
            if (c) c.innerHTML = '<div style="font-size:12px;color:var(--danger);padding:6px">Load failed \u2014 check token</div>';
          });
      }

      // Load after admin session is ready
      (function _waitIbm() {
        if (sessionStorage.getItem("ibm_admin_token_v1")) { _loadIbmFromDb(); }
        else { setTimeout(_waitIbm, 300); }
      })();

      // Add Group button
      document.getElementById("dc-add-ibmdir-group")?.addEventListener("click", () => {
        const container = document.getElementById("dc-ibmdir-groups");
        const div = document.createElement("div");
        div.className = "dc-ibmdir-group";
        div.style.cssText = "border:1px solid var(--border-subtle);border-radius:var(--radius-md);padding:10px;margin-top:6px";
        div.innerHTML = `<div style="display:flex;gap:6px;align-items:center;margin-bottom:6px">
          <input class="form-input dc-ibmdir-group-name" style="font-size:12px;font-weight:600;width:200px" placeholder="Group name"/>
          <button class="btn btn-ghost btn-sm" style="padding:2px 7px;font-size:11px;color:var(--danger)" onclick="this.closest('.dc-ibmdir-group').remove()">Remove Group</button>
        </div>
        <div class="dc-ibmdir-rows"></div>
        <button class="btn btn-ghost btn-sm dc-add-ibmdir-row" style="margin-top:4px;font-size:11px">+ Add Contact</button>`;
        div.querySelector(".dc-add-ibmdir-row").onclick = () => {
          const rowsDiv = div.querySelector(".dc-ibmdir-rows");
          const r = document.createElement("div");
          r.className = "dc-ibmdir-row"; r.style.cssText = "display:flex;gap:6px;margin-bottom:4px"; r.setAttribute("data-id", "");
          r.innerHTML = `<input class="form-input dc-ibmdir-name" style="width:160px;font-size:12px" placeholder="Name"/>
            <input class="form-input dc-ibmdir-email" style="flex:1;font-size:12px;font-family:var(--font-mono)" placeholder="email@ibm.com"/>
            <button class="btn btn-ghost btn-sm" style="padding:3px 7px;font-size:13px;color:var(--danger)" onclick="this.closest('.dc-ibmdir-row').remove()">&times;</button>`;
          rowsDiv.appendChild(r);
        };
        container.appendChild(div);
      });

      // Save — POST new rows, PUT existing, DELETE removed
      document.getElementById("dc-save-ibmdir")?.addEventListener("click", async () => {
        const tok = _tok();
        // Snapshot current DB state
        let existingRows = [];
        try {
          const r = await fetch(_adminBase + "/ibm-contacts", { headers: { "x-iip-admin-token": tok } });
          existingRows = await r.json();
        } catch(e) { console.warn("[Admin] pre-save ibm fetch failed", e); }
        const existingById = {};
        (existingRows || []).forEach(c => { existingById[String(c.id)] = c; });

        // Read UI state
        const uiRows = [];
        document.querySelectorAll("#dc-ibmdir-groups .dc-ibmdir-group").forEach(grpEl => {
          const group_name = grpEl.querySelector(".dc-ibmdir-group-name")?.value?.trim();
          if (!group_name) return;
          grpEl.querySelectorAll(".dc-ibmdir-row").forEach(row => {
            const name  = row.querySelector(".dc-ibmdir-name")?.value?.trim()  || "";
            const email = row.querySelector(".dc-ibmdir-email")?.value?.trim() || "";
            const id    = row.getAttribute("data-id") || "";
            if (name) uiRows.push({ id, group_name, name, email });
          });
        });

        const uiIds = new Set(uiRows.filter(r => r.id).map(r => r.id));
        let saved = 0, errors = 0;

        // DELETE rows removed from UI
        for (const id of Object.keys(existingById)) {
          if (!uiIds.has(id)) {
            try { await fetch(_adminBase + "/ibm-contacts/" + id, { method: "DELETE", headers: { "x-iip-admin-token": tok } }); }
            catch(e) { errors++; }
          }
        }

        // POST new / PUT existing
        for (const row of uiRows) {
          try {
            if (row.id && existingById[row.id]) {
              await fetch(_adminBase + "/ibm-contacts/" + row.id, {
                method: "PUT",
                headers: { "Content-Type": "application/json", "x-iip-admin-token": tok },
                body: JSON.stringify({ group_name: row.group_name, name: row.name, email: row.email }),
              });
            } else {
              await fetch(_adminBase + "/ibm-contacts", {
                method: "POST",
                headers: { "Content-Type": "application/json", "x-iip-admin-token": tok },
                body: JSON.stringify({ group_name: row.group_name, name: row.name, email: row.email }),
              });
            }
            saved++;
          } catch(e) { errors++; }
        }

        // Reload from DB to refresh ids
        _ibmLoaded = false;
        _loadIbmFromDb();
        _refreshAllDashboards();
        showToast(errors ? `Saved with ${errors} error(s)` : "IBM Directory saved!", errors ? "warning" : "success");
      });

      // Export Excel — reads from DOM (current UI state)
      document.getElementById("dc-export-ibmdir-xlsx")?.addEventListener("click", () => {
        const aoa = [["group","name","email"]];
        document.querySelectorAll("#dc-ibmdir-groups .dc-ibmdir-group").forEach(grpEl => {
          const group = grpEl.querySelector(".dc-ibmdir-group-name")?.value?.trim() || "";
          grpEl.querySelectorAll(".dc-ibmdir-row").forEach(row => {
            const name  = row.querySelector(".dc-ibmdir-name")?.value?.trim()  || "";
            const email = row.querySelector(".dc-ibmdir-email")?.value?.trim() || "";
            if (name) aoa.push([group, name, email]);
          });
        });
        _downloadXlsx(aoa, "ibm-directory.xlsx", "IBM Directory");
      });

      // Import Excel — POST each row directly to DB
      document.getElementById("dc-import-ibmdir-xlsx")?.addEventListener("change", async e => {
        const file = e.target.files?.[0]; if (!file) return;
        try {
          const rows = await _readXlsx(file);
          if (!rows.length) { showToast("Empty file", "warning"); return; }
          const hdr = rows[0].map(h => String(h||"").toLowerCase().trim());
          const gi = hdr.indexOf("group"), ni = hdr.indexOf("name"), ei = hdr.indexOf("email");
          if (gi < 0 || ni < 0 || ei < 0) { showToast("Need columns: group, name, email", "warning"); return; }
          const tok = _tok();
          let posted = 0;
          for (const row of rows.slice(1)) {
            const g = String(row[gi]||"").trim(), n = String(row[ni]||"").trim(), em = String(row[ei]||"").trim();
            if (!g || !n) continue;
            try {
              await fetch(_adminBase + "/ibm-contacts", {
                method: "POST",
                headers: { "Content-Type": "application/json", "x-iip-admin-token": tok },
                body: JSON.stringify({ group_name: g, name: n, email: em }),
              });
              posted++;
            } catch(e2) {}
          }
          _ibmLoaded = false;
          _loadIbmFromDb();
          showToast(`IBM Directory imported (${posted} contacts)!`, "success");
        } catch(err) {
          showToast("Import failed: " + err.message, "danger");
        }
        e.target.value = "";
      });
    })();

    // ── Weekly Tracker: stats display ─────────────────────────────────────
    function _wtUpdateStats() {
      const el = document.getElementById("dc-wt-stats");
      if (!el) return;
      let total = 0, years = new Set();
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (!k || !k.startsWith("ibm_wtracker_")) continue;
        if (k === "ibm_wtracker_seeded_v4" || k === "ibm_wtracker_history") continue;
        const yr = k.replace("ibm_wtracker_","");
        if (!/^\d{4}$/.test(yr)) continue;
        try {
          const d = JSON.parse(localStorage.getItem(k) || "{}");
          const count = Object.values(d).flat().length;
          total += count;
          if (count > 0) years.add(yr);
        } catch(e){}
      }
      // Count server-side comments
      let cmtCount = 0;
      try {
        if (typeof DashWeeklyTracker !== "undefined" && DashWeeklyTracker._serverComments) {
          cmtCount = Object.keys(DashWeeklyTracker._serverComments).length;
        }
      } catch(e) {}
      const cmtNote = cmtCount > 0 ? ` · ${cmtCount} comment${cmtCount!==1?"s":""} on server` : "";
      el.textContent = total
        ? `\u{1F4CB} ${total} cases stored across ${[...years].sort().join(", ")}${cmtNote}`
        : "No tracker data in storage yet.";
    }
    _wtUpdateStats();

    // ══════════════════════════════════════════════════════════════════
    //  CUSTOMER PRODUCTS MANAGEMENT
    // ══════════════════════════════════════════════════════════════════

    // ── Customer Products: Populate grid with checkboxes ─────────────
    function _populateProductsGrid() {
      const DC = (typeof DynamicConfig !== "undefined") ? DynamicConfig : null;
      const grid = document.getElementById("dc-products-grid");
      if (!grid) return;
      const savedProducts = new Set(DC.customerProducts ? [...DC.customerProducts()] : []);
      // Fetch distinct products from DB, merge with saved products
      const API = (typeof window.__APP_BASE__ !== 'undefined')
        ? window.__APP_BASE__.replace(/\/$/, '') + '/api/v2'
        : '/api/v2';
      fetch(`${API}/cases/distinct-products`)
        .then(r => r.ok ? r.json() : Promise.reject(r.status))
        .then(data => {
          const dbProducts = (data.ok && Array.isArray(data.products)) ? data.products : [];
          // Merge: all DB products + any saved products not in DB
          const allProducts = [...new Set([...dbProducts, ...savedProducts])].sort();
          if (!allProducts.length) {
            grid.innerHTML = '<div style="padding:20px;text-align:center;color:var(--text-tertiary);font-size:12px">No products found. Import a CSV to populate.</div>';
            return;
          }
          grid.innerHTML = allProducts.map(p => `
            <label style="display:flex;align-items:center;gap:8px;padding:5px 8px;cursor:pointer;border-radius:var(--radius-xs);font-size:var(--font-size-sm);transition:background var(--t-fast)" onmouseover="this.style.background='var(--bg-hover)'" onmouseout="this.style.background=''">
              <input type="checkbox" class="dc-product-chk" aria-label="${Utils.escHtml(p)}" data-product="${Utils.escHtml(p)}"
                ${savedProducts.has(p) ? "checked" : ""}
                style="accent-color:var(--ibm-blue-50);cursor:pointer"/>
              <span>${Utils.escHtml(p)}</span>
            </label>`).join("");
          // Update count
          const countEl = document.getElementById("dc-products-count");
          if (countEl) countEl.textContent = `${savedProducts.size} of ${allProducts.length} selected`;
          const badge = document.getElementById("dc-products-badge");
          if (badge) badge.textContent = savedProducts.size;
        })
        .catch(() => {
          // Fallback: show only saved products
          const allProducts = [...savedProducts].sort();
          if (!allProducts.length) {
            grid.innerHTML = '<div style="padding:20px;text-align:center;color:var(--text-tertiary);font-size:12px">No products configured. Could not reach DB.</div>';
            return;
          }
          grid.innerHTML = allProducts.map(p => `
            <label style="display:flex;align-items:center;gap:8px;padding:5px 8px;cursor:pointer;border-radius:var(--radius-xs);font-size:var(--font-size-sm);transition:background var(--t-fast)" onmouseover="this.style.background='var(--bg-hover)'" onmouseout="this.style.background=''">
              <input type="checkbox" class="dc-product-chk" aria-label="${Utils.escHtml(p)}" data-product="${Utils.escHtml(p)}"
                checked style="accent-color:var(--ibm-blue-50);cursor:pointer"/>
              <span>${Utils.escHtml(p)}</span>
            </label>`).join("");
        });
    }
    (function() {
      const pb = document.getElementById("adm-products-body");
      if (pb && !document.getElementById("dc-products-grid")) {
        pb.innerHTML = '<div style="padding:12px">'
          + '<div style="display:flex;gap:8px;margin-bottom:10px;flex-wrap:wrap;align-items:center">'
          + '<button id="dc-products-refresh" class="btn btn-ghost btn-sm">Refresh</button>'
          + '<button id="dc-products-select-all" class="btn btn-ghost btn-sm">Select All</button>'
          + '<button id="dc-products-deselect-all" class="btn btn-ghost btn-sm">Deselect All</button>'
          + '<button id="dc-products-save" class="btn btn-primary btn-sm">Save</button>'
          + '<span id="dc-products-count" style="font-size:11px;color:var(--text-tertiary)"></span>'
          + '<span id="dc-products-badge" style="font-size:11px;color:var(--text-tertiary)"></span>'
          + '</div>'
          + '<div id="dc-products-grid" style="display:flex;flex-wrap:wrap;gap:6px"></div>'
          + '</div>';
      }
    })();
    _populateProductsGrid();

    // ── Customer Products: Refresh from DB ───────────────────────────
    document.getElementById("dc-products-refresh")?.addEventListener("click", () => {
      const grid = document.getElementById("dc-products-grid");
      if (grid) grid.innerHTML = '<div style="padding:20px;text-align:center;color:var(--text-tertiary);font-size:12px">Loading products from database…</div>';
      _populateProductsGrid();
    });

    // ── Customer Products: Select All / Deselect All ─────────────────
    document.getElementById("dc-products-select-all")?.addEventListener("click", () => {
      document.querySelectorAll(".dc-product-chk").forEach(cb => cb.checked = true);
      _updateProductCount();
    });
    document.getElementById("dc-products-deselect-all")?.addEventListener("click", () => {
      document.querySelectorAll(".dc-product-chk").forEach(cb => cb.checked = false);
      _updateProductCount();
    });
    function _updateProductCount() {
      const all = document.querySelectorAll(".dc-product-chk");
      const checked = document.querySelectorAll(".dc-product-chk:checked");
      const countEl = document.getElementById("dc-products-count");
      if (countEl) countEl.textContent = `${checked.length} of ${all.length} selected`;
    }
    // Live count update on checkbox change
    document.getElementById("dc-products-grid")?.addEventListener("change", _updateProductCount);

    // ── Customer Products: Save ────────────────────────────────────────
    document.getElementById("dc-save-products")?.addEventListener("click", async () => {
      Data.snapshotForAdmin();
      const products = [...document.querySelectorAll(".dc-product-chk:checked")].map(cb => cb.dataset.product).filter(Boolean);
      const DC = (typeof DynamicConfig !== "undefined") ? DynamicConfig : null;

      const prevProds = [...(DC.customerProducts ? DC.customerProducts() : [])].sort();
      const hasChanges = JSON.stringify([...products].sort()) !== JSON.stringify(prevProds);

      // Save directly to app_settings via dedicated API
      const API = (typeof window.__APP_BASE__ !== 'undefined')
        ? window.__APP_BASE__.replace(/\/$/, '') + '/api'
        : '/api';
      const adminToken = (typeof Admin !== 'undefined' && Admin.getToken)
        ? Admin.getToken() : '';
      try {
        const resp = await fetch(`${API}/customer-products`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            ...(adminToken ? { 'X-IIP-Admin-Token': adminToken } : {}),
          },
          body: JSON.stringify({ value: products }),
        });
        if (!resp.ok) throw new Error(`Server returned ${resp.status}`);
      } catch (err) {
        showSaveBanner(`⚠ Save failed — could not persist customer products. (${err.message || 'Network error'})`);
        return;
      }

      // Update local config cache so UI reflects changes immediately
      await _dcSave({ customerProducts: products, _savedProductList: products });

      // Update badge
      const badge = document.getElementById("dc-products-badge");
      if (badge) badge.textContent = products.length;

      if (hasChanges && typeof Data !== "undefined" && typeof Data.pushChange === "function") {
        Data.pushChange({
          id: Date.now(), caseNumber: "CONFIG", field: "Customer Products",
          oldValue: `${prevProds.length} products`, newValue: `${products.length} products`,
          updatedBy: "Admin", timestamp: new Date().toLocaleString(),
        });
        render();
      }
      showToast(hasChanges ? `Saved ${products.length} customer product(s)!` : "No changes to save.", hasChanges ? "success" : "info");
      if (hasChanges) {
        _refreshAllDashboards();
      }
    });

    // ── Customer Products: Export Excel ───────────────────────────────
    document.getElementById("dc-export-products-xlsx")?.addEventListener("click", () => {
      const products = [...document.querySelectorAll(".dc-product-chk:checked")].map(cb => cb.dataset.product).filter(Boolean);
      const aoa = [["product"], ...products.map(p => [p])];
      _downloadXlsx(aoa, "customer-products.xlsx", "Customer Products");
    });

    // ── Customer Products: Scan from DB (refresh grid with DB products) ──
    document.getElementById("dc-scan-products")?.addEventListener("click", async () => {
      const grid = document.getElementById("dc-products-grid");
      if (!grid) return;
      grid.innerHTML = '<div style="padding:20px;text-align:center;color:var(--text-tertiary);font-size:12px">Scanning database…</div>';
      _populateProductsGrid();
      showToast("Products refreshed from database", "success");
    });

    // ── Customer Products: Select All (in scan list) ─────────────────
    document.getElementById("dc-select-all-products")?.addEventListener("click", () => {
      document.querySelectorAll(".dc-scan-prod-chk").forEach(cb => cb.checked = true);
      document.querySelectorAll(".dc-detected-prod-chk").forEach(cb => cb.checked = true);
    });

    // ── Customer Products: Import Excel ──────────────────────────────
    document.getElementById("dc-import-products-xlsx")?.addEventListener("change", async (e) => {
      const file = e.target.files?.[0]; if (!file) return;
      try {
        if (!_xlsxAvail()) { showToast("Excel library not ready", "warning"); return; }
        const rows = await _readXlsx(file);
        if (!rows.length) { showToast("No data found in file", "warning"); e.target.value = ""; return; }
        const imported = new Set();
        rows.forEach(row => {
          const p = _col(row, "product", "products", "productname", "product_name", "productname");
          if (p) imported.add(p);
        });
        // Check boxes for imported products, add new ones to grid
        const grid = document.getElementById("dc-products-grid");
        const existingChks = document.querySelectorAll(".dc-product-chk");
        const existingSet = new Set([...existingChks].map(cb => cb.dataset.product));
        existingChks.forEach(cb => { if (imported.has(cb.dataset.product)) cb.checked = true; });
        // Add products not already in grid
        imported.forEach(p => {
          if (!existingSet.has(p) && grid) {
            const lbl = document.createElement("label");
            lbl.style.cssText = "display:flex;align-items:center;gap:8px;padding:5px 8px;cursor:pointer;border-radius:var(--radius-xs);font-size:var(--font-size-sm);transition:background var(--t-fast)";
            lbl.onmouseover = function(){ this.style.background='var(--bg-hover)'; };
            lbl.onmouseout  = function(){ this.style.background=''; };
            lbl.innerHTML = `<input type="checkbox" class="dc-product-chk" aria-label="${Utils.escHtml(p)}" data-product="${Utils.escHtml(p)}" checked style="accent-color:var(--ibm-blue-50);cursor:pointer"/><span>${Utils.escHtml(p)}</span>`;
            grid.appendChild(lbl);
          }
        });
        _updateProductCount();
        showToast(`Imported ${imported.size} product(s) — click Save to apply`, "success");
      } catch (err) { showToast("Import failed: " + err.message, "danger"); }
      e.target.value = "";
    });

    // ── Customer Products: Detect from Excel (scan Product column) ────
    document.getElementById("dc-detect-products-xlsx")?.addEventListener("change", async (e) => {
      const file = e.target.files?.[0]; if (!file) return;
      try {
        if (!_xlsxAvail()) { showToast("Excel library not ready", "warning"); return; }
        const rows = await _readXlsx(file);
        if (!rows.length) { showToast("No data found in file", "warning"); e.target.value = ""; return; }
        const detected = new Set();
        rows.forEach(row => {
          const p = _col(row, "product");
          if (p && p !== "Product") detected.add(p);
        });
        if (!detected.size) { showToast("No Product column found in this file.", "warning"); e.target.value = ""; return; }
        // Check boxes for detected products, add new ones to grid
        const grid = document.getElementById("dc-products-grid");
        const existingChks = document.querySelectorAll(".dc-product-chk");
        const existingSet = new Set([...existingChks].map(cb => cb.dataset.product));
        existingChks.forEach(cb => { if (detected.has(cb.dataset.product)) cb.checked = true; });
        detected.forEach(p => {
          if (!existingSet.has(p) && grid) {
            const lbl = document.createElement("label");
            lbl.style.cssText = "display:flex;align-items:center;gap:8px;padding:5px 8px;cursor:pointer;border-radius:var(--radius-xs);font-size:var(--font-size-sm);transition:background var(--t-fast)";
            lbl.onmouseover = function(){ this.style.background='var(--bg-hover)'; };
            lbl.onmouseout  = function(){ this.style.background=''; };
            lbl.innerHTML = `<input type="checkbox" class="dc-product-chk" aria-label="${Utils.escHtml(p)}" data-product="${Utils.escHtml(p)}" checked style="accent-color:var(--ibm-blue-50);cursor:pointer"/><span>${Utils.escHtml(p)}</span>`;
            grid.appendChild(lbl);
          }
        });
        _updateProductCount();
        showToast(`Detected ${detected.size} product(s) — click Save to apply`, "success");
      } catch (err) { showToast("Detect failed: " + err.message, "danger"); }
      e.target.value = "";
    });

    // ── Weekly Tracker: Export Excel ──────────────────────────────────────
    document.getElementById("dc-wt-export-xlsx")?.addEventListener("click", () => {
      const aoa = [["Year","Week","Case Number","Owner","Title","Product","Severity","Status","Age","Closed Date","Category","Comments"]];
      const serverCmts = (typeof DashWeeklyTracker !== "undefined") ? (DashWeeklyTracker._serverComments || {}) : {};
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (!k || !k.startsWith("ibm_wtracker_")) continue;
        const yr = k.replace("ibm_wtracker_","");
        if (!/^\d{4}$/.test(yr)) continue;
        try {
          const yearData = JSON.parse(localStorage.getItem(k) || "{}");
          Object.entries(yearData).forEach(([wk, rows]) => {
            (rows||[]).forEach(r => {
              // Use server comment if available, fall back to stored
              const cmt = (serverCmts[r.caseNumber] !== undefined) ? serverCmts[r.caseNumber] : (r.comments||"");
              aoa.push([
                yr, wk, r.caseNumber||"", r.owner||"", r.title||"",
                r.product||"", r.severity||"", r.status||"",
                r.age||"", r.closedDate||"", r.category||"", cmt
              ]);
            });
          });
        } catch(e){}
      }
      _downloadXlsx(aoa, "weekly-tracker-export.xlsx", "Weekly Tracker");
    });

    // ── Weekly Tracker: Import Excel/CSV → server-side comments ──────────
    document.getElementById("dc-wt-import-excel")?.addEventListener("change", async e => {
      const file = e.target.files?.[0];
      e.target.value = "";
      if (!file) return;

      const statusEl = document.getElementById("dc-wt-import-status");
      const _setStatus = (msg, type) => {
        if (!statusEl) return;
        const colors = { info:"var(--text-secondary)", success:"var(--green)", error:"var(--red)", warn:"var(--orange)" };
        statusEl.style.display = "block";
        statusEl.style.color   = colors[type] || colors.info;
        statusEl.innerHTML     = msg;
      };

      // ── Strict format check: xlsx / xlsm only ─────────────────────────
      const ext = file.name.toLowerCase().split(".").pop();
      if (ext !== "xlsx" && ext !== "xlsm") {
        _setStatus("❌ Invalid file type. Only <strong>.xlsx</strong> or <strong>.xlsm</strong> files are accepted for this import.", "error");
        showToast("❌ Invalid file type — please use .xlsx or .xlsm", "danger");
        return;
      }

      _setStatus("⏳ Parsing file…", "info");

      try {
        // ── Parse Excel ────────────────────────────────────────────────
        if (!_xlsxAvail()) { _setStatus("❌ XLSX library not loaded.", "error"); return; }
        let rows = await _readXlsx(file);

        // Normalize all header keys to lowercase trimmed
        rows = rows.map(r => {
          const norm = {};
          Object.entries(r).forEach(([k, v]) => { norm[k.toLowerCase().trim()] = v; });
          return norm;
        });

        if (!rows.length) throw new Error("No data rows found in file.");

        // ── Strict column validation: must have exactly SL.No, Case Number, Comments ──
        const sampleKeys = Object.keys(rows[0]);
        const hasSLNo       = sampleKeys.some(k => k === "sl.no" || k === "sl no" || k === "slno" || k === "sl.no." || k === "#");
        const hasCaseNumber = sampleKeys.some(k => k === "case number" || k === "casenumber" || k === "case no");
        const hasComments   = sampleKeys.some(k => k === "comments" || k === "comment");

        if (!hasCaseNumber) throw new Error('Required column "Case Number" not found. Make sure your file has the header: SL.No | Case Number | Comments');
        if (!hasComments)   throw new Error('Required column "Comments" not found. Make sure your file has the header: SL.No | Case Number | Comments');

        const cnKey  = sampleKeys.find(k => k === "case number" || k === "casenumber" || k === "case no");
        const cmtKey = sampleKeys.find(k => k === "comments" || k === "comment");

        // ── Build import map: only rows that have a comment ────────────
        const toImport  = {}; // caseNumber → comment (new/changed only — skip already-set)
        let totalRows = 0, blankComment = 0, invalidCN = 0;

        rows.forEach(r => {
          const cn  = (r[cnKey]  || "").toString().trim();
          const cmt = (r[cmtKey] || "").toString().trim();
          if (!cn) { invalidCN++; return; }
          totalRows++;
          if (!cmt) { blankComment++; return; }
          toImport[cn] = cmt;
        });

        if (!Object.keys(toImport).length) {
          _setStatus(`⚠ Nothing to import — all ${totalRows} rows had blank Comments. Fill in the Comments column and re-upload.`, "warn");
          showToast("⚠ All rows had blank comments — nothing imported.", "warning");
          return;
        }

        // ── Ensure server comments are loaded ─────────────────────────
        if (typeof DashWeeklyTracker === "undefined" || !DashWeeklyTracker._mergeServerComments) {
          _setStatus("❌ Weekly Tracker module not available.", "error"); return;
        }
        _setStatus("⏳ Checking existing comments on server…", "info");
        await DashWeeklyTracker._ensureServerCommentsLoaded();

        // ── Validate: only process cases that exist in the Weekly Tracker ──
        const trackerCaseNumbers = new Set(
          (DashWeeklyTracker._getAllWTCases?.() || []).map(r => (r.caseNumber || "").trim())
        );
        const notInTracker = [];
        const validImport  = {};
        Object.entries(toImport).forEach(([cn, cmt]) => {
          if (!trackerCaseNumbers.has(cn)) { notInTracker.push(cn); }
          else { validImport[cn] = cmt; }
        });

        if (!Object.keys(validImport).length) {
          const detail = notInTracker.length <= 5
            ? notInTracker.join(", ")
            : notInTracker.slice(0, 5).join(", ") + ` … (+${notInTracker.length - 5} more)`;
          _setStatus(`⚠ Nothing to import — none of the case numbers exist in the Weekly Tracker.<br><small>${detail}</small>`, "warn");
          showToast("⚠ No matching cases found in Weekly Tracker.", "warning");
          return;
        }

        // ── Classify: new (no comment yet) vs update (comment changed) vs unchanged ──
        const existing      = DashWeeklyTracker._serverComments || {};
        const toAdd         = {};
        const toUpdate      = {};
        const unchangedList = [];
        Object.entries(validImport).forEach(([cn, cmt]) => {
          const existingCmt = (existing[cn] || "").trim();
          if (!existingCmt)            { toAdd[cn]    = cmt; }
          else if (existingCmt !== cmt){ toUpdate[cn]  = cmt; }
          else                         { unchangedList.push(cn); }
        });

        const addCount       = Object.keys(toAdd).length;
        const updateCount    = Object.keys(toUpdate).length;
        const unchangedCount = unchangedList.length;
        const entriesToSave  = { ...toAdd, ...toUpdate };

        if (!addCount && !updateCount) {
          const msg = `ℹ️ Already up to date — all ${unchangedCount} case${unchangedCount!==1?"s":""} already had identical comments. No changes made.`;
          _setStatus(msg, "info");
          showToast(`ℹ️ Already up to date — ${unchangedCount} case${unchangedCount!==1?"s":""} unchanged.`, "info");
          return;
        }

        // ── Save to server (adds new + overwrites changed) ─────────────
        const saveCount = addCount + updateCount;
        _setStatus(`☁️ Saving ${saveCount} comment${saveCount!==1?"s":""}…`, "info");
        await DashWeeklyTracker._mergeServerComments(entriesToSave);

        // ── Re-render tracker ──────────────────────────────────────────
        try { DashWeeklyTracker.render(); } catch(e) {}
        _wtUpdateStats();

        // ── Build detailed status message ──────────────────────────────
        const parts = [];
        if (addCount)        parts.push(`<strong class="c-green">✅ ${addCount} added</strong>`);
        if (updateCount)     parts.push(`<strong class="c-blue">✏️ ${updateCount} updated</strong>`);
        if (unchangedCount)  parts.push(`<span class="c-tertiary">— ${unchangedCount} unchanged</span>`);
        if (notInTracker.length) parts.push(`<span class="c-orange">⚠ ${notInTracker.length} not in tracker (skipped)</span>`);
        if (blankComment)    parts.push(`<span class="c-tertiary">— ${blankComment} row${blankComment!==1?"s":""} had no comment in file</span>`);

        _setStatus(parts.join(" &nbsp;·&nbsp; "), "success");

        // Toast breakdown
        const toastParts = [];
        if (addCount)    toastParts.push(`✅ ${addCount} added`);
        if (updateCount) toastParts.push(`✏️ ${updateCount} updated`);
        if (notInTracker.length) toastParts.push(`⚠ ${notInTracker.length} skipped (not in tracker)`);
        showToast(toastParts.join(" · "), "success");

        const auditDetail = [
          addCount    ? `${addCount} added`    : "",
          updateCount ? `${updateCount} updated` : "",
          notInTracker.length ? `${notInTracker.length} skipped (not in tracker)` : ""
        ].filter(Boolean).join(", ");
        Data.pushChange({
          id: Date.now(), caseNumber: "CONFIG", field: "Weekly Tracker Comments",
          oldValue: "", newValue: `${auditDetail} — from ${file.name}`,
          updatedBy: "Admin", timestamp: new Date().toLocaleString()
        });
        render();

      } catch(err) {
        _setStatus("❌ Import failed: " + err.message, "error");
        showToast("❌ Import failed: " + err.message, "danger");
      }
    });

    // ── Weekly Tracker: Reset to built-in seed ────────────────────────
    document.getElementById("dc-wt-reset-seed")?.addEventListener("click", () => {
      /* F52: Custom confirmation modal requiring user to type "RESET" */
      const wtCount = (() => {
        let count = 0;
        for (let i = 0; i < localStorage.length; i++) {
          const k = localStorage.key(i);
          if (k && k.startsWith("ibm_wtracker_")) count++;
        }
        return count;
      })();

      const overlay = document.createElement("div");
      overlay.style.cssText = "position:fixed;inset:0;z-index:var(--z-toast);background:rgba(0,0,0,.55);backdrop-filter:blur(3px);display:flex;align-items:center;justify-content:center";
      overlay.innerHTML = `
        <div style="background:var(--bg-ui);border:1px solid rgba(218,30,40,.3);border-radius:var(--radius-lg);padding:28px 32px;width:380px;box-shadow:0 8px 32px rgba(0,0,0,.15);font-family:var(--font-sans)">
          <div style="font-size:15px;font-weight:700;color:var(--red,#da1e28);margin-bottom:8px">⚠ Reset to Built-in Seed Data</div>
          <div style="font-size:13px;color:var(--text-secondary);line-height:1.5;margin-bottom:12px">
            This will permanently overwrite <strong>${wtCount} local storage key(s)</strong> with factory seed data.
            All custom Weekly Tracker entries will be lost. This cannot be undone.
          </div>
          <label style="font-size:var(--font-size-xs);font-weight:600;color:var(--text-tertiary);display:block;margin-bottom:6px">
            Type <strong class="c-red">RESET</strong> to confirm:
          </label>
          <input id="reset-confirm-input" type="text" class="form-input" placeholder="RESET"
            style="width:100%;box-sizing:border-box;font-size:13px;margin-bottom:16px;text-transform:uppercase"/>
          <div class="d-flex gap-8">
            <button id="reset-confirm-btn" class="btn btn-danger" style="flex:1;justify-content:center;opacity:.4" disabled>Reset Data</button>
            <button id="reset-cancel-btn" class="btn btn-ghost flex-1-c">Cancel</button>
          </div>
        </div>`;
      document.body.appendChild(overlay);
      const input = document.getElementById("reset-confirm-input");
      const confirmBtn = document.getElementById("reset-confirm-btn");
      input?.addEventListener("input", () => {
        const valid = (input.value.toUpperCase() === "RESET");
        confirmBtn.disabled = !valid;
        confirmBtn.style.opacity = valid ? "1" : ".4";
      });
      document.getElementById("reset-cancel-btn")?.addEventListener("click", () => overlay.remove());
      confirmBtn?.addEventListener("click", () => {
        overlay.remove();
        localStorage.removeItem("ibm_wtracker_seeded_v4");
        try {
          if (typeof DashWeeklyTracker !== "undefined" && DashWeeklyTracker._applySeed) {
            DashWeeklyTracker._applySeed();
          }
        } catch(e) {
          ["2025","2026"].forEach(yr => localStorage.removeItem("ibm_wtracker_" + yr));
        }
        _wtUpdateStats();
        showToast("Tracker reset to built-in seed data. Reload the Weekly Tracker tab.", "success");
        Data.pushChange({ id: Date.now(), caseNumber: 'CONFIG', field: 'Weekly Tracker Reset', oldValue: '', newValue: 'Reset to built-in seed data', updatedBy: 'Admin', timestamp: new Date().toLocaleString() });
      });
    });

    // ── Weekly Tracker: Clear all ─────────────────────────────────────
    document.getElementById("dc-wt-clear-all")?.addEventListener("click", () => {
      Modal.showConfirm({ title:"Clear Tracker Data", message:"This will permanently delete ALL Weekly Tracker data from this browser AND clear all server-stored comments. Are you sure?", confirmLabel:"Clear All", danger:true })
        .then(ok => {
          if (!ok) return;
          const keysToRemove = [];
          for (let i = 0; i < localStorage.length; i++) {
            const k = localStorage.key(i);
            if (k && k.startsWith("ibm_wtracker_")) keysToRemove.push(k);
          }
          keysToRemove.forEach(k => localStorage.removeItem(k));
          try { localStorage.removeItem("ibm_wtracker_comments_v1"); } catch(e) {}
          _wtUpdateStats();
          showToast(`Cleared ${keysToRemove.length} tracker storage key(s) and server comments.`, "warning");
          Data.pushChange({ id: Date.now(), caseNumber: 'CONFIG', field: 'Weekly Tracker Cleared', oldValue: '', newValue: `${keysToRemove.length} storage key(s) removed`, updatedBy: 'Admin', timestamp: new Date().toLocaleString() });
        });
    });

    // ── RFE CSV Import with Deduplication ─────────────────────────────────────
    document.getElementById("rfe-import-csv")?.addEventListener("change", async (e) => {
      const file = e.target.files?.[0];
      if (!file) return;

      const statusEl = document.getElementById("rfe-csv-import-status");
      statusEl.style.display = "block";
      statusEl.style.color = "var(--text-secondary)";
      statusEl.innerHTML = "⏳ Processing...";

      try {
        if (typeof XLSX === "undefined") {
          throw new Error("Excel library not ready");
        }

        const buf = await file.arrayBuffer();
        const wb = XLSX.read(buf, { type: "array" });
        const ws = wb.Sheets[wb.SheetNames[0]];
        const rows = XLSX.utils.sheet_to_json(ws, { defval: "" });

        if (!rows.length) {
          throw new Error("No data rows found in file");
        }

        // Normalize and parse RFE data
        const newRfeData = rows.map((row, idx) => {
          const normalized = {};
          Object.entries(row).forEach(([key, val]) => {
            normalized[key.trim()] = val;
          });
          return normalized;
        });

        // Load existing RFE data
        let existingData = [];
        try {
          const raw = localStorage.getItem("ibm_rfe_tracking_v1");
          existingData = raw ? JSON.parse(raw) : [];
        } catch (e) {}

        // Check for duplicates
        const existingRefs = new Set(existingData.map(r => r['Idea Reference']));
        const newRefs = new Set(newRfeData.map(r => r['Idea Reference']));
        const duplicates = Array.from(newRefs).filter(ref => existingRefs.has(ref));
        const newOnly = newRfeData.filter(r => !existingRefs.has(r['Idea Reference']));

        // Show merge dialog if duplicates exist
        if (duplicates.length > 0 && existingData.length > 0) {
          _showRFEMergeDialog(newRfeData, existingData, duplicates, file.name, statusEl);
          e.target.value = "";
          return;
        }

        // No duplicates, merge data
        const mergedData = [...existingData, ...newRfeData];
        _saveRFEData(mergedData, newRfeData.length, file.name, statusEl);
        e.target.value = "";

      } catch (err) {
        statusEl.style.color = "var(--red)";
        statusEl.innerHTML = `❌ Import failed: ${err.message}`;
        showToast(`❌ RFE import failed: ${err.message}`, "danger");
      }
    });

    // ── Shared helper: light-theme merge/replace/cancel dialog ─────────────
    function _showImportMergeDialog({ title, subtitle, existingCount, newCount, onMerge, onReplace, onCancel }) {
      const overlay = document.createElement("div");
      overlay.style.cssText = "position:fixed;inset:0;z-index:var(--z-modal)9;background:rgba(0,0,0,.45);backdrop-filter:blur(3px);display:flex;align-items:center;justify-content:center";
      overlay.innerHTML = `
        <div style="background:var(--bg-ui);border:1px solid var(--border-subtle);border-radius:var(--radius-lg);padding:28px 32px;width:420px;max-width:92vw;box-shadow:0 8px 32px rgba(0,0,0,.15);font-family:var(--font-sans)">
          <div style="font-size:15px;font-weight:700;color:var(--text-primary);margin-bottom:4px">${title}</div>
          <div style="font-size:12px;color:var(--text-tertiary);margin-bottom:20px;padding-bottom:16px;border-bottom:1px solid var(--border-subtle)">${subtitle}</div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:20px">
            <div style="background:var(--bg-layer);border:1px solid var(--border-subtle);border-radius:var(--radius-sm);padding:12px;text-align:center">
              <div style="font-size:22px;font-weight:700;color:var(--text-primary)">${existingCount}</div>
              <div style="font-size:11px;color:var(--text-tertiary);margin-top:2px">Existing records</div>
            </div>
            <div style="background:rgba(15,98,254,.06);border:1px solid rgba(15,98,254,.2);border-radius:var(--radius-sm);padding:12px;text-align:center">
              <div style="font-size:22px;font-weight:700;color:var(--ibm-blue-50)">${newCount}</div>
              <div style="font-size:11px;color:var(--text-tertiary);margin-top:2px">Records in file</div>
            </div>
          </div>
          <div style="font-size:12px;font-weight:600;color:var(--text-secondary);margin-bottom:10px">What would you like to do?</div>
          <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px">
            <button id="_imd-merge" class="btn btn-primary" style="flex:1;justify-content:center">➕ Merge</button>
            <button id="_imd-replace" class="btn btn-danger" style="flex:1;justify-content:center">🔄 Replace All</button>
            <button id="_imd-cancel" class="btn btn-ghost" style="flex:1;justify-content:center;border:1px solid var(--border-subtle)">✕ Cancel</button>
          </div>
          <div style="font-size:11px;color:var(--text-tertiary);line-height:1.6;background:var(--bg-layer);padding:10px;border-radius:var(--radius-sm)">
            <strong style="color:var(--text-secondary)">Merge:</strong> Keep existing + append new records.<br/>
            <strong style="color:var(--text-secondary)">Replace:</strong> Overwrite all existing with file data.
          </div>
        </div>`;
      document.body.appendChild(overlay);
      overlay.querySelector("#_imd-merge")?.addEventListener("click", () => { overlay.remove(); onMerge?.(); });
      overlay.querySelector("#_imd-replace")?.addEventListener("click", () => { overlay.remove(); onReplace?.(); });
      overlay.querySelector("#_imd-cancel")?.addEventListener("click", () => { overlay.remove(); onCancel?.(); });
      overlay.addEventListener("click", e => { if (e.target === overlay) { overlay.remove(); onCancel?.(); } });
    }

    // ── Helper: Show merge dialog ─────────────────────────────────────
    function _showRFEMergeDialog(newData, existingData, duplicates, fileName, statusEl) {
      const existingRefs = new Set(existingData.map(r => r['Idea Reference']));
      const newOnly = newData.filter(r => !existingRefs.has(r['Idea Reference']));

      const overlay = document.createElement("div");
      overlay.style.cssText = "position:fixed;inset:0;z-index:var(--z-modal)9;background:rgba(0,0,0,.55);backdrop-filter:blur(3px);display:flex;align-items:center;justify-content:center";
      overlay.innerHTML = `
        <div style="background:var(--bg-ui);border:1px solid var(--border-subtle);border-radius:var(--radius-lg);padding:28px 32px;width:440px;box-shadow:0 8px 32px rgba(0,0,0,.15);font-family:var(--font-sans)">
          <div style="font-size:15px;font-weight:700;color:var(--text-primary);margin-bottom:4px">📋 RFE Data Already Exists</div>
          <div style="font-size:12px;color:var(--text-tertiary);margin-bottom:20px;padding-bottom:16px;border-bottom:1px solid var(--border-subtle)">Review conflicts before importing</div>
          <div style="font-size:13px;color:var(--text-secondary);line-height:1.6;margin-bottom:16px">
            <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;margin-bottom:16px">
              <div style="background:var(--bg-layer);border:1px solid var(--border-subtle);border-radius:var(--radius-sm);padding:10px;text-align:center">
                <div style="font-size:20px;font-weight:700;color:var(--text-primary)">${existingData.length}</div>
                <div style="font-size:11px;color:var(--text-tertiary);margin-top:2px">Existing RFEs</div>
              </div>
              <div style="background:var(--bg-layer);border:1px solid var(--border-subtle);border-radius:var(--radius-sm);padding:10px;text-align:center">
                <div style="font-size:20px;font-weight:700;color:var(--ibm-blue-50)">${newData.length}</div>
                <div style="font-size:11px;color:var(--text-tertiary);margin-top:2px">New in file</div>
              </div>
              <div style="background:rgba(218,30,40,.06);border:1px solid rgba(218,30,40,.2);border-radius:var(--radius-sm);padding:10px;text-align:center">
                <div style="font-size:20px;font-weight:700;color:var(--red)">${duplicates.length}</div>
                <div style="font-size:11px;color:var(--text-tertiary);margin-top:2px">Duplicates</div>
              </div>
            </div>
          </div>

          <div style="background:var(--bg-layer);border:1px solid var(--border-subtle);border-radius:var(--radius-sm);padding:12px;margin-bottom:20px;font-size:12px;max-height:120px;overflow-y:auto">
            <div style="font-weight:600;color:var(--text-secondary);margin-bottom:8px;font-size:11px;text-transform:uppercase;letter-spacing:.04em">Duplicate RFEs</div>
            ${duplicates.slice(0, 10).map(d => `<div style="color:var(--text-primary);padding:2px 0;border-bottom:1px solid var(--border-subtle)">• ${d}</div>`).join('')}
            ${duplicates.length > 10 ? `<div style="color:var(--text-tertiary);margin-top:6px;font-style:italic">... and ${duplicates.length - 10} more</div>` : ''}
          </div>

          <div style="font-size:12px;font-weight:600;color:var(--text-secondary);margin-bottom:10px">What would you like to do?</div>
          <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px">
            <button id="rfe-merge-add" class="btn btn-primary" style="flex:1;justify-content:center">
              ➕ Merge (Add ${newOnly.length} New)
            </button>
            <button id="rfe-merge-replace" class="btn btn-danger" style="flex:1;justify-content:center">
              🔄 Replace All
            </button>
            <button id="rfe-merge-cancel" class="btn btn-ghost" style="flex:1;justify-content:center;border:1px solid var(--border-subtle)">
              ✕ Cancel
            </button>
          </div>
          <div style="font-size:11px;color:var(--text-tertiary);line-height:1.6;background:var(--bg-layer);padding:10px;border-radius:var(--radius-sm)">
            <strong style="color:var(--text-secondary)">Merge:</strong> Keep existing + add only new RFEs.<br/>
            <strong style="color:var(--text-secondary)">Replace:</strong> Replace all existing with new file.
          </div>
        </div>`;

      document.body.appendChild(overlay);

      document.getElementById('rfe-merge-add')?.addEventListener('click', () => {
        overlay.remove();
        const mergedData = [...existingData, ...newOnly];
        _saveRFEData(mergedData, newOnly.length, fileName, statusEl, true);
      });

      document.getElementById('rfe-merge-replace')?.addEventListener('click', () => {
        overlay.remove();
        _saveRFEData(newData, newData.length, fileName, statusEl, false);
      });

      document.getElementById('rfe-merge-cancel')?.addEventListener('click', () => {
        overlay.remove();
        statusEl.style.color = "var(--orange)";
        statusEl.innerHTML = "⏭ Import cancelled";
      });
    }

    // ── Helper: Save RFE data with confirmation ──────────────────────
    function _saveRFEData(rfeData, importedCount, fileName, statusEl, isMerge) {
      const tok = (typeof Admin !== "undefined" && Admin.getToken) ? Admin.getToken() : "";
      fetch("/iip/api/v2/rfe-data", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-iip-admin-token": tok },
        body: JSON.stringify({ data: rfeData })
      })
      .then(r => { if (!r.ok) throw new Error("HTTP " + r.status); return r.json(); })
      .then(() => {
      try {

        // Update display
        statusEl.style.color = "var(--green)";
        const action = isMerge ? `merged ${importedCount} new` : `replaced with ${rfeData.length}`;
        statusEl.innerHTML = `✅ Successfully ${action} RFE(s)`;

        // Update RFE tracking dashboard
        if (typeof DashRFEAdvanced !== "undefined" && DashRFEAdvanced.render) {
          setTimeout(() => DashRFEAdvanced.render(), 100);
        }
        if (typeof DashRFETracking !== "undefined" && DashRFETracking.render) {
          setTimeout(() => DashRFETracking.render(), 100);
        }

        // Update total count and timestamp
        const countEl = document.getElementById("rfe-total-count");
        if (countEl) countEl.textContent = rfeData.length;

        const dateEl = document.getElementById("rfe-last-updated");
        if (dateEl) {
          const now = new Date().toLocaleString();
          dateEl.textContent = `Last updated: ${now}`;
        }

        showToast(`✅ RFE data updated! Total: ${rfeData.length} RFE(s)`, "success");

        // Log change
        Data.pushChange({
          id: Date.now(),
          caseNumber: "CONFIG",
          field: "RFE Data Updated",
          oldValue: "",
          newValue: `${action} from ${fileName} (Total: ${rfeData.length})`,
          updatedBy: "Admin",
          timestamp: new Date().toLocaleString()
        });
      } catch (err) {
        statusEl.style.color = "var(--red)";
        statusEl.innerHTML = `❌ Save failed: ${err.message}`;
        showToast(`❌ Failed to save RFE data: ${err.message}`, "danger");
      }
      })
      .catch(err => {
        statusEl.style.color = "var(--red)";
        statusEl.innerHTML = `❌ Save failed: ${err.message}`;
        showToast(`❌ Failed to save RFE data: ${err.message}`, "danger");
      });
    }

    // ── Clear RFE Data ─────────────────────────────────────────────────
    document.getElementById("rfe-clear-data-btn")?.addEventListener("click", () => {
      Modal.showConfirm({ title:"Clear RFE Data", message:"This will permanently delete ALL RFE data. This cannot be undone. Are you sure?", confirmLabel:"Delete All", danger:true })
        .then(ok => {
          if (!ok) return;
          const _rfeClearTok = (typeof Admin !== "undefined" && Admin.getToken) ? Admin.getToken() : "";
          fetch("/iip/api/v2/rfe-data", {
            method: "DELETE",
            headers: { "x-iip-admin-token": _rfeClearTok }
          })
          .then(r => { if (!r.ok) throw new Error("HTTP " + r.status); return r.json(); })
          .then(() => {
          try {
            document.getElementById("rfe-total-count").textContent = "0";
            document.getElementById("rfe-last-updated").textContent = "Not yet imported";

            if (typeof DashRFEAdvanced !== "undefined") DashRFEAdvanced.render();
            if (typeof DashRFETracking !== "undefined") DashRFETracking.render();

            showToast("✅ All RFE data cleared", "success");
            Data.pushChange({
              id: Date.now(),
              caseNumber: "CONFIG",
              field: "RFE Data Cleared",
              oldValue: "",
              newValue: "All RFE data deleted",
              updatedBy: "Admin",
              timestamp: new Date().toLocaleString()
            });
          } catch (err) {
            showToast(`❌ Failed to clear RFE data: ${err.message}`, "danger");
          }
          })
          .catch(err => { showToast(`❌ Failed to clear RFE data: ${err.message}`, "danger"); });
        });
    });


    // Inject WT body then load
    (function() {
      const wtBody = document.getElementById("adm-wt-body");
      if (wtBody && !document.getElementById("wt-cat-list")) {
        wtBody.innerHTML = '<div style="padding:12px">'
          + '<div id="wt-cat-list" style="margin-bottom:12px"></div>'
          + '<div style="display:flex;gap:8px;align-items:center">'
          + '<button id="wt-cat-add" class="btn btn-ghost btn-sm">+ Add Category</button>'
          + '<button id="wt-cat-save" class="btn btn-primary btn-sm">Save All</button>'
          + '<span id="wt-cat-count-badge" style="font-size:11px;color:var(--text-tertiary)"></span>'
          + '</div></div>';
      }
      _loadWtCatSection();
    })();
  }

  // ══════════════════════════════════════════════════════════════════
  //  WEEKLY TRACKER CATEGORIES MANAGEMENT
  // ══════════════════════════════════════════════════════════════════
  let _wtCatData = []; // current category list in memory

  async function _loadWtCatSection() {
    const listEl   = document.getElementById("wt-cat-list");
    const badgeEl  = document.getElementById("wt-cat-count-badge");
    if (!listEl) return;
    // Deduplicate concurrent calls — only one fetch in flight at a time
    if (!window.__wtCategoriesPromise) {
      const base = (window.API_BASE_V2 || "/iip/api/v2");
      window.__wtCategoriesPromise = fetch(base + "/wt-categories", { cache: "no-store" })
        .then(r => r.ok ? r.json() : []).catch(() => []);
      setTimeout(() => { delete window.__wtCategoriesPromise; }, 30000);
    }
    try { _wtCatData = await window.__wtCategoriesPromise; } catch(e) { _wtCatData = []; }
    _renderWtCatList();
    if (badgeEl) badgeEl.textContent = _wtCatData.length + " categories";
  }

  function _renderWtCatList() {
    const listEl = document.getElementById("wt-cat-list");
    if (!listEl) return;
    if (!_wtCatData.length) {
      listEl.innerHTML = "<div style=\"font-size:12px;color:var(--text-tertiary)\">No categories yet.</div>";
      return;
    }
    listEl.innerHTML = _wtCatData.map((c, i) => `
      <div style="display:flex;align-items:center;gap:8px;padding:6px 10px;background:var(--bg-ui);border:1px solid var(--border-subtle);border-radius:var(--radius-sm)">
        <span style="flex:1;font-size:12px;color:var(--text-primary)">${Utils.escHtml(c.name)}</span>
        <button onclick="_wtCatDelete(${i})" style="background:none;border:none;cursor:pointer;color:var(--red);font-size:14px;padding:0 4px;line-height:1" title="Remove">✕</button>
      </div>`).join("");
  }

  window._wtCatDelete = function(i) {
    _wtCatData.splice(i, 1);
    _renderWtCatList();
    const badgeEl = document.getElementById("wt-cat-count-badge");
    if (badgeEl) badgeEl.textContent = _wtCatData.length + " categories";
  };

  // WT categories: loaded eagerly from _wireTeamConfigEvents, no lazy toggle needed

  document.addEventListener("click", function(e) {
    if (e.target && e.target.id === "wt-cat-add-btn") {
      const nameEl  = document.getElementById("wt-cat-new-name");
      const name = (nameEl?.value || "").trim();
      if (!name) { showToast("Enter a category name", "warning"); return; }
      if (_wtCatData.find(c => c.name.toLowerCase() === name.toLowerCase())) {
        showToast("Category already exists", "warning"); return;
      }
      _wtCatData.push({ name, color: "" });
      _wtCatData.sort((a, b) => a.name.localeCompare(b.name));
      _renderWtCatList();
      if (nameEl) nameEl.value = "";
      const badgeEl = document.getElementById("wt-cat-count-badge");
      if (badgeEl) badgeEl.textContent = _wtCatData.length + " categories";
    }
    if (e.target && e.target.id === "wt-cat-save-btn") {
      const statusEl = document.getElementById("wt-cat-status");
      if (statusEl) statusEl.textContent = "Saving…";
      const base = (window.API_BASE_V2 || "/iip/api/v2");
      fetch(base + "/wt-categories", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ categories: _wtCatData })
      }).then(r => r.json()).then(data => {
        if (statusEl) statusEl.textContent = "";
        showToast("✓ Saved " + data.count + " categories", "success");
        if (typeof DashWeeklyTracker !== "undefined" && typeof DashWeeklyTracker._reloadCategories === "function") {
          DashWeeklyTracker._reloadCategories();
        }
      }).catch(err => {
        if (statusEl) statusEl.textContent = "";
        showToast("Failed to save: " + err.message, "danger");
      });
    }
  });


  function renderPerfNums(data) {
    var body = document.getElementById('perf-nums-body');
    if (!body) return;
    var nums = ((data && data.performance_cases) || []).map(function(p){ return p.case_number; }).filter(Boolean);
    if (!nums.length) { body.innerHTML = '<span style="font-size:11px;color:var(--text-tertiary);padding:4px 8px">No performance cases</span>'; return; }
    body.innerHTML = nums.map(function(n){
      return '<span style="background:var(--red-bg);color:var(--red);border:1px solid rgba(218,30,40,.2);display:inline-flex;align-items:center;gap:4px;border-radius:4px;font-size:11px;font-family:var(--font-mono);padding:2px 7px;margin:2px">' + n + '</span>';
    }).join('');
  }

  function renderNonPerfNums(data) {
    var body = document.getElementById('nonperf-nums-body');
    if (!body) return;
    var nums = ((data && data.non_performance_cases) || []).map(function(p){ return p.case_number; }).filter(Boolean);
    if (!nums.length) { body.innerHTML = '<span style="font-size:11px;color:var(--text-tertiary);padding:4px 8px">No non-performance cases</span>'; return; }
    body.innerHTML = nums.map(function(n){
      return '<span style="background:#f0faf0;color:var(--green);border:1px solid rgba(36,161,72,.2);display:inline-flex;align-items:center;gap:4px;border-radius:4px;font-size:11px;font-family:var(--font-mono);padding:2px 7px;margin:2px">' + n + '</span>';
    }).join('');
  }

  return { render, renderPerfNums, renderNonPerfNums };
})();
