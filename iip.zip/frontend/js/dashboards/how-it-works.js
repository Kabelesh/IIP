/* ================================================================
   how-it-works.js — Cinematic "How It Works" interactive guide
   Features: animated flow diagram, step-by-step stepper mode,
   progress tracking, live search, and app tour launcher.
   ================================================================ */
(function () {
  "use strict";

const PAGES = [
    {
      id: "upload",
      icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>',
      color: "#198038", colorBg: "#defbe6", title: "Upload Data", tagline: "Import your case data to get started",
      description: "Everything starts here. Drag a CSV or Excel file onto the upload zone and the platform handles the rest — parsing, deduplicating, and merging data into your live dashboards. Team configuration and contact data load automatically from the server in the background.",
      steps: [
        { action: 'Drag & drop a CSV/XLSX file onto the upload screen, or click "Choose File"', result: "File is read and parsed by the XLSX library — entirely in your browser", icon: "📂" },
        { action: "Progress bar advances: Reading → Parsing → Merging → Building → Done", result: "Cases are validated, normalized, and intelligently merged with existing data", icon: "⚙️" },
        { action: "Upload completes — dashboard loads automatically", result: "All pages now have live data; cases are queued for permanent archive via server API", icon: "✅" }
      ],
      backend: "File parsed client-side (XLSX.js). Case data stored in localStorage. Team config fetched from /api/team-config (PostgreSQL). No raw file is uploaded to the server.",
      tips: ["Supports CSV, XLSX, XLS, XLSM formats", "Re-uploading merges new data — nothing is lost", "Duplicate files are detected by fingerprint to prevent redundant imports"]
    },
    {
      id: "overview",
      icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></svg>',
      color: "#0f62fe", colorBg: "#edf5ff", title: "Overview", tagline: "Your command center — everything at a glance",
      description: "Mission control for the whole platform. The Overview shows three rows of KPI cards: team-wide case health, customer account snapshots (ACC-02 and your default account), and a live performance case summary. Interactive charts let you click through to filtered case lists in seconds.",
      steps: [
        { action: "View team KPI cards: Total, Open, Stale, Closed (7d) with week-over-week deltas", result: "Instant snapshot of team health and case volume trends", icon: "📊" },
        { action: "Check ACC-02 and customer account KPIs (open, IBM-working, awaiting feedback)", result: "Account-level health visible without switching pages", icon: "🏢" },
        { action: "Review the Performance KPIs row: active perf cases, in-progress, new this week", result: "Performance incidents tracked in real time alongside regular cases", icon: "⚡" },
        { action: "Explore the Created vs Closed trend chart, Status donut, and owner workload bar chart", result: "Click any bar to filter the case table by that owner", icon: "📈" },
        { action: "Switch trend window: 3 / 6 / 12 months", result: "See how case volume and closure rate have evolved over time", icon: "🔭" }
      ],
      backend: "Pure client-side aggregation from localStorage. Performance case numbers fetched from /api/v2/cases/performance-summary (PostgreSQL). No additional API calls for main KPIs.",
      tips: ["Stale = cases not updated in 5+ days", "Click chart bars to cross-filter the case table", "Performance KPI row turns red when active perf cases exceed threshold"]
    },
    {
      id: "team",
      icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
      color: "#6929c4", colorBg: "#f6f2ff", title: "Team Cases", tagline: "Filter, search, and manage all team cases",
      description: "Your day-to-day workspace. Apply powerful filters to isolate specific subsets of work, use the Column Manager to show only the columns you need, save frequent searches as chips, send reminder emails with one click, and sort any column to reprioritize.",
      steps: [
        { action: "Filter by Owner, Status, or Days Since Update using the filter bar", result: "Table narrows to matching cases instantly", icon: "🔍" },
        { action: "Click the column pills bar to show/hide columns (Column Manager)", result: "Your column choices persist in localStorage across sessions", icon: "⚙️" },
        { action: 'Type a search query and click the bookmark icon to save it as a Saved Search chip', result: "Saved searches appear as one-click chips above the search bar", icon: "🔖" },
        { action: 'Click "Send Reminder Mail" for filtered cases', result: "Outlook opens pre-filled with overdue case details for each owner", icon: "📧" },
        { action: "Sort columns by clicking headers; click owner chart bars to toggle owner filter", result: "Combine visual chart filtering with column sorting for precise views", icon: "↕️" }
      ],
      backend: "All filtering and sorting is client-side (localStorage data). Reminder mail uses mailto: generating Outlook-compatible HTML tables. Saved searches stored in localStorage.",
      tips: ["Use \"Days since update\" to surface neglected cases", "Column Manager defaults to 6 key columns — add more as needed", "Saved Search chips persist across page refreshes"]
    },
    {
      id: "members",
      icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="19" y1="8" x2="19" y2="14"/><line x1="22" y1="11" x2="16" y2="11"/></svg>',
      color: "#0f62fe", colorBg: "#edf5ff", title: "Member Dashboard", tagline: "Individual workload and health scores",
      description: "See your team through an individual lens. The Member Dashboard calculates a health score (0–100) for each person based on stale cases and awaiting-feedback ratios. Active and Departed members are tracked separately, and KPI cards are clickable to filter the member list.",
      steps: [
        { action: "View team-wide KPI cards: Members, Active, Awaiting, Closed (7d) — click to filter", result: "Quick summary of the entire team with instant drill-down filtering", icon: "👥" },
        { action: "Browse member cards showing per-person stats (Active, Closed, Awaiting, Health score)", result: "Spot overloaded or underutilized team members at a glance", icon: "🃏" },
        { action: "Sort members by Active, Closed, Health, or Awaiting via the sort bar", result: "Instantly reprioritize who needs attention", icon: "↕️" },
        { action: "Click a member row to expand full detail with all their cases", result: "View case list, performance metrics, and filter by case status", icon: "🔎" }
      ],
      backend: "Health score computed client-side: factors in stale % and awaiting-feedback %. Departed members are detected from DynamicConfig team roster.",
      tips: ["Health score 0–100: higher = healthier workload", "Red indicators flag members with too many stale cases", "Departed members shown separately — their cases remain visible for handover"]
    },
    {
      id: "customer",
      icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>',
      color: "#198038", colorBg: "#defbe6", title: "Customer Cases", tagline: "Track cases by customer account",
      description: "A dedicated view scoped to a specific customer account. All filters and charts respond to your selected account ID (set in Admin Portal), giving you a clean, customer-centric perspective on open, closed, and in-progress cases.",
      steps: [
        { action: "View KPIs: Customer total, open, closed, in-progress cases", result: "Account-level case health at a glance", icon: "📋" },
        { action: "Filter by Year, Month, Date Range, or Status", result: "Slice customer cases by any time period", icon: "📅" },
        { action: "Click owner chart bars to filter by assignee", result: "See which team members handle this customer's cases", icon: "👆" },
        { action: "Sort and search the case table by any column", result: "Find specific customer cases quickly", icon: "🔍" }
      ],
      backend: "Filters cases by Customer Account ID — configurable in Admin Portal. All computation is client-side from localStorage.",
      tips: ["Default customer account ID can be changed in Admin Portal → Team Config", "Combine date range filter with owner filter for detailed account reviews"]
    },
    {
      id: "closed",
      icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>',
      color: "#198038", colorBg: "#defbe6", title: "Closed Cases", tagline: "Historical analysis of case closures",
      description: "The historical record of resolved cases. Three trend charts reveal your team's closure patterns and help identify seasonal workload shifts. Filter by Customer # to scope closures to a single account.",
      steps: [
        { action: "View KPIs: Total closed, this month, last 7 days", result: "Closure rate metrics at a glance", icon: "✅" },
        { action: "Explore 3 trend charts: Monthly, Weekly (12 wk), Yearly", result: "Spot closure patterns and seasonal trends", icon: "📈" },
        { action: "Click owner bars to filter by who closed cases", result: "See individual contribution to closures", icon: "👆" },
        { action: "Apply date filters (Year/Month, From/To range, last N days) and Customer # filter", result: "Drill into specific time periods or account-scoped closures", icon: "📅" }
      ],
      backend: "All computed from case Closed Date field in localStorage. No API calls.",
      tips: ["Weekly chart shows last 12 ISO weeks for recent momentum", "Use Customer # filter to see how many cases were closed for a specific account", "Compare with Created Cases to see if you're closing faster than opening"]
    },
    {
      id: "created",
      icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg>',
      color: "#6929c4", colorBg: "#f6f2ff", title: "Created Cases", tagline: "Track case creation rate and trends",
      description: "The intake side of your pipeline. Track how many new cases are arriving and when, then compare against Closed Cases to understand whether the queue is growing or shrinking.",
      steps: [
        { action: "View creation KPIs: Total, this month, last 7 days", result: "Case intake velocity at a glance", icon: "📊" },
        { action: "Explore Monthly, Weekly, and Yearly creation charts", result: "Identify spikes in case creation", icon: "📈" },
        { action: "Filter by date range or owner", result: "Narrow to specific periods or assignees", icon: "🔍" },
        { action: "Compare with the Closed Cases page", result: "Determine if the team is keeping up with incoming volume", icon: "⚖️" }
      ],
      backend: "Aggregated from Created Date field. Pure client-side, same architecture as Closed Cases.",
      tips: ["Creation spikes often correlate with product releases or outages", "Use alongside Closed Cases to track net case growth/reduction"]
    },
    {
      id: "performance",
      icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>',
      color: "#da1e28", colorBg: "#fff1f1", title: "Performance", tagline: "ALM instance performance case tracking",
      description: "Auto-detects performance-related cases using regex matching on ALM instance identifiers. Maintains two live tables — Performance Cases and Non-Performance Cases (ACC-08 scope) — updated in real time via SSE when tags change in the Admin Portal.",
      steps: [
        { action: "View Performance Cases table — ALM instance auto-detected (ALM-01-P through ALM-28-T4)", result: "Cases tagged with app type (RM, QM, CCM, DCC, LQE, etc.) automatically", icon: "🔬" },
        { action: "Check or add Work Item IDs (CCM defect numbers) for each performance case", result: "Click any defect ID to open the linked CCM work item directly", icon: "🔗" },
        { action: "Use filters: ALM instance, app type, or toggle 'Missing Work Item' to find gaps", result: "Focus on specific infrastructure problems or unlinked cases", icon: "🔍" },
        { action: "Browse the Non-Performance Cases table for ACC-08 open cases", result: "Secondary view shows active non-perf cases for context", icon: "📋" },
        { action: "Tag/untag performance cases via the Admin Portal — changes reflect here in real time", result: "SSE event (iip:perf-tag-updated) triggers automatic table refresh", icon: "⚡" }
      ],
      backend: "Performance case list fetched from /api/v2/cases/performance-summary (PostgreSQL). Non-perf from /api/v2/cases/nonperf-summary. SSE stream pushes tag changes live. Work Item links open the CCM defect tracker.",
      tips: ["App detection auto-categorizes: RM, QM, CCM, DCC, LQE, IHS, LDX, ATS, MQTT, HAPROXY", "Work Items are stored per-case in the server database — visible to all admin users", "The 'Missing Work Item' filter instantly shows cases that need a defect linked"]
    },
    {
      id: "weekly-tracker",
      icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/><polyline points="9 16 11 18 15 14"/></svg>',
      color: "#0f62fe", colorBg: "#edf5ff", title: "Weekly Tracker", tagline: "Track case closures by calendar week",
      description: "Your weekly closure ledger. Record which cases were closed each ISO week, add standup notes stored server-side, and browse historical weeks. Cross-week grayout prevents duplicate entries across different weeks.",
      steps: [
        { action: "Select Year and Calendar Week from the dropdowns", result: "View and edit cases closed in that specific ISO week", icon: "📅" },
        { action: "Add case numbers to the selected week", result: "Cases linked to the weekly closure record; cross-week duplicates are greyed out", icon: "➕" },
        { action: "Add or edit the week's standup comment", result: "Comment saved to the server database — visible to all team members", icon: "📝" },
        { action: "Browse the History tab for past weekly entries", result: "Review and compare historical weekly performance across all weeks", icon: "📚" }
      ],
      backend: "Closed case data read from localStorage (case Closed Date field). Week comments stored server-side in PostgreSQL via IIPStore (/api/kv-store). Comments load from DB on render and sync on every edit.",
      tips: ["Cross-week grayout prevents the same case appearing in two different weeks", "Comments persist in the database — great for standup notes and sprint reviews", "Undo/Redo available for accidental case additions"]
    },
    {
      id: "investigate",
      icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>',
      color: "#6929c4", colorBg: "#f6f2ff", title: "Investigate", tagline: "Search, archive, and find similar cases",
      description: "A permanent, ever-growing archive of every case ever uploaded — served from the PostgreSQL database. Search across current and historical data with TF-IDF similarity scoring to find related past cases and accelerate resolution.",
      steps: [
        { action: "Type a search query (case #, title, owner, product, error code)", result: "Real-time results from current localStorage data + permanent server archive", icon: "🔍" },
        { action: "Switch to the Archive Search tab", result: "Search all cases ever recorded — nothing ever deleted from the PostgreSQL archive", icon: "📦" },
        { action: "View similar cases with TF-IDF similarity scoring", result: "The Similarity engine (tokenization, keyword extraction, error-code matching) surfaces the most related historical cases", icon: "🤖" },
        { action: "Use the Support Intelligence panel for error code lookup and diagnostics", result: "Pre-built error code templates and known-issue patterns to accelerate investigation", icon: "🧠" },
        { action: "Click any result for the full case detail modal", result: "View complete metadata, history, and context from both current and archived data", icon: "🔎" }
      ],
      backend: "Archive fetched from /api/v2/cases/archive (PostgreSQL). Similarity scoring uses similarity.js: TF-IDF, error-code extraction, product detection, and linear-regression pattern detection. No localStorage dependency for archive data.",
      tips: ["The archive grows with every upload — all historical cases permanently searchable", "TF-IDF scoring weights rare terms more heavily for better match quality", "Error code extraction (CRJAZ, HTTP codes, Jazz exceptions) improves match precision"]
    },
    {
      id: "rfe-tracking",
      icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/><line x1="9" y1="13" x2="15" y2="13"/><line x1="9" y1="17" x2="15" y2="17"/></svg>',
      color: "#198038", colorBg: "#defbe6", title: "RFE Tracking", tagline: "Track Requests for Enhancement",
      description: "Manage your enhancement request pipeline from submitted to delivered. Shows vote counts, delivery status, and top-voted RFEs. The Advanced view adds notes, tags, target releases, and a Kanban board for a complete RFE workflow.",
      steps: [
        { action: "View RFE analytics: Total RFEs, Delivered, total votes, average votes per RFE", result: "High-level progress on the enhancement request pipeline", icon: "📊" },
        { action: "Filter by Product or Workflow State; search RFEs by keyword", result: "Focus on specific products or pipeline stages", icon: "🔍" },
        { action: "Sort by Vote Count (⭐ for 10+ votes), Product, or Status", result: "Prioritize high-demand enhancements at a glance", icon: "↕️" },
        { action: "Switch to Advanced view for notes, tags, target release dates, and Kanban board", result: "Full RFE metadata management with per-RFE notes and workflow board", icon: "🗂️" },
        { action: 'Click "Export Excel" to download the filtered RFE list', result: "XLSX export includes all visible columns for reporting", icon: "📥" }
      ],
      backend: "RFE data imported via CSV/Excel through Admin Portal. Stored in localStorage (ibm_rfe_tracking_v1). Notes and tags stored in a separate localStorage key. Export uses XLSX.js client-side.",
      tips: ["RFEs with 10+ votes get a ⭐ star indicator for easy identification", "Advanced view Kanban groups RFEs by Workflow State for pipeline visibility", "Upload updated RFE exports from Aha! via Admin Portal to keep data current"]
    },
    {
      id: "documentation",
      icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>',
      color: "#6929c4", colorBg: "#f6f2ff", title: "Documentation", tagline: "Full technical reference for developers and admins",
      description: "In-app IBM-style documentation covering the entire platform. Organized into Overview, Getting Started, Dashboards, Administration, Operations, and Tools & Features. Some admin-only sections require Admin Portal login.",
      steps: [
        { action: "Browse the left-hand nav tree: Overview → Getting Started → Dashboards → Admin → Ops → Tools", result: "Jump directly to any section — table of contents always visible", icon: "📚" },
        { action: "Read platform architecture, system requirements, and the end-to-end application flowchart", result: "Understand how all components fit together (RHEL9 · Apache · FastAPI · PostgreSQL)", icon: "🏗️" },
        { action: "Follow the Installation & Setup guide or Boot Sequence walkthrough", result: "Step-by-step instructions for first-time setup and server configuration", icon: "🚀" },
        { action: "Access admin-only sections: Security Questions, DB Schema, Auth Architecture, Deployment ops", result: "Requires Admin Portal session — protected pages hidden without auth", icon: "🔐" },
        { action: "Use the in-page search to find any topic across all documentation sections", result: "Instant filtering of all doc sections by keyword", icon: "🔍" }
      ],
      backend: "Documentation is rendered entirely client-side from static content in documentation.js. Admin-only sections check for a live Admin Portal session. No server API calls required for doc content.",
      tips: ["Deployment History section lists every version change with dates", "Operations section covers PostgreSQL schema, systemd service config, and Apache setup", "Keyboard shortcut: press ? anywhere in the app to open the shortcuts reference"]
    },
    {
      id: "info",
      icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>',
      color: "#0f62fe", colorBg: "#edf5ff", title: "Information", tagline: "Contacts, escalation matrix, and resources",
      description: "Your on-call reference guide. The severity matrix, must-gather instructions, contact directory, and quick links give you everything needed to escalate cases correctly and reach the right expert fast.",
      steps: [
        { action: "Review the Severity Matrix with escalation SLAs per severity level", result: "Know the response time expectations for Sev 1 (Critical) through Sev 4 (Low)", icon: "⚠️" },
        { action: "Access Must-Gather guides and investigation templates", result: "Collect the right diagnostic data (ISADC logs, Java cores, GC logs) before engaging IBM support", icon: "🛠️" },
        { action: "Search the Contact Directory by name, email, or expertise area", result: "Find the right expert for your issue within seconds", icon: "📇" },
        { action: "Click Quick Links for external IBM tools, wikis, and case handling resources", result: "Navigate directly to IBM Case Handling portals, CCM, and IBM support", icon: "🔗" }
      ],
      backend: "Contact data loaded from DynamicConfig (server /api/team-config if available) with fallback to static config.js.",
      tips: ["Severity levels: 1 (Critical) → 4 (Low) — each has different SLA and escalation paths", "Must-Gather links include ISADC log collection, Java core dump guides, and GC log analysis", "Contact directory searchable by name, email, and expertise area"]
    },
    {
      id: "admin",
      icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="3"/><path d="M19.07 4.93l-1.41 1.41M4.93 19.07l1.41-1.41M4.93 4.93l1.41 1.41M19.07 19.07l-1.41-1.41M12 2v2M12 20v2M2 12h2M20 12h2"/></svg>',
      color: "#da1e28", colorBg: "#fff1f1", title: "Admin Portal", tagline: "Configuration, bulk operations, and audit trail",
      description: "Protected by server-side bcrypt authentication with a 30-minute session stored in sessionStorage (cleared on tab close). Handles bulk reassignments, performance tagging, RFE data uploads, and maintains a complete audit trail in PostgreSQL.",
      steps: [
        { action: "Log in with admin credentials — server validates via bcrypt, issues a session token", result: "Token stored in sessionStorage only — never in localStorage, invisible to XSS. Session lasts 30 min.", icon: "🔐" },
        { action: "Bulk reassign cases via Excel import (Old Owner → New Owner column mapping)", result: "All matching cases reassigned; change logged to the PostgreSQL audit trail", icon: "📋" },
        { action: "Mark/unmark performance cases, add Work Item IDs, tags, and notes", result: "Saved to PostgreSQL — visible to all users immediately via SSE push", icon: "🏷️" },
        { action: "Upload RFE CSV/Excel data to refresh the RFE Tracking page", result: "New RFE data parsed and stored in localStorage for the RFE dashboard", icon: "📤" },
        { action: "View Change History — searchable, filterable, exportable audit log", result: "Every admin action recorded with timestamp, actor, and before/after values. Undo supported.", icon: "📜" }
      ],
      backend: "Authentication: FastAPI server with bcrypt (passlib). Session token in sessionStorage. Audit trail in PostgreSQL (admin_actions table). Perf tag changes broadcast to all clients via SSE. Undo/Redo up to 30 snapshots in-memory.",
      tips: ["Admin session survives F5 refresh (sessionStorage) but is cleared when the tab is closed", "Team member renames in Admin cascade across all case data in localStorage", "Security Questions enable admin password reset without direct server access"]
    }
  ];;


  let stepperPage = 0, stepperIndex = 0, searchQuery = "";
  let completedPages = [];
  try { completedPages = JSON.parse(localStorage.getItem("hiw_completed") || "[]"); } catch(e) {}

  function saveProgress() { try { localStorage.setItem("hiw_completed", JSON.stringify(completedPages)); } catch(e) {} }
  function markComplete(id) { if (!completedPages.includes(id)) { completedPages.push(id); saveProgress(); } }

  function render() {
    const el = document.getElementById("tab-how-it-works");
    if (!el) return;
    searchQuery = "";

    el.innerHTML = buildHTML();
    attachEvents(el);
    animateIn(el);
  }

  function buildHTML() {
    return `
      <div class="hiw-container" id="hiw-root">
        <div class="hiw-hero">
          <div class="hiw-hero-badge"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" width="13" height="13"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg> Interactive Guide</div>
          <h1 class="hiw-hero-title">How It Works</h1>
          <p class="hiw-hero-sub">A complete walkthrough of every page in the IBM Case Intelligence Platform.<br>Explore at your own pace — or take the guided tour.</p>
          <div class="hiw-hero-actions">
            <button class="hiw-btn-primary" id="hiw-start-tour"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" width="14" height="14"><polygon points="5 3 19 12 5 21 5 3"/></svg> Start Guided Tour</button>
            <button class="hiw-btn-ghost" id="hiw-reset-progress"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 .49-4.96"/></svg> Reset Progress</button>
          </div>
          <div class="hiw-progress-wrap">
            <div class="hiw-progress-label"><span>Progress</span><span id="hiw-progress-count">${completedPages.length} / ${PAGES.length} explored</span></div>
            <div class="hiw-progress-bar"><div class="hiw-progress-fill" id="hiw-prog-fill" style="width:${Math.round((completedPages.length/PAGES.length)*100)}%"></div></div>
            <div class="hiw-progress-dots" id="hiw-prog-dots">${PAGES.map(p=>`<div class="hiw-dot${completedPages.includes(p.id)?" done":""}" title="${p.title}" style="--dc:${p.color}"></div>`).join("")}</div>
          </div>
        </div>

        <div class="hiw-flow-section">
          <div class="hiw-flow-label">Application Flow</div>
          <div class="hiw-flow-diagram" id="hiw-flow">
            ${[
              {label:"Upload",sub:"Import CSV/XLSX",cls:"hiw-flow-start",icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>'},
              {label:"Parse & Store",sub:"localStorage + PostgreSQL",cls:"",icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/></svg>'},
              {label:"Dashboards",sub:"Overview · Team · Members",cls:"",icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></svg>'},
              {label:"Analyze",sub:"Performance · Investigate",cls:"",icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>'},
              {label:"Act & Resolve",sub:"Track · Close · Report",cls:"hiw-flow-end",icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>'}
            ].map((n,i,arr)=>`
              <div class="hiw-flow-node ${n.cls}">
                <div class="hiw-flow-node-icon">${n.icon}</div>
                <span>${n.label}</span>
                <div class="hiw-flow-node-sub">${n.sub}</div>
              </div>
              ${i<arr.length-1?'<div class="hiw-flow-arr"><svg viewBox="0 0 32 10" fill="none"><path d="M0 5 L26 5" stroke="currentColor" stroke-width="1.5" stroke-dasharray="4 2.5" opacity=".5"/><path d="M22 1 L29 5 L22 9" fill="currentColor" opacity=".4"/></svg></div>':""}
            `).join("")}
          </div>
        </div>

        <div class="hiw-toolbar">
          <div class="hiw-search-wrap">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="15" height="15"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
            <input type="text" id="hiw-search" class="hiw-search-input" placeholder="Search pages, features, tips…" autocomplete="off">
            <button class="hiw-search-clear" id="hiw-search-clear" style="display:none">✕</button>
          </div>
          <div class="hiw-view-toggle">
            <button class="hiw-view-btn active" id="hiw-grid-btn" title="Card view"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg></button>
            <button class="hiw-view-btn" id="hiw-list-btn" title="List view"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg></button>
          </div>
        </div>

        <div class="hiw-grid" id="hiw-grid">
          ${PAGES.map((p,i)=>renderCard(p,i)).join("")}
        </div>
        <div class="hiw-no-results" id="hiw-no-results" style="display:none">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="28" height="28"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
          <p>No pages match your search</p>
        </div>

        <div class="hiw-architecture">
          <div class="hiw-arch-label">Data Architecture</div>
          <div class="hiw-arch-sub">How the platform stores and processes your data</div>
          <div class="hiw-arch-grid">
            ${[
              {bg:"#defbe6",ic:"#198038",icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>',title:"File Import",body:"CSV/XLSX/XLS/XLSM files are parsed client-side using XLSX.js. No data leaves your browser."},
              {bg:"#edf5ff",ic:"#0f62fe",icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/></svg>',title:"localStorage",body:"Case data and settings persist in localStorage. Archive, perf tags, and comments also sync to PostgreSQL for cross-session durability."},
              {bg:"#f6f2ff",ic:"#6929c4",icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18"/><path d="M9 21V9"/></svg>',title:"Smart Merge",body:"Re-uploading merges new data with existing records. Duplicate detection by fingerprint prevents redundant imports."},
              {bg:"#fff1f1",ic:"#da1e28",icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>',title:"Privacy First",body:"Core case data stays in your browser. Admin auth, archive, and perf tags use a local FastAPI server (RHEL9) — no external cloud dependency."}
            ].map(a=>`<div class="hiw-arch-card"><div class="hiw-arch-icon" style="background:${a.bg}"><svg viewBox="0 0 24 24" fill="none" stroke="${a.ic}" stroke-width="1.8" width="18" height="18">${a.icon.replace(/<svg[^>]*>/,"")}</div><h4>${a.title}</h4><p>${a.body}</p></div>`).join("")}
          </div>
        </div>

        <div class="hiw-shortcuts-section">
          <div class="hiw-arch-label">Keyboard Shortcuts</div>
          <div class="hiw-shortcuts-grid">
            <div class="hiw-sc-item"><div class="hiw-sc-keys"><kbd>1</kbd>–<kbd>9</kbd></div><div class="hiw-sc-desc">Jump to pages</div></div>
            <div class="hiw-sc-item"><div class="hiw-sc-keys"><kbd>Ctrl</kbd><kbd>K</kbd></div><div class="hiw-sc-desc">Command palette</div></div>
            <div class="hiw-sc-item"><div class="hiw-sc-keys"><kbd>?</kbd></div><div class="hiw-sc-desc">All shortcuts</div></div>
            <div class="hiw-sc-item"><div class="hiw-sc-keys"><kbd>Esc</kbd></div><div class="hiw-sc-desc">Close modals</div></div>
          </div>
        </div>
      </div>

      <div class="hiw-stepper-overlay" id="hiw-stepper-overlay" style="display:none" aria-modal="true" role="dialog">
        <div class="hiw-stepper-modal">
          <div class="hiw-stepper-top">
            <div class="hiw-stepper-pills" id="hiw-stepper-pills"></div>
            <button class="hiw-stepper-close" id="hiw-stepper-close" aria-label="Close tour">✕</button>
          </div>
          <div class="hiw-stepper-body" id="hiw-stepper-body"></div>
          <div class="hiw-stepper-footer">
            <button class="hiw-stp-prev" id="hiw-step-prev">← Prev</button>
            <div class="hiw-stp-dots" id="hiw-stepper-dots"></div>
            <button class="hiw-stp-next" id="hiw-step-next">Next →</button>
          </div>
        </div>
      </div>
    `;
  }

  function renderCard(page, index) {
    const done = completedPages.includes(page.id);
    const isUpload = page.id === "upload";
    return `
      <div class="hiw-card${done?" hiw-card-done":""}" data-page="${page.id}" data-index="${index}"
           data-search="${[page.title,page.tagline,page.description,...page.steps.map(s=>s.action+" "+s.result),...page.tips].join(" ").toLowerCase()}"
           style="--cc:${page.color};--cb:${page.colorBg}">
        <div class="hiw-card-header">
          <div class="hiw-card-hl">
            <div class="hiw-card-num">${done?`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" width="11" height="11"><polyline points="20 6 9 17 4 12"/></svg>`:index+1}</div>
            <div class="hiw-card-icon">${page.icon}</div>
            <div>
              <div class="hiw-card-title">${page.title}</div>
              <div class="hiw-card-tagline">${page.tagline}</div>
            </div>
          </div>
          <div class="hiw-card-hr">
            <div class="hiw-steps-pill">${page.steps.length} steps</div>
            ${!isUpload?`<button class="hiw-goto-btn" data-goto="${page.id}"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="11" height="11"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg> Open</button>`:""}
            <div class="hiw-chevron"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" width="15" height="15"><polyline points="6 9 12 15 18 9"/></svg></div>
          </div>
        </div>
        <div class="hiw-card-body" style="max-height:0;overflow:hidden">
          <div class="hiw-card-body-in">
            <p class="hiw-card-desc">${page.description}</p>
            <div class="hiw-sl">Workflow steps</div>
            <div class="hiw-steps">
              ${page.steps.map((s,si)=>`
                <div class="hiw-step">
                  <div class="hiw-step-track">
                    <div class="hiw-step-num">${si+1}</div>
                    ${si<page.steps.length-1?'<div class="hiw-step-line"></div>':""}
                  </div>
                  <div class="hiw-step-cnt">
                    <div class="hiw-step-emoji">${s.icon}</div>
                    <div>
                      <div class="hiw-step-action">${s.action}</div>
                      <div class="hiw-step-result"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" width="11" height="11"><polyline points="20 6 9 17 4 12"/></svg> ${s.result}</div>
                    </div>
                  </div>
                </div>`).join("")}
            </div>
            <div class="hiw-sl">Under the hood</div>
            <div class="hiw-backend-pill"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" width="13" height="13"><rect x="4" y="4" width="16" height="16" rx="2"/><rect x="9" y="9" width="6" height="6"/></svg> ${page.backend}</div>
            <div class="hiw-sl">Pro tips</div>
            <div class="hiw-tips-grid">${page.tips.map(t=>`<div class="hiw-tip"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="11" height="11"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg> ${t}</div>`).join("")}</div>
            <div class="hiw-card-foot">
              <button class="hiw-mark-done${done?" done":""}" data-id="${page.id}">${done?`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" width="13" height="13"><polyline points="20 6 9 17 4 12"/></svg> Explored`:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg> Mark explored`}</button>
              <button class="hiw-walk-btn" data-pi="${index}"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="11" height="11"><polygon points="5 3 19 12 5 21 5 3"/></svg> Walk through</button>
            </div>
          </div>
        </div>
      </div>`;
  }

  function openStepper(pi) {
    stepperPage = pi; stepperIndex = 0;
    const ov = document.getElementById("hiw-stepper-overlay");
    ov.style.display = "flex";
    setTimeout(()=>ov.classList.add("visible"),10);
    document.body.style.overflow = "hidden";
    renderStepper();
  }

  function closeStepper() {
    const ov = document.getElementById("hiw-stepper-overlay");
    ov.classList.remove("visible");
    setTimeout(()=>{ ov.style.display="none"; document.body.style.overflow=""; }, 280);
  }

  function renderStepper() {
    const page = PAGES[stepperPage];
    const step = page.steps[stepperIndex];
    const pillsEl = document.getElementById("hiw-stepper-pills");
    const bodyEl = document.getElementById("hiw-stepper-body");
    const dotsEl = document.getElementById("hiw-stepper-dots");
    if (!pillsEl||!bodyEl) return;

    pillsEl.innerHTML = PAGES.map((p,i)=>`<button class="hiw-spill${i===stepperPage?" act":""}" data-pi="${i}" style="${i===stepperPage?`color:${p.color};border-color:${p.color};background:${p.colorBg}`:""}">${p.icon}<span>${p.title}</span></button>`).join("");
    pillsEl.querySelectorAll(".hiw-spill").forEach(b=>b.addEventListener("click",()=>{stepperPage=+b.dataset.pi;stepperIndex=0;renderStepper();}));
    const ap=pillsEl.querySelector(".hiw-spill.act");
    if(ap) ap.scrollIntoView({behavior:"smooth",block:"nearest",inline:"center"});

    bodyEl.innerHTML = `
      <div class="hiw-sb-hero" style="--sa:${page.color};--sb:${page.colorBg}">
        <div class="hiw-sb-icon">${page.icon}</div>
        <div><div class="hiw-sb-name">${page.title}</div><div class="hiw-sb-tag">${page.tagline}</div></div>
      </div>
      <div class="hiw-sb-prog">
        <span>Step ${stepperIndex+1} of ${page.steps.length}</span>
        <div class="hiw-sb-track"><div class="hiw-sb-fill" style="width:${((stepperIndex+1)/page.steps.length)*100}%;background:${page.color}"></div></div>
      </div>
      <div class="hiw-sb-card" style="--sa:${page.color};--sb:${page.colorBg}">
        <div class="hiw-sb-stepnum">${stepperIndex+1}</div>
        <div class="hiw-sb-emoji">${step.icon}</div>
        <div class="hiw-sb-action">${step.action}</div>
        <div class="hiw-sb-div"></div>
        <div class="hiw-sb-result-label">What happens</div>
        <div class="hiw-sb-result">${step.result}</div>
      </div>
      <div class="hiw-sb-mini-steps">
        ${page.steps.map((s,i)=>`<div class="hiw-sbm${i===stepperIndex?" act":i<stepperIndex?" done":""}" data-si="${i}" style="${i===stepperIndex?`--sa:${page.color}`:""}"><div class="hiw-sbm-n">${i<stepperIndex?"✓":i+1}</div><div class="hiw-sbm-t">${s.action.length>55?s.action.slice(0,55)+"…":s.action}</div></div>`).join("")}
      </div>`;

    bodyEl.querySelectorAll(".hiw-sbm").forEach(el=>el.addEventListener("click",()=>{stepperIndex=+el.dataset.si;renderStepper();}));

    dotsEl.innerHTML = page.steps.map((_,i)=>`<div class="hiw-sdot${i===stepperIndex?" act":i<stepperIndex?" dn":""}" style="${i===stepperIndex?`background:${page.color}`:""}"></div>`).join("");

    const pv=document.getElementById("hiw-step-prev"), nx=document.getElementById("hiw-step-next");
    if(pv){ pv.disabled=stepperPage===0&&stepperIndex===0; pv.textContent=stepperIndex===0?"← Prev Page":"← Prev Step"; }
    if(nx){ const isLast=stepperPage===PAGES.length-1&&stepperIndex===page.steps.length-1; nx.textContent=isLast?"✓ Finish":stepperIndex===page.steps.length-1?"Next Page →":"Next Step →"; }
  }

  function stepNext() {
    const page=PAGES[stepperPage];
    if(stepperIndex<page.steps.length-1){ stepperIndex++; }
    else {
      markComplete(page.id); updateProgressUI();
      if(stepperPage<PAGES.length-1){ stepperPage++; stepperIndex=0; }
      else { closeStepper(); showCelebration(); return; }
    }
    renderStepper();
  }
  function stepPrev() {
    if(stepperIndex>0){ stepperIndex--; }
    else if(stepperPage>0){ stepperPage--; stepperIndex=PAGES[stepperPage].steps.length-1; }
    renderStepper();
  }

  function updateProgressUI() {
    const ct=document.getElementById("hiw-progress-count"), fill=document.getElementById("hiw-prog-fill"), dotsEl=document.getElementById("hiw-prog-dots");
    if(ct) ct.textContent=`${completedPages.length} / ${PAGES.length} explored`;
    if(fill) fill.style.width=Math.round((completedPages.length/PAGES.length)*100)+"%";
    if(dotsEl) { const dots=dotsEl.querySelectorAll(".hiw-dot"); dots.forEach((d,i)=>{ if(completedPages.includes(PAGES[i].id)) d.classList.add("done"); }); }
    completedPages.forEach(id=>{
      const card=document.querySelector(`.hiw-card[data-page="${id}"]`);
      if(!card) return;
      card.classList.add("hiw-card-done");
      const n=card.querySelector(".hiw-card-num"); if(n&&!n.querySelector("svg")) n.innerHTML=`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" width="11" height="11"><polyline points="20 6 9 17 4 12"/></svg>`;
      const b=card.querySelector(".hiw-mark-done"); if(b&&!b.classList.contains("done")){ b.classList.add("done"); b.innerHTML=`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" width="13" height="13"><polyline points="20 6 9 17 4 12"/></svg> Explored`; }
    });
  }

  function showCelebration() {
    const cel=document.createElement("div"); cel.className="hiw-cel";
    cel.innerHTML=`<div class="hiw-cel-box"><div class="hiw-cel-ic">🎉</div><h2>Tour Complete!</h2><p>You've explored all ${PAGES.length} pages of the IBM Case Intelligence Platform.</p><button class="hiw-btn-primary" id="hiw-cel-ok">Back to Guide</button></div>`;
    document.body.appendChild(cel);
    setTimeout(()=>cel.classList.add("visible"),10);
    cel.querySelector("#hiw-cel-ok").addEventListener("click",()=>{ cel.classList.remove("visible"); setTimeout(()=>cel.remove(),300); });
    cel.addEventListener("click",e=>{ if(e.target===cel){ cel.classList.remove("visible"); setTimeout(()=>cel.remove(),300); } });
  }

  function animateIn(el) {
    const nodes=el.querySelectorAll(".hiw-flow-node");
    nodes.forEach((n,i)=>{ n.style.opacity="0"; n.style.transform="translateY(10px)"; setTimeout(()=>{ n.style.transition="all 0.35s ease"; n.style.opacity="1"; n.style.transform=""; }, 100+i*80); });
    const cards=el.querySelectorAll(".hiw-card");
    cards.forEach((c,i)=>{ c.style.opacity="0"; c.style.transform="translateY(8px)"; setTimeout(()=>{ c.style.transition="all 0.3s ease"; c.style.opacity="1"; c.style.transform=""; }, 200+i*40); });
  }

  function filterCards() {
    const q=searchQuery.toLowerCase().trim();
    const cards=document.querySelectorAll("#hiw-grid .hiw-card");
    let vis=0;
    cards.forEach(c=>{ const m=!q||c.dataset.search.includes(q); c.style.display=m?"":"none"; if(m)vis++; });
    const nr=document.getElementById("hiw-no-results"); if(nr) nr.style.display=vis===0?"flex":"none";
  }

  function attachEvents(el) {
    // Card accordion
    el.querySelectorAll(".hiw-card-header").forEach(h=>{
      h.addEventListener("click",function(e){
        if(e.target.closest(".hiw-goto-btn")||e.target.closest(".hiw-walk-btn")) return;
        const card=this.closest(".hiw-card"), wasOpen=card.classList.contains("open");
        el.querySelectorAll(".hiw-card.open").forEach(c=>{ c.classList.remove("open"); const b=c.querySelector(".hiw-card-body"); if(b) b.style.maxHeight="0px"; });
        if(!wasOpen){
          card.classList.add("open");
          const body=card.querySelector(".hiw-card-body");
          if(body){ body.style.maxHeight=body.scrollHeight+50+"px"; }
          setTimeout(()=>card.scrollIntoView({behavior:"smooth",block:"nearest"}),150);
        }
      });
    });

    // Goto
    el.querySelectorAll(".hiw-goto-btn").forEach(b=>b.addEventListener("click",function(e){
      e.stopPropagation(); const nav=document.querySelector(`.nav-item[data-tab="${this.dataset.goto}"]`); if(nav) nav.click();
    }));

    // Mark done
    el.querySelectorAll(".hiw-mark-done").forEach(b=>b.addEventListener("click",function(e){
      e.stopPropagation(); markComplete(this.dataset.id); updateProgressUI();
    }));

    // Walk through (stepper from card)
    el.querySelectorAll(".hiw-walk-btn").forEach(b=>b.addEventListener("click",function(e){
      e.stopPropagation(); openStepper(+this.dataset.pi);
    }));

    // Tour button
    const tb=document.getElementById("hiw-start-tour"); if(tb) tb.addEventListener("click",()=>openStepper(0));

    // Reset
    const rb=document.getElementById("hiw-reset-progress"); if(rb) rb.addEventListener("click",()=>{
      completedPages=[]; saveProgress(); render();
    });

    // Stepper overlay
    const ov=document.getElementById("hiw-stepper-overlay");
    if(ov){
      ov.addEventListener("click",e=>{ if(e.target===ov) closeStepper(); });
      const cl=document.getElementById("hiw-stepper-close"); if(cl) cl.addEventListener("click",closeStepper);
      const nx=document.getElementById("hiw-step-next"); if(nx) nx.addEventListener("click",stepNext);
      const pv=document.getElementById("hiw-step-prev"); if(pv) pv.addEventListener("click",stepPrev);
    }

    // Search
    const si=document.getElementById("hiw-search"), sc=document.getElementById("hiw-search-clear");
    if(si){ si.addEventListener("input",function(){ searchQuery=this.value; if(sc) sc.style.display=this.value?"":"none"; filterCards(); }); }
    if(sc){ sc.addEventListener("click",()=>{ si.value=""; searchQuery=""; sc.style.display="none"; filterCards(); si.focus(); }); }

    // View toggle
    const gb=document.getElementById("hiw-grid-btn"), lb=document.getElementById("hiw-list-btn"), gr=document.getElementById("hiw-grid");
    if(gb&&lb&&gr){
      gb.addEventListener("click",()=>{ gb.classList.add("active"); lb.classList.remove("active"); gr.classList.remove("hiw-grid-list"); });
      lb.addEventListener("click",()=>{ lb.classList.add("active"); gb.classList.remove("active"); gr.classList.add("hiw-grid-list"); });
    }

    // Keyboard for stepper
    document.addEventListener("keydown",function hiwKey(e){
      const ov=document.getElementById("hiw-stepper-overlay"); if(!ov||ov.style.display==="none") return;
      if(e.key==="ArrowRight"||e.key==="ArrowDown"){ e.preventDefault(); stepNext(); }
      if(e.key==="ArrowLeft"||e.key==="ArrowUp"){ e.preventDefault(); stepPrev(); }
      if(e.key==="Escape") closeStepper();
    });
  }

  window.HowItWorks = { render };

  const _orig=window._switchTab;
  if(typeof _orig==="function"){ window._switchTab=function(tab){ _orig(tab); if(tab==="how-it-works") render(); }; }
  document.addEventListener("click",function(e){ if(e.target.closest('.nav-item[data-tab="how-it-works"]')) setTimeout(render,50); });
  if(document.querySelector("#tab-how-it-works.active")) render();
})();
