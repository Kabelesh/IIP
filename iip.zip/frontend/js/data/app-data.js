/* ================================================================
   js/data/app-data.js  �  IBM Case Intelligence Platform
   Data is now DB-driven. Seed data lives in backend/seed_data.py.
   This file provides empty defaults so existing typeof-guards work.
   ================================================================ */
const AppData = (() => {
  const config = {
    teamName:          "",
    appTitle:          "IBM CASES",
    appSubtitle:       "IBM Case Intelligence Platform",
    defectBaseUrl:     "",
    idleTimeoutMs:      30 * 60 * 1000,
    idleWarningMs:      27 * 60 * 1000,
    tablePageSize:      50,
    persistKeyTracker: "ibm_tracker_persist_v1",
    persistKeyKB:      "ibm_knowledge_base_v2",
    persistKeyCases:   "ibm_cases_raw_v1",
  };
  const teamMembers              = [];
  const teamEmails               = {};
  const expertiseConnect         = [];
  const bdEscalation             = [];
  const teamLead                 = [];
  const customerContacts         = [];
  const almResponsible           = [];
  const ibmDirectory             = {};
  const performanceCases         = [];
  const nonPerformanceCases      = [];
  const performanceMeta          = {};
  const performanceDashboardComments = {};
  const changeHistory            = [];
  const rfeData                  = { rows: "[]", metadata: "{}", lastUpdate: "" };
  const reassignLog              = [];
  const allDashboardData         = {};
  return Object.freeze({
    config, teamMembers, teamEmails, expertiseConnect, bdEscalation,
    teamLead, customerContacts, almResponsible, ibmDirectory,
    performanceCases, nonPerformanceCases, performanceMeta,
    performanceDashboardComments, changeHistory, rfeData,
    reassignLog, allDashboardData,
  });
})();
