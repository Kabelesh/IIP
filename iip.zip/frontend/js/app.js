/* ================================================================
   App Version — Single Source of Truth
   ================================================================ */
const AppVersion = (() => {
  const MAJOR = 1, MINOR = 0, PATCH = 0;
  const version  = `v${MAJOR}.${MINOR}.${PATCH}`;
  const semver   = `${MAJOR}.${MINOR}.${PATCH}`;
  const date     = "2026-05-12";
  const developer = "Kabelesh K";
  return Object.freeze({ version, semver, MAJOR, MINOR, PATCH, date, developer });
})();

/* API_BASE — resolves to /iip/api when served under /iip/ */
/* API_BASE_V2 — for new v2 endpoints (replace /api with /api/v2) */


/* ============================================================
   js/app.js — IBM Case Intelligence Platform v1.0.0
   Sidebar navigation + KB ingestion pipeline
   ============================================================ */
const App = (() => {

  // On file://, use sessionStorage to avoid the empty-namespace isolation issue.

  // ── Session Persistence & Idle Logout ─────────────────────
  const SESSION_KEY     = "ibm_session_v1";
  const IDLE_MS         = (typeof Config !== "undefined") ? Config.IDLE_TIMEOUT_MS  : 30 * 60 * 1000;
  const IDLE_WARN_MS    = (typeof Config !== "undefined") ? Config.IDLE_WARNING_MS  : 27 * 60 * 1000;
  let   _idleTimer      = null;
  let   _idleWarnTimer  = null;
  let   _warnToast      = null;

  function _saveSession(tabId) {
    try { sessionStorage.setItem(SESSION_KEY, JSON.stringify({ tab: tabId, ts: Date.now() })); } catch(e) {}
  }

  function _loadSession() {
    try {
      const raw = sessionStorage.getItem(SESSION_KEY);
      if (!raw) return null;
      const s = JSON.parse(raw);
      // Session valid if within last 30 min (handles normal refresh)
      if (Date.now() - s.ts < 30 * 60 * 1000) return s;
    } catch(e) {}
    return null;
  }

  function _clearSession() {
    try { sessionStorage.removeItem(SESSION_KEY); } catch(e) {}
  }

  function _dismissWarnToast() {
    if (_warnToast && _warnToast.parentNode) _warnToast.parentNode.removeChild(_warnToast);
    _warnToast = null;
  }

  function _showIdleWarning() {
    _dismissWarnToast();
    const toast = document.createElement("div");
    toast.id = "idle-warn-toast";
    toast.style.cssText = [
      "position:fixed;bottom:80px;right:20px;z-index:var(--z-modal)",
      "background:var(--yellow-text);color:#fff;padding:12px 16px",
      "border-radius:var(--radius-sm);font-size:var(--font-size-md);font-weight:600",
      "box-shadow:0 4px 16px rgba(0,0,0,0.2)",
      "display:flex;align-items:center;gap:10px;max-width:320px"
    ].join(";");
    toast.innerHTML = `
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><circle cx="12" cy="16" r="1" fill="currentColor"/></svg>
      <span>Session expires in 3 minutes due to inactivity.</span>
      <button onclick="this.parentNode.remove()" class="btn btn-xs" style="background:rgba(255,255,255,.25);color:#fff;border-color:transparent">Dismiss</button>
    `;
    document.body.appendChild(toast);
    _warnToast = toast;
  }

  function _resetIdleTimer() {
    clearTimeout(_idleTimer);
    clearTimeout(_idleWarnTimer);
    _dismissWarnToast();
    _idleWarnTimer = setTimeout(_showIdleWarning, IDLE_WARN_MS);
    _idleTimer     = setTimeout(_idleLogout, IDLE_MS);
  }

  function _idleLogout() {
    // For local/file-based sessions (no server), idle logout is disruptive with no
    // security benefit — data is already in localStorage/sessionStorage anyway.
    // Only force logout on http(s) server deployments where a real session matters.
    if (window.location.protocol === "file:") {
      // Just dismiss the warning and reset the timer — no logout on local use
      _dismissWarnToast();
      _resetIdleTimer();
      return;
    }
    _dismissWarnToast();
    _clearSession();
    // Show upload screen again
    const app = document.getElementById("app");
    const upload = document.getElementById("upload-screen");
    if (app) app.classList.add("hidden");
    if (upload) {
      upload.style.display = "";
      // Show idle notice
      const status = document.getElementById("upload-status");
      if (status) {
        status.textContent = "⏱ Session expired due to inactivity. Please reload your file.";
        status.classList.remove("hidden");
        status.style.color = "var(--red)";
      }
    }
    // Reset data
    try { if (typeof Data !== "undefined") Data.loadCases([]); } catch(e) {}
    // Reset admin
    try { if (typeof Admin !== "undefined") Admin.updateHeader(); } catch(e) {}
  }

  function _setupIdleEvents() {
    ["mousemove","keydown","click","scroll"].forEach(ev =>
      document.addEventListener(ev, _resetIdleTimer, { passive: true })
    );
    _resetIdleTimer();
  }

  // ── Production boot: loading skeleton ───────────────────────────────────
  // Shows a full-screen loading state INSTEAD of the upload screen during boot.
  // Only reveals the upload screen if the server confirms there is no data.
  function _bootWithLoadingSkeleton() {
    // Upload screen is hidden by default in HTML — no need to hide it here.
    // Just inject the branded boot loader over the blank page.

    if (!document.getElementById('iip-boot-skeleton-css')) {
      const s = document.createElement('style');
      s.id = 'iip-boot-skeleton-css';
      s.textContent = `
        #iip-boot-loader {
          position:fixed; inset:0;
          background: linear-gradient(160deg, #0a0e1a 0%, #001141 35%, #0f3fa3 75%, #1a56db 100%);
          display:flex; align-items:center; justify-content:center;
          flex-direction:column; gap:16px; z-index:9999;
        }
        #iip-boot-loader .boot-logo {
          display:flex; align-items:center; gap:12px; margin-bottom:8px;
        }
        #iip-boot-loader .boot-alm {
          background:rgba(255,255,255,0.15); color:#fff;
          font-size:13px; font-weight:700; padding:5px 10px;
          border-radius:4px; letter-spacing:.05em;
          border: 1px solid rgba(255,255,255,0.2);
        }
        #iip-boot-loader .boot-title {
          font-size:15px; font-weight:600; color:#fff;
          font-family:var(--font-sans,'IBM Plex Sans',sans-serif);
        }
        #iip-boot-loader .boot-spinner {
          width:32px; height:32px;
          border:3px solid rgba(255,255,255,0.15);
          border-top-color:rgba(255,255,255,0.9);
          border-radius:50%; animation:iip-spin .7s linear infinite;
        }
        #iip-boot-loader .boot-msg {
          font-size:13px; color:rgba(255,255,255,0.55);
          font-family:var(--font-sans,'IBM Plex Sans',sans-serif);
        }
        @keyframes iip-spin { to { transform:rotate(360deg); } }
      `;
      document.head.appendChild(s);
    }

    const loader = document.createElement('div');
    loader.id = 'iip-boot-loader';
    loader.innerHTML = `
      <div class="boot-logo">
        <span class="boot-alm">ALM</span>
        <span class="boot-title">IBM Case Intelligence Platform</span>
      </div>
      <div class="boot-spinner"></div>
      <div class="boot-msg">Loading your data…</div>
    `;
    document.body.appendChild(loader);
  }

  function _hideBootLoader() {
    const loader = document.getElementById('iip-boot-loader');
    if (loader) {
      loader.style.opacity = '0';
      loader.style.transition = 'opacity 0.2s';
      setTimeout(() => loader.remove(), 220);
    }
  }

  function _showUploadScreen() {
    _hideBootLoader();
    const uploadScreen = document.getElementById('upload-screen');
    if (uploadScreen) uploadScreen.style.display = '';
  }
  // ── End boot skeleton ────────────────────────────────────────────────────

  // ── SSE: Server-Sent Events for instant cross-user updates ───────────────
  let _sseConnection = null;
  let _sseReconnectTimer = null;
  let _myUploadVersionSSE = null; // set after this tab uploads so we ignore our own event

  function _setupSSE() {
    if (typeof IIPStore === 'undefined' || IIPStore.isFileMode()) return;
    _connectSSE();
  }

  function _connectSSE() {
    if (_sseConnection) { try { _sseConnection.close(); } catch(e) {} }

    try {
      const _sseBase = (typeof window.__APP_BASE__ === 'string') ? window.__APP_BASE__ : '/';
      const es = new EventSource(_sseBase + 'api/events');
      _sseConnection = es;

      es.addEventListener('connected', () => {
        console.info('[IIP] SSE connected — instant updates active');
        clearTimeout(_sseReconnectTimer);
      });

      es.addEventListener('data-updated', (e) => {
        try {
          const data = JSON.parse(e.data);
          // Skip if this tab was the one that uploaded
          if (_myUploadVersionSSE && data.versionTs === _myUploadVersionSSE) return;
          // Show refresh banner to this user
          if (!_bannerShown) _showRefreshBanner();
        } catch(err) {}
      });

      es.addEventListener('perf-tag-updated', (e) => {
        try {
          const data = JSON.parse(e.data || "{}");
          window.dispatchEvent(new CustomEvent("iip:perf-tag-updated", { detail: data }));
        } catch(_) {}
      });
      es.addEventListener('config-updated', async () => {
        try {
          // Reload config from DB and re-render all dashboards immediately
          if (typeof DynamicConfig !== 'undefined') await DynamicConfig.load();
          try { Contacts.refresh(); }      catch(e) {}
          try { Data.refreshTeamIndex(); } catch(e) {}
          try { if (typeof App !== 'undefined') App.refreshAppIdentity(); } catch(e) {}
          try { if (typeof App !== 'undefined') App.updateHeader(); }       catch(e) {}
          try { if (typeof DashOverview    !== 'undefined') DashOverview.render();    } catch(e) {}
          try { if (typeof DashInfo        !== 'undefined') DashInfo.render();        } catch(e) {}
          try { if (typeof DashMembers     !== 'undefined') DashMembers.render();     } catch(e) {}
          try { if (typeof DashTeam        !== 'undefined') DashTeam.render();        } catch(e) {}
          try { if (typeof DashClosed      !== 'undefined') DashClosed.render();      } catch(e) {}
          try { if (typeof DashCreated     !== 'undefined') DashCreated.render();     } catch(e) {}
          try { if (typeof DashCustomer    !== 'undefined') DashCustomer.render();    } catch(e) {}
          try { if (typeof DashPerformance !== 'undefined') DashPerformance.render(); } catch(e) {}
        } catch(e) {}
      });

      es.onerror = () => {
        es.close();
        _sseConnection = null;
        // Reconnect after 5 seconds
        _sseReconnectTimer = setTimeout(_connectSSE, 5000);
      };
    } catch(e) {
      // SSE not supported — fall back to polling (already in place)
      console.info('[IIP] SSE not available, using polling');
    }
  }
  // ── End SSE ──────────────────────────────────────────────────────────────

  // ── Overview section defaults migration ─────────────────────────────────

  // Resets the three overview section prefs to the correct v1.0.3 defaults
  // (Analysis=open, Perf=closed, Active=open) but only once per app version.
  // After that, user's own toggles are preserved as normal.
  function _migrateOverviewDefaults() {
    const MIGRATION_KEY = 'iip_overview_defaults_v1.0.3';
    try {
      if (localStorage.getItem(MIGRATION_KEY)) return; // already done
      const PD_KEY = 'pd_section_prefs_v1';
      const prefs = JSON.parse(localStorage.getItem(PD_KEY) || '{}');
      prefs['ov-analysis'] = true;   // Detailed Analysis → expanded
      prefs['ov-perf']     = false;  // Performance Cases → collapsed
      prefs['ov-table']    = true;   // Active Cases → expanded
      localStorage.setItem(PD_KEY, JSON.stringify(prefs));
      localStorage.setItem(MIGRATION_KEY, '1');
    } catch(e) {}
  }
  // ── End overview defaults migration ─────────────────────────────────────

  // ── Documentation layout CSS — injected once at boot into <head> ─────────
  // Removes main-content padding when doc tab is active so the fixed-position
  // doc-shell can fill the full viewport correctly without gap on the left.
  function _injectDocLayoutCSS() {
    if (document.getElementById('iip-doc-layout-css')) return;
    const s = document.createElement('style');
    s.id = 'iip-doc-layout-css';
    s.textContent = `
      /* When documentation tab is active:
         - remove padding so doc fills flush
         - position:relative so #doc-overlay (absolute) fills it correctly
         - overflow:hidden so doc handles its own scroll internally */
      .main-content.doc-tab-active {
        padding: 0 !important;
        overflow: hidden !important;
        position: relative !important;
      }
    `;
    document.head.appendChild(s);
  }
  // ── End documentation layout CSS ────────────────────────────────────────


  // ── Lazy-load CSS map: tabId → stylesheets injected on first visit ───────
  // These mirror index.html's CSS_LAZY but are needed when a tab renders via
  // renderTab() on page refresh (no nav click, so index.html's lazyLoadTab
  // never fires and the CSS is never injected).
  const _LAZY_CSS = {
    admin: ['css/features/admin-portal-v3.css', 'css/features/custom-select.css?v=1.0.0'],
  };
  function _injectStylesheet(href) {
    const base = (typeof window.__APP_BASE__ === 'string') ? window.__APP_BASE__ : '';
    if (document.querySelector('link[href*="' + href.split('?')[0] + '"]')) return;
    const l = document.createElement('link');
    l.rel = 'stylesheet';
    l.href = base + href;
    document.head.appendChild(l);
  }

  // ── Lazy-load map: tabId → scripts loaded on first visit ────────────────
  const _LAZY_SCRIPTS = {
    overview:         ['js/dashboards/overview.js?v=1.0.0'],
    team:             ['js/dashboards/team.js?v=1.0.0'],
    members:          ['js/dashboards/members.js?v=1.0.0'],
    closed:           ['js/dashboards/closed.js?v=1.0.0'],
    created:          ['js/dashboards/created.js?v=1.0.0'],
    performance:      ['js/dashboards/performance.js?v=1.0.0'],
    customer:         ['js/dashboards/customer.js?v=1.0.0'],
    investigate:      ['js/modules/data/similarity.js?v=1.0.0','js/dashboards/investigate.js?v=1.0.0'],
    info:             ['js/dashboards/app-tour.js?v=1.0.0','js/dashboards/info.js?v=1.0.0'],
    admin:            ['js/modules/ui/custom-select.js?v=1.0.0','js/modules/admin/admin.js?v=1.0.0','js/modules/api/admin-api-client.js?v=1.0.0','js/modules/api/audit-db-sync.js?v=1.0.0','js/dashboards/admin-dash.js?v=1.0.0'],
    'weekly-tracker': ['js/modules/tracker/tracker-ux.js?v=1.0.0','js/modules/tracker/closed-cases-ux.js?v=1.0.0','js/modules/tracker/wt-render.js?v=1.0.0','js/modules/tracker/wt-save.js?v=1.0.0','js/modules/tracker/wt-cross-week-grayout.js?v=1.0.0','js/dashboards/weekly-tracker.js?v=1.0.0'],
    'rfe-tracking':   ['js/dashboards/rfe-tracking-advanced.js?v=1.0.0'],
    'how-it-works':   ['js/dashboards/how-it-works.js?v=1.0.0'],
    documentation:    ['js/dashboards/documentation.js?v=1.0.0'],
  };
  const _lazyLoading = {};
  function _loadScriptSeq(urls) {
    const key = urls.join('|');
    if (_lazyLoading[key]) return _lazyLoading[key];
    const base = (typeof window.__APP_BASE__ === 'string') ? window.__APP_BASE__ : '';
    const p = urls.reduce((chain, url) =>
      chain.then(() => new Promise((res, rej) => {
        if (document.querySelector('script[src*="' + url.split('?')[0] + '"]')) { res(); return; }
        const s = document.createElement('script');
        s.src = base + url;
        s.onload = res;
        s.onerror = () => rej(new Error('Failed to load: ' + url));
        document.head.appendChild(s);
      })), Promise.resolve());
    _lazyLoading[key] = p;
    return p;
  }
  // ── End lazy-load helpers ────────────────────────────────────────────────

  function getDash(tabId) {
    const map = {
      overview:         typeof DashOverview       !=="undefined"?DashOverview       :null,
      team:             typeof DashTeam           !=="undefined"?DashTeam           :null,
      members:          typeof DashMembers        !=="undefined"?DashMembers        :null,
      closed:           typeof DashClosed         !=="undefined"?DashClosed         :null,
      created:          typeof DashCreated        !=="undefined"?DashCreated         :null,
      performance:      typeof DashPerformance    !=="undefined"?DashPerformance    :null,
      customer:         typeof DashCustomer       !=="undefined"?DashCustomer       :null,
      investigate:      typeof DashInvestigate    !=="undefined"?DashInvestigate    :null,
      info:             typeof DashInfo           !=="undefined"?DashInfo           :null,
      admin:            typeof DashAdmin          !=="undefined"?DashAdmin          :null,
      "weekly-tracker": typeof DashWeeklyTracker  !=="undefined"?DashWeeklyTracker  :null,
      "rfe-tracking":   typeof DashRFEAdvanced    !=="undefined"?DashRFEAdvanced    :null,
      "how-it-works":   typeof HowItWorks        !=="undefined"?HowItWorks        :null,
      documentation:    typeof DashDocumentation !=="undefined"?DashDocumentation :null,
    };
    return map[tabId] || null;
  }

  let _activeTab = "overview";

  async function init() {
    // ── App update check — notify users when new code was deployed ──────────
    // Compares the running version against what was stored on last visit.
    // If they differ, the user just loaded new JS (cache-busted) and gets a toast.
    try {
      const SEEN_KEY = 'iip_last_seen_version';
      const current  = typeof AppVersion !== 'undefined' ? AppVersion.semver : null;
      const lastSeen = localStorage.getItem(SEEN_KEY);
      if (current && lastSeen && lastSeen !== current) {
        // New version — show update toast after app is ready
        setTimeout(() => _showAppUpdateToast(current, lastSeen), 2500);
      }
      if (current) localStorage.setItem(SEEN_KEY, current);
    } catch(e) {}
    // ── End app update check ─────────────────────────────────────────────────
    // v2.0: Hydrate localStorage from PostgreSQL FIRST — ensures all users
    // see the same shared data (RFE, Weekly Tracker, Performance) on every load.
    try {
      const _isAdminSession = sessionStorage.getItem('ibm_admin_session_v1') === '1';
      if (!_isAdminSession && typeof IIPStore !== 'undefined' && IIPStore.hydrateFromDB) {
        await IIPStore.hydrateFromDB();
      }
    } catch(e) { console.warn('[App] DB hydration error (non-fatal):', e.message); }

    // Load dynamic config from server before anything else
    try { await DynamicConfig.load(); Contacts.refresh(); Data.refreshTeamIndex(); } catch(e) {}
    // Restore admin session if the user had logged in before the refresh
    try {
      if (sessionStorage.getItem("ibm_admin_session_v1") === "1") {
        Data.setAdminMode(true);
      }
    } catch(e) {}
    try { Modal.init(); } catch(e) {}
    try { Admin.init(); } catch(e) {}

    // Migrate overview section defaults for v1.0.3:
    // Detailed Analysis → expanded, Performance Cases → collapsed, Active Cases → expanded
    // Only runs once per version — skipped if user has already interacted with sections
    _migrateOverviewDefaults();

    // Inject documentation layout CSS early — must exist before renderTab() adds doc-tab-active
    _injectDocLayoutCSS();

    setupUpload();
    setupSidebarNav();
    setupSidebarCollapse();
    setupReload();
    setupGlobalSearch();
    updateKBBadge();
    _setupIdleEvents();
    _setupDataVersionBanner();

    // ── Restore session on page refresh ──
    const sess = _loadSession();
    if (sess && sess.tab) {
      _pendingSessionTab = sess.tab;
    }
    // Try to restore last active tab from StateManager (production-grade persistence)
    if (typeof StateManager !== "undefined") {
      const lastTab = StateManager.getLastActiveTab();
      if (lastTab) {
        _pendingSessionTab = lastTab;
      }
    }

    // ── Direct URL navigation to /<base>/admin ──────────────────────────────
    // Handles both: visiting /iip/admin directly AND the admin/admin.html redirect
    // which sets sessionStorage 'iip_direct_nav' before bouncing back to the app.
    try {
      const directNav = sessionStorage.getItem('iip_direct_nav');
      if (directNav) {
        sessionStorage.removeItem('iip_direct_nav');
        _pendingSessionTab = directNav;
      } else if (/\/admin\/?$/.test(window.location.pathname)) {
        _pendingSessionTab = 'admin';
      }
    } catch(e) {}
    // ── End direct URL navigation ────────────────────────────────────────────

    // ── URL path takes highest priority — /iip/<tab> overrides session ──────
    // HashRouter activates the tab at +200ms but _showAppWithRows() can fire
    // much later and overwrite it with the saved session tab. Resolving from
    // the URL synchronously here ensures the correct tab renders on data-ready.
    try {
      const _KNOWN_TABS = new Set([
        'overview','members','cases','performance','weekly-tracker','team',
        'closed','created','customer','investigate','rfe-tracking',
        'documentation','how-it-works','info','admin'
      ]);
      let _appBase = '';
      try {
        const b = document.querySelector('base');
        if (b && b.href) _appBase = new URL(b.href).pathname.replace(/\/$/, '');
        else if (typeof window.__APP_BASE__ === 'string') _appBase = new URL(window.__APP_BASE__).pathname.replace(/\/$/, '');
      } catch(e) {}
      const _rel = window.location.pathname.startsWith(_appBase)
        ? window.location.pathname.slice(_appBase.length)
        : window.location.pathname;
      const _urlTab = _rel.replace(/^\//, '').split('/')[0].trim();
      if (_urlTab && _KNOWN_TABS.has(_urlTab)) {
        _pendingSessionTab = _urlTab;
      }
    } catch(e) {}
    // ── End URL path priority ────────────────────────────────────────────────

    // ── URL path takes highest priority — /iip/<tab> overrides session ──────
    // HashRouter activates the tab at +200ms but _showAppWithRows() can fire
    // much later and overwrite it with the saved session tab. Resolving from
    // the URL synchronously here ensures the correct tab renders on data-ready.
    try {
      const _KNOWN_TABS = new Set([
        'overview','members','cases','performance','weekly-tracker','team',
        'closed','created','customer','investigate','rfe-tracking',
        'documentation','how-it-works','info','admin'
      ]);
      let _appBase = '';
      try {
        const b = document.querySelector('base');
        if (b && b.href) _appBase = new URL(b.href).pathname.replace(/\/$/, '');
        else if (typeof window.__APP_BASE__ === 'string') _appBase = new URL(window.__APP_BASE__).pathname.replace(/\/$/, '');
      } catch(e) {}
      const _rel = window.location.pathname.startsWith(_appBase)
        ? window.location.pathname.slice(_appBase.length)
        : window.location.pathname;
      const _urlTab = _rel.replace(/^\//, '').split('/')[0].trim();
      if (_urlTab && _KNOWN_TABS.has(_urlTab)) {
        _pendingSessionTab = _urlTab;
      }
    } catch(e) {}
    // ── End URL path priority ────────────────────────────────────────────────

    // ── Production boot: fetch cases from DB first, show skeleton not upload screen ──
    // Never show the upload screen during boot if DB might have data.
    // Show a loading skeleton instead, reveal upload screen ONLY if DB confirms no data.
    _bootWithLoadingSkeleton();
    _tryRestoreFromServer();
    if (sessionStorage.getItem('ibm_admin_session_v1') !== '1') { _setupSSE(); } // Connect SSE for instant cross-user updates
  }

  let _pendingSessionTab = "overview";

  function updateKBBadge() {
    // KB feature removed — no-op
  }

  /* ── Upload ── */
  function setupUpload() {
    document.getElementById("file-input")?.addEventListener("change", e => { if(e.target.files[0]) loadFile(e.target.files[0]); });
    const dz = document.getElementById("dropzone");
    // F3: Consolidated error helper — uses upload-status (removed upload-file-error)
    const _dzError = (msg) => {
      if(msg) showMsg(msg, "var(--red)");
      else { const el=document.getElementById("upload-status"); if(el) el.classList.add("hidden"); }
    };
    dz?.addEventListener("dragover", e=>{ e.preventDefault(); dz.classList.add("drag-over"); _dzError(""); });
    dz?.addEventListener("dragleave", ()=> dz.classList.remove("drag-over"));
    dz?.addEventListener("drop", e=>{
      e.preventDefault(); dz.classList.remove("drag-over");
      const file = e.dataTransfer.files[0];
      if(!file) return;
      const ext = file.name.split(".").pop().toLowerCase();
      if(!["csv","xlsx","xls","xlsm"].includes(ext)){
        _dzError(`Unsupported file type ".${ext}". Please upload a CSV, XLSX, XLS, or XLSM file.`);
        return;
      }
      _dzError("");
      loadFile(file);
    });
    // F5: Keyboard accessibility for dropzone
    dz?.addEventListener("keydown", e=>{
      if(e.key==="Enter"||e.key===" "){
        e.preventDefault();
        document.getElementById("file-input")?.click();
      }
    });
  }

  function setupReload() {
    const reloadInput = document.getElementById("reload-input");
    if (!reloadInput) return;
    reloadInput.addEventListener("change", e => {
      if (!e.target.files[0]) return;
      _importToast("Loading new file…", false);
      loadFile(e.target.files[0], true);
      e.target.value = ""; // reset so same file can be re-selected
    });
  }

  // ── Data-version banner ────────────────────────────────────────────────────
  // Polls the server every 30 s for a new ibm_data_version_v1 timestamp.
  // When the version changes (someone re-uploaded data) a non-blocking banner
  // appears asking the current user to refresh. The uploader's own tab is
  // excluded: we record the version we just wrote in _myUploadVersion.
  let _myUploadVersion  = null; // set by this tab after a re-upload
  let _knownVersion     = null; // last version seen from server
  let _bannerShown      = false;
  const _BANNER_POLL_MS = 30 * 1000;

  function _setupDataVersionBanner() {
    if (typeof IIPStore === "undefined" || IIPStore.isFileMode()) return;

    _knownVersion = IIPStore.getDataVersionSync();
    let _firstPoll = true;

    setInterval(async () => {
      // Skip polling if SSE is connected — SSE handles updates instantly
      if (_sseConnection && _sseConnection.readyState === EventSource.OPEN) return;

      try {
        const r = await fetch(API_BASE_V2 + "/data-version", { cache: 'no-store' });
        if (!r.ok) return;
        const { version } = await r.json();
        if (!version) return;

        if (_myUploadVersion && version === _myUploadVersion) {
          _knownVersion = version;
          _firstPoll = false;
          return;
        }

        if (_firstPoll) {
          if (_knownVersion === null) {
            _knownVersion = version;
          } else if (version !== _knownVersion && !_bannerShown) {
            _showRefreshBanner();
            _knownVersion = version;
          }
          _firstPoll = false;
          return;
        }

        if (version !== _knownVersion && !_bannerShown) {
          _showRefreshBanner();
        }
        _knownVersion = version;
      } catch(e) {}
    }, _BANNER_POLL_MS);
  }

  // Shows a non-intrusive toast when the user has loaded a new app version
  // (cache-busting ensures they get new JS automatically — this just tells them)
  function _showAppUpdateToast(newVer, oldVer) {
    if (document.getElementById('iip-update-toast')) return;
    const toast = document.createElement('div');
    toast.id = 'iip-update-toast';
    toast.style.cssText = `
      position:fixed; bottom:20px; right:20px;
      display:flex; align-items:center; gap:12px;
      background:var(--bg-ui,#fff); color:var(--text-primary,#161616);
      border:1px solid var(--border-mid,#d0d3da);
      border-left:4px solid var(--green,#198038);
      border-radius:8px; padding:12px 16px;
      box-shadow:0 4px 20px rgba(0,0,0,.14);
      font-family:var(--font-sans,'IBM Plex Sans',sans-serif);
      font-size:13px; z-index:9998; max-width:360px;
      animation:iip-banner-in .25s ease;
    `;
    toast.innerHTML = `
      <span style="color:var(--green,#198038);flex-shrink:0">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
          <polyline points="22 4 12 14.01 9 11.01"/>
        </svg>
      </span>
      <div style="flex:1;line-height:1.45">
        <strong style="display:block;font-weight:600;margin-bottom:2px">App updated to v${newVer}</strong>
        <span style="color:var(--text-secondary,#525252);font-size:12px">New fixes and improvements are loaded. <a href="#documentation" style="color:var(--ibm-blue-50);text-decoration:none;font-weight:500">See what's new →</a></span>
      </div>
      <button onclick="document.getElementById('iip-update-toast').remove()"
        style="flex-shrink:0;background:none;border:none;cursor:pointer;color:var(--text-tertiary);padding:4px;font-size:16px;line-height:1;border-radius:4px">×</button>
    `;
    document.body.appendChild(toast);
    // Auto-dismiss after 10 seconds
    setTimeout(() => toast.remove(), 10000);
  }

  function _showRefreshBanner() {
    if (_bannerShown) return;
    _bannerShown = true;

    // Inject banner styles once
    if (!document.getElementById("iip-refresh-banner-css")) {
      const s = document.createElement("style");
      s.id = "iip-refresh-banner-css";
      s.textContent = `
        #iip-refresh-banner {
          position: fixed; bottom: 20px; left: 50%; transform: translateX(-50%);
          display: flex; align-items: center; gap: 12px;
          background: var(--bg-ui, #fff); color: var(--text-primary, #161616);
          border: 1px solid var(--border-mid, #d0d3da);
          border-left: 4px solid var(--ibm-blue-50, #0f62fe);
          border-radius: 8px; padding: 12px 16px;
          box-shadow: 0 4px 20px rgba(0,0,0,.14);
          font-family: var(--font-sans, 'IBM Plex Sans', sans-serif);
          font-size: 13.5px; z-index: 9999;
          animation: iip-banner-in .25s ease;
          max-width: calc(100vw - 40px);
        }
        @keyframes iip-banner-in {
          from { opacity:0; transform: translateX(-50%) translateY(12px); }
          to   { opacity:1; transform: translateX(-50%) translateY(0); }
        }
        #iip-refresh-banner .iip-banner-ico {
          flex-shrink: 0; color: var(--ibm-blue-50, #0f62fe);
        }
        #iip-refresh-banner .iip-banner-text {
          flex: 1; line-height: 1.45;
        }
        #iip-refresh-banner .iip-banner-text strong {
          display: block; font-weight: 600; margin-bottom: 2px;
        }
        #iip-refresh-banner .iip-banner-text span {
          color: var(--text-secondary, #525252); font-size: 12.5px;
        }
        #iip-refresh-banner .iip-banner-btn {
          flex-shrink: 0; padding: 6px 14px; border-radius: 5px;
          background: var(--ibm-blue-50, #0f62fe); color: #fff;
          border: none; cursor: pointer; font-size: 13px; font-weight: 600;
          font-family: var(--font-sans, 'IBM Plex Sans', sans-serif);
          transition: background .15s;
        }
        #iip-refresh-banner .iip-banner-btn:hover { background: var(--ibm-blue-60, #0043ce); }
        #iip-refresh-banner .iip-banner-dismiss {
          flex-shrink: 0; background: none; border: none; cursor: pointer;
          color: var(--text-tertiary, #8d8d8d); padding: 4px;
          font-size: 16px; line-height: 1; border-radius: 4px;
          transition: color .15s;
        }
        #iip-refresh-banner .iip-banner-dismiss:hover { color: var(--text-primary, #161616); }
      `;
      document.head.appendChild(s);
    }

    const banner = document.createElement("div");
    banner.id = "iip-refresh-banner";
    banner.setAttribute("role", "alert");
    banner.innerHTML = `
      <span class="iip-banner-ico">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/>
          <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>
        </svg>
      </span>
      <div class="iip-banner-text">
        <strong>New data available</strong>
        <span>Someone re-uploaded the case file. Refresh to see the latest data.</span>
      </div>
      <button class="iip-banner-btn" id="iip-banner-refresh-btn">Refresh now</button>
      <button class="iip-banner-dismiss" id="iip-banner-dismiss-btn" title="Dismiss">×</button>
    `;
    document.body.appendChild(banner);

    document.getElementById("iip-banner-refresh-btn").addEventListener("click", () => {
      window.location.reload();
    });
    document.getElementById("iip-banner-dismiss-btn").addEventListener("click", () => {
      banner.remove();
      // Allow re-showing if another upload happens later
      _bannerShown = false;
    });
  }
  // ── End data-version banner ────────────────────────────────────────────────

  function showMsg(msg, color) {
    const el = document.getElementById("upload-status");
    if(el){
      el.innerHTML = Utils.escHtml(msg);
      el.classList.remove("hidden"); el.style.color = color || "";
    }
  }

  // ── Progress bar controller ────────────────────────────────────────────────
  // Stages: 0=Reading, 1=Parsing, 2=Merging, 3=Building, 4=Done
  const _STAGES = ["Reading", "Parsing", "Merging", "Building", "Done"];
  let _progressShown = false;

  function _showProgress(fileName) {
    _progressShown = true;
    const statusEl = document.getElementById("upload-status");
    if (!statusEl) return;

    const shortName = fileName.length > 38 ? fileName.slice(0, 35) + "…" : fileName;
    const stageHtml = _STAGES.map((label, i) => `
      <div class="iip-stage" id="iip-stage-${i}">
        <div class="iip-stage-dot">
          <svg class="iip-check" width="8" height="8" viewBox="0 0 10 10" fill="none">
            <polyline points="1.5,5 4,7.5 8.5,2.5" stroke="#fff" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <div class="iip-stage-dot-inner"></div>
        </div>
        <span class="iip-stage-label">${label}</span>
      </div>`).join("");

    statusEl.innerHTML = `
      <div class="iip-progress-wrap">
        <div class="iip-progress-filename">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
          ${Utils.escHtml(shortName)}
        </div>
        <div class="iip-bar-track">
          <div class="iip-bar-fill iip-bar-indeterminate" id="iip-bar-fill" style="width:8%"></div>
        </div>
        <div class="iip-stages">${stageHtml}</div>
      </div>`;

    statusEl.classList.remove("hidden");
    statusEl.style.color = "";
    // Kick off stage 0 as active
    _setStage(0);
  }

  function _setStage(stageIndex) {
    if (!_progressShown) return;
    const pct = [8, 30, 58, 82, 100];
    const bar = document.getElementById("iip-bar-fill");
    if (bar) {
      bar.classList.remove("iip-bar-indeterminate");
      bar.style.width = pct[stageIndex] + "%";
    }
    _STAGES.forEach((_, i) => {
      const el = document.getElementById("iip-stage-" + i);
      if (!el) return;
      el.classList.remove("active", "done");
      if (i < stageIndex)  el.classList.add("done");
      if (i === stageIndex) el.classList.add("active");
    });
  }

  function _finishProgress() {
    _progressShown = false;
    _setStage(4);
    // Mark all done
    _STAGES.forEach((_, i) => {
      const el = document.getElementById("iip-stage-" + i);
      if (el) { el.classList.remove("active"); el.classList.add("done"); }
    });
    const bar = document.getElementById("iip-bar-fill");
    if (bar) { bar.style.width = "100%"; bar.style.background = "linear-gradient(90deg,#198038,#24a148)"; }
    // Update validation panel footer — now lives in #upload-validation, not #upload-status
    const footer = document.querySelector("#upload-validation #iip-validation-panel > div:last-child");
    if (footer) {
      footer.innerHTML = `
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#198038" stroke-width="2.5" stroke-linecap="round"><polyline points="20 6 9 17 4 12"/></svg>
        <span style="font-size:12px;color:var(--green);font-weight:600">Import complete — opening dashboards</span>`;
      footer.style.background = "var(--green-bg)";
      footer.style.borderTopColor = "rgba(25,128,56,.2)";
    }
  }

  function _hideValidation() {
    const el = document.getElementById("upload-validation");
    if (el) el.style.display = "none";
  }

  function _hideProgress() {
    _progressShown = false;
    const statusEl = document.getElementById("upload-status");
    if (statusEl) { statusEl.innerHTML = ""; statusEl.classList.add("hidden"); }
  }
  // ── End progress bar controller ────────────────────────────────────────────

  function loadFile(file, isReload=false) {
    _showProgress(file.name);
    const ext = file.name.split(".").pop().toLowerCase();
    if(ext==="xlsm"||ext==="xlsx"||ext==="xls") _loadExcel(file,isReload);
    else _loadCSV(file,isReload);
  }

  // ── Import fingerprint helpers ─────────────────────────────────────────────
  // Stores a sorted list of case numbers from each imported file to detect re-uploads.

  // Builds a stable string fingerprint from a sorted list of case numbers
  function _buildFingerprint(caseNumbers) {
    return [...new Set(caseNumbers)].sort().join("|");
  }

  // Returns true if this exact set of case numbers was already imported before
  async function _isDuplicateImport(caseNumbers) {
    const fp = _buildFingerprint(caseNumbers);
    try {
      const base = (typeof window.__APP_BASE__ === "string") ? window.__APP_BASE__ : "";
      const res = await fetch(base + "api/v2/uploads/fingerprint-check?fp=" + encodeURIComponent(fp));
      if (res.ok) { const data = await res.json(); return !!data.found; }
    } catch(e) {}
    return false;
  }

  // Records the fingerprint to the uploads table in DB
  async function _recordImport(caseNumbers, fileName, uploadId) {
    const fp = _buildFingerprint(caseNumbers);
    if (!uploadId) return;
    // Cache filename for _getLatestImportDate
    try { if (fileName) localStorage.setItem("iip_latest_upload_filename", fileName); } catch(e) {}
    try {
      const base = (typeof window.__APP_BASE__ === "string") ? window.__APP_BASE__ : "";
      await fetch(base + "api/v2/uploads/" + uploadId + "/fingerprint", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ fingerprint: fp })
      });
    } catch(e) { console.warn("Fingerprint save failed:", e); }
  }

  // ── Toast notification (standalone, works before app is shown) ──────────────
  function _importToast(msg, isErr, isSuccess) {
    let t = document.getElementById("app-import-toast");
    if (!t) {
      t = document.createElement("div");
      t.id = "app-import-toast";
      t.style.cssText = [
        "position:fixed","bottom:28px","left:50%",
        "transform:translateX(-50%) translateY(12px)",
        "z-index:var(--z-modal)","padding:11px 22px","border-radius:var(--radius-sm)",
        "font-size:13px","font-weight:500","letter-spacing:0.01em",
        "box-shadow:0 4px 20px rgba(0,0,0,.22)",
        "display:flex","align-items:center","gap:8px",
        "pointer-events:none","opacity:0",
        "transition:opacity var(--transition-base), transform var(--transition-base)",
        "font-family:var(--font-sans,'IBM Plex Sans',sans-serif)",
        "max-width:480px","white-space:normal","text-align:center"
      ].join(";");
      document.body.appendChild(t);
    }
    const bg  = isErr ? "var(--red)" : isSuccess ? "var(--green,#198038)" : "var(--ibm-blue-50)";
    const ico = isErr
      ? `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><circle cx="12" cy="16.5" r="1.2" fill="currentColor"/></svg>`
      : `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>`;
    t.style.background = bg; t.style.color = "#fff";
    t.innerHTML = `${ico}<span>${Utils.escHtml(msg)}</span>`;
    requestAnimationFrame(() => requestAnimationFrame(() => {
      t.style.opacity = "1"; t.style.transform = "translateX(-50%) translateY(0)";
    }));
    clearTimeout(t._t);
    t._t = setTimeout(() => {
      t.style.opacity = "0"; t.style.transform = "translateX(-50%) translateY(12px)";
    }, isErr ? 5000 : 3500);
  }

  // ── Merge incoming rows with any previously stored cases ─────────────────────
  // New rows REPLACE matching case numbers; cases not in new file are RETAINED.
  // Returns a Promise — callers must await to get merged array.
  // ── Filename date parser ─────────────────────────────────────────────────────
  // Extracts YYYY-MM-DD from filenames like "IBM_Support_-_Case_listing_export_-_2026-03-13.csv"
  // Returns a Date object or null if no date found.
  function _parseDateFromFilename(filename) {
    const m = (filename || "").match(/(\d{4}-\d{2}-\d{2})/);
    if (!m) return null;
    const d = new Date(m[1]);
    return isNaN(d.getTime()) ? null : d;
  }

  // ── Get the latest file date from uploads table ──────────────────────────
  function _getLatestImportDate() {
    try {
      const cached = localStorage.getItem("iip_latest_upload_filename");
      if (cached) { const d = _parseDateFromFilename(cached); if (d) return d; }
      return null;
    } catch(e) { return null; }
  }

  // ── Check if a file is older than the latest known upload ────
  function _isHistoricalFile(filename) {
    const fileDate = _parseDateFromFilename(filename);
    if (!fileDate) return false;
    const latestDate = _getLatestImportDate();
    if (!latestDate) return false;           // nothing uploaded yet → it IS the latest
    // Strictly older means it's historical
    return fileDate < latestDate;
  }

  // ── Smart merge ─────────────────────────────────────────────────────────────
  // isLatest=true  → new file is authoritative (IBM export = source of truth).
  //                  Cases NOT in the new file are dropped — they've been closed.
  //                  Admin override flags are carried forward.
  // isLatest=false → additive (historical file). Only adds unseen cases.
  const _mergeWithStored = async function(newRows, isLatest = true) {
    try {
      const stored = await IIPStore.getCases();
      if (!stored || !stored.length) return newRows;

      const storedByCase = {};
      stored.forEach(r => { const cn = r["Case Number"]; if (cn) storedByCase[cn] = r; });

      if (isLatest) {
        // New file wins — carry forward only admin override flags
        return newRows.map(r => {
          const cn = r["Case Number"];
          const prev = cn ? storedByCase[cn] : null;
          if (!prev) return r;
          const carry = {};
          if (prev._ownerOverride) { carry._ownerOverride = true; carry.Owner = prev.Owner; }
          if (prev._hasOverride)   carry._hasOverride = true;
          return Object.keys(carry).length ? { ...r, ...carry } : r;
        });
      } else {
        // Additive — append only cases not already stored
        const merged = [...stored];
        newRows.forEach(r => {
          const cn = r["Case Number"];
          if (cn && !storedByCase[cn]) merged.push(r);
        });
        return merged;
      }
    } catch(e) {
      console.warn("[IIP] _mergeWithStored error:", e);
      return newRows;
    }
  }


  // Takes closed cases from the file, slots them by Closed Date → CW,
  // and merges into localStorage tracker data. Does NOT touch main cases table.
  function _ingestHistoricalIntoTracker(rows, fileName) {
    const CLOSED_STATUSES = ["Closed by IBM", "Closed by Client", "Closed - Archived", "Cancelled"];
    const STORE_PREFIX = "ibm_wtracker_";

    const _ldy = yr => { try { return JSON.parse(localStorage.getItem(STORE_PREFIX + yr) || "{}"); } catch(e) { return {}; } };
    const _svy = (yr, d) => { try { localStorage.setItem(STORE_PREFIX + yr, JSON.stringify(d)); } catch(e) {} };
    const _isoWeek = d => {
      const yr = d.getFullYear();
      const jan1 = new Date(yr, 0, 1);
      const jan1Day = jan1.getDay();
      const w1Sun = new Date(jan1);
      w1Sun.setDate(jan1.getDate() - jan1Day);
      const target = new Date(yr, d.getMonth(), d.getDate());
      if (target < w1Sun) return _isoWeek(new Date(yr - 1, 11, 31));
      const wk = Math.floor((target - w1Sun) / (7 * 86400000)) + 1;
      return "CW" + String(wk).padStart(2, "0");
    };

    let inserted = 0;
    let skipped  = 0;

    rows.forEach(r => {
      const status = r.Status || "";
      if (!CLOSED_STATUSES.some(s => status.includes(s))) return;

      const closedRaw = r["Closed Date"] || r.ClosedDate || r["Solution date"] || "";
      if (!closedRaw) return;
      const closedDate = new Date(closedRaw);
      if (isNaN(closedDate.getTime())) return;

      const year = closedDate.getFullYear();
      const cwKey = _isoWeek(closedDate);
      const cn = r["Case Number"] || "";
      if (!cn) return;

      const yearData = _ldy(year);
      if (!yearData[cwKey]) yearData[cwKey] = [];

      // Skip if already in tracker (dedup by caseNumber)
      const alreadyExists = yearData[cwKey].some(e => e.caseNumber === cn);
      if (alreadyExists) { skipped++; return; }

      yearData[cwKey].push({
        id:             cn + "_" + cwKey,
        caseNumber:     cn,
        owner:          r.Owner || "",
        title:          r.Title || "",
        product:        r.Product || "",
        severity:       String(r.Severity || ""),
        status:         status,
        age:            r.Age || "",
        closedDate:     closedRaw,
        comments:       "",
        category:       "",
        customerNumber: r["Customer number"] || "",
        created:        r.Created || "",
        solutionDate:   r["Solution date"] || "",
        _fromHistorical: true,
      });

      // Keep CW sorted by case number for consistency
      yearData[cwKey].sort((a, b) => a.caseNumber.localeCompare(b.caseNumber));
      _svy(year, yearData);
      inserted++;
    });

    return { inserted, skipped };
  }

  /* ══════════════════════════════════════════════════════════════════
     COLUMN VALIDATION — runs after parse, before merge/load
     Produces an inline summary: which fields found, which missing,
     how many cases detected. Non-blocking — import always continues.
     ══════════════════════════════════════════════════════════════════ */
  const _REQUIRED_COLS   = ["Case Number", "Title", "Owner", "Status", "Severity"];
  const _IMPORTANT_COLS  = ["Created", "Product", "Age"];
  const _OPTIONAL_COLS   = ["Closed Date", "Customer number"];

  function _validateRows(rows, fileName) {
    if (!rows || !rows.length) return;
    const firstRow = rows[0];
    const presentKeys = new Set(Object.keys(firstRow));

    const required  = _REQUIRED_COLS.map(k  => ({ col: k,  present: presentKeys.has(k),  tier: "required"  }));
    const important = _IMPORTANT_COLS.map(k => ({ col: k,  present: presentKeys.has(k),  tier: "important" }));
    const optional  = _OPTIONAL_COLS.map(k  => ({ col: k,  present: presentKeys.has(k),  tier: "optional"  }));
    const all = [...required, ...important, ...optional];

    const missingRequired  = required.filter(c  => !c.present);
    const missingImportant = important.filter(c => !c.present);
    const caseCount        = rows.length;

    // Severity breakdown
    const sevCounts = { 1: 0, 2: 0, 3: 0, 4: 0, other: 0 };
    rows.forEach(r => {
      const s = String(r.Severity || "").trim().charAt(0);
      if ("1234".includes(s)) sevCounts[s]++;
      else sevCounts.other++;
    });

    // Owner count
    const owners = new Set(rows.map(r => r.Owner).filter(Boolean));

    // Status breakdown (top 4)
    const statusMap = {};
    rows.forEach(r => { const s = r.Status || "Unknown"; statusMap[s] = (statusMap[s] || 0) + 1; });
    const topStatuses = Object.entries(statusMap).sort((a, b) => b[1] - a[1]).slice(0, 4);

    // Render into dedicated #upload-validation — never overwrites #upload-status (progress bar)
    const statusEl = document.getElementById("upload-validation");
    if (!statusEl) return;

    const colRow = (item) => {
      const icon = item.present
        ? `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#198038" stroke-width="2.5" stroke-linecap="round"><polyline points="20 6 9 17 4 12"/></svg>`
        : (item.tier === "required"
            ? `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#da1e28" stroke-width="2.5" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>`
            : `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#a67800" stroke-width="2.5" stroke-linecap="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>`);
      const labelColor = item.present ? "var(--text-primary)" : (item.tier === "required" ? "var(--red)" : "var(--yellow-text)");
      const note = !item.present
        ? (item.tier === "required"  ? " — required for core features"
          : item.tier === "important" ? " — needed for date charts"
          : " — some charts may be limited")
        : "";
      return `<div style="display:flex;align-items:center;gap:7px;padding:3px 0">
        ${icon}
        <span style="font-size:12px;color:${labelColor};font-family:var(--font-mono)">${item.col}</span>
        <span style="font-size:11px;color:var(--text-tertiary)">${note}</span>
      </div>`;
    };

    const sevBar = (n, label, color) => {
      if (!n) return "";
      const pct = Math.round((n / caseCount) * 100);
      return `<div style="display:flex;align-items:center;gap:6px;margin-bottom:3px">
        <span style="font-size:10px;font-weight:700;color:${color};font-family:var(--font-mono);width:18px;flex-shrink:0">${label}</span>
        <div style="flex:1;height:6px;background:var(--border-subtle);border-radius:3px;overflow:hidden">
          <div style="width:${pct}%;height:100%;background:${color};border-radius:3px;transition:width 0.4s ease"></div>
        </div>
        <span style="font-size:11px;color:var(--text-tertiary);font-family:var(--font-mono);width:28px;text-align:right">${n}</span>
      </div>`;
    };

    const hasIssues = missingRequired.length > 0 || missingImportant.length > 0;
    const headerColor = missingRequired.length > 0 ? "var(--red)" : missingImportant.length > 0 ? "var(--yellow-text)" : "var(--green)";
    const headerIcon  = missingRequired.length > 0
      ? `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>`
      : `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="20 6 9 17 4 12"/></svg>`;
    const headerText  = missingRequired.length > 0
      ? `${caseCount} cases loaded — ${missingRequired.length} required column${missingRequired.length > 1 ? "s" : ""} missing`
      : missingImportant.length > 0
      ? `${caseCount} cases loaded — some chart columns missing`
      : `${caseCount} cases — all columns detected`;

    const shortName = fileName.length > 42 ? fileName.slice(0, 39) + "…" : fileName;

    statusEl.innerHTML = `
      <div id="iip-validation-panel" style="
        background:var(--bg-ui);border:1px solid var(--border-mid);border-radius:var(--radius-md);
        overflow:hidden;font-family:var(--font-sans);animation:iip-val-in 0.22s ease;
      ">
        <style>@keyframes iip-val-in{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}</style>

        <!-- Header bar -->
        <div style="display:flex;align-items:center;justify-content:space-between;padding:10px 14px;background:var(--bg-layer);border-bottom:1px solid var(--border-subtle);gap:10px">
          <div style="display:flex;align-items:center;gap:8px;flex:1;min-width:0">
            <span style="color:${headerColor};flex-shrink:0">${headerIcon}</span>
            <span style="font-size:13px;font-weight:600;color:var(--text-primary)">${headerText}</span>
          </div>
          <span style="font-size:11px;color:var(--text-tertiary);font-family:var(--font-mono);flex-shrink:0;overflow:hidden;text-overflow:ellipsis;max-width:180px" title="${shortName}">${shortName}</span>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:0">

          <!-- Left: columns -->
          <div style="padding:12px 14px;border-right:1px solid var(--border-subtle)">
            <div style="font-size:10px;font-weight:600;letter-spacing:0.06em;text-transform:uppercase;color:var(--text-tertiary);margin-bottom:8px">Columns detected</div>
            ${all.map(colRow).join("")}
          </div>

          <!-- Right: quick stats -->
          <div style="padding:12px 14px">
            <div style="font-size:10px;font-weight:600;letter-spacing:0.06em;text-transform:uppercase;color:var(--text-tertiary);margin-bottom:8px">Case snapshot</div>

            <div style="display:flex;gap:16px;margin-bottom:12px">
              <div>
                <div style="font-size:22px;font-weight:700;font-family:var(--font-mono);color:var(--text-primary);line-height:1">${caseCount}</div>
                <div style="font-size:10px;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:0.05em">Cases</div>
              </div>
              <div>
                <div style="font-size:22px;font-weight:700;font-family:var(--font-mono);color:var(--text-primary);line-height:1">${owners.size}</div>
                <div style="font-size:10px;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:0.05em">Owners</div>
              </div>
            </div>

            <div style="margin-bottom:10px">
              ${sevBar(sevCounts[1], "S1", "#da1e28")}
              ${sevBar(sevCounts[2], "S2", "#ff832b")}
              ${sevBar(sevCounts[3], "S3", "#a67800")}
              ${sevBar(sevCounts[4], "S4", "#9ca3af")}
            </div>

            <div style="border-top:1px solid var(--border-subtle);padding-top:8px">
              ${topStatuses.map(([status, count]) => `
                <div style="display:flex;justify-content:space-between;font-size:11px;padding:2px 0">
                  <span style="color:var(--text-secondary);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:140px">${status}</span>
                  <span style="font-family:var(--font-mono);font-weight:600;color:var(--text-primary);flex-shrink:0;margin-left:8px">${count}</span>
                </div>`).join("")}
            </div>
          </div>

        </div>

        <!-- Footer: importing notice -->
        <div style="padding:8px 14px;background:var(--ibm-blue-10);border-top:1px solid rgba(15,98,254,.15);display:flex;align-items:center;gap:8px">
          <div class="upload-spinner" style="flex-shrink:0"></div>
          <span style="font-size:12px;color:var(--ibm-blue-50);font-weight:500">Loading dashboards…</span>
        </div>
      </div>`;

    statusEl.style.display = "block";
  }

  function _loadCSV(file, isReload) {
    const r = new FileReader();
    r.onerror = () => { _hideProgress(); showMsg("Failed to read file", "var(--red)"); };
    r.onload = async ev => {
      try {
        _setStage(1); // Parsing
        const rows = Utils.parseCSV(ev.target.result);
        if(!rows.length){ _hideProgress(); showMsg("No data found","var(--red)"); return; }
        const caseNums = rows.map(r => r["Case Number"]).filter(Boolean);

        // ── Validation summary — shown before dashboards load ──────────────────
        try { _validateRows(rows, file.name); } catch(e) {}

        // ── Determine if this file is historical ─────────────────────────────
        const _isHistorical = _isHistoricalFile(file.name);

        if (_isHistorical) {
          // ── HISTORICAL FILE: only update Weekly Tracker, skip main table ──
          _setStage(2); // Merging (tracker only)
          const { inserted, skipped } = _ingestHistoricalIntoTracker(rows, file.name);
          await _recordImport(caseNums, file.name);
          _setStage(3); // Building
          _hideProgress();
          _importToast(
            `📅 Historical file detected — ${inserted} closed case${inserted !== 1 ? "s" : ""} added to Weekly Tracker` +
            (skipped > 0 ? `, ${skipped} already existed` : "") + ".",
            false
          );
          // Refresh tracker view if visible
          setTimeout(() => {
            try { if (typeof DashWeeklyTracker !== "undefined") DashWeeklyTracker.render(); } catch(e) {}
          }, 300);
          return;
        }

        // ── LATEST FILE: upload to DB, then re-fetch complete dataset ─────────
        // FIX: old code used client-side merge which dropped historical DB cases.
        // DB UPSERT never deletes old cases — re-fetching shows the full dataset.
        _setStage(2); // Uploading to DB
        let _dbLoadDone = false;
        if (!IIPStore.isFileMode()) {
          try {
            const _upFd = new FormData();
            _upFd.append('file', file, file.name);
            const _upRes  = await fetch(API_BASE_V2 + '/upload/cases', { method: 'POST', body: _upFd });
            const _upData = await _upRes.json();
            const _uid = _upData.upload_id || _upData.id;
            if (_uid && caseNums.length) await _recordImport(caseNums, file.name, _uid);
            // Re-fetch ALL cases from DB — preserves every historical case
            _setStage(3); // Building
            const _dbRes = await fetch(API_BASE_V2 + '/cases', { cache: 'no-store' });
            if (_dbRes.ok) {
              const _dbData = await _dbRes.json();
              if (_dbData.cases && _dbData.cases.length) {
                const _norm = _dbData.cases.map(c => ({
                  'Case Number':    c.case_number     || '',
                  'Title':          c.title           || '',
                  'Owner':          c.owner_name      || '',
                  'Status':         c.status          || '',
                  'Severity':       c.severity        || '',
                  'Age':            c.age_days != null ? String(c.age_days) : '',
                  'Product':        c.product         || '',
                  'Customer number':c.customer_number || '',
                  'Created':        c.created_date    || '',
                  'Updated':        c.updated_date    || '',
                  'Closed Date':    c.closed_date     || '',
                  'Country':        c.country_name    || '',
                  'Is Active':      c.is_active != null ? c.is_active : true,
                }));
                try { sessionStorage.setItem('ibm_cases_raw_v1', JSON.stringify(_norm)); } catch(e) {}
                Data.loadCases(_norm, _dbData.latest_upload_id)
                  .then(() => _onLoaded(_norm, isReload, null))
                  .catch(() => _onLoaded(_norm, isReload, null));
                _dbLoadDone = true;
              }
            }
          } catch(_e) { console.warn('[IIP] DB-first CSV upload failed, falling back:', _e); }
        }
        if (!_dbLoadDone) {
          // Fallback: client-side merge (file:// mode or DB unavailable)
          const merged = await _mergeWithStored(rows, true);
          await _recordImport(caseNums, file.name);
          _setStage(3); // Building
          Data.loadCases(merged).then(() => _onLoaded(merged, isReload, file)).catch(() => _onLoaded(merged, isReload, file));
        }
      } catch(e){ _hideProgress(); showMsg("CSV error: "+e.message,"var(--red)"); }
    };
    r.readAsText(file);
  }

  // ── Weekly Closed Cases XLSM detection ────────────────────────────────────
  // Returns true if the workbook looks like a "Weekly_Closed_Cases" file:
  //   - At least 3 sheet names match /^CW\d{2}/i
  //   - At least one of those sheets has a "Comments" or "Category" column
  function _isWeeklyClosedCasesXlsm(wb) {
    const cwSheets = wb.SheetNames.filter(n => /^CW\d{2}/i.test(n.trim()));
    if (cwSheets.length < 3) return false;
    for (const sheetName of cwSheets.slice(0, 3)) {
      const ws = wb.Sheets[sheetName];
      const json = XLSX.utils.sheet_to_json(ws, { defval: "", header: 1 });
      if (!json.length) continue;
      const headerRow = json[0].map(h => String(h || "").toLowerCase().trim());
      if (headerRow.some(h => h === "comments" || h === "comment" || h === "category")) return true;
    }
    return false;
  }

  // ── Populate Weekly Tracker from Weekly_Closed_Cases XLSM ──────────────────
  // Reads all CW sheets, builds tracker rows (preserving Comments + Category),
  // merges them into localStorage, and returns a commentMap for server sync.
  // Q3: only non-empty comments are collected — blank cells leave existing untouched.
  function _extractWeeklyTrackerRows(wb) {
    const _cnPat = (typeof DynamicConfig !== "undefined") ? DynamicConfig.caseNumberPattern() : /\S+/;
    const STORE_PREFIX = "ibm_wtracker_";
    const _ldy = yr => { try { return JSON.parse(localStorage.getItem(STORE_PREFIX + yr) || "{}"); } catch(e) { return {}; } };
    const _svy = (yr, d) => { try { localStorage.setItem(STORE_PREFIX + yr, JSON.stringify(d)); } catch(e) {} };

    const trackerByYearWeek = {};
    const commentMap = {};
    let totalImported = 0;

    wb.SheetNames.forEach(sheetName => {
      const cwMatch = sheetName.trim().match(/^(CW\d{2})/i);
      if (!cwMatch) return;
      const cwKey = cwMatch[1].toUpperCase();

      const ws = wb.Sheets[sheetName];
      const json = XLSX.utils.sheet_to_json(ws, { defval: "" });
      if (!json.length) return;

      json.forEach(raw => {
        const out = {};
        Object.keys(raw).forEach(k => { out[k.trim()] = String(raw[k] ?? "").trim(); });

        const norm = {};
        Object.keys(out).forEach(k => { norm[k.toLowerCase().replace(/[^a-z0-9]/g, "")] = out[k]; });

        let cn    = norm["casenumber"] || norm["caseno"] || "";
        let owner = norm["caseowner"]  || norm["owner"]  || "";

        // Handle 2025 column swap
        if (!_cnPat.test(cn) && _cnPat.test(owner)) { const tmp = owner; owner = cn; cn = tmp; }
        if (!cn || !_cnPat.test(cn)) return;

        const comments = norm["comments"] || norm["comment"] || norm["update"] || "";
        const category = norm["category"] || "";
        const closedRaw = norm["closeddate"] || norm["closed"] || "";

        let year = new Date().getFullYear();
        if (closedRaw) { const d = new Date(closedRaw); if (!isNaN(d)) year = d.getFullYear(); }

        const yKey = year + "_" + cwKey;
        if (!trackerByYearWeek[yKey]) trackerByYearWeek[yKey] = { year, cwKey, rows: [] };

        if (!trackerByYearWeek[yKey].rows.some(r => r.caseNumber === cn)) {
          trackerByYearWeek[yKey].rows.push({
            id: cn + "_" + cwKey,
            caseNumber: cn, owner,
            title:    norm["title"]    || "",
            product:  norm["product"]  || "",
            severity: norm["severity"] || "",
            status:   norm["status"]   || "",
            age:      norm["age"]      || "",
            closedDate: closedRaw,
            comments: "",   // comments live server-side; never in localStorage
            category,
            customerNumber: norm["customernumber"] || "",
            created: "", solutionDate: ""
          });
          totalImported++;
        }

        // Q3: only collect non-empty comments so blank cells never overwrite existing data
        if (comments) commentMap[cn] = comments;
      });
    });

    // Merge into tracker localStorage
    Object.values(trackerByYearWeek).forEach(({ year, cwKey, rows }) => {
      if (!rows.length) return;
      const yearData = _ldy(year);
      const existing = yearData[cwKey] || [];
      const byCase = {};
      existing.forEach(r => { byCase[r.caseNumber] = r; });

      const merged = rows.map(r => {
        const s = byCase[r.caseNumber] || {};
        return { ...r, category: r.category || s.category || "", availability: s.availability || "", comments: "" };
      });
      existing.forEach(s => { if (!merged.find(m => m.caseNumber === s.caseNumber)) merged.push(s); });

      const seen = new Set();
      yearData[cwKey] = merged.filter(r => { if (seen.has(r.caseNumber)) return false; seen.add(r.caseNumber); return true; });
      _svy(year, yearData);
    });

    return { totalImported, commentMap };
  }

  function _loadExcel(file, isReload) {
    if(typeof XLSX==="undefined"){_hideProgress(); showMsg("Excel library not loaded","var(--red)");return;}
    const r = new FileReader();
    r.onerror = () => { _hideProgress(); showMsg("Failed to read file","var(--red)"); };
    r.onload = async ev => {
      try {
        _setStage(1); // Parsing
        const wb = XLSX.read(new Uint8Array(ev.target.result),{type:"array"});

        // ── Q1: Weekly Closed Cases XLSM → also populate the Weekly Tracker ──
        // When the file is a Weekly_Closed_Cases workbook (sheets named CW01…CW53
        // with Comments/Category columns), import it as normal cases AND populate
        // the tracker directly so Comments and Category are preserved from day one.
        if (_isWeeklyClosedCasesXlsm(wb)) {
          const { totalImported, commentMap } = _extractWeeklyTrackerRows(wb);
          if (totalImported > 0) {
            const _cmapLen = Object.keys(commentMap).length;
            setTimeout(async () => {
              try {
                if (typeof DashWeeklyTracker !== "undefined" && DashWeeklyTracker._mergeServerComments) {
                  // Merge non-empty comments to server store.
                  // Q3: blank cells in the Excel are NOT in commentMap, so existing server
                  // comments are never touched — only new / updated values are written.
                  if (_cmapLen > 0) {
                    await DashWeeklyTracker._ensureServerCommentsLoaded();
                    await DashWeeklyTracker._mergeServerComments(commentMap);
                  }
                  DashWeeklyTracker.render();
                }
                _importToast(
                  "✅ Weekly Tracker: " + totalImported + " case" + (totalImported !== 1 ? "s" : "") +
                  " imported" + (_cmapLen > 0 ? ", " + _cmapLen + " comment" + (_cmapLen !== 1 ? "s" : "") + " saved." : "."),
                  false
                );
              } catch(e) { console.warn("Weekly Tracker XLSM population error:", e); }
            }, 650);
          }
        }

        const allRows = [];

        wb.SheetNames.forEach(sheetName => {
          const ws = wb.Sheets[sheetName];
          const json = XLSX.utils.sheet_to_json(ws,{defval:""});
          if(!json.length) return;

          json.forEach(raw => {
            const out = {};
            Object.keys(raw).forEach(k => { out[k.trim()] = String(raw[k]??"").trim(); });

            // Normalize field names
            const row = {};
            Object.keys(out).forEach(k => {
              const kl = k.toLowerCase();
              if(kl==="case number"||kl==="casenumber") row["Case Number"]=out[k];
              else if(kl==="case owner"||kl==="caseowner") row["Owner"]=out[k];
              else if(kl==="title") row["Title"]=out[k];
              else if(kl==="product") row["Product"]=out[k];
              else if(kl==="severity") row["Severity"]=out[k];
              else if(kl==="status") row["Status"]=out[k];
              else if(kl==="age") row["Age"]=out[k];
              else if(kl==="closed date"||kl==="closeddate") row["Closed Date"]=out[k];
              else if(kl==="comments"||kl==="comment") row["Comments"]=out[k];
              else if(kl==="customer number"||kl==="customer no") row["Customer number"]=out[k];
              else if(kl==="category") row["Category"]=out[k];
              else row[k]=out[k];
            });

            // Fix 2025 column swap (Case Owner / Case Number reversed)
            const _swapPat=(typeof DynamicConfig!=="undefined")?DynamicConfig.caseNumberPattern():/^TS\d{6,}/i;
            if(row["Owner"]&&_swapPat.test(row["Owner"])){
              const tmp=row["Owner"]; row["Owner"]=row["Case Number"]||""; row["Case Number"]=tmp;
            }

            // Accept any non-empty Case Number when DynamicConfig not loaded
            const _cnPat = (typeof DynamicConfig!=="undefined") ? DynamicConfig.caseNumberPattern() : /\S+/;
            if(row["Case Number"]&&_cnPat.test(row["Case Number"])) allRows.push(row);
          });
        });

        if(!allRows.length){ _hideProgress(); showMsg("No valid cases found","var(--red)"); return; }

        // Deduplicate within this file (same case on multiple sheets)
        const seen=new Set(), unique=[];
        allRows.forEach(r=>{ const cn=r["Case Number"]; if(!seen.has(cn)){seen.add(cn);unique.push(r);} });

        // ── Validation summary — shown before dashboards load ──────────────────
        try { _validateRows(unique, file.name); } catch(e) {}

        const caseNums = unique.map(r => r["Case Number"]).filter(Boolean);

        // ── Determine if this file is historical ─────────────────────────────
        const _isHistorical = _isHistoricalFile(file.name);

        if (_isHistorical) {
          // ── HISTORICAL FILE: only update Weekly Tracker, skip main table ──
          _setStage(2);
          const { inserted, skipped } = _ingestHistoricalIntoTracker(unique, file.name);
          await _recordImport(caseNums, file.name);
          _setStage(3);
          _hideProgress();
          _importToast(
            `📅 Historical file detected — ${inserted} closed case${inserted !== 1 ? "s" : ""} added to Weekly Tracker` +
            (skipped > 0 ? `, ${skipped} already existed` : "") + ".",
            false
          );
          setTimeout(() => {
            try { if (typeof DashWeeklyTracker !== "undefined") DashWeeklyTracker.render(); } catch(e) {}
          }, 300);
          return;
        }

        // ── LATEST FILE: merge into main table (upsert by Case Number) ───────
        _setStage(2); // Merging
        const merged = await _mergeWithStored(unique, true); // latest file wins
        await _recordImport(caseNums, file.name);

        _setStage(3); // Building
        // FIX: await the loadCases Promise so _applyPersisted() finishes before
        // renderTab()/_renderCharts() fires — prevents chart race condition on first load.
        Data.loadCases(merged).then(() => _onLoaded(merged, isReload, file)).catch(() => _onLoaded(merged, isReload, file));
      } catch(e){ _hideProgress(); console.error(e); showMsg("Excel error: "+e.message,"var(--red)"); }
    };
    r.readAsArrayBuffer(file);
  }

  /* ── Post-load pipeline ── */
  function _onLoaded(rows, isReload, sourceFile) {
    // Always re-apply DynamicConfig so Admin Portal settings override any imported Excel data
    try { Contacts.refresh(); Data.refreshTeamIndex(); } catch(e) {}

    // ── Fool-proof Customer Products restore ────────────────────────────
    // The authoritative source of "what the admin saved" is the Audit & Change History
    // (ibm_tracker_persist_v1). If the most recent "Customer Products" history entry
    // disagrees with what DynamicConfig currently holds, restore from history.
    try {
      if (typeof DynamicConfig !== "undefined" && typeof Data !== "undefined") {
        const history = Data.changeHistory();
        const lastProductEntry = history.find(h => h.caseNumber === "CONFIG" && h.field === "Customer Products");
        if (lastProductEntry) {
          // newValue is like "5 products — Prod A, Prod B …" — we stored the full list separately
          // Check if DynamicConfig raw has a savedProductList (written by save handler below)
          const raw = DynamicConfig.getRaw();
          const dcCount = Array.isArray(raw.customerProducts) ? raw.customerProducts.length : 0;
          // The history newValue format is: "<N> products"
          const histCount = parseInt((lastProductEntry.newValue || "").match(/^(\d+)/)?.[1] || "0", 10);
          if (histCount > 0 && dcCount !== histCount && Array.isArray(raw._savedProductList) && raw._savedProductList.length === histCount) {
            // DynamicConfig has wrong count — restore the saved list silently
            DynamicConfig.save({ customerProducts: raw._savedProductList }).catch(() => {});
          }
        }
      }
    } catch(e) {}
    // ── End fool-proof restore ───────────────────────────────────────────
    // Heal any stale owner names in Weekly Tracker localStorage using current DC name aliases
    try {
      if (typeof DashWeeklyTracker !== "undefined" && typeof DynamicConfig !== "undefined") {
        const aliases = DynamicConfig.nameAliases ? DynamicConfig.nameAliases() : {};
        // Build a renameMap from aliases: only entries where the key != the value (real renames)
        const renameMap = {};
        Object.entries(aliases).forEach(([k, v]) => {
          // Capitalise key to match stored owner format
          const storedKey = k.replace(/\b\w/g, c => c.toUpperCase());
          if (storedKey !== v) renameMap[storedKey] = v;
        });
        if (Object.keys(renameMap).length) DashWeeklyTracker.renameInTracker(renameMap);
      }
    } catch(e) {}
    if(!isReload) { _finishProgress(); setTimeout(() => showApp(), 350); }
    else { _finishProgress(); setTimeout(() => { _hideProgress(); _hideValidation(); try { if (typeof V6 !== 'undefined') V6.hideProgress(); } catch(e) {} updateHeader(); renderActive(); _importToast("Data uploaded successfully ✓", false, true); }, 600); }
    // Save cases to server so refresh restores them
    _saveCasesToServer(rows, isReload, sourceFile);
    // Enrich weekly tracker with closed cases by week
    setTimeout(() => {
      try { if(typeof DashWeeklyTracker!=="undefined") DashWeeklyTracker.enrichFromCases(rows); } catch(e) {}
    }, 400);
    // (KB ingestion removed)
  }

  function _saveCasesToServer(rows, isReload, sourceFile) {
    // Write to sessionStorage immediately for instant same-tab access
    try { sessionStorage.setItem('ibm_cases_raw_v1', JSON.stringify(rows)); } catch(e) {}

    // Upload raw CSV to DB via /upload/cases (no admin token needed)
    if (!IIPStore.isFileMode() && sourceFile && sourceFile.name && sourceFile.name.toLowerCase().endsWith('.csv')) {
      const _fd = new FormData();
      _fd.append('file', sourceFile, sourceFile.name);
      const _caseNums = rows.map(r => r['Case Number'] || r.case_number || '').filter(Boolean);
      fetch(API_BASE_V2 + '/upload/cases', { method: 'POST', body: _fd })
        .then(r => r.json())
        .then(result => {
          if (result.status === 'processing') console.info('[IIP] CSV queued for DB:', result.filename);
          else if (result.status === 'skipped') console.info('[IIP] CSV already in DB:', result.upload_id);
          else console.info('[IIP] upload/cases:', result);
          // Save case fingerprint to uploads table
          const _uid = result.upload_id || result.id;
          if (_uid && _caseNums.length) _recordImport(_caseNums, sourceFile.name, _uid);
        }).catch(e => console.warn('[IIP] upload/cases failed:', e.message));
    }

    // Archive cases permanently for Investigation page
    try { if (typeof DashInvestigate !== 'undefined') DashInvestigate.archiveCases(rows); } catch(e) {}
  }

  function _showAppWithRows(rows, uploadId) {
    // Re-apply DC config (contacts, team index)
    try { Contacts.refresh(); Data.refreshTeamIndex(); } catch(e) {}

    // Heal stale owner names in Weekly Tracker localStorage using current DC name aliases.
    // This runs on EVERY restore (refresh, session restore) so stale names are always fixed.
    try {
      if (typeof DashWeeklyTracker !== "undefined" && typeof DynamicConfig !== "undefined") {
        const aliases = DynamicConfig.nameAliases ? DynamicConfig.nameAliases() : {};
        const renameMap = {};
        Object.entries(aliases).forEach(([k, v]) => {
          const storedKey = k.replace(/\b\w/g, c => c.toUpperCase());
          if (storedKey !== v) renameMap[storedKey] = v;
        });
        if (Object.keys(renameMap).length) DashWeeklyTracker.renameInTracker(renameMap);
      }
    } catch(e) {}

    Data.loadCases(rows, uploadId).then(() => {
      const upload = document.getElementById("upload-screen");
      const app    = document.getElementById("app");
      if (upload) upload.style.display = "none";
      if (app)    app.classList.remove("hidden");
      updateHeader();
      _updateSidebarStats();
      renderTab(_pendingSessionTab || "overview");
      _resetIdleTimer();
      updateKBBadge();
      window._iipAppReady = true; // unblock hash-router initial navigation
      // NOTE: We do NOT call enrichFromCases() here on DB-restored data.
      // The DB (ibm_cases_raw_v1) may contain data from a previous session that differs
      // from the file the user is about to upload. Calling enrichFromCases() with stale
      // DB data would write incorrect week entries (ghost weeks) to localStorage.
      // enrichFromCases() is ONLY called after a fresh user Excel upload — see _onLoaded().
    }).catch(err => {
      console.error("[App] _showAppWithRows loadCases failed:", err);
      // Still show the app — charts may render with defaults
      const upload = document.getElementById("upload-screen");
      const app    = document.getElementById("app");
      if (upload) upload.style.display = "none";
      if (app)    app.classList.remove("hidden");
      updateHeader();
      renderTab(_pendingSessionTab || "overview");
      window._iipAppReady = true; // unblock hash-router even on error path
    });
  }

  async function _tryRestoreFromServer() {
    // Skip cases fetch only when navigating directly to admin portal
    if (sessionStorage.getItem('ibm_admin_session_v1') === '1' && _pendingSessionTab === 'admin') { _hideBootLoader(); _showAppWithRows([]); return false; }
    // 1. sessionStorage — fastest, survives F5 refresh
    try {
      const raw = sessionStorage.getItem('ibm_cases_raw_v1');
      if (raw) {
        const rows = JSON.parse(raw);
        if (Array.isArray(rows) && rows.length > 0) {
          _hideBootLoader();
          _showAppWithRows(rows);
          // Refresh sessionStorage from DB in background (don't block render)
          _refreshCasesFromDB().catch(() => {});
          return true;
        }
      }
    } catch(e) {}

    // 2. Fetch directly from /api/v2/cases — DB is the single source of truth.
    //    This covers ALL refresh types: F5, Ctrl+R, Ctrl+Shift+R, new tab, new browser.
    //    The loading skeleton shows while this runs — never the upload screen.
    try {

      const r = await fetch(API_BASE_V2 + '/cases', { cache: 'no-store' });
      if (r.ok) {
        const data = await r.json();
        if (data.cases && Array.isArray(data.cases) && data.cases.length > 0) {
          // Normalize DB snake_case fields → legacy CSV field names expected by Data module
          function _normalizeCase(c) {
            return {
              "Case Number":    c.case_number    || c["Case Number"]    || "",
              "Title":          c.title          || c["Title"]          || "",
              "Owner":          c.owner_name     || c["Owner"]          || "",
              "Status":         c.status         || c["Status"]         || "",
              "Severity":       c.severity       || c["Severity"]       || "",
              "Age":            c.age_days != null ? String(c.age_days) : (c["Age"] || ""),
              "Product":        c.product        || c["Product"]        || "",
              "Customer number":c.customer_number|| c["Customer number"]|| "",
              "Created":        c.created_date   || c["Created"]        || "",
              "Updated":        c.updated_date   || c["Updated"]        || "",
              "Closed Date":    c.closed_date    || c["Closed Date"]    || "",
              "Country":        c.country_name   || c["Country"]        || "",
              "Is Active":      c.is_active != null ? c.is_active : (c["Is Active"] != null ? c["Is Active"] : true),
              // Pass through any extra fields already in old format
              ...Object.fromEntries(Object.entries(c).filter(([k]) => !['case_number','title','owner_name','status','severity','age_days','product','customer_number','created_date','updated_date','closed_date','country_name','is_active'].includes(k))),
            };
          }
          // Apply admin overrides
          let rows = data.cases.map(_normalizeCase);
          try {
            const overrides = await IIPStore.getOverrides();
            if (overrides && Object.keys(overrides).length) {
              rows = rows.map(c => {
                const ov = overrides[c['Case Number']];
                return ov ? { ...c, ...ov, _hasOverride: true } : c;
              });
            }
          } catch(e) {}
          // Cache in sessionStorage for instant F5 restores
          try { sessionStorage.setItem('ibm_cases_raw_v1', JSON.stringify(rows)); } catch(e) {}
          // Also update localStorage so IIPStore is in sync
          try { localStorage.setItem('ibm_cases_raw_v1', JSON.stringify(rows)); } catch(e) {}
          _hideBootLoader();
          _showAppWithRows(rows, data.latest_upload_id || null);
          return true;
        }
        // Server responded but no cases — this is a fresh install or data was cleared
        if (!window._dataLoaded) { const hasData = await checkDataExists(); if (!hasData) _showUploadScreen(); else window._dataLoaded = true; }
        window._iipAppReady = true;
        return false;
      }
    } catch(e) {
      console.warn('[IIP] /api/cases fetch failed, trying IIPStore fallback:', e.message);
    }

    // 3. IIPStore fallback — only in file:// mode (no server available)
    if (window.location.protocol === 'file:') {
      try {
        const storedRows = await IIPStore.getCases();
        if (storedRows && storedRows.length > 0) {
          try { sessionStorage.setItem('ibm_cases_raw_v1', JSON.stringify(storedRows)); } catch(e) {}
          _hideBootLoader();
          _showAppWithRows(storedRows);
          return true;
        }
      } catch(e) {}
    }

    // 4. Truly no data anywhere — show upload screen
    if (!window._dataLoaded) { const hasData = await checkDataExists(); if (!hasData) _showUploadScreen(); else window._dataLoaded = true; }
    window._iipAppReady = true;
    return false;
  }

  // Refreshes cases from DB in background after a sessionStorage hit
  // so the data stays fresh without blocking the initial render
  async function _refreshCasesFromDB() {
    try {
      const r = await fetch(API_BASE_V2 + "/cases", { cache: "no-store" });
      if (!r.ok) return;
      const data = await r.json();
      if (data.cases && Array.isArray(data.cases) && data.cases.length > 0) {
        // Normalize before caching so sessionStorage always has legacy field names
        function _norm(c) {
          return {
            'Case Number':    c.case_number    || c['Case Number']    || '',
            'Title':          c.title          || c['Title']          || '',
            'Owner':          c.owner_name     || c['Owner']          || '',
            'Status':         c.status         || c['Status']         || '',
            'Severity':       c.severity       || c['Severity']       || '',
            'Age':            c.age_days != null ? String(c.age_days) : (c['Age'] || ''),
            'Product':        c.product        || c['Product']        || '',
            'Customer number':c.customer_number|| c['Customer number']|| '',
            'Created':        c.created_date   || c['Created']        || '',
            'Updated':        c.updated_date   || c['Updated']        || '',
            'Closed Date':    c.closed_date    || c['Closed Date']    || '',
            'Country':        c.country_name   || c['Country']        || '',
            'Is Active':      c.is_active != null ? c.is_active : true,
          };
        }
        const normalized = data.cases.map(_norm);
        try { sessionStorage.setItem('ibm_cases_raw_v1', JSON.stringify(normalized)); } catch(e) {}
        // localStorage write removed — sessionStorage is performance cache only
      }
    } catch(e) {}
  }





  function _ingestKB() { /* KB feature removed */ }

  /* ══════════════════════════════════════════════════════════
     SHOW APP — transition from upload screen to dashboard
     ════════════════════════════════════════════════════════ */
  function showApp() {
    const upload = document.getElementById("upload-screen");
    const app    = document.getElementById("app");
    if (upload) upload.style.display = "none";
    if (app)    app.classList.remove("hidden");
    _hideValidation();
    updateHeader();
    _updateSidebarStats();
    renderTab(_pendingSessionTab || "overview");
    _resetIdleTimer();
    updateKBBadge();
    window._iipAppReady = true;
    try { if (typeof Onboarding !== "undefined") Onboarding.init(); } catch(e) {}

    // If Chart.js hasn't loaded yet by the time the dashboard renders,
    // re-render the active tab once it's ready so charts appear without a page reload.
    if (typeof Chart === "undefined") {
      document.addEventListener('chartjs-ready', function _retry() {
        document.removeEventListener('chartjs-ready', _retry);
        setTimeout(() => { try { renderActive(); } catch(e) {} }, 120);
      });
    }
  }

  /* ══════════════════════════════════════════════════════════
     TAB RENDERING
     ════════════════════════════════════════════════════════ */
  function renderTab(tabId) {
    if (!tabId) tabId = "overview";

    // Guard: admin tab requires login — show modal without revealing admin content
    if (tabId === 'admin') {
      try {
        if (typeof Admin !== 'undefined' && typeof Data !== 'undefined' && !Data.isAdmin()) {
          // Redirect to lightweight standalone login page instead of in-app popup
          try {
            const _b = (typeof window.__APP_BASE__ === 'string') ? window.__APP_BASE__ : '/';
            let _bp; try { _bp = new URL(_b).pathname.replace(/\/$/, ''); } catch(e) { _bp = ''; }
            window.location.href = _bp + '/admin/';
          } catch(e) { Admin.showLoginModal(); }
          return;
        } else if (typeof Admin === 'undefined') {
          // Admin scripts not yet lazy-loaded — load first, THEN auth-gate
          (_LAZY_CSS['admin'] || []).forEach(_injectStylesheet);
          // Update URL to /admin immediately (before scripts load)
          try {
            const _b = (typeof window.__APP_BASE__ === 'string') ? window.__APP_BASE__ : '/';
            let _bp; try { _bp = new URL(_b).pathname.replace(/\/$/, ''); } catch(e) { _bp = ''; }
            const _ap = _bp + '/admin';
            if (window.location.pathname !== _ap) window.history.replaceState({ tab: 'admin' }, '', _ap);
          } catch(e) {}
          _loadScriptSeq(_LAZY_SCRIPTS['admin']).then(async () => {
            if (typeof Admin !== 'undefined') await Admin.init().catch(() => {});
            if (typeof Admin !== 'undefined' && typeof Data !== 'undefined' && !Data.isAdmin()) {
              Admin.showLoginModal();
            } else {
              renderTab('admin'); // retry now that Admin is defined and session validated
            }
          }).catch(() => {});
          return; // Block content reveal until auth is confirmed
        }
      } catch(e) {}
    }

    // Hide all tab pages, show the target
    document.querySelectorAll(".tab-page").forEach(p => p.classList.remove("active"));
    const panel = document.getElementById("tab-" + tabId);
    if (panel) panel.classList.add("active");

    // Show/hide doc overlay (mounted on .main-area) when switching tabs
    const docOverlay = document.getElementById('doc-overlay');
    if (docOverlay) {
      docOverlay.style.display = (tabId === 'documentation') ? 'flex' : 'none';
    }

    // Keep sidebar-collapsed class in sync
    const sidebar = document.getElementById("sidebar");
    document.body.classList.toggle("sidebar-collapsed", !!(sidebar && sidebar.classList.contains("collapsed")));

    // Update sidebar nav active state + resolve human label from data-label attribute
    let tabLabel = tabId.replace(/-/g, " ").replace(/\b\w/g, c => c.toUpperCase());
    document.querySelectorAll(".nav-item[data-tab]").forEach(btn => {
      const isActive = btn.dataset.tab === tabId;
      btn.classList.toggle("active", isActive);
      if (isActive && btn.dataset.label) tabLabel = btn.dataset.label;
    });

    // Update page header title (breadcrumb removed — page-breadcrumb element no longer in DOM)
    const dc  = (typeof DynamicConfig !== "undefined" && DynamicConfig.getRaw) ? DynamicConfig.getRaw() : {};
    const appTitle  = dc.appTitle  || (typeof AppData !== "undefined" ? AppData.config.appTitle  : null) || "IBM Cases";
    const teamName  = dc.teamName  || (typeof AppData !== "undefined" ? AppData.config.teamName  : null) || "BD/TOA-ETS5";
    const titleEl  = document.getElementById("page-title");
    const crumbEl  = document.getElementById("page-breadcrumb");
    if (titleEl) titleEl.textContent = tabLabel;
    if (crumbEl) crumbEl.textContent = `${appTitle} · ${teamName} · ${tabLabel}`; // kept for compat if element exists

    // Update browser tab title
    document.title = `${tabLabel} — ${appTitle} v${(typeof AppVersion !== "undefined" ? AppVersion.semver : "1.0.2")}`;

    _activeTab = tabId;
    _saveSession(tabId);
    // Save state for production-grade persistence
    if (typeof StateManager !== "undefined") {
      StateManager.saveActiveTab(tabId);
    }

    // Sync URL — admin tab gets the clean /admin path; other tabs restore base path
    try {
      if (window.location.protocol !== 'file:') {
        const base = (typeof window.__APP_BASE__ === 'string') ? window.__APP_BASE__ : '/';
        // Derive pathname-only base, e.g. '/iip' from 'https://host/iip/'
        let basePathname;
        try { basePathname = new URL(base).pathname.replace(/\/$/, ''); } catch(e) { basePathname = ''; }
        const adminPath = basePathname + '/admin';
        if (tabId === 'admin') {
          if (window.location.pathname !== adminPath) {
            window.history.replaceState({ tab: 'admin' }, '', adminPath);
          }
        } else if (window.location.pathname === adminPath) {
          // Navigating away from admin — restore base path
          window.history.replaceState({ tab: tabId }, '', basePathname + '/');
        }
      }
    } catch(e) {}

    // Render dashboard — lazy-load script on first visit if not yet loaded
    const dash = getDash(tabId);
    if (dash && typeof dash.render === "function") {
      const heavyTabs = new Set(["team","members","closed","created","weekly-tracker","performance","customer"]);
      if (heavyTabs.has(tabId) && panel) {
        panel.classList.add("tab-loading");
        requestAnimationFrame(() => {
          try { dash.render(); } catch(e) {
            console.warn("[App] renderTab error for", tabId, e);
            _showTabError(panel, tabId, e);
          }
          panel.classList.remove("tab-loading");
        });
      } else {
        try { dash.render(); } catch(e) {
          console.warn("[App] renderTab error for", tabId, e);
          _showTabError(panel, tabId, e);
        }
      }
    } else if (!dash && _LAZY_SCRIPTS[tabId]) {
      // Inject any tab-specific CSS first (handles refresh case where no nav click fired)
      (_LAZY_CSS[tabId] || []).forEach(_injectStylesheet);
      if (panel) panel.classList.add("tab-loading");
      _loadScriptSeq(_LAZY_SCRIPTS[tabId]).then(() => {
        if (panel) panel.classList.remove("tab-loading");
        const d = getDash(tabId);
        if (d && typeof d.render === "function") {
          try { d.render(); } catch(e) { console.warn("[App] renderTab error for", tabId, e); _showTabError(panel, tabId, e); }
        }
      }).catch(err => {
        if (panel) panel.classList.remove("tab-loading");
        console.error("[App] Lazy load failed for", tabId, err);
        _showTabError(panel, tabId, err);
      });
    }
  }

  // ── Tab error boundary ───────────────────────────────────────────────────
  function _showTabError(panel, tabId, err) {
    if (!panel) return;
    panel.innerHTML = `
      <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;
                  min-height:400px;padding:40px;text-align:center;font-family:var(--font-sans)">
        <div style="font-size:40px;margin-bottom:16px">⚠️</div>
        <div style="font-size:16px;font-weight:600;color:var(--text-primary);margin-bottom:8px">
          This page ran into a problem
        </div>
        <div style="font-size:13px;color:var(--text-secondary);margin-bottom:24px;max-width:400px;line-height:1.6">
          The <strong>${tabId}</strong> dashboard failed to load. Your data is safe.
          Try refreshing the page, or contact your admin if this keeps happening.
        </div>
        <button onclick="window.location.reload()"
          style="padding:10px 24px;background:var(--ibm-blue-50);color:#fff;border:none;
                 border-radius:var(--radius-sm);cursor:pointer;font-size:13px;font-weight:600;
                 font-family:var(--font-sans)">
          Refresh page
        </button>
        <details style="margin-top:16px;max-width:480px;text-align:left">
          <summary style="font-size:11px;color:var(--text-tertiary);cursor:pointer">Technical details</summary>
          <pre style="font-size:11px;color:var(--text-tertiary);margin-top:8px;white-space:pre-wrap;
                      background:var(--bg-layer);padding:8px;border-radius:var(--radius-sm)">${String(err)}</pre>
        </details>
      </div>`;
  }
  // ── End tab error boundary ───────────────────────────────────────────────

  function renderActive() {
    renderTab(_activeTab || "overview");
  }

  /* ══════════════════════════════════════════════════════════
     HEADER / SIDEBAR STATS
     ════════════════════════════════════════════════════════ */
  function updateHeader() {
    // App identity
    refreshAppIdentity();
    // Admin button state
    try { if (typeof Admin !== "undefined") Admin.updateHeader(); } catch(e) {}
  }

  function refreshAppIdentity() {
    const dc = (typeof DynamicConfig !== "undefined") ? DynamicConfig : null;
    const _cfg      = (dc && dc.getRaw) ? dc.getRaw() : {};
    const appTitle  = _cfg.appTitle  || (typeof AppData !== "undefined" ? AppData.config.appTitle  : null) || "IBM Cases";
    const teamName  = _cfg.teamName  || (typeof AppData !== "undefined" ? AppData.config.teamName  : null) || "BD/TOA-ETS5";

    const titleEl = document.getElementById("sidebar-app-title");
    const teamEl  = document.getElementById("sidebar-team-name");
    const uploadTitleEl = document.getElementById("upload-app-title");

    if (titleEl)       titleEl.textContent  = appTitle;
    if (teamEl)        teamEl.textContent   = teamName;
    if (uploadTitleEl) uploadTitleEl.textContent = appTitle;

    // Version badge
    try {
      if (typeof AppVersion !== "undefined") {
        const badge = document.getElementById("upload-ver-badge");
        if (badge) badge.textContent = AppVersion.version;
      }
    } catch(e) {}
  }

  function _updateSidebarStats() {
    const el = document.getElementById("sidebar-stats");
    if (el) el.style.display = "none";
  }

  /* ══════════════════════════════════════════════════════════
     SIDEBAR NAV SETUP
     ════════════════════════════════════════════════════════ */
  function setupSidebarNav() {
    // Cases menu parent toggle with StateManager persistence
    const navParent = document.getElementById("nav-cases-parent");
    const navChildren = document.getElementById("nav-cases-children");
    if (navParent && navChildren) {
      // Clean up old localStorage key if it exists (migration from old system)
      try {
        localStorage.removeItem("nav-cases-expanded");
      } catch(e) {}

      // Restore from StateManager (production-grade state persistence)
      let isExpanded = false;  // default: collapsed
      if (typeof StateManager !== "undefined") {
        isExpanded = StateManager.getMenuState("nav-cases", false);
      }

      function updateMenuState(expanded) {
        isExpanded = expanded;
        navParent.setAttribute("aria-expanded", String(expanded));
        navChildren.setAttribute("aria-hidden", String(!expanded));
        navChildren.classList.toggle("open", expanded);
        // Save to StateManager
        if (typeof StateManager !== "undefined") {
          StateManager.saveMenuState("nav-cases", expanded);
        }
      }

      // Set initial state based on saved state
      updateMenuState(isExpanded);

      // Handle clicks
      navParent.addEventListener("click", (e) => {
        e.stopPropagation();
        updateMenuState(!isExpanded);
      });
    }

    document.querySelectorAll(".nav-item[data-tab]").forEach(btn => {
      btn.addEventListener("click", () => {
        const tab = btn.dataset.tab;
        if (!tab) return;
        // Admin tab requires login — redirect to standalone login page
        if (tab === "admin") {
          try {
            if (typeof Data === "undefined" || !Data.isAdmin()) {
              const _b = (typeof window.__APP_BASE__ === 'string') ? window.__APP_BASE__ : '/';
              let _bp; try { _bp = new URL(_b).pathname.replace(/\/$/, ''); } catch(e) { _bp = ''; }
              window.location.href = _bp + '/admin/';
              return;
            }
          } catch(e) {}
        }
        renderTab(tab);
      });
    });
  }

  /* ══════════════════════════════════════════════════════════
     SIDEBAR COLLAPSE
     ════════════════════════════════════════════════════════ */
  function setupSidebarCollapse() {
    const sidebar      = document.getElementById("sidebar");
    const toggleBtn    = document.getElementById("sidebar-toggle");
    const expandBtn    = document.getElementById("sidebar-expand");


    // Restore saved collapse state
    try {
      if (localStorage.getItem("iip_sidebar_collapsed") === "1") {
        sidebar && sidebar.classList.add("collapsed");
      }
    } catch(e) {}

    function _collapse() {
      sidebar && sidebar.classList.add("collapsed");
      try { localStorage.setItem("iip_sidebar_collapsed", "1"); } catch(e) {}
    }
    function _expand() {
      sidebar && sidebar.classList.remove("collapsed");
      try { localStorage.removeItem("iip_sidebar_collapsed"); } catch(e) {}
    }
    toggleBtn    && toggleBtn.addEventListener("click",    _collapse);
    expandBtn    && expandBtn.addEventListener("click",    _expand);
  }

  /* ══════════════════════════════════════════════════════════
     GLOBAL SEARCH
     ════════════════════════════════════════════════════════ */
  function setupGlobalSearch() {
    const input   = document.getElementById("global-search");
    const results = document.getElementById("global-search-results");
    if (!input || !results) return;
    let _debounce;

    // Ctrl+K / Cmd+K focuses the search bar globally
    document.addEventListener("keydown", e => {
      if ((e.ctrlKey || e.metaKey) && e.key === "k") {
        e.preventDefault();
        input.focus();
        input.select();
      }
    });

    // Add aria-live region for screen reader announcements
    let ariaLiveRegion = document.getElementById("search-aria-live");
    if (!ariaLiveRegion) {
      ariaLiveRegion = document.createElement("div");
      ariaLiveRegion.id = "search-aria-live";
      ariaLiveRegion.setAttribute("aria-live", "polite");
      ariaLiveRegion.setAttribute("aria-atomic", "true");
      ariaLiveRegion.style.position = "absolute";
      ariaLiveRegion.style.left = "-9999px";
      document.body.appendChild(ariaLiveRegion);
    }

    input.addEventListener("input", () => {
      clearTimeout(_debounce);
      const q = input.value.trim().toLowerCase();
      if (q.length < 2) { results.classList.add("hidden"); return; }
      ariaLiveRegion.textContent = `Searching for "${q}"...`;
      _debounce = setTimeout(() => _runSearch(q), 150);
    });

    input.addEventListener("keydown", e => {
      if (e.key === "Escape") { input.value = ""; results.classList.add("hidden"); input.blur(); }
      if (e.key === "ArrowDown") {
        e.preventDefault();
        const first = results.querySelector(".gs-item");
        if (first) first.focus();
      }
    });

    document.addEventListener("click", e => {
      if (!input.contains(e.target) && !results.contains(e.target)) {
        results.classList.add("hidden");
      }
    });

    results.addEventListener("keydown", e => {
      if (e.key === "ArrowDown") { e.preventDefault(); e.target.nextElementSibling?.focus(); }
      if (e.key === "ArrowUp")   { e.preventDefault(); (e.target.previousElementSibling || input).focus(); }
      if (e.key === "Escape")    { results.classList.add("hidden"); input.focus(); }
    });

    function _runSearch(q) {
      try {
        const allMatches = Data.allCases().filter(r =>
          (r["Case Number"] || "").toLowerCase().includes(q) ||
          (r.Title         || "").toLowerCase().includes(q) ||
          (r.Owner         || "").toLowerCase().includes(q) ||
          (r.Status        || "").toLowerCase().includes(q) ||
          (r.Product       || "").toLowerCase().includes(q)
        );
        const cases = allMatches.slice(0, 12);
        const totalMatches = allMatches.length;
        const hasMore = totalMatches > 12;

        if (!totalMatches) {
          results.innerHTML = `<div style="padding:14px 16px;font-size:12px;color:var(--text-secondary);text-align:center">
            <div style="margin-bottom:6px">No cases found for "${Utils.escHtml(q)}"</div>
            <div style="font-size:11px;color:var(--text-tertiary)">Try searching by case number, owner, or product name.</div>
          </div>`;
          ariaLiveRegion.textContent = `No cases found for ${q}`;
          results.classList.remove("hidden");
          return;
        }

        results.innerHTML = `<div style="padding:8px 14px;border-bottom:1px solid var(--border-subtle);font-size:11px;color:var(--text-tertiary);font-weight:600">Showing ${cases.length}${hasMore ? ' of ' + totalMatches : ''} matches</div>` + 
          cases.map(r => {
          const cn     = Utils.escHtml(r["Case Number"] || "");
          const title  = Utils.escHtml((r.Title || "").slice(0, 60));
          const owner  = Utils.escHtml(Utils.shortName(r.Owner || ""));
          const closed = Utils.isClosed(r.Status);
          const color  = closed ? "var(--text-tertiary)" : "var(--ibm-blue-50)";
          const sev    = String(r.Severity || "").trim();
          const sevCol = sev.startsWith("1") ? "var(--red)" : sev.startsWith("2") ? "var(--orange)" : sev.startsWith("3") ? "var(--yellow)" : "var(--text-disabled)";
          return `<div class="gs-item" tabindex="0" data-cn="${cn}"
            style="padding:9px 14px;cursor:pointer;border-bottom:1px solid var(--border-subtle);display:flex;gap:10px;align-items:flex-start"
            role="option">
            <div style="flex:1;min-width:0">
              <div style="display:flex;align-items:center;gap:6px;margin-bottom:2px">
                <span style="font-family:var(--font-mono);font-size:12px;font-weight:700;color:${color};flex-shrink:0">${cn}</span>
                ${sev ? `<span style="font-size:10px;font-weight:700;color:${sevCol};font-family:var(--font-mono)">S${sev.charAt(0)}</span>` : ""}
              </div>
              <span style="font-size:12px;color:var(--text-primary);display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${title}</span>
              <div style="display:flex;gap:8px;margin-top:2px">
                <span style="font-size:10px;color:var(--text-tertiary)">${owner}</span>
                <span style="font-size:10px;color:var(--text-disabled)">·</span>
                <span style="font-size:10px;color:var(--text-tertiary)">${Utils.escHtml(r.Status || "")}</span>
              </div>
            </div>
            <span style="font-size:10px;color:var(--ibm-blue-50);opacity:.7;flex-shrink:0;align-self:center;padding-top:1px">View →</span>
          </div>`;
        }).join("") + 
        (hasMore ? `<div style="padding:10px 14px;border-top:1px solid var(--border-subtle);text-align:center">
          <button class="gs-view-all" style="background:none;border:none;color:var(--ibm-blue-50);font-size:12px;font-weight:600;cursor:pointer;padding:4px 0;width:100%;font-family:inherit">
            View all ${totalMatches} results →
          </button>
        </div>` : "");

        results.querySelectorAll(".gs-item").forEach(item => {
          const activate = () => {
            results.classList.add("hidden");
            input.value = "";
            const cn  = item.dataset.cn;
            const row = Data.allCases().find(r => r["Case Number"] === cn);
            if (row) _showCaseDetail(row);
          };
          item.addEventListener("click",  activate);
          item.addEventListener("keydown", e => { if (e.key === "Enter") activate(); });
        });

        // "View all results" button handler
        const viewAllBtn = results.querySelector(".gs-view-all");
        if (viewAllBtn) {
          viewAllBtn.addEventListener("click", () => {
            // Navigate to search dashboard with query
            RouterApp.go('#/investigate');
            results.classList.add("hidden");
            input.value = "";
            // Trigger global filter once dashboard loads
            setTimeout(() => {
              document.dispatchEvent(new CustomEvent('iip:search:query', { detail: { q } }));
            }, 300);
          });
        }

        // Fix keyboard focus trapping: wrap around first/last items
        const items = results.querySelectorAll(".gs-item, .gs-view-all");
        if (items.length > 0) {
          const first = items[0];
          const last = items[items.length - 1];
          last.addEventListener("keydown", e => {
            if (e.key === "ArrowDown") {
              e.preventDefault();
              first.focus();
            }
          });
          first.addEventListener("keydown", e => {
            if (e.key === "ArrowUp") {
              e.preventDefault();
              input.focus();
            }
          });
        }

        results.classList.remove("hidden");
        // Announce to screen readers
        ariaLiveRegion.textContent = `Found ${totalMatches} case${totalMatches!==1?'s':''}, showing ${cases.length}`;
      } catch(e) { results.classList.add("hidden"); }
    }

    /* ── Case Detail Modal ───────────────────────────────── */
    function _showCaseDetail(row) {
      const cn      = row["Case Number"] || "";
      const closed  = Utils.isClosed(row.Status);
      const cnColor = closed ? "var(--text-tertiary)" : "var(--ibm-blue-50)";
      const sev     = String(row.Severity || "").trim();
      const sevCol  = sev.startsWith("1") ? "var(--red)" : sev.startsWith("2") ? "var(--orange)" : sev.startsWith("3") ? "var(--yellow)" : "var(--text-disabled)";
      const days    = Utils.daysDiff(Utils.parseDate(row.Updated));
      const stale   = days >= 5;
      const age     = parseInt(row.Age || "0", 10);

      const defectBaseUrl = (typeof DynamicConfig !== "undefined" && DynamicConfig.appConfig)
        ? (DynamicConfig.appConfig().defectBaseUrl || "")
        : (typeof Config !== "undefined" ? (Config.DEFECT_BASE_URL || "") : "");

      const isPerf = (typeof Data !== "undefined" && Data.isMarkedPerformance)
        ? Data.isMarkedPerformance(cn) : false;
      const isNonPerf = (typeof Data !== "undefined" && Data.getNonPerfCaseNums)
        ? Data.getNonPerfCaseNums().includes(cn) : false;
      const meta = (typeof Data !== "undefined" && Data.performanceMeta)
        ? (Data.performanceMeta()[cn] || {}) : {};
      const workItem = meta.workItem || "";

      const html = `
        <div style="display:flex;flex-direction:column;gap:16px">

          <!-- Header row -->
          <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px;flex-wrap:wrap">
            <div>
              <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
                <span style="font-family:var(--font-mono);font-size:16px;font-weight:700;color:${cnColor}">${Utils.escHtml(cn)}</span>
                ${sev ? `<span style="background:${sevCol}22;color:${sevCol};border:1px solid ${sevCol}44;font-size:11px;font-weight:700;padding:2px 8px;border-radius:var(--radius-sm);font-family:var(--font-mono)">Sev ${sev.charAt(0)}</span>` : ""}
                ${isPerf ? `<span style="background:rgba(218,30,40,.1);color:var(--red);border:1px solid rgba(218,30,40,.25);font-size:11px;font-weight:600;padding:2px 8px;border-radius:var(--radius-sm)">⚡ Performance</span>` : ""}
              </div>
              <div style="margin-top:6px">${Utils.statusBadge(row.Status)}</div>
            </div>
            <a href="https://www.ibm.com/mysupport/s/case/${encodeURIComponent(cn)}" target="_blank" rel="noopener"
              style="display:inline-flex;align-items:center;gap:5px;font-size:12px;font-weight:600;color:var(--ibm-blue-50);text-decoration:none;padding:6px 12px;border:1px solid rgba(15,98,254,.3);border-radius:var(--radius-sm);background:rgba(15,98,254,.05);flex-shrink:0">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
              Open in IBM
            </a>
          </div>

          <!-- Title -->
          <div>
            <div style="font-size:11px;font-weight:600;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px">Title</div>
            <div style="font-size:14px;color:var(--text-primary);line-height:1.5">${Utils.escHtml(row.Title || "—")}</div>
          </div>

          <!-- Grid of key fields -->
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
            <div style="background:var(--bg-layer);border:1px solid var(--border-subtle);border-radius:var(--radius-sm);padding:10px 12px">
              <div style="font-size:10px;font-weight:600;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px">Owner</div>
              <div style="font-size:13px;font-weight:600;color:var(--text-primary)">${Utils.escHtml((typeof Data !== "undefined" && Data.displayName ? Data.displayName(row.Owner) : row.Owner) || "—")}</div>
            </div>
            <div style="background:var(--bg-layer);border:1px solid var(--border-subtle);border-radius:var(--radius-sm);padding:10px 12px">
              <div style="font-size:10px;font-weight:600;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px">Product</div>
              <div style="font-size:13px;color:var(--text-primary)">${Utils.escHtml(row.Product || "—")}</div>
            </div>
            <div style="background:var(--bg-layer);border:1px solid var(--border-subtle);border-radius:var(--radius-sm);padding:10px 12px">
              <div style="font-size:10px;font-weight:600;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px">Created</div>
              <div style="font-size:13px;font-family:var(--font-mono);color:var(--text-primary)">${Utils.escHtml(row.Created || "—")}</div>
            </div>
            <div style="background:var(--bg-layer);border:1px solid var(--border-subtle);border-radius:var(--radius-sm);padding:10px 12px">
              <div style="font-size:10px;font-weight:600;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px">Last Updated</div>
              <div style="font-size:13px;font-family:var(--font-mono);color:${stale ? "var(--red)" : "var(--text-primary)"}">${Utils.escHtml(row.Updated || "—")}${stale ? ` <span style="font-size:11px;color:var(--red)">(+${days}d)</span>` : ""}</div>
            </div>
            <div style="background:var(--bg-layer);border:1px solid var(--border-subtle);border-radius:var(--radius-sm);padding:10px 12px">
              <div style="font-size:10px;font-weight:600;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px">Age</div>
              <div style="font-size:13px;font-family:var(--font-mono);color:${age>30?"var(--red)":age>14?"var(--orange)":"var(--text-primary)"}">${age > 0 ? age + " days" : "—"}</div>
            </div>
            <div style="background:var(--bg-layer);border:1px solid var(--border-subtle);border-radius:var(--radius-sm);padding:10px 12px">
              <div style="font-size:10px;font-weight:600;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px">Customer #</div>
              <div style="font-size:13px;font-family:var(--font-mono);color:var(--text-primary)">${Utils.escHtml(row["Customer number"] || "—")}</div>
            </div>
          </div>

          ${workItem ? `
          <div style="background:var(--bg-layer);border:1px solid var(--border-subtle);border-radius:var(--radius-sm);padding:10px 12px">
            <div style="font-size:10px;font-weight:600;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px">Work Item (Defect)</div>
            <a href="${Utils.escHtml(defectBaseUrl + workItem)}" target="_blank" rel="noopener"
              style="font-size:13px;font-family:var(--font-mono);color:var(--ibm-blue-50);text-decoration:none">${Utils.escHtml(workItem)}</a>
          </div>` : ""}

          <!-- Comments from Weekly Tracker -->
          ${(() => {
            try {
              const cmtStore = localStorage.getItem("ibm_wtracker_comments_v1");
              const comments = cmtStore ? JSON.parse(cmtStore) : {};
              const caseComment = comments[cn] || "";
              if (caseComment.trim()) {
                return `<div style="background:var(--bg-layer);border:1px solid var(--border-subtle);border-radius:var(--radius-sm);padding:10px 12px">
                  <div style="font-size:10px;font-weight:600;color:var(--text-tertiary);text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px">Comments</div>
                  <div style="font-size:13px;line-height:1.5;color:var(--text-primary);white-space:pre-wrap;word-wrap:break-word">${Utils.escHtml(caseComment)}</div>
                </div>`;
              }
            } catch(e) {}
            return "";
          })()}

          <!-- Actions -->
          <div style="display:flex;gap:8px;flex-wrap:wrap;padding-top:4px;border-top:1px solid var(--border-subtle)">
            <button onclick="
              if(typeof Modal!=='undefined')Modal.close();
              if(typeof App!=='undefined'){App.renderTab('team');setTimeout(()=>{if(typeof DashTeam!=='undefined'&&DashTeam.setSearch)DashTeam.setSearch('${Utils.escHtml(cn)}');},400);}
            " class="btn btn-primary btn-sm" style="flex:1">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg>
              View in Team Cases
            </button>
            <button onclick="
              navigator.clipboard?.writeText('${Utils.escHtml(cn)}').then(()=>{this.textContent='✓ Copied!';setTimeout(()=>this.innerHTML='<svg width=\\'12\\' height=\\'12\\' viewBox=\\'0 0 24 24\\' fill=\\'none\\' stroke=\\'currentColor\\' stroke-width=\\'2\\'><rect x=\\'9\\' y=\\'9\\' width=\\'13\\' height=\\'13\\' rx=\\'2\\'/><path d=\\'M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1\\'/></svg> Copy Case #',1500);})
            " class="btn btn-ghost btn-sm">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg>
              Copy Case #
            </button>
          </div>
        </div>`;

      if (typeof Modal !== "undefined") {
        Modal.open(cn + " — Case Details", html);
      }
    }
  }

  /* ══════════════════════════════════════════════════════════
     EXTRA PUBLIC METHODS
     ════════════════════════════════════════════════════════ */
  function loadFileExternal(file) {
    if (file) loadFile(file, true);
  }

  function navigate(hash) {
    try {
      if (typeof IIPRouter !== "undefined") IIPRouter.navigate(hash);
      else renderTab(hash);
    } catch(e) { renderTab(hash); }
  }

  function refresh() {
    updateHeader();
    _updateSidebarStats();
    renderActive();
  }

  /* ══════════════════════════════════════════════════════════
     PUBLIC API
     ════════════════════════════════════════════════════════ */
  return {
    init,
    renderTab,
    renderActive,
    updateHeader,
    refreshAppIdentity,
    loadFileExternal,
    navigate,
    refresh,
    showApp,
  };
})();




  /* ── Check if data exists in DB ─────────────────────────── */
  async function checkDataExists() {
    try {
      const resp = await fetch(window.API_BASE + '/store/cases-count', { method: 'GET', cache: 'no-store' });
      const data = await resp.json();
      return data.ok && data.count && parseInt(data.count) > 0;
    } catch(e) {
      return false;
    }
  }

document.addEventListener("DOMContentLoaded", async () => {
  App.init().catch(e => {
    console.error("App init:", e);
  });
});
