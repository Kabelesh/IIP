# UX Features Implementation Analysis

## 1. EMPTY STATE HANDLING

### Primary Implementation
**File**: [js/modules/ui/ui-components.js](js/modules/ui/ui-components.js#L203-L247)

**Component**: `IIPEmpty` — Standardized empty state renderer with preset system

#### Presets Available
```javascript
noData    → "No data available" (📭)
noCases   → "No cases found" (📋)
noResults → "No results match" (🔍)
noKB      → "No KB articles" (📚)
noHistory → "No history recorded" (🕒)
error     → "Something went wrong" (⚠️)
loading   → "Loading…" (⏳)
```

#### Structure
- Icon (emoji) + Heading + Text + Optional CTA button
- Compact variant for inline table/chart empties
- Supports custom config: `{ icon, heading, text, ctaLabel, onCta }`

#### CSS Classes
```css
.iip-empty {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 48px 32px;
  min-height: 200px;
}
.iip-empty.compact { padding: 24px 16px; min-height: 120px; }
.iip-empty-icon    { font-size: var(--empty-icon-size); opacity: 0.7; }
.iip-empty-heading { font: var(--type-h4); color: var(--empty-heading-color); }
.iip-empty-text    { font: var(--type-body-sm); color: var(--empty-text-color); max-width: 320px; }
```

### Secondary Implementation: Search-Aware Empty States
**File**: [js/modules/ui/perf-utils.js](js/modules/ui/perf-utils.js#L301-L332)

Shows contextual messages based on search state:
- **Filtered**: "No cases match your search" + suggestions + clear button
- **No Filter**: "No cases found" + upload prompt

**Used By**: Performance & tracker dashboards

### Tertiary: Inline Empty States
**Locations**:
- [js/dashboards/performance.js](js/dashboards/performance.js#L567-L575) — "No cases tagged yet" in tables
- [js/dashboards/overview.js](js/dashboards/overview.js#L426-L427) — Simple `<p class="ov7-empty">`
- [js/dashboards/investigate.js](js/dashboards/investigate.js#L524-L527) — Archive search empties

---

## 2. GLOBAL SEARCH IMPLEMENTATION

**File**: [js/app.js](js/app.js#L1899-L1996)

### Architecture
- **Trigger**: Command palette search input
- **Debounce**: 150ms
- **Result Limit**: Top 12 matches (`.slice(0, 12)`)
- **Search Fields**: Case Number, Title, Owner, Status, Product

### Key Functions
| Function | Purpose |
|----------|---------|
| Input listener (L1918-1921) | Debounced search query capture |
| Keyboard navigation (L1923-1941) | Arrow keys, Escape, Enter handling |
| Filter logic (L1943-1952) | Multi-field search matching |
| Dropdown rendering (L1959-1984) | Result formatting & display |
| Item activation (L1986-1996) | Click → navigate & close dropdown |

### DOM Structure
```html
<!-- Dropdown container -->
<div class="cmd-list">
  <!-- Generated items from filtered results -->
  <div class="cmd-item" data-index="0">
    <div class="cmd-icon">📋</div>
    <div class="cmd-label">TS123456</div>
  </div>
</div>

<!-- No results state -->
<div class="cmd-empty">No results for "query"</div>
```

### State Management
- `_lastSearchValue` — current query
- `_cmdIdx` — keyboard selection index
- No persistence (ephemeral)

---

## 3. PERFORMANCE CASE TAGGING

**File**: [js/dashboards/admin-dash.js](js/dashboards/admin-dash.js#L1480-L1650)

### Circular Prevention Logic
Located in `_addPerfTag()` function:

```javascript
// Detect opposing tag
const opposing = isPerf ? Data.isMarkedNonPerformance(val) : Data.isMarkedPerformance(val);
const oppLabel = isPerf ? "Non-Performance" : "Performance";

if (opposing) {
  // Show confirmation
  if (!confirm(`Case ${val} is currently tagged as ${oppLabel}.\nTagging it as ${thisLabel} will remove the ${oppLabel} tag. Proceed?`)) 
    return;
  // Remove from opposing list
  if (isPerf) Data.removeNonPerfCaseNum(val); 
  else Data.removePerfCaseNum(val);
}
```

### Modal Confirmation Patterns
1. **Validation Check** — Format validation with "Tag anyway?" fallback
2. **Conflict Warning** — Shows if case already tagged oppositely
3. **Bulk Import Summary** — Lists count of duplicates & new cases before proceeding
4. **Safety Guard** — `SafetyGuard.guardBulkTagging()` for >5 case imports

### Data Flow
```
1. Input validation (_validateCaseNum)
2. Opposing tag check
3. User confirmation (if needed)
4. Data.snapshotForAdmin() — backup
5. Add/Remove tag via Data API
6. Render update + re-sync Performance dashboard
7. Toast notification + change log
```

### Supported Input Formats
- Single case: `TS123456`
- Defect/Task: `Defect 12345 TS123456`
- Bulk paste: comma or newline separated

---

## 4. VIRTUAL TABLE / VIRTUAL SCROLLING

**Status**: NOT IMPLEMENTED as virtual scrolling

### Actual Implementation
**File**: [js/dashboards/closed.js](js/dashboards/closed.js) and [js/modules/tracker/wt-render.js](js/modules/tracker/wt-render.js)

**Pattern Used**: Full DOM rendering with client-side sorting/filtering

#### Selection Tracking (Weekly Tracker)
**File**: [js/modules/tracker/tracker-ux.js](js/modules/tracker/tracker-ux.js)

- Checkboxes with case number keys
- State stored in `_selected` Map
- Synced to DOM via checkbox `.checked` attribute

#### Table Rendering Pattern
```javascript
// Filter data
const filtered = data.filter(row => matchesFilters(row));

// Render all rows to DOM
container.innerHTML = filtered.map(row => `
  <tr>
    <td><input type="checkbox" data-case="${row['Case Number']}"/></td>
    <td>${row['Case Number']}</td>
    <!-- ... -->
  </tr>
`).join('');

// Bind selection listeners
container.querySelectorAll('input[type=checkbox]').forEach(cb => {
  cb.addEventListener('change', () => {
    _selected.set(cb.dataset.case, cb.checked);
  });
});
```

#### Performance Optimization (Observed)
- Table row limit: typically 100-200 rows visible
- Pagination NOT used
- CSS classes applied for visual virtualization (off-screen hiding)

---

## 5. FILTER LOGIC & PERSISTENC

**Central Manager**: [js/modules/ui/state-manager.js](js/modules/ui/state-manager.js#L13-L68)

### Architecture
```
localStorage
    ↓
STORAGE_KEY_FILTERS = "iip_filters_v1"
    ↓
{
  "team": { owner: "John Doe", status: "open", days: 30, timestamp: ... },
  "closed": { year: "2025", month: "03", from: "2025-01-01", ... },
  ...
}
```

### Key Functions
| Function | Purpose |
|----------|---------|
| `saveFiltersForDashboard(id, filters)` | Merge & persist filters for dashboard |
| `getFiltersForDashboard(id)` | Retrieve saved filters on render |
| `clearFiltersForDashboard(id)` | Remove all filters for dashboard |

### Dashboard Integration
**Example**: [js/dashboards/team.js](js/dashboards/team.js#L23-L48)

```javascript
// Restore on render
function render() {
  const savedFilters = StateManager.getFiltersForDashboard("team");
  if (savedFilters.owner !== undefined) _filterOwner = savedFilters.owner;
  if (savedFilters.status !== undefined) _filterStatus = savedFilters.status;
}

// Save on filter change
function applyFilters() {
  _saveFilters();  // internal call
  render();
}

function _saveFilters() {
  StateManager.saveFiltersForDashboard("team", {
    owner: _filterOwner,
    status: _filterStatus,
    days: _filterDays
  });
}
```

### Multiple Persistence Strategies (Mixed)
1. **StateManager** — Primary (dashboard-scoped filters)
2. **Global Date Context** — Secondary (shared across multiple dashboards)
   - [index.html](index.html#L565-L585)
   - Key: `iip_date_ctx_v1`
   - Scope: `closed`, `created`, `customer` dashboards

### Filter Persistence Across Navigation
- **Tab Switches**: StateManager restores last-used filters
- **Session Survival**: localStorage persists across page reloads
- **Timestamp**: `timestamp: Date.now()` recorded for debugging

---

## 6. LOADING STATES

### Skeleton Shimmer (Primary)
**Files**: 
- CSS: [css/ui-system.css](css/ui-system.css#L180-L252)
- CSS: [css/core/components.css](css/core/components.css#L751-L784)

#### Animation
```css
@keyframes iip-shimmer {
  0%   { background-position: -600px 0; }
  100% { background-position: 600px 0; }
}
```

#### CSS Classes
```css
.iip-skeleton {
  background: linear-gradient(90deg, var(--bg-layer) 25%, var(--bg-layer-2) 50%, var(--bg-layer) 75%);
  background-size: 600px 100%;
  animation: iip-shimmer 1.4s ease-in-out infinite;
  border-radius: var(--radius-xs);
}

/* Presets */
.iip-skeleton-text    { height: 14px; }
.iip-skeleton-heading { height: 20px; }
.iip-skeleton-kpi     { height: 48px; }
.iip-skeleton-card    { height: 120px; }
.iip-skeleton-avatar  { width: 32px; height: 32px; border-radius: 50%; }
.iip-skeleton-row     { height: 44px; margin-bottom: 1px; }
```

#### Auto-Skeleton for Tables
```css
.skeleton-loading .dash-table tbody tr::after {
  content: '';
  position: absolute;
  inset: 0;
  background: linear-gradient(...);
  animation: iip-shimmer 1.4s ease-in-out infinite;
  z-index: 1;
}
.skeleton-loading .dash-table tbody tr td { 
  color: transparent !important; 
}
```

### Spinner Component
**Usage**: Inline loading indicators

```css
.iip-spinner {
  width: 28px; height: 28px;
  border: 3px solid var(--border-mid);
  border-top-color: var(--ibm-blue-50);
  border-radius: 50%;
  animation: iip-spin 0.7s linear infinite;
}
```

### Progressive Loading Messages
**File**: [js/modules/ui/perf-utils.js](js/modules/ui/perf-utils.js#L261-L285)

#### Random Message Rotation
```javascript
const LOADING_MESSAGES = [
  '🔍 Finding your cases…',
  '📊 Crunching the numbers…',
  '✨ Sorting things out…',
  '⚡ Almost there…',
  '🎯 Getting everything ready…',
  '🚀 Loading at warp speed…',
];

function showLoading(containerEl, message) {
  const msg = message || LOADING_MESSAGES[Math.floor(Math.random() * LOADING_MESSAGES.length)];
  containerEl.innerHTML = `
    <div class="loading-message">
      <span class="loading-spinner-sm"></span>
      <span id="loading-msg-text">${msg}</span>
    </div>`;
}
```

### Undo Toast with Progress Bar
```javascript
// Shrink progress bar over timeout
const bar = toast.querySelector('#undo-progress-bar');
if (bar) {
  bar.style.transition = `width ${UNDO_TIMEOUT_MS}ms linear`;
  requestAnimationFrame(() => bar.style.width = '0%');
}
```

---

## 7. MODAL IMPLEMENTATIONS

**Central Module**: [js/modules/ui/modal.js](js/modules/ui/modal.js)

### Generic Modal API

#### Open/Close
```javascript
Modal.open(title, html)   // Generic modal
Modal.close()             // Close and clear
```

#### Progressive/Lazy Loading
```javascript
Modal.openLazy(title, renderFn, opts = {})
// Shows skeleton immediately, then renders content
// renderFn can return Promise or sync HTML
```

**Options**:
- `skeletonLines` — number of skeleton lines (default: 4)
- `showAvatar` — include avatar placeholder (default: false)

#### Load More Within Modal
```javascript
Modal.wireLoadMore(bodyEl)
// Binds [data-modal-load-more] buttons to lazy-load content
```

### Modal Styling
**File**: [css/features/modals.css](css/features/modals.css#L1-L81)

#### DOM Structure
```html
<div id="modal-overlay" class="modal-overlay">
  <div id="modal-box" class="modal-box">
    <div class="modal-header">
      <h2 id="modal-title" class="modal-title">Title</h2>
      <button id="modal-close" class="modal-close">✕</button>
    </div>
    <div id="modal-body" class="modal-body">Content</div>
    <div class="modal-footer">Footer actions</div>
  </div>
</div>
```

#### Styling
```css
.modal-overlay {
  position: fixed; inset: 0;
  z-index: var(--z-modal);
  background: rgba(0, 0, 0, 0.55);
  backdrop-filter: blur(2px);
  display: flex;
  align-items: center;
  justify-content: center;
  animation: fadeIn 0.15s ease;
}

.modal-box {
  background: var(--bg-ui);
  border: 1px solid var(--border-subtle);
  border-radius: var(--radius-lg);
  max-width: 500px;
  box-shadow: var(--shadow-lg);
  animation: slideUp 0.18s ease;
  border-top: 3px solid var(--ibm-blue-50);
  overflow: visible; /* allow select dropdowns to escape */
}

.modal-close {
  width: 28px; height: 28px;
  background: transparent; 
  border: 1px solid var(--border-mid);
  border-radius: 50%;
  cursor: pointer;
  transition: all var(--t-fast);
}
.modal-close:hover {
  background: var(--red);
  border-color: var(--red);
  color: #fff;
}
```

### Reassign Modal (Complex Example)
**File**: [js/modules/ui/modal.js](js/modules/ui/modal.js#L147-L240)

#### Features
1. **Reassignment History Banner** — Shows previous owner changes
2. **Custom Dropdown** — Fixed position to escape modal clipping
3. **Confirmation Gate** — Disable button until selection made
4. **Floating List** — Positions relative to trigger, appended to body

#### Structure
```html
<div class="reassign-case-preview">
  Case <strong>TS123456</strong> assigned to <strong>John Doe</strong>
</div>

<!-- History if reassigned before -->
<div style="background: rgba(224,112,0,.07);">
  <div>ℹ Already reassigned 2 times</div>
  <div>John → Jane (2025-03-20)</div>
  <div>Jane → Mike (2025-03-19)</div>
</div>

<!-- Dropdown that breaks out of modal -->
<button id="modal-reassign-trigger">— Select new owner —</button>
<div id="modal-reassign-droplist"> <!-- positioned:fixed, z-index:99999 -->
  <div data-value="Alice">Alice</div>
  <div data-value="Bob">Bob</div>
</div>

<!-- Actions -->
<button id="modal-reassign-confirm" disabled>Confirm Reassign</button>
<button id="modal-reassign-cancel">Cancel</button>
```

### RFE Modal (Advanced)
**File**: [js/dashboards/rfe-tracking-advanced.js](js/dashboards/rfe-tracking-advanced.js#L282-L300)

#### Custom Modal System
```javascript
// RFE uses inline fixed modal (not Modal.open)
const modal = document.getElementById('rfe-modal');
modal.style.display = 'flex'; // show

// Backdrop + content box (separate z-index layering)
const backdrop = document.getElementById('rfe-modal-bd');
const box = document.getElementById('rfe-modal-box');
```

#### Animation
```css
@keyframes rfe-modal-in {
  from { opacity: 0; transform: scale(.96) translateY(6px); }
  to   { opacity: 1; transform: scale(1) translateY(0); }
}
```

#### Detail Row Animation
```javascript
// When expanding RFE detail row
.rfe-row-anim { 
  animation: rfe-row-in .24s var(--ease-std) both; 
}

@keyframes rfe-row-in {
  from { opacity: 0; transform: translateY(3px); }
  to   { opacity: 1; transform: translateY(0); }
}
```

### Confirm Modal Component
**File**: [js/modules/ui/ui-components.js](js/modules/ui/ui-components.js#L118-L155)

#### Usage
```javascript
IIPModal.confirm(message, {
  title: 'Confirm Delete',
  icon: '⚠️',
  confirmLabel: 'Delete',
  cancelLabel: 'Cancel',
  danger: true
}).then(result => {
  if (result) { /* confirmed */ }
});
```

#### Structure
```html
<div class="iip-modal-backdrop iip-confirm-modal">
  <div class="iip-modal-card" role="dialog">
    <div class="iip-modal-body" style="text-align: center;">
      <span class="iip-confirm-icon">⚠️</span>
      <h3 id="iip-confirm-title">Confirm Delete</h3>
      <p>Are you sure?</p>
    </div>
    <div class="iip-modal-footer" style="justify-content: center; gap: 12px;">
      <button class="btn btn-secondary">Cancel</button>
      <button class="btn btn-danger">Delete</button>
    </div>
  </div>
</div>
```

### RFE Merge Dialog
**File**: [js/dashboards/admin-dash.js](js/dashboards/admin-dash.js#L4142-L4211)

#### Custom Overlay Pattern
```javascript
const overlay = document.createElement("div");
overlay.style.cssText = "position:fixed;inset:0;z-index:var(--z-modal)9;background:rgba(0,0,0,.55);backdrop-filter:blur(3px);display:flex;align-items:center;justify-content:center";
overlay.innerHTML = `<div style="...">Content</div>`;
document.body.appendChild(overlay);
```

#### Conflict Resolution UI
- Shows count of: existing RFEs, new in file, duplicates
- List of duplicates with scrollable area
- Three action buttons: Merge | Replace All | Cancel
- Explains each action in small text

---

## SUMMARY: Current Patterns & Utilities

### State Management
- **Filters**: StateManager + localStorage
- **Selection**: DOM checkboxes + Map tracking
- **Modal State**: DOM classList + simple booleans
- **Search**: In-memory, no persistence

### DOM Patterns
- InnerHTML for bulk rendering (no VDOM)
- Data attributes for event delegation
- CSS classes for styling states
- Fixed positioning for dropdowns escaping overflow clipping

### Error Handling
- Confirmation dialogs before destructive actions
- Toast notifications for feedback
- Validation with fallback "proceed anyway" options
- Safety guards for bulk operations

### Performance Considerations
- No virtual scrolling (full DOM rendering)
- Debounced search (150ms)
- Skeleton shimmer for perceived performance
- Progressive disclosure (lazy modal content)

### CSS Architecture
- CSS custom properties (--colors, --spacing, --z-levels)
- Utility classes for common patterns (`.btn`, `.form-input`, `.chip`)
- Feature-scoped stylesheets (modals.css, tier1-improvements.css, etc.)
- Animation constants (--t-fast, --t-slow, --ease-std)

---

## Files Index

| Feature | File | Lines |
|---------|------|-------|
| Empty State Component | `js/modules/ui/ui-components.js` | 203-247 |
| Empty State (Search) | `js/modules/ui/perf-utils.js` | 301-332 |
| Global Search | `js/app.js` | 1899-1996 |
| Performance Tagging | `js/dashboards/admin-dash.js` | 1480-1650 |
| Filter Persistence | `js/modules/ui/state-manager.js` | 13-68 |
| Filter Usage (Team) | `js/dashboards/team.js` | 23-48 |
| Loading States (CSS) | `css/ui-system.css` | 180-252 |
| Loading Messages | `js/modules/ui/perf-utils.js` | 261-285 |
| Modal System | `js/modules/ui/modal.js` | 1-150, 147-240 |
| Modal CSS | `css/features/modals.css` | 1-81 |
| RFE Modal | `js/dashboards/rfe-tracking-advanced.js` | 100-300 |
| Confirm Modal | `js/modules/ui/ui-components.js` | 118-155 |
