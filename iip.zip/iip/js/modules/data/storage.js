/* =============================================================================
   js/modules/data/storage.js  —  IIP Storage Adapter  v2.1
   -----------------------------------------------------------------------------
   v2.1 fixes:
   - BUG FIX: Infinite recursion — interceptor now uses a _syncing guard flag
     and IIPStore internal writes bypass the interceptor via _origSetItem
   - BUG FIX: hydrateFromDB gracefully falls back to individual key fetches
     when /api/store-bulk-get returns 404 (old server not yet restarted)
   - BUG FIX: Interceptor no longer fires during hydrateFromDB reads
   - BUG FIX: Writes from interceptor don't re-trigger themselves

   HOW IT WORKS:
     Server mode (http/https):
       • Boot: pulls ALL shared keys from PostgreSQL into localStorage
       • Every dashboard write: syncs to DB automatically via interceptor
       • 60-second poll: re-syncs critical keys for long-running sessions
     File mode (file://): localStorage only, no network calls.
   =============================================================================*/
(function () {
  'use strict';

  const API          = '/api/store';
  const API_PREFIX   = '/api/store-prefix';
  const API_BULK_GET = '/api/store-bulk-get';
  const POLL_MS      = 60 * 1000;

  const _isFileMode = window.location.protocol === 'file:';

  /* ── Admin token ──────────────────────────────────────────────── */
  let _adminToken = '';
  function setAdminToken(token) { _adminToken = token || ''; }
  function getAdminToken()      { return _adminToken; }
  function _writeHeaders() {
    const h = { 'Content-Type': 'application/json' };
    if (_adminToken) h['X-IIP-Admin-Token'] = _adminToken;
    return h;
  }

  /* ── Shared key definitions ───────────────────────────────────── */
  const SHARED_KEYS_EXACT = [
    'ibm_cases_raw_v1',
    'ibm_cases_overrides_v1',
    'ibm_reopened_cases_v1',
    'ibm_import_log_v1',
    'ibm_tracker_persist_v1',
    'ibm_team_config_v1',
    'ibm_wtracker_comments_v1',
    'ibm_wtracker_history',
    'ibm_wtracker_linkmap_v1',
    'ibm_wtracker_seeded_v5',
    'ibm_wtracker_seed_v1',
    'ibm_rfe_tracking_v1',
    'ibm_rfe_tracking_metadata_v1',
    'ibm_rfe_tracking_last_update',
    'ibm_perf_comments_v1',
    'ibm_investigate_archive_v1',
    'ibm_knowledge_base_v2',
    'ibm_admin_pwd_v1',
    'ibm_data_version_v1',
    'admin-perf-cases',
    'admin-non-perf-cases',
    'admin-perf-meta',
    'admin-members',
    'admin-cfg',
    'admin-alm',
    'admin-emails',
    'admin-change-history',
    'admin-emails',
    'admin-expertise',
    'admin-escalation',
    'admin-lead',
    'admin-customers',
    'admin-ibm-dir',
  ];

  const SHARED_PREFIXES = [
    'ibm_wtracker_',
    'ibm_cases_raw_',
    'admin-',
  ];

  const LOCAL_ONLY = new Set([
    'iip_sidebar_collapsed',
    'iip_token',
    'hiw_completed',
    'iip_onb_state_v1',
    'iip_proficiency_v1',
    'ibm_admin_session_v1',
    'ibm_team_config_v1_cache',
    'ibm_wtracker_seeded_v4',
  ]);

  function _isShared(key) {
    if (!key) return false;
    if (LOCAL_ONLY.has(key)) return false;
    if (SHARED_KEYS_EXACT.includes(key)) return true;
    return SHARED_PREFIXES.some(p => key.startsWith(p));
  }

  /* ── SAFE localStorage helpers (always use original, bypass interceptor) ── */
  // Capture the originals BEFORE any interceptor can replace them
  const _origSetItem    = localStorage.setItem.bind(localStorage);
  const _origGetItem    = localStorage.getItem.bind(localStorage);
  const _origRemoveItem = localStorage.removeItem.bind(localStorage);

  function _lsGet(key) {
    try {
      const r = _origGetItem(key);
      return r === null ? null : JSON.parse(r);
    } catch (_) { return null; }
  }

  function _lsSet(key, value) {
    try {
      _origSetItem(key, JSON.stringify(value));
      return true;
    } catch (e) {
      console.warn('[IIPStore] localStorage write failed:', e.message);
      return false;
    }
  }

  // Raw set — value is already a JSON string
  function _lsSetRaw(key, rawStr) {
    try { _origSetItem(key, rawStr); } catch (e) {
      console.warn('[IIPStore] localStorage raw write failed:', key, e.message);
    }
  }

  function _lsDel(key) {
    try { _origRemoveItem(key); } catch (_) {}
  }

  const API_PUBLIC_WRITE = '/api/store-public';

  // Keys that any user can write to DB (no admin token needed)
  const PUBLIC_WRITE_KEYS = new Set([
    'ibm_rfe_tracking_v1',
    'ibm_rfe_tracking_metadata_v1',
    'ibm_rfe_tracking_last_update',
    'ibm_investigate_archive_v1',
  ]);

  async function _apiSetPublic(key, value) {
    try {
      const r = await fetch(API_PUBLIC_WRITE + '/' + encodeURIComponent(key), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ value })
      });
      return r.ok;
    } catch(e) {
      console.warn('[IIPStore] Public API set failed:', e.message);
      return false;
    }
  }

  async function _apiGet(key) {
    try {
      const r = await fetch(API + '/' + encodeURIComponent(key));
      if (!r.ok) return null;
      const d = await r.json();
      return d.value !== undefined ? d.value : null;
    } catch (e) {
      console.warn('[IIPStore] API get failed:', e.message);
      return _lsGet(key);
    }
  }

  async function _apiSet(key, value) {
    if (!_adminToken) return false; // No token — skip silently
    try {
      const r = await fetch(API + '/' + encodeURIComponent(key), {
        method: 'POST',
        headers: _writeHeaders(),
        body: JSON.stringify({ value })
      });
      return r.ok;
    } catch (e) {
      console.warn('[IIPStore] API set failed:', e.message);
      return false;
    }
  }

  async function _apiDel(key) {
    if (!_adminToken) return;
    try {
      await fetch(API + '/' + encodeURIComponent(key), {
        method: 'DELETE',
        headers: _writeHeaders()
      });
    } catch (e) {}
  }

  /* ── Write value from DB response into localStorage correctly ─── */
  // DB (PostgreSQL JSONB) returns values as already-parsed JS objects/arrays.
  // We need to store them as JSON strings in localStorage.
  function _applyFromDB(key, value) {
    if (value === null || value === undefined) return;
    // value from pg JSONB is already a JS object/array/string/number
    // _lsSet will JSON.stringify it correctly
    _lsSet(key, value);
  }

  /* ── Boot hydration ───────────────────────────────────────────── */
  let _hydrated   = false;
  let _hydrating  = false; // guard: prevent interceptor firing during hydration

  async function hydrateFromDB() {
    if (_isFileMode || _hydrated) return;
    _hydrated  = true;
    _hydrating = true;

    try {
      // Strategy: try bulk-get first (v2.0 server), fall back to individual
      // fetches (v1.x server still running old server.js)
      let hydrated = 0;

      // === Attempt 1: Bulk-get (requires server v2.0) ===
      let usedBulk = false;
      try {
        const r = await fetch(API_BULK_GET, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ keys: SHARED_KEYS_EXACT })
        });
        if (r.ok) {
          const { entries } = await r.json();
          if (entries) {
            Object.entries(entries).forEach(([key, value]) => {
              _applyFromDB(key, value);
              hydrated++;
            });
            usedBulk = true;
          }
        }
      } catch(e) {}

      // === Attempt 1b: Prefix fetch for wtracker years (server v2.0) ===
      if (usedBulk) {
        try {
          const r = await fetch(API_PREFIX + '/ibm_wtracker_');
          if (r.ok) {
            const { entries } = await r.json();
            if (entries) {
              Object.entries(entries).forEach(([key, value]) => {
                if (/ibm_wtracker_\d{4}$/.test(key)) {
                  _applyFromDB(key, value);
                  hydrated++;
                }
              });
            }
          }
        } catch(e) {}

        // Prefix fetch for admin-* keys
        try {
          const r = await fetch(API_PREFIX + '/admin-');
          if (r.ok) {
            const { entries } = await r.json();
            if (entries) {
              Object.entries(entries).forEach(([key, value]) => {
                _applyFromDB(key, value);
                hydrated++;
              });
            }
          }
        } catch(e) {}
      }

      // === Fallback: Individual key fetches (server v1.x — old server.js) ===
      if (!usedBulk) {
        console.info('[IIPStore] Bulk endpoint not available — using individual fetches (old server)');
        const criticalKeys = [
          'ibm_cases_raw_v1',
          'ibm_tracker_persist_v1',
          'ibm_wtracker_comments_v1',
          'ibm_rfe_tracking_v1',
          'ibm_rfe_tracking_metadata_v1',
          'ibm_reopened_cases_v1',
          'ibm_cases_overrides_v1',
          'ibm_import_log_v1',
        ];
        for (const key of criticalKeys) {
          try {
            const r = await fetch(API + '/' + encodeURIComponent(key));
            if (r.ok) {
              const d = await r.json();
              if (d.value !== null && d.value !== undefined) {
                _applyFromDB(key, d.value);
                hydrated++;
              }
            }
          } catch(e) {}
        }
      }

      console.info(`[IIPStore] Boot hydration complete — ${hydrated} keys loaded from DB (${usedBulk ? 'bulk' : 'individual'})`);
    } catch (e) {
      console.warn('[IIPStore] Boot hydration failed — using localStorage:', e.message);
    } finally {
      _hydrating = false;
    }
  }

  /* ── 60-second polling ────────────────────────────────────────── */
  const POLL_KEYS = [
    'ibm_rfe_tracking_v1',
    'ibm_rfe_tracking_metadata_v1',
    'ibm_wtracker_comments_v1',
    'ibm_wtracker_history',
    'ibm_tracker_persist_v1',
    'ibm_perf_comments_v1',
    'ibm_cases_raw_v1',
    'ibm_data_version_v1',
    'ibm_investigate_archive_v1',
  ];

  async function _pollSharedKeys() {
    if (_isFileMode || _hydrating) return;
    _hydrating = true;
    try {
      // Try bulk first, fall back to individual
      let ok = false;
      try {
        const r = await fetch(API_BULK_GET, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ keys: POLL_KEYS })
        });
        if (r.ok) {
          const { entries } = await r.json();
          if (entries) {
            Object.entries(entries).forEach(([key, value]) => _applyFromDB(key, value));
            ok = true;
          }
        }
      } catch(e) {}

      if (!ok) {
        // Old server fallback — individual fetches
        for (const key of POLL_KEYS) {
          try {
            const r = await fetch(API + '/' + encodeURIComponent(key));
            if (r.ok) {
              const d = await r.json();
              if (d.value !== null) _applyFromDB(key, d.value);
            }
          } catch(e) {}
        }
      }
    } catch(e) {}
    finally { _hydrating = false; }
  }

  if (!_isFileMode) {
    setInterval(_pollSharedKeys, POLL_MS);
  }

  /* ── Public API ───────────────────────────────────────────────── */

  async function set(key, value) {
    _lsSet(key, value);
    if (!_isFileMode && _isShared(key)) {
      if (_adminToken) {
        // Admin path — authenticated write
        _apiSet(key, value).catch(() => {});
      } else if (PUBLIC_WRITE_KEYS.has(key)) {
        // Public path — allowed without admin token (RFE, Investigate)
        _apiSetPublic(key, value).catch(() => {});
      }
    }
    return true;
  }

  async function get(key) {
    const local = _lsGet(key);
    if (local !== null) return local;
    if (!_isFileMode && _isShared(key)) {
      const remote = await _apiGet(key);
      if (remote !== null) { _lsSet(key, remote); return remote; }
    }
    return null;
  }

  function getSync(key) { return _lsGet(key); }

  async function remove(key) {
    _lsDel(key);
    if (!_isFileMode && _isShared(key)) _apiDel(key).catch(() => {});
  }

  const KEYS = {
    CASES_RAW:        'ibm_cases_raw_v1',
    CASES_OVERRIDES:  'ibm_cases_overrides_v1',
    REOPENED_CASES:   'ibm_reopened_cases_v1',
    TRACKER_PERSIST:  'ibm_tracker_persist_v1',
    TEAM_CONFIG:      'ibm_team_config_v1',
    TRACKER_COMMENTS: 'ibm_wtracker_comments_v1',
    IMPORT_LOG:       'ibm_import_log_v1',
    RFE_DATA:         'ibm_rfe_tracking_v1',
    RFE_META:         'ibm_rfe_tracking_metadata_v1',
    INVESTIGATE:      'ibm_investigate_archive_v1',
    PERF_COMMENTS:    'ibm_perf_comments_v1',
    DATA_VERSION:     'ibm_data_version_v1',
  };

  const setCases     = rows => set(KEYS.CASES_RAW, rows);
  const getCases     = ()   => get(KEYS.CASES_RAW).then(d => Array.isArray(d) ? d : null);
  const setOverrides = ov   => set(KEYS.CASES_OVERRIDES, ov);
  const getOverrides = ()   => get(KEYS.CASES_OVERRIDES).then(d => (d && typeof d === 'object') ? d : {});
  const setReopened  = arr  => set(KEYS.REOPENED_CASES, arr);
  const getReopened  = ()   => get(KEYS.REOPENED_CASES).then(d => Array.isArray(d) ? d : []);

  // Data version — written after every re-upload so other users can detect a change
  const setDataVersion = (ts) => set(KEYS.DATA_VERSION, ts || Date.now());
  const getDataVersion = ()   => get(KEYS.DATA_VERSION).then(d => d || null);
  // Sync-read from localStorage only (no network) — used by the banner poller
  const getDataVersionSync = () => _lsGet(KEYS.DATA_VERSION);

  window.IIPStore = {
    set, get, getSync, remove,
    hydrateFromDB,
    setCases, getCases,
    setOverrides, getOverrides,
    setReopened, getReopened,
    setDataVersion, getDataVersion, getDataVersionSync,
    setAdminToken, getAdminToken,
    KEYS,
    mode:         _isFileMode ? 'local' : 'server',
    isFileMode:   () => _isFileMode,
    isServerMode: () => !_isFileMode,
    isShared:     _isShared,
  };

  /* ── localStorage interceptor ─────────────────────────────────── */
  // Syncs any localStorage.setItem call for a shared key to the DB.
  // Uses _hydrating guard to prevent firing during boot hydration.
  // Uses _origSetItem internally to avoid infinite recursion.
  if (!_isFileMode) {
    // _origSetItem was already captured at the top of this IIFE
    // Any call to localStorage.setItem from OUTSIDE this module goes through
    // the intercepted version below. Calls from INSIDE this module use
    // _origSetItem directly (via _lsSet / _lsSetRaw) — no recursion possible.

    let _intercepting = false; // extra guard against recursion

    localStorage.setItem = function(key, value) {
      // Always write to storage first
      _origSetItem(key, value);

      // Skip DB sync during hydration or re-entrant calls
      if (_hydrating || _intercepting) return;
      if (!_isShared(key)) return;

      _intercepting = true;
      try {
        let parsed;
        try { parsed = JSON.parse(value); } catch(e) { parsed = value; }

        if (_adminToken) {
          // Admin — full write access
          _apiSet(key, parsed).catch(() => {});
        } else if (PUBLIC_WRITE_KEYS.has(key)) {
          // Non-admin — allowed for public-write keys (RFE, Investigate)
          _apiSetPublic(key, parsed).catch(() => {});
        }
      } catch(e) {}
      finally { _intercepting = false; }
    };

    localStorage.removeItem = function(key) {
      _origRemoveItem(key);
      if (!_hydrating && !_intercepting && _isShared(key) && _adminToken) {
        _apiDel(key).catch(() => {});
      }
    };

    console.info('[IIPStore] v2.1 ready — localStorage interceptor active');
  }

}());
