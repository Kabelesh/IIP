/* ============================================================
   js/modules/admin/admin.js  —  Admin Module  v1.1.0
   ────────────────────────────────────────────────────────────
   v1.1.0 changes (Phase 2):
   • Login now calls POST /api/auth — server-side bcrypt verify
   • Admin token NEVER stored in localStorage — sessionStorage only
   • Password change calls POST /api/auth/set-password
   • Legacy localStorage token read removed
   ============================================================ */
const Admin = (() => {
  'use strict';

  const ADMIN_PWD_KEY     = 'ibm_admin_pwd_v1';
  const ADMIN_TOKEN_KEY   = 'ibm_admin_token_v1';
  const SESSION_KEY       = 'ibm_admin_session_v1';

  let _role  = 'write';
  let _actor = 'Admin';

  function _getLsPwd() {
    try {
      let v = localStorage.getItem(ADMIN_PWD_KEY);
      if (v === null) return null;
      // Handle legacy double-encoding: if stored as JSON-quoted string, unwrap it
      if (v.startsWith('"') && v.endsWith('"')) {
        try { v = JSON.parse(v); } catch(e) {}
      }
      return v || null;
    } catch(e) { return null; }
  }
  function _setLsPwd(pwd) {
    try { localStorage.setItem(ADMIN_PWD_KEY, pwd); } catch(e) {}
  }
  // Token is ONLY stored in sessionStorage (tab-scoped, never persisted to disk)
  function _getSessionToken() {
    try { return sessionStorage.getItem(ADMIN_TOKEN_KEY) || ''; }
    catch(e) { return ''; }
  }
  function _setSessionToken(token) {
    try {
      sessionStorage.setItem(ADMIN_TOKEN_KEY, token);
      // Scrub any legacy localStorage token
      try { localStorage.removeItem(ADMIN_TOKEN_KEY); } catch(e) {}
      try { localStorage.removeItem('ibm_admin_token_v1'); } catch(e) {}
    } catch(e) {}
  }

  function _isFirstTimeSetup() {
    return _getLsPwd() === null;
  }

  function updateHeader() {
    const adminBtn = document.getElementById('admin-btn');
    const isAdmin  = (typeof Data !== 'undefined') ? Data.isAdmin() : false;
    if (adminBtn) adminBtn.style.display = isAdmin ? 'flex' : 'none';
  }

  function showLoginModal() {
    const existing = document.getElementById('admin-login-modal');
    if (existing) { existing.remove(); }

    const isSetup = _isFirstTimeSetup();

    const modal = document.createElement('div');
    modal.id = 'admin-login-modal';
    modal.style.cssText = [
      'position:fixed;inset:0;z-index:var(--z-modal)',
      'display:flex;align-items:center;justify-content:center',
      'background:rgba(0,0,0,0.55)'
    ].join(';');

    modal.innerHTML = isSetup ? `
      <div style="background:var(--bg-ui);border-radius:var(--radius-lg);padding:32px 36px;width:380px;box-shadow:var(--shadow-xl)">
        <h3 style="margin:0 0 6px;font-size:16px;font-weight:700;color:var(--text-primary)">Admin Setup</h3>
        <p style="margin:0 0 18px;font-size:13px;color:var(--text-secondary);line-height:1.5">No admin password has been configured. Set one now to secure the Admin Portal.</p>
        <input id="admin-pwd-new" type="password" placeholder="New password (min 8 characters)"
          style="width:100%;padding:9px 12px;border:1px solid var(--border-mid);border-radius:var(--radius-sm);font-size:14px;margin-bottom:10px;box-sizing:border-box;background:var(--bg-input);color:var(--text-primary)"/>
        <input id="admin-pwd-confirm" type="password" placeholder="Confirm password"
          style="width:100%;padding:9px 12px;border:1px solid var(--border-mid);border-radius:var(--radius-sm);font-size:14px;margin-bottom:10px;box-sizing:border-box;background:var(--bg-input);color:var(--text-primary)"/>
        <input id="admin-token-input" type="text" placeholder="API Admin Token (from server console)"
          style="width:100%;padding:9px 12px;border:1px solid var(--border-mid);border-radius:var(--radius-sm);font-size:14px;margin-bottom:14px;box-sizing:border-box;background:var(--bg-input);color:var(--text-primary)"/>
        <div id="admin-login-err" style="color:var(--red);font-size:12px;margin-bottom:10px;display:none"></div>
        <div style="display:flex;gap:8px;justify-content:flex-end">
          <button id="admin-login-cancel" class="btn btn-ghost btn-sm">Cancel</button>
          <button id="admin-login-submit" class="btn btn-primary btn-sm">Set Password</button>
        </div>
      </div>` : `
      <div style="background:var(--bg-ui);border-radius:var(--radius-lg);padding:32px 36px;width:340px;box-shadow:var(--shadow-xl)">
        <h3 style="margin:0 0 20px;font-size:16px;font-weight:700;color:var(--text-primary)">Admin Login</h3>
        <input id="admin-pwd-input" type="password" placeholder="Password"
          style="width:100%;padding:9px 12px;border:1px solid var(--border-mid);border-radius:var(--radius-sm);font-size:14px;margin-bottom:14px;box-sizing:border-box;background:var(--bg-input);color:var(--text-primary)"/>
        <div id="admin-login-err" style="color:var(--red);font-size:12px;margin-bottom:10px;display:none">Incorrect password</div>
        <div style="display:flex;gap:8px;justify-content:flex-end">
          <button id="admin-login-cancel" class="btn btn-ghost btn-sm">Cancel</button>
          <button id="admin-login-submit" class="btn btn-primary btn-sm">Login</button>
        </div>
      </div>`;

    document.body.appendChild(modal);

    const errEl  = modal.querySelector('#admin-login-err');
    const submit = modal.querySelector('#admin-login-submit');
    const cancel = modal.querySelector('#admin-login-cancel');

    if (isSetup) {
      const newPwd   = modal.querySelector('#admin-pwd-new');
      const confPwd  = modal.querySelector('#admin-pwd-confirm');
      const tokenInp = modal.querySelector('#admin-token-input');

      const _setupAttempt = async () => {
        const np = newPwd.value;
        const cp = confPwd.value;
        if (np.length < 8) {
          errEl.textContent = 'Password must be at least 8 characters.';
          errEl.style.display = '';
          return;
        }
        if (np !== cp) {
          errEl.textContent = 'Passwords do not match.';
          errEl.style.display = '';
          return;
        }
        submit.disabled = true;
        submit.textContent = 'Setting…';
        try {
          // Store password hash server-side via set-password endpoint
          // On first setup there is no current password — send empty string
          const tok = _getSessionToken() || '';
          const r = await fetch('/api/auth/set-password', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-IIP-Admin-Token': tok },
            body: JSON.stringify({ currentPassword: '', newPassword: np })
          });
          const data = await r.json();
          if (!r.ok) {
            errEl.textContent = data.error || 'Failed to set password.';
            errEl.style.display = '';
            submit.disabled = false;
            submit.textContent = 'Set Password';
            return;
          }
          // Now login with the new password to get the token
          const lr = await fetch('/api/auth', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ password: np })
          });
          const ldata = await lr.json();
          if (lr.ok && ldata.token) {
            _setSessionToken(ldata.token);
            _setLsPwd(np); // keep local pwd for offline fallback
            _onLoginSuccess(ldata.token);
            modal.remove();
          } else {
            errEl.textContent = ldata.error || 'Setup succeeded but login failed. Reload and try.';
            errEl.style.display = '';
          }
        } catch(e) {
          errEl.textContent = 'Network error. Check server connection.';
          errEl.style.display = '';
        }
        submit.disabled = false;
        submit.textContent = 'Set Password';
      };
      submit.addEventListener('click', _setupAttempt);
      confPwd.addEventListener('keydown', e => { if (e.key === 'Enter') _setupAttempt(); });
      setTimeout(() => newPwd.focus(), 50);
    } else {
      const input = modal.querySelector('#admin-pwd-input');

      const _attempt = async () => {
        const pwd = input.value;
        if (!pwd) return;
        submit.disabled = true;
        submit.textContent = 'Checking…';
        try {
          const r = await fetch('/api/auth', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ password: pwd })
          });
          const data = await r.json();
          if (r.ok && data.token) {
            _setSessionToken(data.token);
            _setLsPwd(pwd); // keep local copy for offline fallback
            modal.remove();
            _onLoginSuccess(data.token);
          } else {
            errEl.textContent = data.error || 'Incorrect password.';
            errEl.style.display = '';
            input.value = '';
            input.focus();
          }
        } catch(e) {
          // Network error — fall back to local password check
          if (pwd === _getLsPwd()) {
            const fallbackToken = _getSessionToken();
            modal.remove();
            _onLoginSuccess(fallbackToken);
          } else {
            errEl.textContent = 'Server unreachable. Check connection.';
            errEl.style.display = '';
          }
        }
        submit.disabled = false;
        submit.textContent = 'Login';
      };
      submit.addEventListener('click', _attempt);
      input.addEventListener('keydown', e => { if (e.key === 'Enter') _attempt(); });
      setTimeout(() => input.focus(), 50);
    }

    cancel.addEventListener('click', () => modal.remove());
    modal.addEventListener('click', e => { if (e.target === modal) modal.remove(); });
  }

  function _onLoginSuccess(token) {
    if (typeof Data !== 'undefined') Data.setAdminMode(true);
    // Set the API write token so IIPStore can make authenticated writes
    if (typeof IIPStore !== 'undefined' && token) {
      IIPStore.setAdminToken(token);
    }
    try { sessionStorage.setItem(SESSION_KEY, '1'); } catch(e) {}
    if (token) _setSessionToken(token);
    updateHeader();
    try { if (typeof App !== 'undefined') App.renderTab('admin'); } catch(e) {}
  }

  function logout() {
    if (typeof Data !== 'undefined') Data.setAdminMode(false);
    if (typeof IIPStore !== 'undefined') IIPStore.setAdminToken('');
    try { sessionStorage.removeItem(SESSION_KEY); } catch(e) {}
    try { sessionStorage.removeItem(ADMIN_TOKEN_KEY); } catch(e) {}
    updateHeader();
    try { if (typeof App !== 'undefined') App.renderTab('overview'); } catch(e) {}
  }

  async function changePassword(currentPwd, newPwd) {
    if (newPwd.length < 8) return { ok: false, error: 'New password must be at least 8 characters' };
    try {
      const token = _getSessionToken();
      const r = await fetch('/api/auth/set-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-IIP-Admin-Token': token },
        body: JSON.stringify({ currentPassword: currentPwd, newPassword: newPwd })
      });
      const data = await r.json();
      if (r.ok) { _setLsPwd(newPwd); return { ok: true }; }
      return { ok: false, error: data.error || 'Failed to change password.' };
    } catch(e) {
      // Offline fallback
      if (currentPwd !== _getLsPwd()) return { ok: false, error: 'Current password incorrect' };
      _setLsPwd(newPwd);
      return { ok: true };
    }
  }

  function _wireAdminBtn() {
    const btn = document.getElementById('admin-btn');
    if (!btn) return;
    btn.addEventListener('click', () => {
      if (typeof Data !== 'undefined' && Data.isAdmin()) logout();
      else showLoginModal();
    });
  }

  function _wireAdminNavItem() {
    const navBtn = document.getElementById('nav-admin-portal');
    if (!navBtn) return;
    navBtn.addEventListener('click', e => {
      if (typeof Data !== 'undefined' && !Data.isAdmin()) {
        e.stopImmediatePropagation();
        showLoginModal();
      }
    }, true);
  }

  function _wireNavDirtyGuard() {} // no-op without server sessions

  function setDirtyGuard() {}

  async function checkSession() { return false; }

  async function init() {
    updateHeader();
    _wireAdminBtn();
    _wireAdminNavItem();
    _wireNavDirtyGuard();
    // Restore admin session from sessionStorage (survives F5 but not tab close)
    try {
      if (sessionStorage.getItem(SESSION_KEY) === '1') {
        if (typeof Data !== 'undefined') Data.setAdminMode(true);
        // Token is sessionStorage-only — never read from localStorage
        const cachedToken = _getSessionToken();
        if (typeof IIPStore !== 'undefined' && cachedToken) {
          IIPStore.setAdminToken(cachedToken);
        }
        updateHeader();
      }
    } catch(e) {}
  }

  return { init, updateHeader, showLoginModal, logout, checkSession, changePassword, getActor: () => _actor, getRole: () => _role, isWriter: () => true, setDirtyGuard };
})();
