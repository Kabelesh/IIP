/* ================================================================
   js/modules/ui/polish.js
   Tier 4 & 5 — Preventive Design + Delight on Success

   4.1  ActionGuard  — disable buttons, show state chips, validate fields
   4.1  NetworkMonitor — online/offline detection + smart error routing
   5.3  Celebrate     — confetti, success toasts, haptic feedback
   5.3  AutoSave      — saving indicator for forms (wt-save, admin)

   All features auto-initialise; nothing needs to be called manually.
   Exports window.Polish for use in dashboards.
   ================================================================ */

const Polish = (() => {
  'use strict';

  /* ================================================================
     NETWORK MONITOR — detect online/offline, reroute PerfUtils errors
     ================================================================ */
  const NetworkMonitor = (() => {
    let _statusBar = null;
    let _backOnlineTimeout = null;

    function _showBar(type, message) {
      _statusBar?.remove();
      const bar = document.createElement('div');
      bar.className = `network-status-bar ${type}`;
      bar.innerHTML = `<span class="network-status-dot"></span><span>${message}</span>`;
      document.body.prepend(bar);
      _statusBar = bar;
    }

    function _hideBar() {
      _statusBar?.remove();
      _statusBar = null;
    }

    function _onOffline() {
      clearTimeout(_backOnlineTimeout);
      _showBar('offline', '📡 No internet connection — working offline. Changes saved locally.');
      // Notify PerfUtils if available
      if (typeof PerfUtils !== 'undefined') {
        PerfUtils.showError('network-offline');
      }
    }

    function _onOnline() {
      clearTimeout(_backOnlineTimeout);
      _showBar('back-online', '✓ Back online — your changes will sync automatically.');
      _backOnlineTimeout = setTimeout(_hideBar, 3500);
    }

    function init() {
      window.addEventListener('offline', _onOffline);
      window.addEventListener('online', _onOnline);
      // Show immediately if already offline
      if (!navigator.onLine) _onOffline();
    }

    return { init, isOnline: () => navigator.onLine };
  })();

  /* ================================================================
     ACTION GUARD — preventive button state management
     ================================================================ */
  const ActionGuard = (() => {

    /**
     * guard(buttonEl, conditionsFn, helpTextFn)
     * Keeps a button disabled until all conditions pass.
     * Adds tooltip with helpful explanation when disabled.
     *
     * conditionsFn() → { hasChanges: bool, isValid: bool, isOnline: bool }
     * helpTextFn(conditions) → string (shown as title tooltip)
     */
    function guard(buttonEl, conditionsFn, helpTextFn) {
      if (!buttonEl) return;

      function update() {
        const cond = conditionsFn();
        const ready = Object.values(cond).every(Boolean);
        buttonEl.disabled = !ready;
        buttonEl.title = helpTextFn ? helpTextFn(cond) : (ready ? 'Ready' : 'Not ready');
        buttonEl.classList.toggle('btn-action-ready', ready);
      }

      update();
      return { update };
    }

    /**
     * wrapSaveButton(buttonEl, opts)
     * Manages a save button's full lifecycle:
     *   - Disabled when no changes
     *   - Pulse animation when ready
     *   - Shows save-state chip (Pending → Saving → Saved / Error)
     */
    function wrapSaveButton(buttonEl, opts = {}) {
      if (!buttonEl) return;
      const { chipEl, onSave, getHasChanges, checkOnline = true } = opts;

      function _setChip(state, text) {
        if (!chipEl) return;
        chipEl.className = `save-state-chip state-${state}`;
        chipEl.textContent = text;
        chipEl.style.display = text ? 'inline-flex' : 'none';
      }

      function _updateButton() {
        const hasChanges = getHasChanges ? getHasChanges() : true;
        const isOnline   = !checkOnline || navigator.onLine;
        const ready      = hasChanges && isOnline;
        buttonEl.disabled = !ready;
        buttonEl.classList.toggle('btn-action-ready', ready);

        if (!isOnline) {
          _setChip('error', '📡 Offline');
          buttonEl.title = 'No internet connection — will sync when online';
        } else if (!hasChanges) {
          _setChip('', '');
          buttonEl.title = 'No changes to save';
        } else {
          _setChip('pending', '● Unsaved changes');
          buttonEl.title = 'Click to save your changes';
        }
      }

      async function _doSave(e) {
        if (!onSave) return;
        e.preventDefault();
        buttonEl.disabled = true;
        buttonEl.classList.remove('btn-action-ready');
        _setChip('pending', '⟳ Saving…');
        try {
          await onSave();
          _setChip('saved', '✓ Saved');
          // Brief success state, then clear
          setTimeout(() => _setChip('', ''), 2500);
        } catch (err) {
          _setChip('error', '✗ Save failed');
          if (typeof PerfUtils !== 'undefined') {
            PerfUtils.showError({ category: 'generic', title: 'Save Failed', message: err?.message || 'Please try again.' });
          }
          setTimeout(_updateButton, 3000);
        }
      }

      buttonEl.addEventListener('click', _doSave);
      _updateButton();

      // Re-check on network change
      window.addEventListener('online',  _updateButton);
      window.addEventListener('offline', _updateButton);

      return { update: _updateButton };
    }

    /**
     * validateField(inputEl, validateFn)
     * Real-time inline validation on blur/input.
     * validateFn(value) → null (valid) | 'Error message' (invalid)
     */
    function validateField(inputEl, validateFn) {
      if (!inputEl) return;

      function _showResult(error) {
        // Remove existing feedback
        inputEl.parentElement.querySelectorAll('.field-error,.field-ok').forEach(el => el.remove());
        inputEl.classList.remove('input-invalid', 'input-valid');

        if (error) {
          inputEl.classList.add('input-invalid');
          const el = document.createElement('div');
          el.className = 'field-error';
          el.textContent = error;
          inputEl.insertAdjacentElement('afterend', el);
        } else {
          inputEl.classList.add('input-valid');
          const el = document.createElement('div');
          el.className = 'field-ok';
          el.textContent = 'Looks good';
          inputEl.insertAdjacentElement('afterend', el);
        }
      }

      inputEl.addEventListener('blur', () => {
        const error = validateFn(inputEl.value);
        _showResult(error);
      });

      inputEl.addEventListener('input', () => {
        // Clear error immediately when user starts typing
        if (inputEl.classList.contains('input-invalid')) {
          inputEl.parentElement.querySelectorAll('.field-error').forEach(el => el.remove());
          inputEl.classList.remove('input-invalid');
        }
      });
    }

    /**
     * confirmDestructive(buttonEl, message, onConfirm)
     * Two-step confirmation for dangerous actions (delete, bulk close, etc.)
     * First click → button turns red + shows "Are you sure? Click again to confirm"
     * Second click → executes onConfirm
     */
    function confirmDestructive(buttonEl, message, onConfirm) {
      if (!buttonEl) return;
      let _confirmed = false;
      let _resetTimeout = null;

      buttonEl.addEventListener('click', e => {
        e.stopPropagation();
        if (!_confirmed) {
          _confirmed = true;
          const origText = buttonEl.textContent;
          buttonEl.textContent = '⚠ ' + (message || 'Click again to confirm');
          buttonEl.classList.add('btn-confirm-pending');
          _resetTimeout = setTimeout(() => {
            _confirmed = false;
            buttonEl.textContent = origText;
            buttonEl.classList.remove('btn-confirm-pending');
          }, 3500);
        } else {
          clearTimeout(_resetTimeout);
          _confirmed = false;
          buttonEl.classList.remove('btn-confirm-pending');
          if (typeof onConfirm === 'function') onConfirm();
        }
      });
    }

    return { guard, wrapSaveButton, validateField, confirmDestructive };
  })();

  /* ================================================================
     CELEBRATE — success micro-moments
     ================================================================ */
  const Celebrate = (() => {
    const CONFETTI_COLORS = [
      '#0f62fe', '#198038', '#a67800', '#6929c4', '#da1e28', '#ff832b', '#007d79'
    ];

    /**
     * show(opts)
     * opts: {
     *   title     : '🎉 12 cases closed!',
     *   message   : 'Great progress this week!',
     *   count     : 12,           // if ≥ 10, triggers confetti
     *   duration  : 3500,
     *   onDismiss : fn,
     * }
     */
    function show(opts = {}) {
      const { title = 'Done!', message = '', count = 0, duration = 3500, onDismiss } = opts;



      // Confetti for big wins
      if (count >= 10) _spawnConfetti(count);

      // Success toast
      const toast = document.createElement('div');
      toast.className = 'success-celebration';
      toast.innerHTML = `
        <div class="success-celebration-icon" aria-hidden="true">
          ${count >= 10 ? '🎉' : count >= 5 ? '✅' : '✓'}
        </div>
        <div class="success-celebration-text">
          <div class="success-celebration-title">${_esc(title)}</div>
          ${message ? `<div class="success-celebration-msg">${_esc(message)}</div>` : ''}
        </div>`;

      document.body.appendChild(toast);

      // Track proficiency
      try { if (typeof Onboarding !== 'undefined') Onboarding.track('success_action'); } catch {}

      const remove = () => {
        toast.style.transition = 'opacity 0.3s, transform 0.3s';
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(-50%) translateY(12px)';
        setTimeout(() => { toast.remove(); if (onDismiss) onDismiss(); }, 320);
      };

      toast.addEventListener('click', remove);
      if (duration > 0) setTimeout(remove, duration);

      return { dismiss: remove };
    }

    /**
     * celebrateRow(rowEl)
     * Briefly highlights and bounces a table row after an action
     */
    function celebrateRow(rowEl) {
      if (!rowEl) return;
      rowEl.classList.add('row-celebrated');
      setTimeout(() => rowEl.classList.remove('row-celebrated'), 600);
    }

    /**
     * highlightRow(rowEl)
     * Flash-highlight a row as "just updated" (e.g. after undo)
     */
    function highlightRow(rowEl) {
      if (!rowEl) return;
      rowEl.classList.add('row-just-updated');
      setTimeout(() => rowEl.classList.remove('row-just-updated'), 1800);
    }

    function _spawnConfetti(count) {
      const clamp = Math.min(count, 30);
      for (let i = 0; i < clamp; i++) {
        setTimeout(() => {
          const p = document.createElement('div');
          p.className = 'confetti-particle';
          p.style.cssText = [
            `background:${CONFETTI_COLORS[i % CONFETTI_COLORS.length]}`,
            `left:${20 + Math.random() * 60}%`,
            `top:${window.innerHeight * 0.6 + Math.random() * 40}px`,
            `animation-duration:${0.7 + Math.random() * 0.5}s`,
            `animation-delay:${Math.random() * 0.3}s`,
            `width:${6 + Math.random() * 6}px`,
            `height:${6 + Math.random() * 6}px`,
            `border-radius:${Math.random() > 0.5 ? '50%' : '2px'}`,
          ].join(';');
          document.body.appendChild(p);
          p.addEventListener('animationend', () => p.remove(), { once: true });
        }, i * 30);
      }
    }

    return { show, celebrateRow, highlightRow };
  })();

  /* ================================================================
     AUTO-SAVE INDICATOR — wraps WTSave and admin save points
     ================================================================ */
  const AutoSave = (() => {
    /**
     * wrap(indicatorEl, saveFn, opts)
     * indicatorEl — a .autosave-indicator element to update
     * saveFn      — async function to call; returns a Promise
     * opts        — { debounceMs: 800 }
     *
     * Returns a function: call it whenever data changes to trigger debounced save.
     */
    function wrap(indicatorEl, saveFn, opts = {}) {
      const { debounceMs = 800 } = opts;
      let _timer = null;

      function _setStatus(state, text) {
        if (!indicatorEl) return;
        indicatorEl.className = `autosave-indicator ${state}`;
        indicatorEl.innerHTML = `<span class="autosave-dot"></span>${_esc(text)}`;
      }

      function trigger() {
        clearTimeout(_timer);
        _setStatus('saving', 'Saving…');
        _timer = setTimeout(async () => {
          try {
            await saveFn();
            _setStatus('saved', 'Saved');
            setTimeout(() => { if (indicatorEl) indicatorEl.innerHTML = ''; }, 2500);
          } catch (err) {
            _setStatus('error', 'Save failed');
            if (typeof PerfUtils !== 'undefined') {
              PerfUtils.showError({ category: 'generic', title: 'Auto-save Failed', message: 'Your changes could not be saved. Please try again.' });
            }
          }
        }, debounceMs);
      }

      return trigger;
    }

    return { wrap };
  })();

  /* ================================================================
     INIT
     ================================================================ */
  function init() {
    NetworkMonitor.init();
  }

  // Auto-init when app is ready — wait for App to exist
  function _waitForApp() {
    if (typeof App !== 'undefined') {
      // Init after a short delay so App is fully wired
      setTimeout(init, 500);
    } else {
      setTimeout(_waitForApp, 200);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', _waitForApp);
  } else {
    _waitForApp();
  }

  function _esc(s) {
    return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

  return {
    NetworkMonitor,
    ActionGuard,
    Celebrate,
    AutoSave,
    init,
  };
})();
