/* ================================================================
   js/modules/ui/onboarding.js
   Tier 2 — Superior User Onboarding & Guided Tours

   Exports a single global: Onboarding

   Public API:
     Onboarding.init()          — call once after App.showApp()
     Onboarding.startTour()     — launch the guided tour manually
     Onboarding.track(action)   — record a feature usage event
     Onboarding.proficiency()   — returns 'beginner'|'intermediate'|'advanced'
     Onboarding.resetAll()      — clear all onboarding data (for testing)

   Storage keys (localStorage):
     iip_onb_state_v1    — {seen, tourDone, dykDismissed[], visitCounts{}}
     iip_proficiency_v1  — {actions{}, level, lastUpdated}
   ================================================================ */

const Onboarding = (() => {
  'use strict';

  /* ── Storage helpers ──────────────────────────────────────────── */
  const ONB_KEY  = 'iip_onb_state_v1';
  const PROF_KEY = 'iip_proficiency_v1';

  function _loadOnb() {
    try { return JSON.parse(localStorage.getItem(ONB_KEY) || '{}'); } catch { return {}; }
  }
  function _saveOnb(d) {
    try { localStorage.setItem(ONB_KEY, JSON.stringify(d)); } catch {}
  }
  function _loadProf() {
    try { return JSON.parse(localStorage.getItem(PROF_KEY) || '{}'); } catch { return {}; }
  }
  function _saveProf(d) {
    try { localStorage.setItem(PROF_KEY, JSON.stringify(d)); } catch {}
  }

  /* ── Tour step definitions ────────────────────────────────────── */
  const TOUR_STEPS = [
    {
      id       : 'sidebar',
      selector : '.sidebar-nav',
      title    : 'Your Navigation Hub',
      desc     : 'Use the sidebar to jump between dashboards. Press keys <kbd class="onb-kbd">1</kbd>–<kbd class="onb-kbd">9</kbd> for instant keyboard navigation — no mouse needed.',
      arrow    : 'right',
      offsetX  : 12,
      offsetY  : 0,
    },
    {
      id       : 'kpi-strip',
      selector : '.ov7-strip',
      title    : 'Executive KPI Strip',
      desc     : 'Your most critical numbers at a glance — active cases, closed this week, in-progress, and account breakdowns. Always visible, always current.',
      arrow    : 'top',
      offsetX  : 0,
      offsetY  : 12,
    },
    {
      id       : 'search',
      selector : '#global-search',
      title    : 'Instant Case Search',
      desc     : 'Press <kbd class="onb-kbd">/</kbd> from anywhere to focus search. Find any case by number, title, owner, or product in milliseconds.',
      arrow    : 'bottom',
      offsetX  : 0,
      offsetY  : -12,
    },
    {
      id       : 'cmd-palette',
      selector : '#header-cmd-hint',
      title    : 'Command Palette',
      desc     : 'Press <kbd class="onb-kbd">Ctrl</kbd><kbd class="onb-kbd">K</kbd> to open the command palette — navigate, filter, and perform actions without touching the mouse.',
      arrow    : 'bottom',
      offsetX  : 0,
      offsetY  : -12,
    },
    {
      id       : 'help',
      selector : '#header-shortcut-hint',
      title    : 'Keyboard Shortcuts',
      desc     : 'Press <kbd class="onb-kbd">?</kbd> any time to see all keyboard shortcuts. The more you use them, the faster you\'ll work.',
      arrow    : 'bottom',
      offsetX  : 0,
      offsetY  : -12,
    },
  ];

  /* ── "Did You Know?" tip pool ─────────────────────────────────── */
  const DYK_TIPS = [
    {
      id   : 'kb-slash',
      text : 'Press <strong>/</strong> anywhere in the app to instantly focus the search bar — no clicking required.',
      tab  : null,
      weight: 3,
    },
    {
      id   : 'kb-1to9',
      text : 'Use number keys <strong>1–9</strong> to jump directly to any dashboard in the sidebar.',
      tab  : null,
      weight: 3,
    },
    {
      id   : 'kb-ctrlk',
      text : 'Press <strong>Ctrl+K</strong> to open the command palette and run any action without a mouse.',
      tab  : null,
      weight: 2,
    },
    {
      id   : 'overview-collapse',
      text : 'On the Overview dashboard, you can collapse sections to focus on just the KPIs that matter most. Your layout is saved automatically.',
      tab  : 'overview',
      weight: 2,
    },
    {
      id   : 'team-columns',
      text : 'On Team Cases, use the <strong>Columns</strong> pill bar to show only the columns you need. Your preference is remembered.',
      tab  : 'team',
      weight: 2,
    },
    {
      id   : 'wt-drag',
      text : 'On the Weekly Tracker, you can drag cases to reassign them between weeks.',
      tab  : 'weekly-tracker',
      weight: 2,
    },
    {
      id   : 'alert-click',
      text : 'Click any alert row on the Overview to drill down into exactly those cases in the table below.',
      tab  : 'overview',
      weight: 1,
    },
    {
      id   : 'chart-click',
      text : 'Click any bar or slice in the charts to instantly filter the cases table to that segment.',
      tab  : 'overview',
      weight: 1,
    },
    {
      id   : 'export',
      text : 'Every table has an <strong>Export</strong> button — download a CSV of the current filtered view at any time.',
      tab  : null,
      weight: 1,
    },
    {
      id   : 'perf-wi',
      text : 'Performance cases without a Work Item are highlighted in red. Assign a WI from the Performance dashboard to clear the flag.',
      tab  : 'performance',
      weight: 2,
    },
  ];

  /* ── Welcome modal HTML ───────────────────────────────────────── */
  function _welcomeHTML() {
    return `
<div class="onb-overlay" id="onb-overlay" role="dialog" aria-modal="true" aria-labelledby="onb-title">
  <div class="onb-modal">
    <div class="onb-body">
      <div class="onb-step" id="onb-step-welcome">
        <div class="onb-icon" aria-hidden="true">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/>
          </svg>
        </div>
        <h2 class="onb-title" id="onb-title">Welcome to Case Intelligence Platform</h2>
        <p class="onb-subtitle">Your operations hub for IBM case management. Here's what you can do — take a quick 60-second tour to get the most out of it.</p>
        <div class="onb-features">
          <div class="onb-feat">
            <div class="onb-feat-icon" style="background:rgba(15,98,254,.1);color:var(--ibm-blue-50)">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
            </div>
            <div>
              <div class="onb-feat-text">Live Dashboard</div>
              <div class="onb-feat-sub">KPIs, alerts & trends</div>
            </div>
          </div>
          <div class="onb-feat">
            <div class="onb-feat-icon" style="background:rgba(25,128,56,.1);color:var(--green)">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
            </div>
            <div>
              <div class="onb-feat-text">Instant Search</div>
              <div class="onb-feat-sub">Press / to search</div>
            </div>
          </div>
          <div class="onb-feat">
            <div class="onb-feat-icon" style="background:rgba(105,41,196,.1);color:var(--purple)">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>
            </div>
            <div>
              <div class="onb-feat-text">Keyboard First</div>
              <div class="onb-feat-sub">1–9, Ctrl+K, / and more</div>
            </div>
          </div>
          <div class="onb-feat">
            <div class="onb-feat-icon" style="background:rgba(0,125,121,.1);color:var(--teal)">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></svg>
            </div>
            <div>
              <div class="onb-feat-text">Team Tracking</div>
              <div class="onb-feat-sub">Members, workload & SLAs</div>
            </div>
          </div>
        </div>
        <div class="onb-actions">
          <button class="onb-btn-primary" id="onb-start-tour">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polygon points="5 3 19 12 5 21 5 3"/></svg>
            Take Quick Tour
          </button>
          <button class="onb-btn-ghost" id="onb-skip">Skip for now</button>
        </div>
      </div>
    </div>
    <div class="onb-dots">
      <div class="onb-dot onb-dot-active"></div>
      <div class="onb-dot"></div>
      <div class="onb-dot"></div>
    </div>
  </div>
</div>`;
  }

  /* ── Tour engine ──────────────────────────────────────────────── */
  let _tourActive    = false;
  let _tourStep      = 0;
  let _backdrop      = null;
  let _spotlight     = null;
  let _tooltip       = null;

  function _buildTourDOM() {
    // Backdrop (dims everything)
    _backdrop = document.createElement('div');
    _backdrop.className = 'tour-backdrop';
    _backdrop.id = 'tour-backdrop';

    // Spotlight ring
    _spotlight = document.createElement('div');
    _spotlight.className = 'tour-spotlight';
    _spotlight.id = 'tour-spotlight';

    // Tooltip
    _tooltip = document.createElement('div');
    _tooltip.className = 'tour-tooltip';
    _tooltip.id = 'tour-tooltip';

    document.body.append(_backdrop, _spotlight, _tooltip);
  }

  function _destroyTourDOM() {
    _backdrop?.remove();  _backdrop  = null;
    _spotlight?.remove(); _spotlight = null;
    _tooltip?.remove();   _tooltip   = null;
    _tourActive = false;
    // Remove pulse from any highlighted element
    document.querySelectorAll('.tour-highlighted').forEach(el => el.classList.remove('tour-highlighted'));
  }

  function _positionSpotlight(el) {
    const r = el.getBoundingClientRect();
    const pad = 8;
    const top    = r.top    - pad;
    const left   = r.left   - pad;
    const width  = r.width  + pad * 2;
    const height = r.height + pad * 2;

    // Backdrop clips to this rect
    Object.assign(_backdrop.style, {
      top   : top    + 'px',
      left  : left   + 'px',
      width : width  + 'px',
      height: height + 'px',
      borderRadius: '10px',
    });

    // Spotlight ring
    Object.assign(_spotlight.style, {
      top   : top    + 'px',
      left  : left   + 'px',
      width : width  + 'px',
      height: height + 'px',
    });
  }

  function _positionTooltip(el, step) {
    const r     = el.getBoundingClientRect();
    const tt    = _tooltip;
    const arrow = step.arrow || 'top';

    // Temporarily show to measure
    tt.style.visibility = 'hidden';
    tt.style.display    = 'block';
    const ttW = tt.offsetWidth;
    const ttH = tt.offsetHeight;
    tt.style.visibility = '';

    let top, left;
    const PAD = 16;

    if (arrow === 'right') {
      top  = r.top + r.height / 2 - ttH / 2;
      left = r.right + PAD + (step.offsetX || 0);
    } else if (arrow === 'left') {
      top  = r.top + r.height / 2 - ttH / 2;
      left = r.left - ttW - PAD + (step.offsetX || 0);
    } else if (arrow === 'bottom') {
      top  = r.top - ttH - PAD + (step.offsetY || 0);
      left = r.left + (step.offsetX || 0);
    } else { // top
      top  = r.bottom + PAD + (step.offsetY || 0);
      left = r.left + (step.offsetX || 0);
    }

    // Clamp to viewport
    const vw = window.innerWidth, vh = window.innerHeight;
    left = Math.max(PAD, Math.min(left, vw - ttW - PAD));
    top  = Math.max(PAD, Math.min(top,  vh - ttH - PAD));

    tt.setAttribute('data-arrow', arrow);
    Object.assign(tt.style, { top: top + 'px', left: left + 'px' });
  }

  function _renderStep(index) {
    const steps   = TOUR_STEPS;
    const step    = steps[index];
    const total   = steps.length;
    const isLast  = index === total - 1;

    // Find target element; try the selector; fallback to body-center
    let target = null;
    if (step.selector) {
      target = document.querySelector(step.selector);
    }

    // Highlight the target
    document.querySelectorAll('.tour-highlighted').forEach(el => el.classList.remove('tour-highlighted'));
    if (target) {
      target.classList.add('tour-highlighted');
      _positionSpotlight(target);
    } else {
      // No element found — centre spotlight off screen
      Object.assign(_backdrop.style,  { top: '-999px', left: '-999px', width: '0', height: '0' });
      Object.assign(_spotlight.style, { top: '-999px', left: '-999px', width: '0', height: '0' });
    }

    // Build tooltip HTML
    _tooltip.innerHTML = `
      <div class="tour-step-label">Step ${index + 1} of ${total}</div>
      <div class="tour-step-title">${step.title}</div>
      <div class="tour-step-desc">${step.desc}</div>
      <div class="tour-step-actions">
        <button class="tour-btn-skip" id="tour-skip">End tour</button>
        <div style="display:flex;align-items:center;gap:8px">
          <span class="tour-step-progress">${index + 1}/${total}</span>
          <button class="tour-btn-next" id="tour-next">
            ${isLast ? 'Finish' : 'Next'}
            ${isLast
              ? '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"><polyline points="20 6 9 17 4 12"/></svg>'
              : '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>'}
          </button>
        </div>
      </div>`;

    if (target) _positionTooltip(target, step);
    else Object.assign(_tooltip.style, { top: '50%', left: '50%', transform: 'translate(-50%,-50%)' });

    // Wire buttons
    document.getElementById('tour-next')?.addEventListener('click', () => {
      if (isLast) _endTour(true); else _renderStep(index + 1);
    });
    document.getElementById('tour-skip')?.addEventListener('click', () => _endTour(false));
    _backdrop.onclick = () => _endTour(false);
  }

  function _endTour(completed) {
    _destroyTourDOM();
    const state = _loadOnb();
    state.tourDone = true;
    if (completed) state.tourCompleted = true;
    _saveOnb(state);

    // If completed, show the shortcut step as a "you're ready" toast
    if (completed) {
      setTimeout(() => {
        _showDYKCard({
          id  : '_tour_done',
          text: '🎉 Tour complete! Press <strong>?</strong> any time to see all keyboard shortcuts, or <strong>Ctrl+K</strong> to run any command.',
        }, true);
      }, 500);
    }
  }

  function startTour() {
    if (_tourActive) return;

    // Ensure Overview is active so .ov7-strip exists in the DOM
    // (tour step 2 targets it; it only renders when Overview tab is shown)
    const needsOverview = !document.querySelector('.ov7-strip');
    if (needsOverview && typeof App !== 'undefined') {
      try { App.renderTab('overview'); } catch(e) {}
      // Wait for overview to paint before starting
      setTimeout(() => {
        _tourActive = true;
        _buildTourDOM();
        _renderStep(0);
        track('tour_started');
      }, 350);
      return;
    }

    _tourActive = true;
    _buildTourDOM();
    _renderStep(0);
    track('tour_started');
  }

  /* ── Welcome modal ────────────────────────────────────────────── */
  function _showWelcome() {
    const el = document.createElement('div');
    el.innerHTML = _welcomeHTML();
    document.body.appendChild(el.firstElementChild);

    const overlay = document.getElementById('onb-overlay');

    document.getElementById('onb-start-tour')?.addEventListener('click', () => {
      overlay?.remove();
      const state = _loadOnb();
      state.seen = true;
      _saveOnb(state);
      setTimeout(() => startTour(), 200);
    });

    document.getElementById('onb-skip')?.addEventListener('click', () => {
      overlay?.remove();
      const state = _loadOnb();
      state.seen = true;
      _saveOnb(state);
    });

    // Close on backdrop click
    overlay?.addEventListener('click', e => {
      if (e.target === overlay) {
        overlay.remove();
        const state = _loadOnb();
        state.seen = true;
        _saveOnb(state);
      }
    });
  }

  /* ── "Did You Know?" cards ────────────────────────────────────── */
  let _dykTimeout = null;

  function _getNextTip(currentTab) {
    const state = _loadOnb();
    const dismissed = new Set(state.dykDismissed || []);

    // Filter out permanently dismissed tips
    const available = DYK_TIPS.filter(t => !dismissed.has(t.id));
    if (!available.length) return null;

    // Weight towards current tab and higher-weight tips
    const weighted = [];
    available.forEach(t => {
      const tabBonus = (t.tab === currentTab || t.tab === null) ? 2 : 1;
      for (let i = 0; i < (t.weight || 1) * tabBonus; i++) weighted.push(t);
    });

    return weighted[Math.floor(Math.random() * weighted.length)] || null;
  }

  function _showDYKCard(tip, immediate = false) {
    // Remove any existing card
    document.getElementById('dyk-card')?.remove();

    const card = document.createElement('div');
    card.className = 'dyk-card';
    card.id = 'dyk-card';
    card.setAttribute('role', 'status');
    card.setAttribute('aria-live', 'polite');
    card.innerHTML = `
      <div class="dyk-header">
        <span class="dyk-emoji" aria-hidden="true">💡</span>
        <span class="dyk-label">Did You Know?</span>
        <button class="dyk-close-btn" id="dyk-close" aria-label="Dismiss tip" title="Dismiss">✕</button>
      </div>
      <p class="dyk-text">${tip.text}</p>
      <div class="dyk-actions">
        <button class="dyk-btn-got-it" id="dyk-got-it">Got it</button>
        <button class="dyk-btn-later" id="dyk-later">Remind me later</button>
      </div>`;

    document.body.appendChild(card);

    function _dismissPermanently() {
      card.classList.add('dyk-hiding');
      const state = _loadOnb();
      state.dykDismissed = state.dykDismissed || [];
      if (tip.id && !state.dykDismissed.includes(tip.id)) {
        state.dykDismissed.push(tip.id);
      }
      _saveOnb(state);
      setTimeout(() => card.remove(), 350);
    }

    function _dismissTemporarily() {
      card.classList.add('dyk-hiding');
      setTimeout(() => card.remove(), 350);
    }

    document.getElementById('dyk-got-it')?.addEventListener('click', _dismissPermanently);
    document.getElementById('dyk-close')?.addEventListener('click', _dismissPermanently);
    document.getElementById('dyk-later')?.addEventListener('click', _dismissTemporarily);

    // Auto-dismiss after 12 seconds
    setTimeout(() => {
      if (document.getElementById('dyk-card') === card) _dismissTemporarily();
    }, 12000);
  }

  function _maybeTriggerDYK(tabId) {
    clearTimeout(_dykTimeout);
    const state = _loadOnb();

    // Only show on second+ visit to each tab
    state.visitCounts = state.visitCounts || {};
    state.visitCounts[tabId] = (state.visitCounts[tabId] || 0) + 1;
    _saveOnb(state);

    if (state.visitCounts[tabId] < 2) return;

    // Show DYK tip after 3 seconds on the dashboard
    _dykTimeout = setTimeout(() => {
      // Don't show if modal or tour is active
      if (document.getElementById('onb-overlay') || _tourActive) return;
      const tip = _getNextTip(tabId);
      if (tip) _showDYKCard(tip);
    }, 3000);
  }

  /* ── Proficiency tracking ─────────────────────────────────────── */
  const PROF_THRESHOLDS = {
    advanced     : { keyboardNav: 15, commandPalette: 5,  advancedFilters: 5  },
    intermediate : { keyboardNav: 5,  commandPalette: 1,  advancedFilters: 1  },
  };

  function track(action) {
    try {
      const prof = _loadProf();
      prof.actions = prof.actions || {};
      prof.actions[action] = (prof.actions[action] || 0) + 1;
      prof.level = _computeLevel(prof.actions);
      prof.lastUpdated = Date.now();
      _saveProf(prof);
      _updateProficiencyBadge(prof.level);
    } catch {}
  }

  function _computeLevel(actions) {
    const kbNav   = (actions.kb_1to9 || 0) + (actions.kb_slash || 0) + (actions.kb_question || 0);
    const cmdPal  = actions.commandPalette || 0;
    const filters = (actions.filter_owner || 0) + (actions.filter_status || 0) + (actions.col_toggle || 0);

    const adv = PROF_THRESHOLDS.advanced;
    const mid = PROF_THRESHOLDS.intermediate;

    if (kbNav >= adv.keyboardNav && cmdPal >= adv.commandPalette && filters >= adv.advancedFilters) {
      return 'advanced';
    }
    if (kbNav >= mid.keyboardNav || cmdPal >= mid.commandPalette || filters >= mid.advancedFilters) {
      return 'intermediate';
    }
    return 'beginner';
  }

  function proficiency() {
    return _loadProf().level || 'beginner';
  }

  /* ── Sidebar proficiency badge ────────────────────────────────── */
  function _updateProficiencyBadge(level) {
    let badge = document.getElementById('proficiency-badge');
    if (!badge) {
      badge = document.createElement('div');
      badge.id = 'proficiency-badge';
      badge.className = 'proficiency-badge';
      badge.setAttribute('title', 'Your proficiency level is based on feature usage');
      // Try sidebar-footer first, fall back to inserting before sidebar-nav bottom
      const footer = document.querySelector('.sidebar-footer');
      const sidebarNav = document.querySelector('.sidebar-nav');
      if (footer) {
        footer.prepend(badge);
      } else if (sidebarNav) {
        sidebarNav.insertAdjacentElement('afterend', badge);
      }
    }

    const labels = { beginner: 'Getting Started', intermediate: 'Proficient', advanced: 'Power User' };
    badge.className = 'proficiency-badge';
    badge.innerHTML = `
      <div class="proficiency-dot ${level}"></div>
      <span class="proficiency-label">${labels[level] || 'Getting Started'}</span>
      <span class="proficiency-level ${level}">${level.toUpperCase()}</span>`;
  }

  /* ── Hook into keyboard shortcuts for proficiency tracking ───── */
  function _wireTracking() {
    document.addEventListener('keydown', e => {
      const tag = document.activeElement?.tagName;
      const isEditing = tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT'
                     || document.activeElement?.isContentEditable;

      if (!isEditing) {
        if (e.key === '/') { track('kb_slash'); }
        if (e.key === '?' || (e.shiftKey && e.key === '/')) { track('kb_question'); }
        if (e.key >= '1' && e.key <= '9' && !e.ctrlKey && !e.metaKey) { track('kb_1to9'); }
        if ((e.ctrlKey || e.metaKey) && e.key === 'k') { track('commandPalette'); }
      }
    }, { passive: true });

    // Track tab navigation clicks (sidebar) as keyboard-equivalent proficiency signal
    document.querySelectorAll('.nav-item[data-tab]').forEach(btn => {
      btn.addEventListener('click', () => track('nav_click'), { passive: true });
    });
  }

  /* ── Patch App.renderTab to trigger DYK ─────────────────────── */
  function _patchRenderTab() {
    if (typeof App === 'undefined' || !App.renderTab) return;
    const _orig = App.renderTab.bind(App);
    App.renderTab = function(tabId) {
      _orig(tabId);
      try { _maybeTriggerDYK(tabId); } catch {}
    };
  }

  /* ── Main init ────────────────────────────────────────────────── */
  function init() {
    try {
      const state = _loadOnb();
      const prof  = _loadProf();

      // Update proficiency badge on load
      _updateProficiencyBadge(prof.level || 'beginner');

      // Wire keyboard tracking
      _wireTracking();

      // Patch renderTab for DYK
      _patchRenderTab();

      // Show welcome modal for first-time users (after a short delay so app settles)
      if (!state.seen) {
        setTimeout(_showWelcome, 800);
      }
    } catch (err) {
      console.warn('[Onboarding] init error:', err);
    }
  }

  /* ── Reset (for testing / re-running tour) ───────────────────── */
  function resetAll() {
    try { localStorage.removeItem(ONB_KEY); } catch {}
    try { localStorage.removeItem(PROF_KEY); } catch {}
    document.getElementById('proficiency-badge')?.remove();
    console.info('[Onboarding] All onboarding data reset. Reload the page to see the welcome modal.');
  }

  return { init, startTour, track, proficiency, resetAll };
})();
