/* ================================================================
   js/modules/ui/progressive-disclosure.js
   Tier 1.1 + 1.3 — Progressive Disclosure & Lazy Loading
   
   API:
     PD.section(id, title, content, opts)   → HTML string for collapsible
     PD.init(container)                     → wire all .pd-toggle inside container
     PD.initLazy(container)                 → Intersection Observer lazy load
     PD.skeleton(lines, opts)               → returns skeleton HTML
     PD.showMore(listEl, opts)              → wire "show N more" pattern
   ================================================================ */

const PD = (() => {

  const STORAGE_KEY = 'pd_section_prefs_v1';
  const CHEVRON_SVG = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none"
    stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
    <polyline points="6 9 12 15 18 9"/></svg>`;

  /* ── Persist open/closed state ──────────────────────────────── */
  function _loadPrefs() {
    try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}'); }
    catch { return {}; }
  }

  function _savePrefs(prefs) {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(prefs)); }
    catch {}
  }

  function _getPref(id, defaultOpen) {
    const prefs = _loadPrefs();
    return (id in prefs) ? prefs[id] : defaultOpen;
  }

  function _setPref(id, isOpen) {
    const prefs = _loadPrefs();
    prefs[id] = isOpen;
    _savePrefs(prefs);
  }

  /* ── Build a collapsible section HTML string ─────────────────
     opts: {
       defaultOpen  : true,           // initial state
       count        : null,           // shows badge like "12"
       countClass   : '',             // extra CSS class for count badge
       metaText     : '',             // small muted text right of title
       icon         : '',             // SVG icon HTML
       id           : 'unique-id',    // required for persistence
       lazy         : false,          // defer content render
     }
  ──────────────────────────────────────────────────────────────── */
  function section(id, title, content, opts = {}) {
    const {
      defaultOpen = true,
      count       = null,
      countClass  = '',
      metaText    = '',
      icon        = '',
      lazy        = false,
    } = opts;

    const isOpen = _getPref(id, defaultOpen);

    const countBadge = (count !== null)
      ? `<span class="pd-toggle-count ${countClass}">${count}</span>`
      : '';

    const metaHtml = metaText
      ? `<span class="pd-toggle-meta">${metaText}</span>`
      : '';

    const bodyContent = lazy && !isOpen
      ? `<div class="pd-lazy-placeholder" data-pd-id="${id}" data-pd-content="${_escAttr(content)}" style="min-height:60px"></div>`
      : content;

    return `
<div class="pd-section${isOpen ? ' pd-open' : ''}" data-pd-id="${id}" role="region" aria-labelledby="pd-hdr-${id}">
  <div class="pd-toggle" id="pd-hdr-${id}" role="button" tabindex="0"
       aria-expanded="${isOpen}" aria-controls="pd-body-${id}">
    <div class="pd-toggle-left">
      ${icon ? `<span class="pd-toggle-icon" aria-hidden="true">${icon}</span>` : ''}
      <span class="pd-toggle-title">${title}</span>
      ${countBadge}
      ${metaHtml}
    </div>
    <span class="pd-chevron" aria-hidden="true">${CHEVRON_SVG}</span>
  </div>
  <div class="pd-body" id="pd-body-${id}" role="group" aria-hidden="${!isOpen}">
    <div class="pd-body-inner">
      ${bodyContent}
    </div>
  </div>
</div>`;
  }

  /* ── Wire toggle events inside a container ──────────────────── */
  function init(container) {
    if (!container) return;

    // Wire all pd-toggle elements
    container.querySelectorAll('.pd-toggle').forEach(toggle => {
      // Avoid double-wiring
      if (toggle.dataset.pdWired) return;
      toggle.dataset.pdWired = '1';

      const section = toggle.closest('.pd-section');
      if (!section) return;
      const id = section.dataset.pdId;

      function handleToggle() {
        const isOpen = section.classList.toggle('pd-open');
        toggle.setAttribute('aria-expanded', String(isOpen));
        const body = section.querySelector('.pd-body');
        if (body) body.setAttribute('aria-hidden', String(!isOpen));

        // Handle lazy placeholder
        if (isOpen) {
          const placeholder = section.querySelector('.pd-lazy-placeholder');
          if (placeholder) {
            const encoded = placeholder.dataset.pdContent;
            if (encoded) {
              placeholder.outerHTML = _unescAttr(encoded);
            }
          }
        }

        // Persist preference
        if (id) _setPref(id, isOpen);
      }

      toggle.addEventListener('click', handleToggle);
      toggle.addEventListener('keydown', e => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          handleToggle();
        }
      });
    });
  }

  /* ── Intersection Observer lazy loading ─────────────────────── */
  function initLazy(container) {
    if (!container || !('IntersectionObserver' in window)) return;

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (!entry.isIntersecting) return;
        const el = entry.target;
        const renderFn = el._pdLazyRender;
        if (renderFn) {
          el.innerHTML = skeleton(3);
          // Slight delay to show skeleton, then render
          setTimeout(() => {
            const html = renderFn();
            el.innerHTML = html;
            el.classList.add('sk-loaded');
            delete el._pdLazyRender;
          }, 150);
        }
        observer.unobserve(el);
      });
    }, { rootMargin: '100px' });

    container.querySelectorAll('[data-pd-lazy]').forEach(el => {
      observer.observe(el);
    });
  }

  /* ── Skeleton loader HTML ────────────────────────────────────── */
  function skeleton(lineCount = 3, opts = {}) {
    const { showAvatar = false, padding = '14px' } = opts;
    let html = `<div class="sk-card" style="padding:${padding}">`;
    if (showAvatar) {
      html += `<div class="sk-row">
        <span class="skeleton sk-circle" style="width:32px;height:32px;flex-shrink:0"></span>
        <div style="flex:1">
          <span class="skeleton sk-line" style="width:60%"></span>
          <span class="skeleton sk-line" style="width:35%"></span>
        </div>
      </div>`;
    }
    for (let i = 0; i < lineCount; i++) {
      const w = [85, 70, 55, 40, 75][i % 5];
      html += `<span class="skeleton sk-line" style="width:${w}%"></span>`;
    }
    html += `</div>`;
    return html;
  }

  /* ── "Show N more" expand pattern ──────────────────────────────
     Usage:
       const items = [...];
       const INITIAL = 3;
       const html = items.slice(0, INITIAL).map(renderItem).join('')
                  + items.slice(INITIAL).map(i => `<div class="pd-hidden-item">${renderItem(i)}</div>`).join('')
                  + PD.showMoreBtn(items.length - INITIAL, 'alerts');
       container.innerHTML = html;
       PD.wireShowMore(container);
  ──────────────────────────────────────────────────────────────── */
  function showMoreBtn(count, label = 'items') {
    if (count <= 0) return '';
    return `
      <div class="pd-show-more" role="button" tabindex="0" data-pd-show-more-label="${label}">
        ${CHEVRON_SVG}
        <span>Show ${count} more ${label}</span>
      </div>`;
  }

  function wireShowMore(container) {
    if (!container) return;
    container.querySelectorAll('.pd-show-more').forEach(btn => {
      if (btn.dataset.pdWired) return;
      btn.dataset.pdWired = '1';

      btn.addEventListener('click', () => {
        const expanded = btn.classList.toggle('pd-expanded');
        const label = btn.dataset.pdShowMoreLabel || 'items';
        if (expanded) {
          // Show hidden items above the button
          let sibling = btn.previousElementSibling;
          while (sibling) {
            if (sibling.classList.contains('pd-hidden-item')) {
              sibling.style.display = 'block';
              sibling.classList.add('sk-loaded');
            }
            sibling = sibling.previousElementSibling;
          }
          btn.querySelector('span').textContent = `Show fewer ${label}`;
        } else {
          let sibling = btn.previousElementSibling;
          while (sibling) {
            if (sibling.classList.contains('pd-hidden-item')) {
              sibling.style.display = 'none';
            }
            sibling = sibling.previousElementSibling;
          }
          const hiddenCount = [...btn.parentElement.querySelectorAll('.pd-hidden-item')].length;
          btn.querySelector('span').textContent = `Show ${hiddenCount} more ${label}`;
        }
      });

      btn.addEventListener('keydown', e => {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); btn.click(); }
      });
    });
  }

  /* ── Internal helpers ─────────────────────────────────────────  */
  function _escAttr(str) {
    return btoa(unescape(encodeURIComponent(str)));
  }
  function _unescAttr(str) {
    try { return decodeURIComponent(escape(atob(str))); }
    catch { return ''; }
  }

  return { section, init, initLazy, skeleton, showMoreBtn, wireShowMore };
})();
