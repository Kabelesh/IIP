/* ================================================================
   js/modules/ui/perf-utils.js
   Tier 3 — Performance & Micro-interaction Utilities

   5.1  Ripple effect on all .btn clicks
   5.2  Smart loading messages
   4.2  Smart error toasts with actions
   4.3  Undo/redo system (Ctrl+Z / Ctrl+Y)
   5.4  Smart empty states (used by VirtualTable + Table patches)
   3.2  Progressive data loading indicator

   Auto-initialises on DOMContentLoaded — no manual call needed.
   Also exports window.PerfUtils for manual use.
   ================================================================ */

const PerfUtils = (() => {
  'use strict';

  /* ================================================================
     5.1  RIPPLE EFFECT
     ================================================================ */
  function _initRipple() {
    document.addEventListener('mousedown', e => {
      const btn = e.target.closest('.btn');
      if (!btn || btn.disabled) return;
      // Don't ripple on icon-only tiny buttons
      if (btn.classList.contains('btn-remove') || btn.classList.contains('btn-icon')) return;

      const rect   = btn.getBoundingClientRect();
      const x      = e.clientX - rect.left;
      const y      = e.clientY - rect.top;
      const ripple = document.createElement('span');
      ripple.className = 'btn-ripple';
      ripple.style.left = x + 'px';
      ripple.style.top  = y + 'px';
      btn.appendChild(ripple);
      ripple.addEventListener('animationend', () => ripple.remove(), { once: true });
    }, { passive: true });
  }

  /* ================================================================
     4.2  SMART ERROR TOASTS
     Categorises errors and surfaces actionable recovery options.
     ================================================================ */

  const ERROR_SPECS = {
    'network-offline': {
      icon   : '📡',
      title  : 'Connection Lost',
      message: 'Your changes are saved locally and will sync when you\'re back online.',
      actions: [{ label: 'Retry', cls: 'primary', id: 'retry' }, { label: 'Continue Working', cls: 'ghost', id: 'dismiss' }],
      type   : 'error',
      duration: null,
    },
    'validation-failed': {
      icon   : '⚠️',
      title  : 'Please Fix These Issues',
      message: '',   // filled dynamically from error.details
      actions: [{ label: 'Fix Errors', cls: 'primary', id: 'dismiss' }],
      type   : 'error',
      duration: null,
    },
    'timeout': {
      icon   : '⏱',
      title  : 'Request Timed Out',
      message: 'This is taking longer than expected.',
      actions: [{ label: 'Retry', cls: 'primary', id: 'retry' }, { label: 'Cancel', cls: 'ghost', id: 'dismiss' }],
      type   : 'warn',
      duration: 6000,
    },
    'permission': {
      icon   : '🔒',
      title  : 'Permission Denied',
      message: 'You don\'t have permission to perform this action.',
      actions: [{ label: 'Dismiss', cls: 'ghost', id: 'dismiss' }],
      type   : 'error',
      duration: 4000,
    },
    'success': {
      icon   : '✅',
      title  : '',
      message: '',
      actions: [],
      type   : 'success',
      duration: 3000,
    },
    'generic': {
      icon   : '⚠️',
      title  : 'Something went wrong',
      message: 'Please try again or refresh the page.',
      actions: [{ label: 'Retry', cls: 'primary', id: 'retry' }, { label: 'Dismiss', cls: 'ghost', id: 'dismiss' }],
      type   : 'error',
      duration: 6000,
    },
  };

  let _activeErrorToast = null;

  /**
   * showError(errorOrSpec)
   *
   * errorOrSpec can be:
   *   'network-offline'  (key)
   *   { category: 'timeout', details: [...] }
   *   { title: '...', message: '...', icon: '⚠️', actions: [...], duration: 4000 }
   *   { category: 'success', title: 'Saved!', message: '3 cases updated.' }
   *
   * opts: { onRetry: fn }
   */
  function showError(errorOrSpec, opts = {}) {
    _activeErrorToast?.remove();

    let spec;
    if (typeof errorOrSpec === 'string') {
      spec = { ...ERROR_SPECS[errorOrSpec] || ERROR_SPECS.generic };
    } else if (errorOrSpec.category) {
      const base = ERROR_SPECS[errorOrSpec.category] || ERROR_SPECS.generic;
      spec = { ...base };
      if (errorOrSpec.details && errorOrSpec.category === 'validation-failed') {
        spec.message = errorOrSpec.details.map(d => `• ${d}`).join('\n');
      }
      if (errorOrSpec.title)   spec.title   = errorOrSpec.title;
      if (errorOrSpec.message) spec.message = errorOrSpec.message;
    } else {
      spec = {
        ...ERROR_SPECS.generic,
        ...errorOrSpec,
      };
    }

    const typeClass = spec.type === 'success' ? 'smart-success' : spec.type === 'warn' ? 'smart-warn' : '';

    const actionsHTML = (spec.actions || []).map(a =>
      `<button class="smart-toast-btn ${a.cls}" data-action="${a.id}">${a.label}</button>`
    ).join('');

    const toast = document.createElement('div');
    toast.className = `smart-error-toast ${typeClass}`;
    toast.innerHTML = `
      <div class="smart-toast-header">
        <span class="smart-toast-icon" aria-hidden="true">${spec.icon || '⚠️'}</span>
        <span class="smart-toast-title">${_esc(spec.title || '')}</span>
        <button class="smart-toast-close" aria-label="Dismiss">✕</button>
      </div>
      ${spec.message ? `<p class="smart-toast-message" style="white-space:pre-line">${_esc(spec.message)}</p>` : ''}
      ${actionsHTML ? `<div class="smart-toast-actions">${actionsHTML}</div>` : ''}`;

    document.body.appendChild(toast);
    _activeErrorToast = toast;

    const dismiss = () => { toast.remove(); if (_activeErrorToast === toast) _activeErrorToast = null; };

    toast.querySelector('.smart-toast-close')?.addEventListener('click', dismiss);

    toast.querySelectorAll('[data-action]').forEach(btn => {
      btn.addEventListener('click', () => {
        if (btn.dataset.action === 'retry' && opts.onRetry) opts.onRetry();
        dismiss();
      });
    });

    if (spec.duration) setTimeout(dismiss, spec.duration);

    return { dismiss };
  }

  /* ================================================================
     4.3  UNDO / REDO SYSTEM
     ================================================================ */

  const _undoStack = [];
  const _redoStack = [];
  const UNDO_TIMEOUT_MS = 6000;

  let _undoToastEl = null;

  /**
   * pushAction({ name, undo, redo })
   *   name — human-readable label e.g. 'Reassigned Anjali → Kabelesh'
   *   undo — function to reverse the action
   *   redo — function to re-apply (optional)
   */
  function pushAction(action) {
    _undoStack.push(action);
    _redoStack.length = 0;
    _showUndoToast(action);
  }

  function undo() {
    if (!_undoStack.length) return;
    const action = _undoStack.pop();
    _redoStack.push(action);
    try { action.undo(); } catch(e) { console.warn('[Undo] error:', e); }
    _undoToastEl?.remove();
    _undoToastEl = null;
    // Show brief success
    showError({ category: 'success', title: `Undone: ${action.name}`, icon: '↶' });
  }

  function redo() {
    if (!_redoStack.length) return;
    const action = _redoStack.pop();
    _undoStack.push(action);
    try { if (action.redo) action.redo(); else console.info('[Redo] no redo fn for:', action.name); } catch(e) {}
  }

  function _showUndoToast(action) {
    _undoToastEl?.remove();

    const toast = document.createElement('div');
    toast.className = 'undo-toast';
    toast.innerHTML = `
      <span class="undo-toast-label"><strong>${_esc(action.name)}</strong></span>
      <button class="undo-btn" id="undo-btn-action">
        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M3 7v6h6"/><path d="M21 17a9 9 0 0 0-9-9 9 9 0 0 0-6 2.3L3 13"/></svg>
        Undo
      </button>
      <div class="undo-progress" id="undo-progress-bar" style="width:100%"></div>`;

    document.body.appendChild(toast);
    _undoToastEl = toast;

    toast.querySelector('#undo-btn-action')?.addEventListener('click', undo);

    /* Shrink progress bar over UNDO_TIMEOUT_MS, then auto-remove */
    const bar = toast.querySelector('#undo-progress-bar');
    if (bar) {
      bar.style.transition = `width ${UNDO_TIMEOUT_MS}ms linear`;
      requestAnimationFrame(() => requestAnimationFrame(() => { bar.style.width = '0%'; }));
    }

    const timeout = setTimeout(() => {
      if (_undoToastEl === toast) {
        toast.remove();
        _undoToastEl = null;
      }
    }, UNDO_TIMEOUT_MS);

    toast.querySelector('#undo-btn-action')?.addEventListener('click', () => clearTimeout(timeout));
  }

  function _initUndoKeyboard() {
    document.addEventListener('keydown', e => {
      const tag = document.activeElement?.tagName;
      const isEditing = tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT'
                     || document.activeElement?.isContentEditable;
      if (isEditing) return;

      if ((e.ctrlKey || e.metaKey) && e.key === 'z' && !e.shiftKey) {
        e.preventDefault();
        undo();
      }
      if ((e.ctrlKey || e.metaKey) && (e.key === 'y' || (e.key === 'z' && e.shiftKey))) {
        e.preventDefault();
        redo();
      }
    });
  }

  /* ================================================================
     5.2  SMART LOADING MESSAGES
     ================================================================ */
  const LOADING_MESSAGES = [
    '🔍 Finding your cases…',
    '📊 Crunching the numbers…',
    '✨ Sorting things out…',
    '⚡ Almost there…',
    '🎯 Getting everything ready…',
    '🚀 Loading at warp speed…',
  ];

  let _loadingInterval = null;

  function showLoading(containerEl, message) {
    if (!containerEl) return;
    const msg = message || LOADING_MESSAGES[Math.floor(Math.random() * LOADING_MESSAGES.length)];
    containerEl.innerHTML = `
      <div class="loading-message">
        <span class="loading-spinner-sm" aria-hidden="true"></span>
        <span id="loading-msg-text">${_esc(msg)}</span>
      </div>`;

    let idx = 0;
    _loadingInterval = setInterval(() => {
      const el = containerEl.querySelector('#loading-msg-text');
      if (!el) { clearInterval(_loadingInterval); return; }
      idx = (idx + 1) % LOADING_MESSAGES.length;
      el.style.opacity = '0';
      setTimeout(() => { el.textContent = LOADING_MESSAGES[idx]; el.style.opacity = '1'; }, 200);
    }, 2200);
  }

  function hideLoading() {
    clearInterval(_loadingInterval);
    _loadingInterval = null;
  }

  /* ================================================================
     5.4  SMART EMPTY STATES — helper for Table.render patches
     ================================================================ */
  function emptyStateHTML(search, uid, extraActions) {
    const isFiltered = search && search.trim().length > 0;

    if (isFiltered) {
      return `
        <div class="empty-state">
          <div class="empty-state-icon">🔍</div>
          <div class="empty-state-title">No cases match your search</div>
          <div class="empty-state-message">No results for <strong>"${_esc(search)}"</strong></div>
          <div class="empty-state-suggestions">
            <div class="empty-state-suggestion">Try a shorter or different keyword</div>
            <div class="empty-state-suggestion">Search by case number, owner, or product</div>
          </div>
          <div class="empty-state-actions">
            ${uid ? `<button class="btn btn-ghost btn-sm" onclick="
              var el=document.getElementById('tbl-search-${uid}');
              if(el){el.value='';el.dispatchEvent(new Event('input',{bubbles:true}));}
            ">Clear search</button>` : ''}
          </div>
        </div>`;
    }

    return `
      <div class="empty-state">
        <div class="empty-state-icon">📂</div>
        <div class="empty-state-title">No cases found</div>
        <div class="empty-state-message">Upload a case export file to populate the dashboard.</div>
      </div>`;
  }

  /* ================================================================
     3.2  PROGRESSIVE LOADING INDICATOR
     Wraps a render function to show skeleton → real content
     ================================================================ */
  function progressiveRender(containerEl, stages) {
    /* stages = [
         { delay: 0,   fn: () => renderSkeleton() },
         { delay: 300, fn: () => renderShell() },
         { delay: 600, fn: () => renderData(first50) },
       ]
    */
    stages.forEach(({ delay, fn }) => {
      if (delay === 0) { try { fn(); } catch(e) {} }
      else setTimeout(() => { try { fn(); } catch(e) {} }, delay);
    });
  }

  /* ================================================================
     INIT
     ================================================================ */
  function init() {
    _initRipple();
    _initUndoKeyboard();
  }

  function _esc(s) {
    return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

  /* Auto-init after DOM is ready */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  return {
    /* Ripple — auto-wired */
    /* Smart errors */
    showError,
    /* Undo */
    pushAction, undo, redo,
    /* Loading */
    showLoading, hideLoading,
    /* Empty states */
    emptyStateHTML,
    /* Progressive render */
    progressiveRender,
    /* Manual re-init */
    init,
  };
})();
