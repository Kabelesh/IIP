/* ════════════════════════════════════════════════════════════════════════════
   STATE MANAGER — Production-grade state persistence
   ════════════════════════════════════════════════════════════════════════════
   Handles saving and restoring UI state across page refreshes:
   - Active tab
   - Filter states per dashboard
   - Sidebar menu states
   ═════════════════════════════════════════════════════════════════════════ */

const StateManager = (() => {
  const STORAGE_KEY_TAB = "iip_active_tab";
  const STORAGE_KEY_FILTERS = "iip_filters_state";
  const STORAGE_KEY_MENU = "iip_menu_state";

  /* ── Save and restore active tab ── */
  function saveActiveTab(tabId) {
    try {
      localStorage.setItem(STORAGE_KEY_TAB, tabId);
    } catch(e) {
      console.warn("[StateManager] Failed to save active tab:", e);
    }
  }

  function getLastActiveTab() {
    try {
      const tab = localStorage.getItem(STORAGE_KEY_TAB);
      // Return tab if it's a valid dashboard tab, otherwise return null
      const validTabs = ["overview", "team", "customer", "closed", "created", "members", "performance", "weekly-tracker", "investigate", "rfe-tracking", "admin", "documentation", "how-it-works"];
      return validTabs.includes(tab) ? tab : null;
    } catch(e) {
      return null;
    }
  }

  /* ── Save and restore filter states by dashboard ── */
  function saveFiltersForDashboard(dashboardId, filters) {
    try {
      const allFilters = JSON.parse(localStorage.getItem(STORAGE_KEY_FILTERS) || "{}");
      allFilters[dashboardId] = {
        ...allFilters[dashboardId],
        ...filters,
        timestamp: Date.now()
      };
      localStorage.setItem(STORAGE_KEY_FILTERS, JSON.stringify(allFilters));
    } catch(e) {
      console.warn("[StateManager] Failed to save filters for", dashboardId, e);
    }
  }

  function getFiltersForDashboard(dashboardId) {
    try {
      const allFilters = JSON.parse(localStorage.getItem(STORAGE_KEY_FILTERS) || "{}");
      return allFilters[dashboardId] || {};
    } catch(e) {
      return {};
    }
  }

  function clearFiltersForDashboard(dashboardId) {
    try {
      const allFilters = JSON.parse(localStorage.getItem(STORAGE_KEY_FILTERS) || "{}");
      delete allFilters[dashboardId];
      localStorage.setItem(STORAGE_KEY_FILTERS, JSON.stringify(allFilters));
    } catch(e) {}
  }

  /**
   * Count active filters (non-empty values that aren't timestamp).
   * Useful for showing filter badge that indicates how many filters are active.
   */
  function countActiveFilters(dashboardId) {
    const filters = getFiltersForDashboard(dashboardId);
    if (!filters || typeof filters !== 'object') return 0;
    let count = 0;
    for (let key in filters) {
      if (key !== 'timestamp' && filters[key] !== '' && filters[key] !== undefined && filters[key] !== null) {
        count++;
      }
    }
    return count;
  }

  /* ── Save and restore menu states ── */
  function saveMenuState(menuId, isExpanded) {
    try {
      const menus = JSON.parse(localStorage.getItem(STORAGE_KEY_MENU) || "{}");
      menus[menuId] = isExpanded;
      localStorage.setItem(STORAGE_KEY_MENU, JSON.stringify(menus));
    } catch(e) {
      console.warn("[StateManager] Failed to save menu state:", e);
    }
  }

  function getMenuState(menuId, defaultState = false) {
    try {
      const menus = JSON.parse(localStorage.getItem(STORAGE_KEY_MENU) || "{}");
      return menus[menuId] !== undefined ? menus[menuId] : defaultState;
    } catch(e) {
      return defaultState;
    }
  }

  /* ── Clear all saved state ── */
  function clearAllState() {
    try {
      localStorage.removeItem(STORAGE_KEY_TAB);
      localStorage.removeItem(STORAGE_KEY_FILTERS);
      localStorage.removeItem(STORAGE_KEY_MENU);
    } catch(e) {
      console.warn("[StateManager] Failed to clear state:", e);
    }
  }

  return {
    saveActiveTab,
    getLastActiveTab,
    saveFiltersForDashboard,
    getFiltersForDashboard,
    countActiveFilters,
    clearFiltersForDashboard,
    saveMenuState,
    getMenuState,
    clearAllState
  };
})();
