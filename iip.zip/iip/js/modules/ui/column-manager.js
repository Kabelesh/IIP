/* ================================================================
   js/modules/ui/column-manager.js
   Tier 1.2 — Smart Table Column Defaults
   
   Reduces cognitive load by showing only 6 key columns by default.
   Users can add/remove columns via pills. Choice is persisted in
   localStorage so preferences survive page refresh.
   
   API:
     ColMgr.wrap(tableContainer, columnDefs, opts) → renders pill bar + manages visibility
     ColMgr.getVisibleKeys(tableId)                → returns array of visible column keys
   ================================================================ */

const ColMgr = (() => {

  const STORAGE_KEY = 'col_mgr_prefs_v1';

  /* Default 6 columns per roadmap spec:
     Case #, Title, Status, Owner, Updated, Actions
     Keys must match Table.defaultColumns() key values. */
  const DEFAULT_COLS = ['Case Number', 'Title', 'Status', 'Owner', 'Updated', '_lastUpdDays'];

  /* Friendly labels for pills */
  const COL_LABELS = {
    'Case Number'      : 'Case #',
    'Title'            : 'Title',
    'Status'           : 'Status',
    'Owner'            : 'Owner',
    'Updated'          : 'Updated',
    '_lastUpdDays'     : 'Last Updated (Days)',
    'Product'          : 'Product',
    'Customer number'  : 'Customer #',
    'Created'          : 'Created',
    'Severity'         : 'Severity',
    'Age'              : 'Age (days)',
  };

  /* Columns that can never be hidden */
  const LOCKED_COLS = new Set(['Case Number', 'Title']);

  /* ── Persistence ─────────────────────────────────────────────── */
  function _loadPrefs(tableId) {
    try {
      const all = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
      return all[tableId] || null;
    } catch { return null; }
  }

  function _savePrefs(tableId, visibleKeys) {
    try {
      const all = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
      all[tableId] = visibleKeys;
      localStorage.setItem(STORAGE_KEY, JSON.stringify(all));
    } catch {}
  }

  /* ── Main: inject column manager bar above a rendered table ─────
     tableContainer: the DOM element holding the table (already rendered)
     allColDefs:     array of { key, label } objects from Table.defaultColumns()
     opts: {
       tableId       : 'team',   // unique ID for localStorage key
       defaultCols   : [...],    // override DEFAULT_COLS
       onVisibilityChange: fn,   // callback when columns change
     }
  ──────────────────────────────────────────────────────────────── */
  function wrap(tableContainer, allColDefs, opts = {}) {
    if (!tableContainer) return;

    const {
      tableId            = 'default',
      defaultCols        = DEFAULT_COLS,
      onVisibilityChange = null,
    } = opts;

    // Determine initial visible set (from localStorage or default)
    const savedKeys = _loadPrefs(tableId);
    let visibleKeys = savedKeys
      ? savedKeys.filter(k => allColDefs.some(c => c.key === k))
      : defaultCols.filter(k => allColDefs.some(c => c.key === k));

    // Always include locked columns
    LOCKED_COLS.forEach(k => {
      if (allColDefs.some(c => c.key === k) && !visibleKeys.includes(k)) {
        visibleKeys.unshift(k);
      }
    });

    /* Build pill bar */
    function _buildBar() {
      const savedIndicator = `<span class="col-mgr-saved" id="colmgr-saved-${tableId}">
        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
        Saved
      </span>`;

      const pills = allColDefs.map(col => {
        const isVisible = visibleKeys.includes(col.key);
        const isLocked  = LOCKED_COLS.has(col.key);
        const label     = COL_LABELS[col.key] || col.label;
        const checkSvg  = isVisible
          ? `<svg class="col-pill-check" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>`
          : `<span class="col-pill-check"></span>`;

        const cls = [
          'col-pill',
          isVisible ? 'col-pill-active' : '',
          isLocked  ? 'col-pill-locked'  : '',
        ].filter(Boolean).join(' ');

        return `<button class="${cls}" data-col-key="${_esc(col.key)}"
          ${isLocked ? 'disabled title="This column cannot be hidden"' : ''}
          aria-pressed="${isVisible}" aria-label="Toggle column: ${label}">
          ${checkSvg} ${label}
        </button>`;
      }).join('');

      return `
<div class="col-mgr-bar" role="toolbar" aria-label="Manage visible columns">
  <span class="col-mgr-label">Columns</span>
  ${pills}
  <span class="col-mgr-reset" role="button" tabindex="0"
    id="colmgr-reset-${tableId}" title="Reset to default 6 columns" aria-label="Reset columns to default">
    Reset to default
  </span>
  ${savedIndicator}
</div>`;
    }

    /* Apply visibility to the actual table DOM */
    function _applyVisibility() {
      const table = tableContainer.querySelector('.data-table');
      if (!table) return;

      const allKeys = allColDefs.map(c => c.key);

      // For each column key, toggle visibility on th and all tds
      allKeys.forEach((key, colIdx) => {
        const isVisible = visibleKeys.includes(key);
        const thEl = table.querySelectorAll('thead th')[colIdx];
        const tdEls = table.querySelectorAll(`tbody tr td:nth-child(${colIdx + 1})`);
        if (thEl) thEl.classList.toggle('col-hidden', !isVisible);
        tdEls.forEach(td => td.classList.toggle('col-hidden', !isVisible));
      });
    }

    /* Flash "Saved" indicator */
    function _flashSaved() {
      const el = document.getElementById(`colmgr-saved-${tableId}`);
      if (!el) return;
      el.classList.add('col-mgr-saved-show');
      setTimeout(() => el.classList.remove('col-mgr-saved-show'), 1800);
    }

    /* Wire pill bar events */
    function _wireBar(barEl) {
      barEl.querySelectorAll('.col-pill:not(.col-pill-locked)').forEach(pill => {
        pill.addEventListener('click', () => {
          const key = pill.dataset.colKey;
          if (!key) return;

          const idx = visibleKeys.indexOf(key);
          if (idx > -1) {
            // Only hide if there are still ≥ 1 visible non-locked cols
            const remainingVisible = visibleKeys.filter(k => !LOCKED_COLS.has(k));
            if (remainingVisible.length <= 1) {
              // Refuse to hide the last non-locked column
              pill.style.animation = 'none';
              pill.offsetHeight; // reflow
              pill.style.animation = 'shake 0.25s ease';
              return;
            }
            visibleKeys.splice(idx, 1);
          } else {
            visibleKeys.push(key);
          }

          _savePrefs(tableId, visibleKeys);
          try { if (typeof Onboarding !== 'undefined') Onboarding.track('col_toggle'); } catch(e) {}
          _flashSaved();
          _applyVisibility();

          // Update pill appearance
          const isNowVisible = visibleKeys.includes(key);
          pill.classList.toggle('col-pill-active', isNowVisible);
          pill.setAttribute('aria-pressed', String(isNowVisible));
          const check = pill.querySelector('.col-pill-check');
          if (check) {
            if (isNowVisible) {
              check.innerHTML = `<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>`;
            } else {
              check.innerHTML = '';
            }
          }

          if (onVisibilityChange) onVisibilityChange(visibleKeys);
        });
      });

      // Reset to default
      const resetBtn = barEl.querySelector(`#colmgr-reset-${tableId}`);
      if (resetBtn) {
        const doReset = () => {
          visibleKeys = defaultCols
            .filter(k => allColDefs.some(c => c.key === k))
            .slice();
          _savePrefs(tableId, visibleKeys);
          _applyVisibility();
          // Re-render bar
          const newBar = document.createElement('div');
          newBar.innerHTML = _buildBar();
          const oldBar = tableContainer.querySelector('.col-mgr-bar');
          if (oldBar) oldBar.replaceWith(newBar.firstElementChild);
          _wireBar(tableContainer.querySelector('.col-mgr-bar'));
          _flashSaved();
          if (onVisibilityChange) onVisibilityChange(visibleKeys);
        };
        resetBtn.addEventListener('click', doReset);
        resetBtn.addEventListener('keydown', e => {
          if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); doReset(); }
        });
      }
    }

    /* Inject bar before the table */
    const barEl = document.createElement('div');
    barEl.innerHTML = _buildBar();
    const bar = barEl.firstElementChild;
    tableContainer.insertBefore(bar, tableContainer.firstChild);

    _wireBar(bar);
    _applyVisibility();

    return {
      getVisibleKeys: () => [...visibleKeys],
      refresh: (newAllColDefs) => {
        _applyVisibility();
      }
    };
  }

  /* ── Utility ─────────────────────────────────────────────────── */
  function getVisibleKeys(tableId) {
    return _loadPrefs(tableId) || DEFAULT_COLS;
  }

  function _esc(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }

  return { wrap, getVisibleKeys, DEFAULT_COLS };
})();
