/* ================================================================
   app-tour.js — IBM Case Intelligence Platform
   Production-Grade Guided Tour  v2.0
   ================================================================
   Triggers:
     • Ctrl+L  — anywhere in the app (toggle open/close)
     • Esc     — exits tour at any time
     • ← / →  — previous / next step
     • "Start Guided Tour" in Command Palette (Ctrl+K)
     • "Start Guided Tour" button in How It Works page
     • Exit button inside the tooltip
   ================================================================ */
(function () {
  "use strict";

  /* ── Inject styles (once) ─────────────────────────────────────── */
  function _injectStyles() {
    if (document.getElementById("igt-styles")) return;
    const s = document.createElement("style");
    s.id = "igt-styles";
    s.textContent = `
      /* ── IIP Guided Tour — Light mode only, no blur ─────────────────── */
      #igt-root{position:fixed;inset:0;z-index:99999;pointer-events:none;font-family:'IBM Plex Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;}

      /* Subtle dark vignette — no blur so users can see the app clearly */
      #igt-backdrop{position:fixed;inset:0;background:rgba(15,20,40,0.45);pointer-events:auto;transition:opacity .3s ease;opacity:0;}
      #igt-root.igt-vis #igt-backdrop{opacity:1;}

      /* Spotlight: bright cut-out that highlights the target element */
      #igt-spotlight{
        position:fixed;border-radius:8px;
        box-shadow:
          0 0 0 3px #0f62fe,
          0 0 0 6px rgba(15,98,254,.25),
          0 0 0 9999px rgba(15,20,40,.45);
        transition:all .35s cubic-bezier(.22,1,.36,1);
        pointer-events:none;z-index:2;opacity:0;
      }
      #igt-root.igt-vis #igt-spotlight{opacity:1;}

      /* Tooltip — always white/light, crisp shadow */
      #igt-tooltip{
        position:fixed;width:350px;
        background:#ffffff;
        border-radius:12px;
        box-shadow:0 4px 6px rgba(0,0,0,.05),0 16px 40px rgba(0,0,0,.15);
        border:1px solid #e0e0e0;
        pointer-events:auto;z-index:3;
        opacity:0;transform:translateY(8px) scale(.98);
        transition:all .28s cubic-bezier(.22,1,.36,1);overflow:hidden;
      }
      #igt-root.igt-vis #igt-tooltip{opacity:1;transform:translateY(0) scale(1);}

      /* Arrow pointer */
      #igt-tooltip::before{content:'';position:absolute;width:11px;height:11px;background:#ffffff;border:1px solid #e0e0e0;transform:rotate(45deg);}
      #igt-tooltip[data-pos="right"]::before{left:-6px;top:24px;border-right:none;border-top:none;}
      #igt-tooltip[data-pos="left"]::before{right:-6px;top:24px;border-left:none;border-bottom:none;}
      #igt-tooltip[data-pos="bottom"]::before{top:-6px;left:26px;border-bottom:none;border-right:none;}
      #igt-tooltip[data-pos="top"]::before{bottom:-6px;left:26px;border-top:none;border-left:none;}
      #igt-tooltip[data-pos="center"]::before{display:none;}

      /* Header band */
      #igt-hdr{background:linear-gradient(135deg,#0f62fe 0%,#0043ce 100%);padding:12px 14px 11px;display:flex;align-items:flex-start;justify-content:space-between;gap:10px;}
      #igt-hdr-left{display:flex;align-items:center;gap:9px;flex:1;min-width:0;}
      #igt-icon{width:32px;height:32px;background:rgba(255,255,255,.18);border-radius:7px;display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:15px;line-height:1;}
      #igt-section{font-size:9px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:rgba(255,255,255,.7);margin-bottom:1px;}
      #igt-title{font-size:13px;font-weight:700;color:#fff;line-height:1.3;}
      #igt-xbtn{width:24px;height:24px;background:rgba(255,255,255,.15);border:1px solid rgba(255,255,255,.3);border-radius:50%;color:#fff;font-size:10px;font-weight:700;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:all .15s;flex-shrink:0;}
      #igt-xbtn:hover{background:rgba(255,255,255,.35);}

      /* Body */
      #igt-body{padding:12px 14px 10px;}
      #igt-counter{display:inline-flex;align-items:center;font-size:9px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#0f62fe;background:#edf5ff;padding:2px 8px;border-radius:20px;margin-bottom:8px;}
      #igt-desc{font-size:12.5px;color:#3d3d3d;line-height:1.65;margin-bottom:10px;}
      #igt-desc strong{color:#161616;font-weight:600;}
      #igt-desc kbd{display:inline-block;font-size:10px;font-weight:700;background:#f4f4f4;color:#161616;border:1px solid #c6c6c6;border-bottom-width:2px;border-radius:4px;padding:1px 5px;font-family:'IBM Plex Mono',monospace;line-height:1.4;}
      #igt-tips{background:#f4f7ff;border-left:3px solid #0f62fe;border-radius:0 6px 6px 0;padding:7px 10px;margin-bottom:10px;}
      #igt-tips-lbl{font-size:9px;font-weight:700;letter-spacing:.08em;color:#0f62fe;text-transform:uppercase;margin-bottom:4px;}
      #igt-tips ul{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:3px;}
      #igt-tips li{font-size:11px;color:#525252;line-height:1.5;display:flex;align-items:flex-start;gap:5px;}
      #igt-tips li::before{content:'→';color:#0f62fe;font-size:10px;flex-shrink:0;margin-top:1px;}

      /* Footer */
      #igt-foot{display:flex;align-items:center;padding:8px 14px 12px;gap:8px;border-top:1px solid #f0f0f0;}
      #igt-pbtn{padding:6px 12px;background:#fff;border:1.5px solid #c6c6c6;border-radius:6px;font-size:11px;font-weight:600;color:#6f6f6f;cursor:pointer;transition:all .15s;font-family:inherit;}
      #igt-pbtn:hover:not(:disabled){background:#f4f4f4;color:#161616;border-color:#8d8d8d;}
      #igt-pbtn:disabled{opacity:.3;cursor:default;}
      #igt-nbtn{padding:6px 14px;background:#0f62fe;border:1.5px solid #0f62fe;border-radius:6px;font-size:11px;font-weight:700;color:#fff;cursor:pointer;transition:all .15s;font-family:inherit;margin-left:auto;}
      #igt-nbtn:hover{background:#0043ce;}
      #igt-nbtn.fin{background:#198038;border-color:#198038;}
      #igt-nbtn.fin:hover{background:#0e6027;}
      #igt-dots{display:flex;align-items:center;gap:4px;flex:1;justify-content:center;flex-wrap:wrap;}
      .igd{height:4px;border-radius:2px;background:#d0d0d0;transition:all .2s;width:4px;flex-shrink:0;}
      .igd.act{background:#0f62fe;width:16px;}
      .igd.dn{background:#97c1f7;}
      #igt-kbhint{padding:4px 14px 8px;display:flex;align-items:center;gap:5px;font-size:10px;color:#b0b0b0;}
      #igt-kbhint kbd{font-size:9px;background:#f4f4f4;color:#6f6f6f;border:1px solid #d0d0d0;border-bottom-width:2px;border-radius:3px;padding:1px 4px;font-family:'IBM Plex Mono',monospace;}

      /* Welcome splash — light card, no blur */
      #igt-welcome{position:fixed;inset:0;z-index:99999;display:flex;align-items:center;justify-content:center;background:rgba(15,20,40,.5);pointer-events:auto;opacity:0;transition:opacity .3s ease;}
      #igt-welcome.igt-vis{opacity:1;}
      #igt-wcard{background:#fff;border-radius:16px;width:500px;max-width:92vw;box-shadow:0 8px 16px rgba(0,0,0,.08),0 24px 64px rgba(0,0,0,.16);border:1px solid #e8e8e8;overflow:hidden;transform:scale(.95) translateY(16px);transition:transform .32s cubic-bezier(.22,1,.36,1);}
      #igt-welcome.igt-vis #igt-wcard{transform:scale(1) translateY(0);}
      #igt-wtop{background:linear-gradient(135deg,#0f62fe 0%,#0043ce 100%);padding:28px 28px 24px;text-align:center;}
      #igt-wbadge{display:inline-flex;align-items:center;gap:6px;background:rgba(255,255,255,.18);border:1px solid rgba(255,255,255,.3);color:rgba(255,255,255,.95);font-size:10px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;padding:3px 11px;border-radius:20px;margin-bottom:12px;}
      #igt-wtitle{font-size:20px;font-weight:700;color:#fff;line-height:1.25;margin-bottom:6px;}
      #igt-wsub{font-size:12px;color:rgba(255,255,255,.85);line-height:1.55;}
      #igt-wbot{padding:20px 26px 24px;background:#fff;}
      #igt-wpages{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:18px;}
      .igt-wpi{display:flex;align-items:center;gap:8px;padding:8px 10px;background:#f8f9fc;border:1px solid #eaecf4;border-radius:8px;}
      .igt-wpi-ic{width:28px;height:28px;border-radius:7px;display:flex;align-items:center;justify-content:center;font-size:13px;flex-shrink:0;}
      .igt-wpi-nm{font-size:11.5px;font-weight:600;color:#161616;}
      .igt-wpi-sb{font-size:10px;color:#6f6f6f;margin-top:1px;}
      #igt-wactions{display:flex;gap:9px;}
      #igt-wstart{flex:1;padding:10px 16px;background:#0f62fe;border:none;border-radius:8px;color:#fff;font-size:13px;font-weight:700;cursor:pointer;font-family:inherit;display:flex;align-items:center;justify-content:center;gap:7px;transition:background .15s;}
      #igt-wstart:hover{background:#0043ce;}
      #igt-wskip{padding:10px 14px;background:#fff;border:1.5px solid #d0d0d0;border-radius:8px;color:#6f6f6f;font-size:12px;font-weight:600;cursor:pointer;font-family:inherit;transition:all .15s;}
      #igt-wskip:hover{background:#f4f4f4;color:#161616;border-color:#a0a0a0;}
      #igt-wtip{text-align:center;font-size:10px;color:#b0b0b0;margin-top:12px;}
      #igt-wtip kbd{font-size:9px;background:#f4f4f4;color:#6f6f6f;border:1px solid #d0d0d0;border-bottom-width:2px;border-radius:3px;padding:1px 4px;font-family:'IBM Plex Mono',monospace;}
    `;
    document.head.appendChild(s);
  }

  /* ── Tour steps ──────────────────────────────────────────────── */
  const STEPS = [
    {
      target:"#nav-cases-parent, .sidebar-nav", navigate:null,
      icon:"🧭", section:"Navigation",
      title:"Sidebar — Your Navigation Hub",
      desc:"This is your <strong>main navigation menu</strong>. Every page of the platform is listed here. Click any item to switch dashboards instantly.<br><br>Use keyboard shortcuts <kbd>1</kbd>–<kbd>9</kbd> to jump to any tab without touching the mouse.",
      tips:["Press 1 for Overview, 2 for Members Dashboard","Cases sub-menu expands to show Team, Customer, Closed, Created","Admin Portal is visible only to Admin users"],
      pos:"right"
    },
    {
      target:"#header-cmd-hint", navigate:null,
      icon:"⌨️", section:"Navigation",
      title:"Command Palette  (Ctrl+K)",
      desc:"Press <kbd>Ctrl</kbd><kbd>K</kbd> to open the <strong>Command Palette</strong> — a fast launcher for every action in the app. Navigate pages, run actions, and open tools without ever touching the mouse.",
      tips:["Type to filter: 'overview', 'tracker', 'tour'…","Arrow keys navigate · Enter runs · Esc closes","Works from any page at any time"],
      pos:"bottom"
    },
    {
      target:"#global-search", navigate:"overview",
      icon:"🔍", section:"Global Search",
      title:"Instant Case Search  ( / )",
      desc:"Press <kbd>/</kbd> from anywhere to instantly focus the <strong>Global Search</strong> bar. Search by case number, title, owner, product, or any keyword. Results appear in real-time as you type.",
      tips:["Searches ALL cases — including archived history","Press Esc to clear and close results","Supports partial matches: 'ALM-20', 'OOM', 'LQE'"],
      pos:"bottom"
    },
    {
      target:".ov7-strip, .kpi-row, #ov-kpi-row, #tab-overview .kpi-row",
      navigate:"overview",
      icon:"📊", section:"Overview Dashboard",
      title:"KPI Strip — Critical Numbers at a Glance",
      desc:"These <strong>KPI cards</strong> show your most important metrics instantly: total active cases, cases closed this week, stale cases (not updated in 5+ days), and cases currently being worked on by IBM.",
      tips:["Red = needs immediate attention  ·  Green = positive","Stale = no update for 5+ days","Numbers update automatically after each file upload"],
      pos:"bottom"
    },
    {
      target:'.nav-item[data-tab="team"]', navigate:"team",
      icon:"👥", section:"Team Cases",
      title:"Team Cases — Your Daily Workspace",
      desc:"The <strong>Team Cases</strong> page is your day-to-day workspace. Filter cases by owner, status, or days since last update. Click chart bars to cross-filter the table. Sort any column to reprioritize your queue.",
      tips:["'Days Since Update' filter finds neglected cases fast","Click any owner bar in the chart to filter by that person","Send Reminder Mail for all filtered cases with one click"],
      pos:"right"
    },
    {
      target:'.nav-item[data-tab="customer"]', navigate:"customer",
      icon:"🏢", section:"Cases",
      title:"Customer Cases — Account-Level View",
      desc:"A dedicated view scoped to a <strong>specific customer account</strong>. All KPIs, charts, and the case table respond to the selected account ID. Filter by year, month, date range, or status for precise account-level analysis.",
      tips:["Default customer account ID set in Admin Portal → Settings","Combine date + status filters for targeted timeframe views","Owner chart bars are clickable for quick assignee filtering"],
      pos:"right"
    },
    {
      target:'.nav-item[data-tab="closed"]', navigate:"closed",
      icon:"✅", section:"Cases",
      title:"Closed Cases — Historical Trend Analysis",
      desc:"The complete <strong>historical record</strong> of resolved cases. Three trend charts reveal your team's closure patterns over time: monthly totals, a 12-week rolling chart, and a year-over-year comparison.",
      tips:["Use monthly chart to spot seasonal closure spikes","Export any filtered view to Excel for management reporting","Closed cases remain searchable in the Investigate archive"],
      pos:"right"
    },
    {
      target:'.nav-item[data-tab="created"]', navigate:"created",
      icon:"🆕", section:"Cases",
      title:"Created Cases — Case Intake Trends",
      desc:"Track <strong>case creation patterns</strong> over time. See when new cases are being opened, identify intake spikes, and correlate creation rate with closure rate to understand backlog growth or reduction.",
      tips:["High creation + low closure = backlog building up","Compare against Closed Cases page for flow analysis","Filter by product to isolate intake per application (CCM, RM, QM…)"],
      pos:"right"
    },
    {
      target:'.nav-item[data-tab="members"]', navigate:"members",
      icon:"🏅", section:"Member Dashboard",
      title:"Member Dashboard — Individual Workload",
      desc:"See your team through an individual lens. The <strong>Member Dashboard</strong> calculates a <strong>health score (0–100)</strong> for each person based on stale case ratio, awaiting-feedback ratio, and case velocity — perfect for workload rebalancing.",
      tips:["Health score 80+ = healthy workload balance","Red cards = member likely needs support or cases reassigned","Click any member row to expand and see all their cases in full detail"],
      pos:"right"
    },
    {
      target:'.nav-item[data-tab="performance"]', navigate:"performance",
      icon:"⚡", section:"Performance Cases",
      title:"Performance Cases — Critical Issue Tracker",
      desc:"A dedicated tracker for <strong>performance and slowness cases</strong> — CCM slowness, LQE timeouts, OOM events, and app outages. Each case is linked to a Work Item (WI) defect and tracked through weekly Wednesday update sessions.",
      tips:["Cases without a Work Item number are highlighted in red (⚠)","Wednesday updates persist permanently across browser sessions","Click any case row to expand its full detail panel with history"],
      pos:"right"
    },
    {
      target:null, navigate:"performance",
      icon:"📋", section:"Performance Cases",
      title:"Availability Status — Admin-Only Editing",
      desc:"Admins can mark each performance case with an <strong>Availability Status</strong> to track whether the IBM call happened each Wednesday:<br><br>✓ <strong>Attended</strong> · ✗ <strong>Not Joined</strong> · ◌ <strong>On Leave</strong> · → <strong>Follow Up</strong><br><br>Non-admins see the current status as a read-only badge.",
      tips:["Cases marked 'Not Joined' appear in the Follow-Up alert list","Status history is tracked and visible in case detail panel","Only Admins can change Availability — other users see read-only view"],
      pos:"center"
    },
    {
      target:'.nav-item[data-tab="weekly-tracker"]', navigate:"weekly-tracker",
      icon:"📅", section:"Weekly Tracker",
      title:"Weekly Tracker — Closed Case Log",
      desc:"The <strong>Weekly Tracker</strong> is a structured weekly log of every case closed, organized by calendar week (CW01–CW52). Browse any past week to review what was resolved, who handled it, what comments were recorded, and how cases were categorized.",
      tips:["Navigate weeks using the horizontal strip at the top","Click ⟲ Today to jump instantly to the current week","Export any week or the full year to an Excel spreadsheet"],
      pos:"right"
    },
    {
      target:"#wt-nav-strip",
      navigate:"weekly-tracker",
      icon:"🗓️", section:"Weekly Tracker",
      title:"Week Navigation Strip",
      desc:"Scroll horizontally through this strip to browse <strong>calendar weeks</strong>. Each week shows a badge with its case count. The currently selected week is highlighted in blue. Weeks are grouped by month for easy orientation.",
      tips:["Blue = currently selected week","Badge number = total cases closed that week","Scroll left to see earlier weeks in the year"],
      pos:"bottom"
    },
    {
      target:"#wt-global-search-wrap, #wt-global-search",
      navigate:"weekly-tracker",
      icon:"🔎", section:"Weekly Tracker",
      title:"Cross-Year Case Search",
      desc:"The Tracker's <strong>built-in search</strong> searches across ALL years simultaneously — not just the current week. Find any case by number, title, owner, category, or comment text. Results link directly back to the week it appeared in.",
      tips:["Works across 2025 and 2026 data simultaneously","Click a result row to jump to that case's week automatically","Use the 'Hide empty entries' checkbox to reduce clutter"],
      pos:"bottom"
    },
    {
      target:null, navigate:"weekly-tracker",
      icon:"📝", section:"Weekly Tracker — Admin Features",
      title:"Editing Cases (Admin Only)",
      desc:"Admins have full editing capabilities in the Tracker:<br><br>• <strong>Comment cell</strong> — click to open a rich popover editor<br>• <strong>Category pill</strong> — click to open the category picker<br>• <strong>Edit button</strong> — opens the full case edit modal<br>• <strong>Delete (×)</strong> — removes a case from the week<br>• <strong>Bulk select</strong> — checkboxes + bulk set Category/Availability",
      tips:["Non-admins can VIEW all data but cannot edit anything","Unsaved changes in comment popover are preserved while you scroll","History of all edits is automatically tracked and viewable in History tab"],
      pos:"center"
    },
    {
      target:null, navigate:"weekly-tracker",
      icon:"⏱️", section:"Weekly Tracker — Admin Features",
      title:"History & Reopened Tabs (Admin Only)",
      desc:"Two powerful audit tabs only visible to Admins:<br><br>• <strong>⏱ History</strong> — tracks every comment and status change for every case. Useful when a case is reopened after being marked closed.<br><br>• <strong>↺ Reopened</strong> — lists all cases that were closed and then reopened, across any week or year.",
      tips:["History entries are recorded automatically on every comment save","The history badge ⏱ N on case numbers shows how many changes were logged","Export full history to Excel for audit and compliance reporting"],
      pos:"center"
    },
    {
      target:'.nav-item[data-tab="investigate"]', navigate:"investigate",
      icon:"🔬", section:"Investigate",
      title:"Investigate — Permanent Case Archive & AI Search",
      desc:"The <strong>Investigate</strong> page gives you a searchable, permanent archive of every case ever loaded. Find similar past cases to resolve current issues faster, and use the AI assistant to analyze patterns and suggest solutions.",
      tips:["Archive grows with every Excel upload — cases are never deleted","Similarity matching automatically finds related past cases","Search by error code, product area, or symptom description"],
      pos:"right"
    },
    {
      target:'.nav-item[data-tab="rfe-tracking"]', navigate:"rfe-tracking",
      icon:"💡", section:"RFE Tracking",
      title:"RFE Tracking — IBM Feature Request Manager",
      desc:"Track <strong>IBM Request for Enhancement (RFE)</strong> items your team has submitted. Monitor vote counts, target releases, product areas, and internal notes. Keep visibility on what's in IBM's development pipeline for your customers.",
      tips:["Sort by Votes to prioritize the highest-impact requests","Add internal notes, tags, and target release expectations","Link RFEs to related IBM support cases for context"],
      pos:"right"
    },
    {
      target:'.nav-item[data-tab="documentation"]', navigate:"documentation",
      icon:"📚", section:"Documentation",
      title:"Documentation — Full Platform Reference",
      desc:"The platform's built-in <strong>reference manual</strong>, covering every feature in detail. Navigate using the left sidebar — sections cover Getting Started, every dashboard, keyboard shortcuts, data format requirements, admin configuration, and the API reference.",
      tips:["Use in-page search to find topics quickly","Architecture diagrams and flowcharts included","Always up-to-date with the latest version of the platform"],
      pos:"right"
    },
    {
      target:'.nav-item[data-tab="admin"], #nav-admin-portal',
      navigate:null,
      icon:"🔐", section:"Admin Portal",
      title:"Admin Portal — Restricted to Admins",
      desc:"The <strong>Admin Portal</strong> is only accessible to Admin users. It provides: bulk case reassignment across the team, performance case curation, RFE data import from Excel, system configuration (account IDs, SLA targets), and a full audit trail with undo support.",
      tips:["Admins can reassign multiple cases to a different owner in one action","Configure customer account IDs and SLA thresholds here","All admin actions are logged with timestamps for auditing"],
      pos:"right"
    },
    {
      target:null, navigate:null,
      icon:"⌨️", section:"Keyboard Shortcuts",
      title:"All Keyboard Shortcuts — Work Faster",
      desc:`Master these shortcuts to move at full speed:<br><br>
        <kbd>Ctrl</kbd><kbd>K</kbd> — Open Command Palette<br>
        <kbd>Ctrl</kbd><kbd>L</kbd> — Open / Close this Guide<br>
        <kbd>/</kbd> — Focus global case search<br>
        <kbd>?</kbd> — Open keyboard shortcut reference panel<br>
        <kbd>1</kbd>–<kbd>9</kbd> — Jump directly to numbered dashboard<br>
        <kbd>←</kbd> <kbd>→</kbd> — Navigate tour steps<br>
        <kbd>Esc</kbd> — Exit this tour at any time`,
      tips:["Press ? any time to open the full shortcut reference panel","Shortcuts are disabled when typing in input fields","Number keys 1–9 follow the sidebar order from top to bottom"],
      pos:"center"
    },
    {
      target:null, navigate:"overview",
      icon:"🎉", section:"You're All Set!",
      title:"Tour Complete — Welcome to the Platform",
      desc:"You've completed the full tour of the <strong>IBM Case Intelligence Platform</strong>! You now know how to navigate every page, use the key features, and work efficiently with keyboard shortcuts.<br><br>Press <kbd>Ctrl</kbd><kbd>L</kbd> at any time to reopen this guide. Press <kbd>Ctrl</kbd><kbd>K</kbd> to run any action instantly.",
      tips:["Upload your latest Excel file to refresh all dashboard data","Bookmark this page for quick daily access","Check the Documentation page for deep-dive reference on any feature"],
      pos:"center",
      isLast:true
    }
  ];

  /* ── State ───────────────────────────────────────────────────── */
  let _active  = false;
  let _step    = 0;
  let _root    = null;
  let _welcome = null;

  /* ────────────────────────────────────────────────────────────── */
  /*  PUBLIC: startTour                                             */
  /* ────────────────────────────────────────────────────────────── */
  function startTour() {
    if (_active || _welcome) return;
    _injectStyles();
    _showWelcome();
  }

  /* ── Welcome splash modal ────────────────────────────────────── */
  function _showWelcome() {
    _welcome = document.createElement("div");
    _welcome.id = "igt-welcome";
    _welcome.innerHTML = `
      <div id="igt-wcard">
        <div id="igt-wtop">
          <div id="igt-wbadge">🎯 Interactive Platform Guide</div>
          <div id="igt-wtitle">IBM Case Intelligence Platform</div>
          <div id="igt-wsub">A complete walkthrough of every feature — dashboards, tracking tools, admin features, and keyboard shortcuts. Takes about 3–4 minutes.</div>
        </div>
        <div id="igt-wbot">
          <div id="igt-wpages">
            <div class="igt-wpi"><div class="igt-wpi-ic" style="background:#edf5ff">📊</div><div><div class="igt-wpi-nm">Dashboards</div><div class="igt-wpi-sb">Overview, Team, Members</div></div></div>
            <div class="igt-wpi"><div class="igt-wpi-ic" style="background:#defbe6">✅</div><div><div class="igt-wpi-nm">Case Tracking</div><div class="igt-wpi-sb">Weekly, Performance, RFE</div></div></div>
            <div class="igt-wpi"><div class="igt-wpi-ic" style="background:#f6f2ff">🔬</div><div><div class="igt-wpi-nm">Investigate</div><div class="igt-wpi-sb">AI search & archive</div></div></div>
            <div class="igt-wpi"><div class="igt-wpi-ic" style="background:#fff1f1">🔐</div><div><div class="igt-wpi-nm">Admin Tools</div><div class="igt-wpi-sb">Bulk actions & config</div></div></div>
          </div>
          <div id="igt-wactions">
            <button id="igt-wstart">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polygon points="5 3 19 12 5 21 5 3"/></svg>
              Start Tour (${STEPS.length} steps)
            </button>
            <button id="igt-wskip">Skip for now</button>
          </div>
          <div id="igt-wtip">Press <kbd>Enter</kbd> to start · <kbd>Esc</kbd> to close · <kbd>Ctrl</kbd><kbd>L</kbd> to reopen later</div>
        </div>
      </div>`;
    document.body.appendChild(_welcome);
    setTimeout(() => _welcome.classList.add("igt-vis"), 10);
    _welcome.querySelector("#igt-wstart").addEventListener("click", () => { _dismissWelcome(); setTimeout(_beginTour, 260); });
    _welcome.querySelector("#igt-wskip").addEventListener("click", _dismissWelcome);
    _welcome.addEventListener("click", e => { if (e.target === _welcome) _dismissWelcome(); });
    document.addEventListener("keydown", _wKeyHandler);
  }

  function _wKeyHandler(e) {
    if (e.key === "Escape") { e.preventDefault(); _dismissWelcome(); }
    if (e.key === "Enter")  { e.preventDefault(); _dismissWelcome(); setTimeout(_beginTour, 260); }
  }

  function _dismissWelcome() {
    document.removeEventListener("keydown", _wKeyHandler);
    if (!_welcome) return;
    _welcome.classList.remove("igt-vis");
    setTimeout(() => { _welcome?.remove(); _welcome = null; }, 300);
  }

  /* ── Build main tour DOM ─────────────────────────────────────── */
  function _beginTour() {
    _active = true;
    _step   = 0;
    _root   = document.createElement("div");
    _root.id = "igt-root";
    _root.innerHTML = `
      <div id="igt-backdrop"></div>
      <div id="igt-spotlight"></div>
      <div id="igt-tooltip" data-pos="right">
        <div id="igt-hdr">
          <div id="igt-hdr-left">
            <div id="igt-icon"></div>
            <div><div id="igt-section"></div><div id="igt-title"></div></div>
          </div>
          <button id="igt-xbtn" title="Exit tour (Esc)">✕</button>
        </div>
        <div id="igt-body">
          <div id="igt-counter"></div>
          <div id="igt-desc"></div>
          <div id="igt-tips"><div id="igt-tips-lbl">💡 Quick Tips</div><ul></ul></div>
        </div>
        <div id="igt-foot">
          <button id="igt-pbtn">← Prev</button>
          <div id="igt-dots"></div>
          <button id="igt-nbtn">Next →</button>
        </div>
        <div id="igt-kbhint"><kbd>←</kbd><kbd>→</kbd> navigate &nbsp;·&nbsp; <kbd>Esc</kbd> exit</div>
      </div>`;
    document.body.appendChild(_root);
    _q("#igt-xbtn").addEventListener("click", endTour);
    _q("#igt-backdrop").addEventListener("click", endTour);
    _q("#igt-pbtn").addEventListener("click", _prev);
    _q("#igt-nbtn").addEventListener("click", _next);
    document.addEventListener("keydown", _kHandler);
    setTimeout(() => _root.classList.add("igt-vis"), 10);
    _renderStep(0);
  }

  /* ── Render a step ───────────────────────────────────────────── */
  function _renderStep(idx) {
    const step  = STEPS[idx];
    const total = STEPS.length;
    const isLast = step.isLast || idx === total - 1;

    // Navigate if needed
    if (step.navigate && typeof App !== "undefined") {
      try { App.renderTab(step.navigate); } catch(e) {}
    }

    const doRender = () => {
      _q("#igt-icon").textContent    = step.icon || "▶";
      _q("#igt-section").textContent = step.section || "";
      _q("#igt-title").textContent   = step.title || "";
      _q("#igt-counter").textContent = `Step ${idx + 1} of ${total}`;
      _q("#igt-desc").innerHTML      = step.desc || "";

      // Tips
      const ul = _q("#igt-tips ul");
      if (step.tips && step.tips.length) {
        ul.innerHTML = step.tips.map(t => `<li>${t}</li>`).join("");
        _q("#igt-tips").style.display = "block";
      } else {
        _q("#igt-tips").style.display = "none";
      }

      // Dots
      _q("#igt-dots").innerHTML = STEPS.map((_, i) => {
        const c = i === idx ? "act" : (i < idx ? "dn" : "");
        return `<div class="igd ${c}"></div>`;
      }).join("");

      // Buttons
      _q("#igt-pbtn").disabled = idx === 0;
      const nb = _q("#igt-nbtn");
      nb.textContent = isLast ? "Finish ✓" : "Next →";
      nb.className   = isLast ? "fin" : "";
      nb.id          = "igt-nbtn";

      // Position spotlight + tooltip
      const target = step.target ? document.querySelector(step.target) : null;
      if (target) {
        target.scrollIntoView({ behavior:"smooth", block:"nearest" });
        requestAnimationFrame(() => _positionOnTarget(target, step.pos || "right"));
      } else {
        _hideSpot();
        _centerTT();
        _q("#igt-tooltip").setAttribute("data-pos","center");
      }
    };

    step.navigate ? setTimeout(doRender, 380) : doRender();
  }

  function _positionOnTarget(target, pos) {
    const pad  = 8;
    const rect = target.getBoundingClientRect();
    const spot = _q("#igt-spotlight");
    spot.style.cssText = `left:${rect.left-pad}px;top:${rect.top-pad}px;width:${rect.width+pad*2}px;height:${rect.height+pad*2}px;`;
    _placeTT(rect, pos);
  }

  function _placeTT(r, pos) {
    const tt  = _q("#igt-tooltip");
    const ttW = 348;
    const ttH = tt.offsetHeight || 290;
    const vw  = window.innerWidth;
    const vh  = window.innerHeight;
    const g   = 16, p = 12;
    let left, top, fp = pos;

    if (pos === "right") {
      left = r.right + g; top = r.top + r.height/2 - ttH/2;
      if (left + ttW > vw - p) { left = r.left - ttW - g; fp = "left"; }
    } else if (pos === "left") {
      left = r.left - ttW - g; top = r.top + r.height/2 - ttH/2;
      if (left < p) { left = r.right + g; fp = "right"; }
    } else if (pos === "bottom") {
      top = r.bottom + g; left = r.left + r.width/2 - ttW/2;
      if (top + ttH > vh - p) { top = r.top - ttH - g; fp = "top"; }
    } else {
      top = r.top - ttH - g; left = r.left + r.width/2 - ttW/2;
      if (top < p) { top = r.bottom + g; fp = "bottom"; }
    }

    left = Math.max(p, Math.min(left, vw - ttW - p));
    top  = Math.max(p, Math.min(top,  vh - ttH - p));
    tt.style.left = left+"px"; tt.style.top = top+"px";
    tt.setAttribute("data-pos", fp);
  }

  function _hideSpot() {
    const s = _q("#igt-spotlight");
    s.style.cssText = "left:-9999px;top:-9999px;width:0;height:0;";
  }

  function _centerTT() {
    const tt = _q("#igt-tooltip");
    const ttW = 348, ttH = tt.offsetHeight || 320;
    const vw = window.innerWidth, vh = window.innerHeight;
    tt.style.left = Math.max(12,(vw-ttW)/2)+"px";
    tt.style.top  = Math.max(12,(vh-ttH)/2)+"px";
    tt.setAttribute("data-pos","center");
  }

  /* ── Navigation ──────────────────────────────────────────────── */
  function _next() { if (_step < STEPS.length-1) { _step++; _renderStep(_step); } else { endTour(); } }
  function _prev() { if (_step > 0) { _step--; _renderStep(_step); } }

  /* ── End tour ────────────────────────────────────────────────── */
  function endTour() {
    _active = false;
    document.removeEventListener("keydown", _kHandler);
    _dismissWelcome();
    if (_root) {
      _root.classList.remove("igt-vis");
      setTimeout(() => { _root?.remove(); _root = null; }, 350);
    }
  }

  /* ── Key handler ─────────────────────────────────────────────── */
  function _kHandler(e) {
    if (e.key==="Escape")                          { e.preventDefault(); endTour(); }
    if (e.key==="ArrowRight"||e.key==="ArrowDown") { e.preventDefault(); _next(); }
    if (e.key==="ArrowLeft" ||e.key==="ArrowUp")   { e.preventDefault(); _prev(); }
  }

  function _q(sel) { return _root ? _root.querySelector(sel) : null; }

  /* ═══════════════════════════════════════════════════════════════
     PUBLIC API & TRIGGER WIRING
  ═══════════════════════════════════════════════════════════════ */
  window.AppTour        = { start: startTour, end: endTour };
  window._startAppTour  = startTour;

  /* Ctrl+L anywhere — open / close tour */
  document.addEventListener("keydown", function(e) {
    if (!(e.ctrlKey || e.metaKey) || e.key !== "l" || e.shiftKey || e.altKey) return;
    const tag = document.activeElement?.tagName;
    if (tag==="INPUT"||tag==="TEXTAREA"||tag==="SELECT") return;
    e.preventDefault();
    if (_active || _welcome) { endTour(); } else { startTour(); }
  });

  /* "Start Guided Tour" button on How It Works page */
  document.addEventListener("click", function(e) {
    if (e.target.closest("#hiw-start-tour")) { e.preventDefault(); startTour(); }
  });

  /* Command palette "tour" fn — override Onboarding.startTour to use our rich tour */
  document.addEventListener("DOMContentLoaded", function() {
    if (typeof Onboarding !== "undefined" && Onboarding.startTour) {
      Onboarding.startTour = startTour;
    }
  });

  /* Slight delay to also patch after DOMContentLoaded in case Onboarding loaded later */
  setTimeout(function() {
    if (typeof Onboarding !== "undefined" && Onboarding.startTour && Onboarding.startTour !== startTour) {
      Onboarding.startTour = startTour;
    }
  }, 500);

})();
