/* ============================================================
   js/dashboards/team.js  —  Team Cases tab
   ============================================================ */
const DashTeam = (() => {
  /* ── Loading state helper ─────────────────────────────────────
     Usage: _setLoading(true) before data fetch, _setLoading(false) after.
     Applies .is-loading class to the dashboard root element.
  ────────────────────────────────────────────────────────────── */
  function _setLoading(active) {
    const el = document.getElementById('content-area') || document.body;
    el.classList.toggle('dashboard-loading', active);
    // Show/hide skeleton shimmer on tables
    document.querySelectorAll('.table-wrap, .dash-table').forEach(t => {
      t.classList.toggle('skeleton-loading', active);
    });
  }


  let _filterOwner  = "";
  let _filterStatus = "";
  let _filterDays   = "";
  let _tableRef     = null;

  // Save filter state to StateManager (production-grade persistence)
  function _saveFilters() {
    if (typeof StateManager !== "undefined") {
      StateManager.saveFiltersForDashboard("team", {
        owner: _filterOwner,
        status: _filterStatus,
        days: _filterDays
      });
    }
  }

  // Update filter badge: shows count of active filters
  function _updateFilterBadge() {
    const badge = document.getElementById("filter-count-badge");
    if (!badge) return;
    const count = (_filterOwner?1:0) + (_filterStatus?1:0) + (_filterDays?1:0);
    badge.style.display = count > 0 ? 'inline-flex' : 'none';
    badge.textContent = count;
  }

  function render() {
    const el = document.getElementById("tab-team");
    if (!el) return;

    // Restore filter state from StateManager (production-grade persistence)
    if (typeof StateManager !== "undefined") {
      const savedFilters = StateManager.getFiltersForDashboard("team");
      if (savedFilters.owner !== undefined) _filterOwner = savedFilters.owner;
      if (savedFilters.status !== undefined) _filterStatus = savedFilters.status;
      if (savedFilters.days !== undefined) _filterDays = savedFilters.days;
    }

    const team    = Data.teamCases();
    const members = Data.teamMembers().slice().sort();

    const memberOpts = members.map(m =>
      `<option value="${Utils.escHtml(m)}" ${m===_filterOwner?"selected":""}>
        ${Utils.escHtml(Utils.shortName(m))}</option>`).join("");

    const statusOpts = [
      { value: "__inprogress__", label: "In Progress (All)" },
      { value: "__closed__",     label: "Closed (All)" },
      { value: "Awaiting your feedback", label: "Awaiting your feedback" },
      { value: "IBM is working",         label: "IBM is working" },
      { value: "Waiting for IBM",        label: "Waiting for IBM" },
      { value: "Closed by IBM",          label: "Closed by IBM" },
      { value: "Closed by Client",       label: "Closed by Client" },
      { value: "Closed - Archived",      label: "Closed - Archived" },
    ].map(s => `<option value="${Utils.escHtml(s.value)}" ${s.value===_filterStatus?"selected":""}>${Utils.escHtml(s.label)}</option>`)
     .join("");

    el.innerHTML = `
      <div class="kpi-row" id="team-kpi-row"></div>

      <!-- Toolbar: Send Mail button + filters -->
      <div class="filter-bar mt-5">
        <div class="filter-group" style="position:relative">
          <span class="filter-label">Owner</span>
          <div style="position:relative;display:flex;align-items:center">
            <input id="tf-owner-search" type="text" class="form-input form-input-sm"
              placeholder="Search owner…" autocomplete="off"
              style="min-width:180px;padding-right:28px;cursor:pointer" readonly/>
            <svg style="position:absolute;right:8px;pointer-events:none;color:var(--text-tertiary)" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
          </div>
          <div id="tf-owner-dropdown" style="display:none;position:absolute;top:100%;left:0;background:var(--bg-ui);border:1px solid var(--border-mid);border-radius:var(--radius-md);box-shadow:var(--shadow-lg);z-index:400;max-height:260px;overflow-y:auto;min-width:180px">
            <div style="padding:6px 8px;border-bottom:1px solid var(--border-subtle);position:sticky;top:0;background:var(--bg-ui)">
              <input id="tf-owner-filter" type="text" class="form-input form-input-sm" placeholder="Type to search…" style="width:100%"/>
            </div>
            <div id="tf-owner-option-list"></div>
          </div>
        </div>
        <div class="filter-group">
          <span class="filter-label">Status</span>
          <select id="tf-status" class="form-select min-200">
            <option value="">All Statuses</option>${statusOpts}
          </select>
        </div>
        <div class="filter-group">
          <span class="filter-label">Last Updated ≥ (days)</span>
          <input id="tf-days" type="number" class="form-input form-input-sm"
            style="width:90px" placeholder="e.g. 5" value="${Utils.escHtml(_filterDays)}"/>
        </div>
        <div style="display:flex;align-items:center;gap:6px">
          <button id="tf-clear" aria-label="Clear team filter" class="btn btn-ghost btn-sm">Clear</button>
          <span id="filter-count-badge" style="display:${_filterOwner || _filterStatus || _filterDays ? 'inline-flex' : 'none'};align-items:center;justify-content:center;background:var(--ibm-blue-50);color:white;font-size:11px;font-weight:600;border-radius:50%;width:20px;height:20px;min-width:20px">${(_filterOwner?1:0)+(_filterStatus?1:0)+(_filterDays?1:0)}</span>
        </div>
        <button id="tf-send-mail" aria-label="Send reminder mail" class="btn btn-primary btn-sm">✉ Send Reminder Mail</button>
      </div>

      <div class="tile mt-5">
        <div class="section-title">Owner vs Case Count</div>
        <div class="chart-canvas-wrap" style="height:300px"><canvas id="chart-team-owners"></canvas></div>
      </div>

      <div class="tile mt-5">
        <div class="section-title">Case Details</div>
        <div id="tbl-team"></div>
      </div>
    `;

    const filtered = filteredCases();
    renderKPIs(filtered);

    try { Charts.ownerBar("chart-team-owners", Utils.ownerCounts(filtered), {
      color: "#0043ce",
      onClick: ownerName => {
        // Toggle: if clicking same owner, clear filter; otherwise set to that owner
        if (_filterOwner === ownerName) {
          _filterOwner = "";
          document.getElementById("tf-owner-search").value = "";
        } else {
          _filterOwner = ownerName;
          document.getElementById("tf-owner-search").value = Utils.shortName(ownerName);
        }
        _saveFilters();
        _updateFilterBadge();
        applyFilters();
        // Scroll to table after a brief delay to let filters apply
        setTimeout(() => {
          const tableEl = document.getElementById("tbl-team");
          if (tableEl) tableEl.scrollIntoView({ behavior: "smooth", block: "start" });
        }, 100);
      }
    }); } catch(e) { console.warn("[DashTeam] chart error:", e); }

    // ── Custom searchable owner dropdown ──────────────
    (function() {
      const searchInput  = document.getElementById("tf-owner-search");
      const dropdown     = document.getElementById("tf-owner-dropdown");
      const filterInput  = document.getElementById("tf-owner-filter");
      const optionList   = document.getElementById("tf-owner-option-list");
      if (!searchInput) return;

      function buildOptions(filter) {
        const q = (filter || "").toLowerCase();
        optionList.innerHTML = "";
        members.forEach(member => {
          const text = Utils.shortName(member);
          if (q && text.toLowerCase().indexOf(q) === -1) return;
          const div = document.createElement("div");
          div.textContent = text;
          div.style.cssText = "padding:8px 12px;cursor:pointer;font-size:13px;color:var(--text-primary)";
          div.dataset.value = member;
          div.addEventListener("mouseenter", () => div.style.background = "var(--bg-hover)");
          div.addEventListener("mouseleave", () => div.style.background = "");
          div.addEventListener("click", () => {
            _filterOwner = member;
            searchInput.value = text;
            dropdown.style.display = "none";
            _saveFilters();
            _updateFilterBadge();
            applyFilters();
          });
          optionList.appendChild(div);
        });
        if (!optionList.children.length) {
          optionList.innerHTML = '<div style="padding:10px 12px;font-size:12px;color:var(--text-tertiary)">No matches</div>';
        }
      }

      searchInput.addEventListener("click", () => {
        const open = dropdown.style.display !== "none";
        dropdown.style.display = open ? "none" : "block";
        if (!open) { buildOptions(""); filterInput.value = ""; filterInput.focus(); }
      });
      searchInput.addEventListener("keydown", () => {
        dropdown.style.display = "block"; buildOptions(""); filterInput.value = ""; filterInput.focus();
      });
      filterInput.addEventListener("input", e => buildOptions(e.target.value));
      filterInput.addEventListener("keydown", e => {
        if (e.key === "Escape") { dropdown.style.display = "none"; searchInput.focus(); }
        if (e.key === "Enter") { const first = optionList.querySelector("div"); if (first) first.click(); }
      });
      document.addEventListener("click", e => {
        const wrap = searchInput.closest(".filter-group");
        if (wrap && !wrap.contains(e.target)) dropdown.style.display = "none";
      });
    })();

    document.getElementById("tf-status").addEventListener("change", e => { _filterStatus = e.target.value; _saveFilters(); _updateFilterBadge(); applyFilters(); });
    document.getElementById("tf-days").addEventListener("input",  e => { _filterDays = e.target.value; _saveFilters(); _updateFilterBadge(); applyFilters(); });
    document.getElementById("tf-clear").addEventListener("click", () => {
      _filterOwner=""; _filterStatus=""; _filterDays="";
      const tos = document.getElementById("tf-owner-search"); if(tos){tos.value="";}
      const tod = document.getElementById("tf-owner-dropdown"); if(tod) tod.style.display="none";
      document.getElementById("tf-status").value="";
      document.getElementById("tf-days").value="";
      _saveFilters();
      _updateFilterBadge();
      applyFilters();
    });

    // Send Reminder Mail — opens Outlook directly, no restrictions
    document.getElementById("tf-send-mail").addEventListener("click", () => {
      const visible = filteredCases();
      if (!visible.length) { alert("No cases in current view."); return; }
      Mail.openReminderPreview(visible, "Kabelesh K");
    });

    const container = document.getElementById("tbl-team");
    _tableRef = Table.render(container, filtered, {
      showActions: true,
      showRemind: false,
      showReassign: Data.isAdmin(),
      onReassign: row => {
        Modal.showReassign(row, (caseNum, newOwner) => {
          const prevOwner = row.Owner;
          Data.reassignCase(caseNum, newOwner);
          if (typeof DashWeeklyTracker !== "undefined") DashWeeklyTracker.enrichFromCases(Data.allCases());
          render();
          // Tier 4.3: Push undo action
          if (typeof PerfUtils !== "undefined") {
            PerfUtils.pushAction({
              name: `Reassigned ${Utils.shortName(caseNum)} → ${Utils.shortName(newOwner)}`,
              undo: () => { Data.reassignCase(caseNum, prevOwner); render(); },
            });
          }
          // Tier 5.3: Celebrate success
          if (typeof Polish !== "undefined") {
            Polish.Celebrate.show({
              title: `Case reassigned`,
              message: `${caseNum} → ${Utils.shortName(newOwner)}`,
              count: 1,
              duration: 2500,
            });
          }
        });
      },
      extraCols: [lastUpdatedDaysCol()],
      defaultSortKey: "_lastUpdDays",
      defaultSortDir: -1   // oldest (highest days) first
    });

    // ── Tier 1.2: Smart Table Defaults — Column Manager ────────────
    // Shows 6 key columns by default; users can add/hide others.
    // Preferences persisted in localStorage per table ID.
    if (typeof ColMgr !== "undefined" && typeof Table !== "undefined") {
      try {
        const allColDefs = [...Table.defaultColumns(), lastUpdatedDaysCol()];
        ColMgr.wrap(container, allColDefs, {
          tableId: "team",
          defaultCols: ColMgr.DEFAULT_COLS,
        });
      } catch(e) { console.warn("ColMgr.wrap:", e); }
    }
  }

  // Opens Outlook with mailto — matches screenshot format with table rows
  function lastUpdatedDaysCol() {
    return {
      key: "_lastUpdDays", label: "Last Updated (Days)", sortable: true,
      render: row => {
        const d = Utils.parseDate(row.Updated) || Utils.parseDate(row.Created);
        const days = Utils.daysDiff(d);
        const color = days >= 10 ? "var(--red)" : days >= 5 ? "var(--yellow)" : "var(--text-tertiary)";
        return `<span style="color:${color};font-family:var(--font-mono);font-weight:600">${days}</span>`;
      },
      sortValue: row => {
        const d = Utils.parseDate(row.Updated) || Utils.parseDate(row.Created);
        return Utils.daysDiff(d);
      }
    };
  }

  function renderKPIs(cases) {
    const row = document.getElementById("team-kpi-row");
    if (!row) return;
    const today   = new Date();
    const active  = cases.filter(r => !Utils.isClosed(r.Status));
    const inprog  = active.filter(r => r.Status==="IBM is working"||r.Status==="Waiting for IBM");
    const await_  = active.filter(r => r.Status==="Awaiting your feedback");
    const members = new Set(active.map(r=>r.Owner)).size;
    const closed7 = cases.filter(r => {
      if (!Utils.isClosed(r.Status)) return false;
      const d = Utils.parseDate(r["Closed Date"]) || Utils.parseDate(r.Updated);
      if (!d) return false;
      return (today - d) >= 0 && (today - d) <= 7 * 86400000;
    });
    const custActive = Data.customerCases().filter(r => !Utils.isClosed(r.Status)).length;
    row.innerHTML = [
      kpi("Total Cases",       active.length,             "kpi-yellow"),
      kpi("In Progress",        inprog.length,             "kpi-blue",
          "IBM Working: "+active.filter(r=>r.Status==="IBM is working").length+" · Waiting: "+active.filter(r=>r.Status==="Waiting for IBM").length),
      kpi("Awaiting Feedback",  await_.length,             "kpi-red"),
      kpi("Closed (Last 7days)",   closed7.length,            "kpi-green"),
      kpi("Active Members",     members,                   "kpi-purple"),
    ].join("");
  }

  function filteredCases() {
    return Data.teamCases().filter(r => {
      if (_filterOwner && r.Owner !== _filterOwner) return false;
      if (_filterStatus) {
        if (_filterStatus === "__inprogress__") {
          if (Utils.isClosed(r.Status)) return false;
        } else if (_filterStatus === "__closed__") {
          if (!Utils.isClosed(r.Status)) return false;
        } else {
          if (r.Status !== _filterStatus) return false;
        }
      }
      if (_filterDays) {
        const d = Utils.parseDate(r.Updated) || Utils.parseDate(r.Created);
        if (Utils.daysDiff(d) < parseInt(_filterDays)) return false;
      }
      return true;
    });
  }

  function applyFilters() {
    const cases = filteredCases();
    renderKPIs(cases);
    // Redraw histogram with filtered data
    try { Charts.ownerBar("chart-team-owners", Utils.ownerCounts(cases), {
      color: "var(--ibm-blue-30)",
      onClick: ownerName => {
        // Toggle: if clicking same owner, clear filter; otherwise set to that owner
        if (_filterOwner === ownerName) {
          _filterOwner = "";
          document.getElementById("tf-owner-search").value = "";
        } else {
          _filterOwner = ownerName;
          document.getElementById("tf-owner-search").value = Utils.shortName(ownerName);
        }
        applyFilters();
        // Scroll to table after a brief delay to let filters apply
        setTimeout(() => {
          const tableEl = document.getElementById("tbl-team");
          if (tableEl) tableEl.scrollIntoView({ behavior: "smooth", block: "start" });
        }, 100);
      }
    }); } catch(e) { console.warn("[DashTeam] chart error:", e); }
    if (_tableRef) _tableRef.refresh(cases);
  }

  function kpi(label, value, cls="", sub="") {
    return `<div class="kpi-card ${cls}">
      <div class="kpi-label">${label}</div>
      <div class="kpi-value">${value}</div>
      ${sub ? `<div class="text-meta-top">${sub}</div>` : ""}
    </div>`;
  }

  return {
    render,
    // F24: Stable method for global search to pre-fill team search without fragile DOM query
    setSearch: val => { if (_tableRef) _tableRef.setSearch(val); }
  };

})();
