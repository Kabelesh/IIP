/* ================================================================
   how-it-works.js — Cinematic "How It Works" interactive guide
   Features: animated flow diagram, step-by-step stepper mode,
   progress tracking, live search, and app tour launcher.
   ================================================================ */
(function () {
  "use strict";

  const PAGES = [
    {
      id: "upload", icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>',
      color: "#198038", colorBg: "#defbe6", title: "Upload Data", tagline: "Import your case data to get started",
      description: "Everything starts here. Drag a CSV or Excel file onto the upload zone and the platform handles the rest — parsing, deduplicating, and merging data into your live dashboards.",
      steps: [
        { action: "Drag & drop a CSV/XLSX file onto the upload screen, or click \"Choose File\"", result: "File is read and parsed by the XLSX library — entirely in your browser", icon: "📂" },
        { action: "Progress bar advances: Reading → Parsing → Merging → Building → Done", result: "Cases are validated, normalized, and intelligently merged with existing data", icon: "⚙️" },
        { action: "Upload completes — dashboard loads automatically", result: "All pages now have live data; cases are archived for future investigation", icon: "✅" }
      ],
      backend: "File parsed client-side (XLSX.js). Data stored in localStorage. No server upload required.",
      tips: ["Supports CSV, XLSX, XLS, XLSM formats", "Re-uploading merges new data — nothing is lost", "Duplicate files are detected by fingerprint to prevent redundant imports"]
    },
    {
      id: "overview", icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></svg>',
      color: "#0f62fe", colorBg: "#edf5ff", title: "Overview", tagline: "Your command center — everything at a glance",
      description: "The Overview page is your mission control. Four KPI cards reveal your team's pulse, while interactive charts let you click through to filtered case lists in seconds.",
      steps: [
        { action: "View KPI cards: Total, Open, Stale, Closed (7d)", result: "Instant snapshot of team health and case volume", icon: "📊" },
        { action: "Check the status donut chart and product breakdown", result: "Understand case distribution across products and statuses", icon: "🍩" },
        { action: "Review the owner workload bar chart (clickable)", result: "Click any bar to filter the table by that owner", icon: "👆" },
        { action: "Switch trend window: 3 / 6 / 12 months", result: "See how case volume has changed over time", icon: "📈" }
      ],
      backend: "Pure client-side aggregation from localStorage. No API calls.",
      tips: ["Stale = cases not updated in 5+ days", "Click chart bars to cross-filter the case table", "Use the search box to find specific cases quickly"]
    },
    {
      id: "team", icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
      color: "#6929c4", colorBg: "#f6f2ff", title: "Team Cases", tagline: "Filter and manage all team cases",
      description: "The Team Cases page is your day-to-day workspace. Apply powerful filters to isolate specific subsets of work, send reminders with one click, and sort by any column to reprioritize.",
      steps: [
        { action: "Filter by Owner, Status, or Days Since Update", result: "Table narrows to matching cases instantly", icon: "🔍" },
        { action: "Click bars in the Owner chart to toggle owner filter", result: "Quick visual filtering by team member", icon: "📊" },
        { action: "Click \"Send Reminder Mail\" for filtered cases", result: "Email reminder triggered for overdue case owners", icon: "📧" },
        { action: "Sort columns by clicking headers", result: "Organize cases by severity, date, status, etc.", icon: "↕️" }
      ],
      backend: "Reminder email uses mailto: link or configured mail service.",
      tips: ["Use \"Days since update\" to find neglected cases", "Combine filters to narrow down specific case sets", "Owner chart bars are interactive — click to filter/unfilter"]
    },
    {
      id: "members", icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="19" y1="8" x2="19" y2="14"/><line x1="22" y1="11" x2="16" y2="11"/></svg>',
      color: "#0f62fe", colorBg: "#edf5ff", title: "Member Dashboard", tagline: "Individual workload and health scores",
      description: "See your team through an individual lens. The Member Dashboard calculates a health score for each person based on stale cases and feedback-awaiting ratios — perfect for workload rebalancing.",
      steps: [
        { action: "View team-wide KPIs at the top (members, active, awaiting, closed 7d)", result: "Quick summary of the entire team's workload", icon: "👥" },
        { action: "Browse member cards showing per-person stats", result: "See each member's open, closed, awaiting cases, and health score", icon: "🃏" },
        { action: "Sort members by Active, Closed, Health, or Awaiting", result: "Quickly find overloaded or underutilized team members", icon: "↕️" },
        { action: "Click a member row to expand full detail", result: "View all cases owned by that member with performance metrics", icon: "🔎" }
      ],
      backend: "Health score computed client-side: factors in stale %, awaiting feedback %.",
      tips: ["Health score 0–100: higher = healthier workload", "Red indicators flag members with too many stale cases", "Use this page for workload rebalancing decisions"]
    },
    {
      id: "customer", icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>',
      color: "#198038", colorBg: "#defbe6", title: "Customer Cases", tagline: "Track cases by customer account",
      description: "A dedicated view scoped to a specific customer account. All filters and charts respond to your selected account ID, giving you a clean, customer-centric perspective.",
      steps: [
        { action: "View KPIs: Customer total, open, closed, in-progress", result: "Account-level case health at a glance", icon: "📋" },
        { action: "Filter by Year, Month, Date Range, or Status", result: "Slice customer cases by any time period", icon: "📅" },
        { action: "Click owner chart bars to filter by assignee", result: "See which team members handle which customer cases", icon: "👆" },
        { action: "Sort and search the case table", result: "Find specific customer cases quickly", icon: "🔍" }
      ],
      backend: "Filters cases by Customer Account ID (configurable in Admin).",
      tips: ["Default customer account ID can be changed in Admin Portal", "Combine date filters for precise time-range analysis"]
    },
    {
      id: "closed", icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>',
      color: "#198038", colorBg: "#defbe6", title: "Closed Cases", tagline: "Historical analysis of case closures",
      description: "The historical record of resolved cases. Three trend charts reveal your team's closure patterns and help identify seasonal workload shifts.",
      steps: [
        { action: "View KPIs: Total closed, this month, last 7 days", result: "Closure rate metrics at a glance", icon: "✅" },
        { action: "Explore 3 trend charts: Monthly, Weekly (12 wk), Yearly", result: "Spot closure patterns and seasonal trends", icon: "📈" },
        { action: "Click owner bars to filter by who closed cases", result: "See individual contribution to case closures", icon: "👆" },
        { action: "Apply date filters (Year/Month, range, last N days)", result: "Drill into specific time periods", icon: "📅" }
      ],
      backend: "All computed from case Closed Date field in localStorage.",
      tips: ["Weekly chart shows last 12 ISO weeks for recent trends", "Combine with Created Cases to see if you're closing faster than opening"]
    },
    {
      id: "created", icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg>',
      color: "#6929c4", colorBg: "#f6f2ff", title: "Created Cases", tagline: "Track case creation rate and trends",
      description: "The intake side of your pipeline. Track how many new cases are arriving and when, then compare against Closed Cases to understand whether the queue is growing or shrinking.",
      steps: [
        { action: "View creation KPIs: Total, this month, last 7 days", result: "Case intake velocity metrics", icon: "📊" },
        { action: "Explore Monthly, Weekly, and Yearly creation charts", result: "Identify spikes in case creation", icon: "📈" },
        { action: "Filter by date range or owner", result: "Narrow to specific periods or assignees", icon: "🔍" },
        { action: "Compare with Closed Cases page", result: "Determine if team is keeping up with incoming volume", icon: "⚖️" }
      ],
      backend: "Aggregated from Created Date field. Same architecture as Closed Cases.",
      tips: ["Creation spikes often correlate with product releases or outages", "Use alongside Closed Cases to track net case growth/reduction"]
    },
    {
      id: "performance", icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>',
      color: "#da1e28", colorBg: "#fff1f1", title: "Performance", tagline: "ALM instance performance case tracking",
      description: "Auto-detects performance-related cases using regex matching on ALM instance identifiers. Link directly to CCM defect IDs and mark or unmark cases as performance issues.",
      steps: [
        { action: "View performance cases table with ALM instance detection", result: "Cases auto-tagged with ALM instance (ALM-01-P through ALM-28-T4)", icon: "🔬" },
        { action: "Filter by ALM instance, product, or severity", result: "Focus on specific infrastructure issues", icon: "🔍" },
        { action: "Click defect IDs to open linked work items", result: "Navigate directly to CCM defect tracking", icon: "🔗" },
        { action: "Assign/unassign cases as performance-related via modal", result: "Curate which cases count as performance issues", icon: "✏️" }
      ],
      backend: "ALM instance detected via regex from case titles. Defect links open external CCM.",
      tips: ["App detection auto-categorizes: RM, QM, CCM, DCC, LQE, etc.", "Use the Performance assignment modal to mark/unmark cases"]
    },
    {
      id: "weekly-tracker", icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/><polyline points="9 16 11 18 15 14"/></svg>',
      color: "#0f62fe", colorBg: "#edf5ff", title: "Weekly Tracker", tagline: "Track case closures by calendar week",
      description: "Your weekly closure ledger. Record which cases were closed each ISO week, add standup notes, and browse historical weeks to track long-term closure momentum.",
      steps: [
        { action: "Select Year and Calendar Week from dropdowns", result: "View/edit cases closed in that specific week", icon: "📅" },
        { action: "Add case numbers to the selected week", result: "Cases linked to the weekly closure record", icon: "➕" },
        { action: "Add comments or notes for the week", result: "Context preserved for weekly reviews and reports", icon: "📝" },
        { action: "Browse history tab for past weekly entries", result: "Review and compare historical weekly performance", icon: "📚" }
      ],
      backend: "Stored in localStorage keyed by year (ibm_wtracker_*). ISO week numbering.",
      tips: ["Cases auto-import from uploaded files based on closure date", "Comments persist across sessions — great for standup notes", "Undo/Redo available for accidental changes"]
    },
    {
      id: "investigate", icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>',
      color: "#6929c4", colorBg: "#f6f2ff", title: "Investigate", tagline: "Search, archive, and find similar cases",
      description: "A permanent, ever-growing archive of every case ever uploaded. Search across current and historical data, and discover similar past cases to accelerate resolution.",
      steps: [
        { action: "Type a search query (case #, title, owner, product)", result: "Real-time results from current data + permanent archive", icon: "🔍" },
        { action: "View similar cases with AI similarity scoring", result: "Find historically related cases for faster resolution", icon: "🤖" },
        { action: "Browse the permanent archive (all cases ever uploaded)", result: "Nothing is lost — every case ever imported is searchable", icon: "📚" },
        { action: "Click any result for full case detail modal", result: "View complete metadata, history, and context", icon: "🔎" }
      ],
      backend: "Archive stored in localStorage (ibm_investigate_archive_v1). Similarity scoring uses text comparison algorithms.",
      tips: ["The archive grows with every upload — never loses data", "Use for knowledge transfer and pattern recognition", "Export search results for reporting"]
    },
    {
      id: "rfe-tracking", icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/><line x1="9" y1="13" x2="15" y2="13"/><line x1="9" y1="17" x2="15" y2="17"/></svg>',
      color: "#198038", colorBg: "#defbe6", title: "RFE Tracking", tagline: "Track Requests for Enhancement",
      description: "Manage your enhancement request pipeline from submitted to delivered. The Advanced view adds notes, tags, target releases, and a Kanban board for a complete RFE workflow.",
      steps: [
        { action: "View RFE stats: Total, Completed, Delivered", result: "High-level progress on enhancement requests", icon: "📊" },
        { action: "Filter by Product or Workflow State", result: "Focus on specific products or pipeline stages", icon: "🔍" },
        { action: "Search RFEs by keyword", result: "Find specific enhancement requests", icon: "🔎" },
        { action: "Switch to Advanced view for notes, tags, Kanban", result: "Full RFE management with metadata and board view", icon: "🗂️" }
      ],
      backend: "RFE data imported via CSV. Stored in localStorage (ibm_rfe_tracking_v1).",
      tips: ["Advanced view supports notes, tags, and target release dates", "Kanban board groups RFEs by workflow state", "Votes column helps prioritize enhancement requests"]
    },
    {
      id: "info", icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>',
      color: "#0f62fe", colorBg: "#edf5ff", title: "Information", tagline: "Contacts, escalation matrix, and resources",
      description: "Your on-call reference guide. The severity matrix, must-gather instructions, contact directory, and quick links give you everything needed to escalate cases correctly.",
      steps: [
        { action: "Review the Severity Matrix with escalation SLAs", result: "Know the response time expectations for each severity level", icon: "⚠️" },
        { action: "Access Must-Gather guides and investigation templates", result: "Collect the right diagnostic data before engaging IBM support", icon: "🛠️" },
        { action: "Search the Contact Directory by name or expertise", result: "Find the right expert for your issue", icon: "📇" },
        { action: "Click Quick Links for external tools and wikis", result: "Navigate to IBM Case Handling resources", icon: "🔗" }
      ],
      backend: "Contact data from static config + DynamicConfig (if server available).",
      tips: ["Severity levels: 1 (Critical) → 4 (Low) with different SLAs", "Must-Gather links include ISADC logs, Java cores, GC logs", "Contact directory searchable by name, email, and expertise area"]
    },
    {
      id: "admin", icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="3"/><path d="M19.07 4.93l-1.41 1.41M4.93 19.07l1.41-1.41M4.93 4.93l1.41 1.41M19.07 19.07l-1.41-1.41M12 2v2M12 20v2M2 12h2M20 12h2"/></svg>',
      color: "#da1e28", colorBg: "#fff1f1", title: "Admin Portal", tagline: "Configuration, bulk operations, and audit trail",
      description: "Protected by a 30-minute session, the Admin Portal handles bulk reassignments, performance case curation, and maintains a complete, undo-able audit trail of every change.",
      steps: [
        { action: "Log in with admin credentials", result: "Access admin-only features (session persists 30 min)", icon: "🔐" },
        { action: "Bulk reassign cases via Excel import (Old → New owner)", result: "All matching cases reassigned; audit trail created", icon: "📋" },
        { action: "Mark/unmark performance cases, add tags and notes", result: "Curate case metadata for tracking and reporting", icon: "🏷️" },
        { action: "View change history — searchable and exportable", result: "Full audit log of all admin actions with undo capability", icon: "📜" }
      ],
      backend: "All changes stored in localStorage. Undo/Redo supports up to 30 snapshots.",
      tips: ["Team member renames cascade across all case data", "Bulk reassignment supports Excel file import", "History tab shows every admin action with timestamps"]
    }
  ];

  let stepperPage = 0, stepperIndex = 0, searchQuery = "";
  let completedPages = [];
  try { completedPages = JSON.parse(localStorage.getItem("hiw_completed") || "[]"); } catch(e) {}

  function saveProgress() { try { localStorage.setItem("hiw_completed", JSON.stringify(completedPages)); } catch(e) {} }
  function markComplete(id) { if (!completedPages.includes(id)) { completedPages.push(id); saveProgress(); } }

  function render() {
    const el = document.getElementById("tab-how-it-works");
    if (!el) return;
    searchQuery = "";

    el.innerHTML = buildHTML();
    attachEvents(el);
    animateIn(el);
  }

  function buildHTML() {
    return `
      <div class="hiw-container" id="hiw-root">
        <div class="hiw-hero">
          <div class="hiw-hero-badge"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" width="13" height="13"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg> Interactive Guide</div>
          <h1 class="hiw-hero-title">How It Works</h1>
          <p class="hiw-hero-sub">A complete walkthrough of every page in the IBM Case Intelligence Platform.<br>Explore at your own pace — or take the guided tour.</p>
          <div class="hiw-hero-actions">
            <button class="hiw-btn-primary" id="hiw-start-tour"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" width="14" height="14"><polygon points="5 3 19 12 5 21 5 3"/></svg> Start Guided Tour</button>
            <button class="hiw-btn-ghost" id="hiw-reset-progress"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 .49-4.96"/></svg> Reset Progress</button>
          </div>
          <div class="hiw-progress-wrap">
            <div class="hiw-progress-label"><span>Progress</span><span id="hiw-progress-count">${completedPages.length} / ${PAGES.length} explored</span></div>
            <div class="hiw-progress-bar"><div class="hiw-progress-fill" id="hiw-prog-fill" style="width:${Math.round((completedPages.length/PAGES.length)*100)}%"></div></div>
            <div class="hiw-progress-dots" id="hiw-prog-dots">${PAGES.map(p=>`<div class="hiw-dot${completedPages.includes(p.id)?" done":""}" title="${p.title}" style="--dc:${p.color}"></div>`).join("")}</div>
          </div>
        </div>

        <div class="hiw-flow-section">
          <div class="hiw-flow-label">Application Flow</div>
          <div class="hiw-flow-diagram" id="hiw-flow">
            ${[
              {label:"Upload",sub:"Import CSV/XLSX",cls:"hiw-flow-start",icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>'},
              {label:"Parse & Store",sub:"localStorage engine",cls:"",icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/></svg>'},
              {label:"Dashboards",sub:"Overview · Team · Members",cls:"",icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></svg>'},
              {label:"Analyze",sub:"Performance · Investigate",cls:"",icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>'},
              {label:"Act & Resolve",sub:"Track · Close · Report",cls:"hiw-flow-end",icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>'}
            ].map((n,i,arr)=>`
              <div class="hiw-flow-node ${n.cls}">
                <div class="hiw-flow-node-icon">${n.icon}</div>
                <span>${n.label}</span>
                <div class="hiw-flow-node-sub">${n.sub}</div>
              </div>
              ${i<arr.length-1?'<div class="hiw-flow-arr"><svg viewBox="0 0 32 10" fill="none"><path d="M0 5 L26 5" stroke="currentColor" stroke-width="1.5" stroke-dasharray="4 2.5" opacity=".5"/><path d="M22 1 L29 5 L22 9" fill="currentColor" opacity=".4"/></svg></div>':""}
            `).join("")}
          </div>
        </div>

        <div class="hiw-toolbar">
          <div class="hiw-search-wrap">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="15" height="15"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
            <input type="text" id="hiw-search" class="hiw-search-input" placeholder="Search pages, features, tips…" autocomplete="off">
            <button class="hiw-search-clear" id="hiw-search-clear" style="display:none">✕</button>
          </div>
          <div class="hiw-view-toggle">
            <button class="hiw-view-btn active" id="hiw-grid-btn" title="Card view"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg></button>
            <button class="hiw-view-btn" id="hiw-list-btn" title="List view"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg></button>
          </div>
        </div>

        <div class="hiw-grid" id="hiw-grid">
          ${PAGES.map((p,i)=>renderCard(p,i)).join("")}
        </div>
        <div class="hiw-no-results" id="hiw-no-results" style="display:none">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="28" height="28"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
          <p>No pages match your search</p>
        </div>

        <div class="hiw-architecture">
          <div class="hiw-arch-label">Data Architecture</div>
          <div class="hiw-arch-sub">How the platform stores and processes your data</div>
          <div class="hiw-arch-grid">
            ${[
              {bg:"#defbe6",ic:"#198038",icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>',title:"File Import",body:"CSV/XLSX/XLS/XLSM files are parsed client-side using XLSX.js. No data leaves your browser."},
              {bg:"#edf5ff",ic:"#0f62fe",icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/></svg>',title:"localStorage",body:"All case data, settings, and history persist in your browser's localStorage. Works fully offline."},
              {bg:"#f6f2ff",ic:"#6929c4",icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18"/><path d="M9 21V9"/></svg>',title:"Smart Merge",body:"Re-uploading merges new data with existing records. Duplicate detection by fingerprint prevents redundant imports."},
              {bg:"#fff1f1",ic:"#da1e28",icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>',title:"Privacy First",body:"Zero server dependency for core features. Your case data stays in your browser — nothing is transmitted externally."}
            ].map(a=>`<div class="hiw-arch-card"><div class="hiw-arch-icon" style="background:${a.bg}"><svg viewBox="0 0 24 24" fill="none" stroke="${a.ic}" stroke-width="1.8" width="18" height="18">${a.icon.replace(/<svg[^>]*>/,"")}</div><h4>${a.title}</h4><p>${a.body}</p></div>`).join("")}
          </div>
        </div>

        <div class="hiw-shortcuts-section">
          <div class="hiw-arch-label">Keyboard Shortcuts</div>
          <div class="hiw-shortcuts-grid">
            <div class="hiw-sc-item"><div class="hiw-sc-keys"><kbd>1</kbd>–<kbd>9</kbd></div><div class="hiw-sc-desc">Jump to pages</div></div>
            <div class="hiw-sc-item"><div class="hiw-sc-keys"><kbd>Ctrl</kbd><kbd>K</kbd></div><div class="hiw-sc-desc">Command palette</div></div>
            <div class="hiw-sc-item"><div class="hiw-sc-keys"><kbd>?</kbd></div><div class="hiw-sc-desc">All shortcuts</div></div>
            <div class="hiw-sc-item"><div class="hiw-sc-keys"><kbd>Esc</kbd></div><div class="hiw-sc-desc">Close modals</div></div>
          </div>
        </div>
      </div>

      <div class="hiw-stepper-overlay" id="hiw-stepper-overlay" style="display:none" aria-modal="true" role="dialog">
        <div class="hiw-stepper-modal">
          <div class="hiw-stepper-top">
            <div class="hiw-stepper-pills" id="hiw-stepper-pills"></div>
            <button class="hiw-stepper-close" id="hiw-stepper-close" aria-label="Close tour">✕</button>
          </div>
          <div class="hiw-stepper-body" id="hiw-stepper-body"></div>
          <div class="hiw-stepper-footer">
            <button class="hiw-stp-prev" id="hiw-step-prev">← Prev</button>
            <div class="hiw-stp-dots" id="hiw-stepper-dots"></div>
            <button class="hiw-stp-next" id="hiw-step-next">Next →</button>
          </div>
        </div>
      </div>
    `;
  }

  function renderCard(page, index) {
    const done = completedPages.includes(page.id);
    const isUpload = page.id === "upload";
    return `
      <div class="hiw-card${done?" hiw-card-done":""}" data-page="${page.id}" data-index="${index}"
           data-search="${[page.title,page.tagline,page.description,...page.steps.map(s=>s.action+" "+s.result),...page.tips].join(" ").toLowerCase()}"
           style="--cc:${page.color};--cb:${page.colorBg}">
        <div class="hiw-card-header">
          <div class="hiw-card-hl">
            <div class="hiw-card-num">${done?`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" width="11" height="11"><polyline points="20 6 9 17 4 12"/></svg>`:index+1}</div>
            <div class="hiw-card-icon">${page.icon}</div>
            <div>
              <div class="hiw-card-title">${page.title}</div>
              <div class="hiw-card-tagline">${page.tagline}</div>
            </div>
          </div>
          <div class="hiw-card-hr">
            <div class="hiw-steps-pill">${page.steps.length} steps</div>
            ${!isUpload?`<button class="hiw-goto-btn" data-goto="${page.id}"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="11" height="11"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg> Open</button>`:""}
            <div class="hiw-chevron"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" width="15" height="15"><polyline points="6 9 12 15 18 9"/></svg></div>
          </div>
        </div>
        <div class="hiw-card-body" style="max-height:0;overflow:hidden">
          <div class="hiw-card-body-in">
            <p class="hiw-card-desc">${page.description}</p>
            <div class="hiw-sl">Workflow steps</div>
            <div class="hiw-steps">
              ${page.steps.map((s,si)=>`
                <div class="hiw-step">
                  <div class="hiw-step-track">
                    <div class="hiw-step-num">${si+1}</div>
                    ${si<page.steps.length-1?'<div class="hiw-step-line"></div>':""}
                  </div>
                  <div class="hiw-step-cnt">
                    <div class="hiw-step-emoji">${s.icon}</div>
                    <div>
                      <div class="hiw-step-action">${s.action}</div>
                      <div class="hiw-step-result"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" width="11" height="11"><polyline points="20 6 9 17 4 12"/></svg> ${s.result}</div>
                    </div>
                  </div>
                </div>`).join("")}
            </div>
            <div class="hiw-sl">Under the hood</div>
            <div class="hiw-backend-pill"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" width="13" height="13"><rect x="4" y="4" width="16" height="16" rx="2"/><rect x="9" y="9" width="6" height="6"/></svg> ${page.backend}</div>
            <div class="hiw-sl">Pro tips</div>
            <div class="hiw-tips-grid">${page.tips.map(t=>`<div class="hiw-tip"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="11" height="11"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg> ${t}</div>`).join("")}</div>
            <div class="hiw-card-foot">
              <button class="hiw-mark-done${done?" done":""}" data-id="${page.id}">${done?`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" width="13" height="13"><polyline points="20 6 9 17 4 12"/></svg> Explored`:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg> Mark explored`}</button>
              <button class="hiw-walk-btn" data-pi="${index}"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="11" height="11"><polygon points="5 3 19 12 5 21 5 3"/></svg> Walk through</button>
            </div>
          </div>
        </div>
      </div>`;
  }

  function openStepper(pi) {
    stepperPage = pi; stepperIndex = 0;
    const ov = document.getElementById("hiw-stepper-overlay");
    ov.style.display = "flex";
    setTimeout(()=>ov.classList.add("visible"),10);
    document.body.style.overflow = "hidden";
    renderStepper();
  }

  function closeStepper() {
    const ov = document.getElementById("hiw-stepper-overlay");
    ov.classList.remove("visible");
    setTimeout(()=>{ ov.style.display="none"; document.body.style.overflow=""; }, 280);
  }

  function renderStepper() {
    const page = PAGES[stepperPage];
    const step = page.steps[stepperIndex];
    const pillsEl = document.getElementById("hiw-stepper-pills");
    const bodyEl = document.getElementById("hiw-stepper-body");
    const dotsEl = document.getElementById("hiw-stepper-dots");
    if (!pillsEl||!bodyEl) return;

    pillsEl.innerHTML = PAGES.map((p,i)=>`<button class="hiw-spill${i===stepperPage?" act":""}" data-pi="${i}" style="${i===stepperPage?`color:${p.color};border-color:${p.color};background:${p.colorBg}`:""}">${p.icon}<span>${p.title}</span></button>`).join("");
    pillsEl.querySelectorAll(".hiw-spill").forEach(b=>b.addEventListener("click",()=>{stepperPage=+b.dataset.pi;stepperIndex=0;renderStepper();}));
    const ap=pillsEl.querySelector(".hiw-spill.act");
    if(ap) ap.scrollIntoView({behavior:"smooth",block:"nearest",inline:"center"});

    bodyEl.innerHTML = `
      <div class="hiw-sb-hero" style="--sa:${page.color};--sb:${page.colorBg}">
        <div class="hiw-sb-icon">${page.icon}</div>
        <div><div class="hiw-sb-name">${page.title}</div><div class="hiw-sb-tag">${page.tagline}</div></div>
      </div>
      <div class="hiw-sb-prog">
        <span>Step ${stepperIndex+1} of ${page.steps.length}</span>
        <div class="hiw-sb-track"><div class="hiw-sb-fill" style="width:${((stepperIndex+1)/page.steps.length)*100}%;background:${page.color}"></div></div>
      </div>
      <div class="hiw-sb-card" style="--sa:${page.color};--sb:${page.colorBg}">
        <div class="hiw-sb-stepnum">${stepperIndex+1}</div>
        <div class="hiw-sb-emoji">${step.icon}</div>
        <div class="hiw-sb-action">${step.action}</div>
        <div class="hiw-sb-div"></div>
        <div class="hiw-sb-result-label">What happens</div>
        <div class="hiw-sb-result">${step.result}</div>
      </div>
      <div class="hiw-sb-mini-steps">
        ${page.steps.map((s,i)=>`<div class="hiw-sbm${i===stepperIndex?" act":i<stepperIndex?" done":""}" data-si="${i}" style="${i===stepperIndex?`--sa:${page.color}`:""}"><div class="hiw-sbm-n">${i<stepperIndex?"✓":i+1}</div><div class="hiw-sbm-t">${s.action.length>55?s.action.slice(0,55)+"…":s.action}</div></div>`).join("")}
      </div>`;

    bodyEl.querySelectorAll(".hiw-sbm").forEach(el=>el.addEventListener("click",()=>{stepperIndex=+el.dataset.si;renderStepper();}));

    dotsEl.innerHTML = page.steps.map((_,i)=>`<div class="hiw-sdot${i===stepperIndex?" act":i<stepperIndex?" dn":""}" style="${i===stepperIndex?`background:${page.color}`:""}"></div>`).join("");

    const pv=document.getElementById("hiw-step-prev"), nx=document.getElementById("hiw-step-next");
    if(pv){ pv.disabled=stepperPage===0&&stepperIndex===0; pv.textContent=stepperIndex===0?"← Prev Page":"← Prev Step"; }
    if(nx){ const isLast=stepperPage===PAGES.length-1&&stepperIndex===page.steps.length-1; nx.textContent=isLast?"✓ Finish":stepperIndex===page.steps.length-1?"Next Page →":"Next Step →"; }
  }

  function stepNext() {
    const page=PAGES[stepperPage];
    if(stepperIndex<page.steps.length-1){ stepperIndex++; }
    else {
      markComplete(page.id); updateProgressUI();
      if(stepperPage<PAGES.length-1){ stepperPage++; stepperIndex=0; }
      else { closeStepper(); showCelebration(); return; }
    }
    renderStepper();
  }
  function stepPrev() {
    if(stepperIndex>0){ stepperIndex--; }
    else if(stepperPage>0){ stepperPage--; stepperIndex=PAGES[stepperPage].steps.length-1; }
    renderStepper();
  }

  function updateProgressUI() {
    const ct=document.getElementById("hiw-progress-count"), fill=document.getElementById("hiw-prog-fill"), dotsEl=document.getElementById("hiw-prog-dots");
    if(ct) ct.textContent=`${completedPages.length} / ${PAGES.length} explored`;
    if(fill) fill.style.width=Math.round((completedPages.length/PAGES.length)*100)+"%";
    if(dotsEl) { const dots=dotsEl.querySelectorAll(".hiw-dot"); dots.forEach((d,i)=>{ if(completedPages.includes(PAGES[i].id)) d.classList.add("done"); }); }
    completedPages.forEach(id=>{
      const card=document.querySelector(`.hiw-card[data-page="${id}"]`);
      if(!card) return;
      card.classList.add("hiw-card-done");
      const n=card.querySelector(".hiw-card-num"); if(n&&!n.querySelector("svg")) n.innerHTML=`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" width="11" height="11"><polyline points="20 6 9 17 4 12"/></svg>`;
      const b=card.querySelector(".hiw-mark-done"); if(b&&!b.classList.contains("done")){ b.classList.add("done"); b.innerHTML=`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" width="13" height="13"><polyline points="20 6 9 17 4 12"/></svg> Explored`; }
    });
  }

  function showCelebration() {
    const cel=document.createElement("div"); cel.className="hiw-cel";
    cel.innerHTML=`<div class="hiw-cel-box"><div class="hiw-cel-ic">🎉</div><h2>Tour Complete!</h2><p>You've explored all ${PAGES.length} pages of the IBM Case Intelligence Platform.</p><button class="hiw-btn-primary" id="hiw-cel-ok">Back to Guide</button></div>`;
    document.body.appendChild(cel);
    setTimeout(()=>cel.classList.add("visible"),10);
    cel.querySelector("#hiw-cel-ok").addEventListener("click",()=>{ cel.classList.remove("visible"); setTimeout(()=>cel.remove(),300); });
    cel.addEventListener("click",e=>{ if(e.target===cel){ cel.classList.remove("visible"); setTimeout(()=>cel.remove(),300); } });
  }

  function animateIn(el) {
    const nodes=el.querySelectorAll(".hiw-flow-node");
    nodes.forEach((n,i)=>{ n.style.opacity="0"; n.style.transform="translateY(10px)"; setTimeout(()=>{ n.style.transition="all 0.35s ease"; n.style.opacity="1"; n.style.transform=""; }, 100+i*80); });
    const cards=el.querySelectorAll(".hiw-card");
    cards.forEach((c,i)=>{ c.style.opacity="0"; c.style.transform="translateY(8px)"; setTimeout(()=>{ c.style.transition="all 0.3s ease"; c.style.opacity="1"; c.style.transform=""; }, 200+i*40); });
  }

  function filterCards() {
    const q=searchQuery.toLowerCase().trim();
    const cards=document.querySelectorAll("#hiw-grid .hiw-card");
    let vis=0;
    cards.forEach(c=>{ const m=!q||c.dataset.search.includes(q); c.style.display=m?"":"none"; if(m)vis++; });
    const nr=document.getElementById("hiw-no-results"); if(nr) nr.style.display=vis===0?"flex":"none";
  }

  function attachEvents(el) {
    // Card accordion
    el.querySelectorAll(".hiw-card-header").forEach(h=>{
      h.addEventListener("click",function(e){
        if(e.target.closest(".hiw-goto-btn")||e.target.closest(".hiw-walk-btn")) return;
        const card=this.closest(".hiw-card"), wasOpen=card.classList.contains("open");
        el.querySelectorAll(".hiw-card.open").forEach(c=>{ c.classList.remove("open"); const b=c.querySelector(".hiw-card-body"); if(b) b.style.maxHeight="0px"; });
        if(!wasOpen){
          card.classList.add("open");
          const body=card.querySelector(".hiw-card-body");
          if(body){ body.style.maxHeight=body.scrollHeight+50+"px"; }
          setTimeout(()=>card.scrollIntoView({behavior:"smooth",block:"nearest"}),150);
        }
      });
    });

    // Goto
    el.querySelectorAll(".hiw-goto-btn").forEach(b=>b.addEventListener("click",function(e){
      e.stopPropagation(); const nav=document.querySelector(`.nav-item[data-tab="${this.dataset.goto}"]`); if(nav) nav.click();
    }));

    // Mark done
    el.querySelectorAll(".hiw-mark-done").forEach(b=>b.addEventListener("click",function(e){
      e.stopPropagation(); markComplete(this.dataset.id); updateProgressUI();
    }));

    // Walk through (stepper from card)
    el.querySelectorAll(".hiw-walk-btn").forEach(b=>b.addEventListener("click",function(e){
      e.stopPropagation(); openStepper(+this.dataset.pi);
    }));

    // Tour button
    const tb=document.getElementById("hiw-start-tour"); if(tb) tb.addEventListener("click",()=>openStepper(0));

    // Reset
    const rb=document.getElementById("hiw-reset-progress"); if(rb) rb.addEventListener("click",()=>{
      completedPages=[]; saveProgress(); render();
    });

    // Stepper overlay
    const ov=document.getElementById("hiw-stepper-overlay");
    if(ov){
      ov.addEventListener("click",e=>{ if(e.target===ov) closeStepper(); });
      const cl=document.getElementById("hiw-stepper-close"); if(cl) cl.addEventListener("click",closeStepper);
      const nx=document.getElementById("hiw-step-next"); if(nx) nx.addEventListener("click",stepNext);
      const pv=document.getElementById("hiw-step-prev"); if(pv) pv.addEventListener("click",stepPrev);
    }

    // Search
    const si=document.getElementById("hiw-search"), sc=document.getElementById("hiw-search-clear");
    if(si){ si.addEventListener("input",function(){ searchQuery=this.value; if(sc) sc.style.display=this.value?"":"none"; filterCards(); }); }
    if(sc){ sc.addEventListener("click",()=>{ si.value=""; searchQuery=""; sc.style.display="none"; filterCards(); si.focus(); }); }

    // View toggle
    const gb=document.getElementById("hiw-grid-btn"), lb=document.getElementById("hiw-list-btn"), gr=document.getElementById("hiw-grid");
    if(gb&&lb&&gr){
      gb.addEventListener("click",()=>{ gb.classList.add("active"); lb.classList.remove("active"); gr.classList.remove("hiw-grid-list"); });
      lb.addEventListener("click",()=>{ lb.classList.add("active"); gb.classList.remove("active"); gr.classList.add("hiw-grid-list"); });
    }

    // Keyboard for stepper
    document.addEventListener("keydown",function hiwKey(e){
      const ov=document.getElementById("hiw-stepper-overlay"); if(!ov||ov.style.display==="none") return;
      if(e.key==="ArrowRight"||e.key==="ArrowDown"){ e.preventDefault(); stepNext(); }
      if(e.key==="ArrowLeft"||e.key==="ArrowUp"){ e.preventDefault(); stepPrev(); }
      if(e.key==="Escape") closeStepper();
    });
  }

  window.HowItWorks = { render };

  const _orig=window._switchTab;
  if(typeof _orig==="function"){ window._switchTab=function(tab){ _orig(tab); if(tab==="how-it-works") render(); }; }
  document.addEventListener("click",function(e){ if(e.target.closest('.nav-item[data-tab="how-it-works"]')) setTimeout(render,50); });
  if(document.querySelector("#tab-how-it-works.active")) render();
})();
