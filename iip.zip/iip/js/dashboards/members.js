/* ============================================================
   js/dashboards/members.js  —  Member Dashboard
   Per-engineer case load, SLA adherence and productivity metrics
   ============================================================ */
const DashMembers = (() => {

  let _selectedMember = "";
  let _sortKey = "active";
  let _sortDir = -1;

  function kpi(label, value, cls = "", sub = "") {
    return `<div class="kpi-card ${cls}">
      <div class="kpi-label">${label}</div>
      <div class="kpi-value">${value}</div>
      ${sub ? `<div class="text-11 text-muted mt-6">${sub}</div>` : ""}
    </div>`;
  }

  function render() {
    const el = document.getElementById("tab-members");
    if (!el) return;

    const members  = Data.teamMembers().slice().sort();
    const teamAll  = Data.teamCases();
    const stats    = members.map(m => getMemberStats(m, teamAll));

    const activeTeam = teamAll.filter(r => !Utils.isClosed(r.Status));
    const awaitAll   = teamAll.filter(r => r.Status === "Awaiting your feedback");
    const closed7d   = teamAll.filter(r => {
      if (!Utils.isClosed(r.Status)) return false;
      const d = Utils.parseDate(r["Closed Date"]) || Utils.parseDate(r.Updated);
      return d && (Utils.today() - d) / 86400000 <= 7;
    });

    const _appCfg  = (typeof DynamicConfig !== "undefined" && DynamicConfig.appConfig) ? DynamicConfig.appConfig() : {};
    const slaTarget = parseInt(_appCfg.slaTargetPct  || "80", 10);
    const slaDays   = parseInt(_appCfg.slaClosureDays || "30", 10);

    // Team-level SLA
    const allClosed = teamAll.filter(r => Utils.isClosed(r.Status));
    const closedInSLA = allClosed.filter(r => {
      const created = Utils.parseDate(r.Created);
      const closedAt = Utils.parseDate(r["Closed Date"]) || Utils.parseDate(r.Updated);
      if (!created || !closedAt) return false;
      return Math.round((closedAt - created) / 86400000) <= slaDays;
    });
    const teamSlaPct = allClosed.length > 0 ? Math.round(closedInSLA.length / allClosed.length * 100) : null;

    const selectedLabel = _selectedMember ? Utils.shortName(_selectedMember) : "";

    el.innerHTML = `
      <div class="kpi-row" id="members-kpi-row">
        ${kpi("Team Members",        members.length,    "")}
        ${kpi("Active Cases",        activeTeam.length, "kpi-blue")}
        ${kpi("Awaiting Feedback",   awaitAll.length,   "kpi-red")}
        ${kpi("Closed (Last 7d)",    closed7d.length,   "kpi-green")}
        ${teamSlaPct !== null
          ? kpi(`SLA Adherence (≤${slaDays}d)`, teamSlaPct + "%",
              teamSlaPct >= slaTarget ? "kpi-green" : "kpi-red",
              `Target: ${slaTarget}%`)
          : kpi("SLA Adherence", "—", "")}
      </div>

      <div class="filter-bar mt-5">
        <div class="filter-group" style="position:relative">
          <span class="filter-label">Team Member</span>
          <div style="position:relative;width:260px">
            <input id="member-search-input" type="text" autocomplete="off"
              placeholder="Search member…"
              value="${Utils.escHtml(selectedLabel)}"
              class="form-input form-input-sm"
              style="width:100%;padding-right:28px"
              aria-label="Search team member"
              aria-autocomplete="list"
              aria-controls="member-dropdown"/>
            <span id="member-search-clear" title="Clear"
              style="position:absolute;right:8px;top:50%;transform:translateY(-50%);
                cursor:pointer;color:var(--text-tertiary);font-size:14px;line-height:1;
                display:${_selectedMember ? "block" : "none"}">&times;</span>
          </div>
          <ul id="member-dropdown" role="listbox"
            style="display:none;position:absolute;top:calc(100% + 2px);left:0;width:260px;
              max-height:220px;overflow-y:auto;margin:0;padding:4px 0;list-style:none;
              background:var(--bg-ui);border:1px solid var(--border-mid);
              border-radius:var(--radius-sm);box-shadow:var(--shadow-md);z-index:300">
            <li role="option" data-value="" style="padding:7px 12px;font-size:12px;
              color:var(--text-tertiary);cursor:pointer"
              onmouseover="this.style.background='var(--bg-hover)'"
              onmouseout="this.style.background=''">— All Members —</li>
            ${members.map(m => `
            <li role="option" data-value="${Utils.escHtml(m)}" style="padding:7px 12px;font-size:13px;
              cursor:pointer;color:var(--text-primary)"
              onmouseover="this.style.background='var(--bg-hover)'"
              onmouseout="this.style.background=''">
              ${Utils.escHtml(Utils.shortName(m))}
            </li>`).join("")}
          </ul>
        </div>
        <button id="member-clear" aria-label="Clear member filter" class="btn btn-ghost btn-sm">Clear</button>
      </div>

      <div id="members-content" class="mt-5"></div>
    `;

    const input    = document.getElementById("member-search-input");
    const dropdown = document.getElementById("member-dropdown");
    const clearX   = document.getElementById("member-search-clear");

    function openDropdown(filter) {
      const q = (filter || "").toLowerCase();
      dropdown.querySelectorAll("li[data-value]").forEach(li => {
        const val = li.dataset.value;
        li.style.display = (!val || !q || Utils.shortName(val).toLowerCase().includes(q)) ? "" : "none";
      });
      dropdown.style.display = "block";
    }

    function closeDropdown() { dropdown.style.display = "none"; }

    function selectMember(val) {
      _selectedMember = val;
      input.value = val ? Utils.shortName(val) : "";
      clearX.style.display = val ? "block" : "none";
      closeDropdown();
      renderContent(teamAll, stats, slaTarget, slaDays);
    }

    input.addEventListener("focus", () => openDropdown(input.value));
    input.addEventListener("input", () => openDropdown(input.value));
    input.addEventListener("keydown", e => {
      if (e.key === "Escape") { closeDropdown(); input.blur(); }
    });

    dropdown.querySelectorAll("li[data-value]").forEach(li => {
      li.addEventListener("mousedown", e => { e.preventDefault(); selectMember(li.dataset.value); });
    });

    clearX.addEventListener("mousedown", e => { e.preventDefault(); selectMember(""); });

    document.getElementById("member-clear").addEventListener("click", () => selectMember(""));

    if (el._outsideClickCleanup) el._outsideClickCleanup();
    function _outsideClick(e) {
      if (!input.contains(e.target) && !dropdown.contains(e.target)) closeDropdown();
    }
    document.addEventListener("click", _outsideClick, true);
    el._outsideClickCleanup = () => document.removeEventListener("click", _outsideClick, true);

    renderContent(teamAll, stats, slaTarget, slaDays);
  }

  /* ── Stats per member ────────────────────────────────── */
  function getMemberStats(member, teamAll) {
    const _appCfg  = (typeof DynamicConfig !== "undefined" && DynamicConfig.appConfig) ? DynamicConfig.appConfig() : {};
    const slaTarget = parseInt(_appCfg.slaTargetPct  || "80", 10);
    const slaDays   = parseInt(_appCfg.slaClosureDays || "30", 10);

    const cases   = teamAll.filter(r => r.Owner === member);
    const open    = cases.filter(r => !Utils.isClosed(r.Status));
    const closed  = cases.filter(r =>  Utils.isClosed(r.Status));
    const closed7d = closed.filter(r => {
      const d = Utils.parseDate(r["Closed Date"]) || Utils.parseDate(r.Updated);
      return d && (Utils.today() - d) / 86400000 <= 7;
    }).length;
    const await_  = cases.filter(r => r.Status === "Awaiting your feedback");
    const inprog  = cases.filter(r => r.Status === "IBM is working" || r.Status === "Waiting for IBM");
    const perfNums = Data.getPerfCaseNums();
    const perf    = cases.filter(r => perfNums.includes(r["Case Number"]));
    const stale   = open.filter(r => Utils.daysDiff(Utils.parseDate(r.Updated) || Utils.parseDate(r.Created)) >= 5);
    const avgDays = open.length > 0
      ? Math.round(open.reduce((sum, r) => sum + Utils.daysDiff(Utils.parseDate(r.Updated) || Utils.parseDate(r.Created)), 0) / open.length)
      : 0;

    // SLA adherence: % of closed cases resolved within SLA window
    const closedInSLA = closed.filter(r => {
      const created  = Utils.parseDate(r.Created);
      const closedAt = Utils.parseDate(r["Closed Date"]) || Utils.parseDate(r.Updated);
      if (!created || !closedAt) return false;
      return Math.round((closedAt - created) / 86400000) <= slaDays;
    });
    const slaPct = closed.length > 0 ? Math.round(closedInSLA.length / closed.length * 100) : null;

    // Workload health: 0 (worst) – 100 (best)
    const health = Math.max(0, Math.min(100,
      Math.round(100 - (stale.length  / Math.max(open.length, 1)) * 60
                     - (await_.length / Math.max(open.length, 1)) * 30)
    ));

    const sorted = [...cases].sort((a, b) => (Utils.parseDate(b.Created) || 0) - (Utils.parseDate(a.Created) || 0));
    return { member, cases, open, closed, closed7d, await_, inprog, perf, stale, avgDays, slaPct, slaTarget, slaDays, health, latest: sorted[0] };
  }

  function renderContent(teamAll, stats, slaTarget, slaDays) {
    if (_selectedMember) renderMemberDetail(_selectedMember, teamAll);
    else                  renderAllMembersGrid(stats, slaTarget, slaDays);
  }

  /* ── Overview Table ──────────────────────────────────── */
  function renderAllMembersGrid(stats, slaTarget, slaDays) {
    const container = document.getElementById("members-content");
    if (!container) return;

    const active = stats.filter(s =>
      s.cases.length > 0 || s.open.length > 0 || s.closed7d > 0 ||
      s.await_.length > 0 || s.inprog.length > 0 || s.perf.length > 0 || s.stale.length > 0
    );

    const SORT_FN = {
      rank:    s => s.open.length,
      member:  s => Utils.shortName(s.member).toLowerCase(),
      active:  s => s.open.length,
      closed7d:s => s.closed7d,
      await:   s => s.await_.length,
      inprog:  s => s.inprog.length,
      perf:    s => s.perf.length,
      stale:   s => s.stale.length,
      avgdays: s => s.avgDays,
      sla:     s => s.slaPct !== null ? s.slaPct : -1,
      health:  s => s.health,
    };
    const fn = SORT_FN[_sortKey] || SORT_FN.active;
    const sorted = [...active].sort((a, b) => {
      const aActive = a.open.length, bActive = b.open.length;
      if (aActive === 0 && bActive > 0) return 1;
      if (bActive === 0 && aActive > 0) return -1;
      const av = fn(a), bv = fn(b);
      if (typeof av === "string") return av < bv ? -_sortDir : av > bv ? _sortDir : 0;
      return (av - bv) * _sortDir;
    });

    function thSort(key, label, tip) {
      const cur = _sortKey === key;
      const arrow = cur ? (_sortDir === -1 ? " ↓" : " ↑") : "";
      const tipAttr = tip ? ` title="${tip}"` : "";
      return `<th class="sort-th" data-sort="${key}"
        style="cursor:pointer;user-select:none;white-space:nowrap${cur ? ";background:var(--ibm-blue-10)" : ""}"
        ${tipAttr}>${label}${arrow}</th>`;
    }

    const maxOpen  = Math.max(...active.map(s => s.open.length), 1);
    const maxStale = Math.max(...active.map(s => s.stale.length), 1);

    let html = `
      <div class="tile">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;flex-wrap:wrap;gap:8px">
          <div class="section-title mb-0">Team Performance Overview
            <span style="font-size:11px;font-weight:400;color:var(--text-tertiary);margin-left:8px">${active.length} members</span>
          </div>
          <div style="display:flex;gap:8px;align-items:center">
            <input id="members-search" type="text" placeholder="Search member..."
              style="border:1px solid var(--border-subtle);border-radius:var(--radius-xs);padding:5px 10px;font-size:12px;
                outline:none;background:var(--bg-layer);color:var(--text-primary);width:200px"
              onfocus="this.style.borderColor='var(--ibm-blue-30)'" onblur="this.style.borderColor='var(--border-subtle)'"/>
            <button class="btn btn-primary btn-sm" id="members-export" aria-label="Export members to CSV">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
              Export CSV
            </button>
          </div>
        </div>
        <div class="data-table-wrap" style="border:1px solid var(--border-subtle);border-radius:var(--radius-md)">
          <table class="data-table" id="members-table">
            <thead><tr>
              ${thSort("rank",    "#")}
              ${thSort("member",  "Member")}
              ${thSort("active",  "Active",         "Open (non-closed) cases")}
              ${thSort("closed7d","Closed (7d)")}
              ${thSort("await",   "Awaiting Feedback")}
              ${thSort("inprog",  "In Progress")}
              ${thSort("perf",    "Perf Cases",     "Performance-tagged cases")}
              ${thSort("stale",   "Stale (5d+)")}
              ${thSort("avgdays", "Avg Days")}
              ${thSort("sla",     "SLA %",          `Cases closed within ${slaDays} days`)}
              ${thSort("health",  "Health",         "Workload health score (0–100)")}
            </tr></thead>
            <tbody id="members-tbody">`;

    sorted.forEach((s, i) => {
      const openPct  = Math.round((s.open.length  / maxOpen)  * 40);
      const stalePct = Math.round((s.stale.length / maxStale) * 40);
      const rowStyle = s.open.length === 0 ? "opacity:.55;" : "";

      const slaCell = s.slaPct !== null
        ? `<span style="color:${s.slaPct >= slaTarget ? "var(--green)" : "var(--red)"};font-weight:600">${s.slaPct}%</span>`
        : `<span class="text-muted">—</span>`;

      const healthColor = s.health >= 80 ? "var(--green)" : s.health >= 50 ? "var(--yellow)" : "var(--red)";

      html += `
        <tr data-member="${Utils.escHtml(s.member)}" style="${rowStyle}">
          <td class="text-muted" style="font-size:12px;width:32px">${i + 1}</td>
          <td style="font-weight:500;white-space:nowrap;min-width:160px">
            <span class="member-detail-btn" data-member="${Utils.escHtml(s.member)}"
              style="display:inline-flex;align-items:center;gap:8px;cursor:pointer;
                color:var(--ibm-blue-50);text-decoration:underline;text-underline-offset:2px">
              <span class="member-avatar">${Utils.escHtml(Utils.shortName(s.member).split(" ").map(p => p[0]).join("").slice(0,2).toUpperCase())}</span>
              ${Utils.escHtml(Utils.shortName(s.member))}
            </span>
          </td>
          <td class="col-stat-blue">
            <div class="row-6">
              <span>${s.open.length}</span>
              ${openPct > 0 ? `<div style="width:${openPct}px;height:4px;background:var(--ibm-blue-30);border-radius:2px;flex-shrink:0"></div>` : ""}
            </div>
          </td>
          <td class="col-stat-green">${s.closed7d}</td>
          <td class="col-stat-await">${s.await_.length > 0 ? `<span style="color:var(--yellow);font-weight:600">${s.await_.length}</span>` : `<span class="text-muted">0</span>`}</td>
          <td class="col-stat-blue">${s.inprog.length}</td>
          <td class="col-stat-red">${s.perf.length || `<span class="text-muted">0</span>`}</td>
          <td class="col-stat-stale">
            <div class="row-6">
              ${s.stale.length > 0
                ? `<span style="color:var(--red);font-weight:600">${s.stale.length}</span>
                   ${stalePct > 0 ? `<div style="width:${stalePct}px;height:4px;background:rgba(218,30,40,.3);border-radius:2px;flex-shrink:0"></div>` : ""}`
                : `<span class="text-muted">0</span>`}
            </div>
          </td>
          <td class="col-stat-days" style="color:${s.avgDays >= 10 ? "var(--red)" : s.avgDays >= 5 ? "var(--yellow)" : "var(--text-tertiary)"}">${s.avgDays}d</td>
          <td style="font-family:var(--font-mono)">${slaCell}</td>
          <td style="font-family:var(--font-mono);font-weight:600;color:${healthColor}">${s.health}</td>
        </tr>`;
    });

    html += `</tbody></table></div>
      <div style="padding:8px 12px;font-size:11px;color:var(--text-tertiary);border-top:1px solid var(--border-subtle);margin-top:4px">
        Click any column header to sort · Click member name to view details
      </div>
    </div>`;

    html += `
      <div class="grid-2 mt-5">
        <div class="tile"><div class="section-title">Active Cases by Member</div>
          <div class="chart-canvas-wrap chart-lg"><canvas id="chart-members-open"></canvas></div></div>
        <div class="tile"><div class="section-title">Stale Cases by Member</div>
          <div class="chart-canvas-wrap chart-lg"><canvas id="chart-members-stale"></canvas></div></div>
      </div>
      <div class="grid-2 mt-5">
        <div class="tile"><div class="section-title">SLA Adherence by Member (≤${slaDays}d)</div>
          <div class="chart-canvas-wrap chart-lg"><canvas id="chart-members-sla"></canvas></div></div>
        <div class="tile"><div class="section-title">Awaiting Feedback by Member</div>
          <div class="chart-canvas-wrap chart-lg"><canvas id="chart-members-await"></canvas></div></div>
      </div>`;

    container.innerHTML = html;

    container.querySelectorAll(".sort-th").forEach(th => {
      th.addEventListener("click", () => {
        const key = th.dataset.sort;
        if (_sortKey === key) _sortDir *= -1;
        else { _sortKey = key; _sortDir = -1; }
        renderAllMembersGrid(stats, slaTarget, slaDays);
      });
    });

    document.getElementById("members-search")?.addEventListener("input", e => {
      const q = e.target.value.toLowerCase();
      document.querySelectorAll("#members-tbody tr").forEach(tr => {
        tr.style.display = tr.textContent.toLowerCase().includes(q) ? "" : "none";
      });
    });

    document.getElementById("members-export")?.addEventListener("click", () => exportMembersTable(sorted, slaDays));

    if (container._memberClickHandler) {
      container.removeEventListener("click", container._memberClickHandler);
    }
    container._memberClickHandler = function(e) {
      const btn = e.target.closest(".member-detail-btn");
      if (!btn) return;
      _selectedMember = btn.dataset.member;
      const inp = document.getElementById("member-search-input");
      const clr = document.getElementById("member-search-clear");
      if (inp) inp.value = Utils.shortName(_selectedMember);
      if (clr) clr.style.display = "block";
      renderMemberDetail(_selectedMember, Data.teamCases());
    };
    container.addEventListener("click", container._memberClickHandler);

    renderMembersCharts(sorted, slaTarget);
  }

  /* ── Charts ──────────────────────────────────────────── */
  function renderMembersCharts(stats, slaTarget) {
    const clickMember = name => {
      _selectedMember = name;
      const inp = document.getElementById("member-search-input");
      const clr = document.getElementById("member-search-clear");
      if (inp) inp.value = Utils.shortName(name);
      if (clr) clr.style.display = "block";
      renderMemberDetail(name, Data.teamCases());
    };

    try {
      Charts.ownerBar("chart-members-open",
        stats.filter(s => s.open.length > 0).map(s => ({ name: Utils.shortName(s.member), fullName: s.member, count: s.open.length })),
        { color: "var(--chart-1)", onClick: clickMember });
    } catch(e) {}

    try {
      Charts.ownerBar("chart-members-stale",
        stats.filter(s => s.stale.length > 0).map(s => ({ name: Utils.shortName(s.member), fullName: s.member, count: s.stale.length })),
        { color: "var(--chart-5)" });
    } catch(e) {}

    try {
      Charts.ownerBar("chart-members-await",
        stats.filter(s => s.await_.length > 0).map(s => ({ name: Utils.shortName(s.member), fullName: s.member, count: s.await_.length })),
        { color: "var(--chart-3)" });
    } catch(e) {}

    // SLA chart — bar colour per member: green if meets target, red if not
    try {
      const slaData = stats.filter(s => s.slaPct !== null).map(s => ({
        name: Utils.shortName(s.member), fullName: s.member, count: s.slaPct
      }));
      if (slaData.length > 0) {
        Charts.ownerBar("chart-members-sla", slaData, {
          color: "var(--green)",
          colorFn: d => {
            const s = stats.find(m => Utils.shortName(m.member) === d.name || m.member === d.fullName);
            return s && s.slaPct >= slaTarget ? "rgba(25,128,56,.7)" : "rgba(218,30,40,.6)";
          }
        });
      }
    } catch(e) {}
  }

  /* ── Member Detail View ──────────────────────────────── */
  function renderMemberDetail(member, teamAll) {
    const container = document.getElementById("members-content");
    if (!container) return;
    const s        = getMemberStats(member, teamAll);
    const trend    = Utils.monthlyTrend(s.cases);
    const initials = Utils.shortName(member).split(" ").map(p => p[0]).join("").slice(0,2).toUpperCase();
    const email    = Data.teamEmails()[member] || "";

    const statusMap = {};
    s.cases.forEach(r => { statusMap[r.Status] = (statusMap[r.Status]||0)+1; });
    const statusData = Object.entries(statusMap).map(([name,value]) => ({ name, value }));

    const healthColor = s.health >= 80 ? "var(--green)" : s.health >= 50 ? "var(--yellow)" : "var(--red)";

    // Hide team KPI row and remove filter-bar top margin when viewing individual member detail
    const kpiRow = document.getElementById("members-kpi-row");
    if (kpiRow) kpiRow.style.display = "none";
    const filterBar = document.querySelector("#tab-members .filter-bar");
    if (filterBar) filterBar.classList.remove("mt-5");

    container.innerHTML = `
      <div class="tile" style="display:flex;align-items:center;gap:20px;flex-wrap:wrap;border-left:4px solid var(--ibm-blue-50);padding:20px">
        <div class="member-avatar member-avatar-lg">${initials}</div>
        <div class="flex-1-0">
          <div style="font-size:20px;font-weight:700;color:var(--text-primary)">${Utils.escHtml(Utils.shortName(member))}</div>
          ${email ? `<a href="mailto:${Utils.escHtml(email)}" style="font-size:12px;color:var(--ibm-blue-50);text-decoration:none;margin-top:2px;display:inline-block"
            onmouseover="this.style.textDecoration='underline'" onmouseout="this.style.textDecoration='none'">${Utils.escHtml(email)}</a>` : ""}
        </div>
        <button id="back-to-all" class="btn btn-ghost btn-sm">← All Members</button>
      </div>

      <div class="tile mt-5 member-stat-strip">
        ${[
          { label: "Active Cases",     val: s.open.length,   color: "var(--ibm-blue-50)",  sub: `of ${s.cases.length} total` },
          { label: "Closed (Last 7d)", val: s.closed7d,      color: "var(--green)",         sub: "" },
          { label: "Awaiting Feedback",val: s.await_.length, color: s.await_.length > 0 ? "var(--red)" : "var(--green)", sub: "" },
          { label: "In Progress",      val: s.inprog.length, color: "var(--ibm-blue-50)",  sub: "" },
          { label: "Perf Cases",       val: s.perf.length,   color: s.perf.length > 0 ? "var(--red)" : "var(--text-secondary)", sub: "" },
          { label: "Stale (5d+)",      val: s.stale.length,  color: s.stale.length > 0 ? "var(--red)" : "var(--text-secondary)", sub: "" },
          { label: "Avg Days Open",    val: s.avgDays + "d", color: s.avgDays >= 10 ? "var(--red)" : s.avgDays >= 5 ? "var(--yellow-text)" : "var(--text-primary)", sub: "" },
          { label: `SLA (≤${s.slaDays}d)`, val: s.slaPct !== null ? s.slaPct + "%" : "—", color: s.slaPct !== null ? (s.slaPct >= s.slaTarget ? "var(--green)" : "var(--red)") : "var(--text-secondary)", sub: s.slaPct !== null ? `Target: ${s.slaTarget}%` : "No closed cases" },
          { label: "Health Score",     val: s.health,        color: healthColor, sub: s.health >= 80 ? "Good" : s.health >= 50 ? "Fair" : "Needs Attention" },
        ].map((st, i, arr) => `
          <div class="member-stat-cell${i < arr.length - 1 ? " member-stat-sep" : ""}">
            <div class="member-stat-label">${st.label}</div>
            <div class="member-stat-val" style="color:${st.color}">${st.val}</div>
            ${st.sub ? `<div class="member-stat-sub">${st.sub}</div>` : `<div class="member-stat-sub">&nbsp;</div>`}
          </div>`).join("")}
      </div>

      <div class="grid-2 mt-5">
        <div class="tile">
          <div class="section-title">Monthly Case Trend</div>
          <div class="chart-canvas-wrap chart-sm"><canvas id="chart-member-trend"></canvas></div>
        </div>
        <div class="tile">
          <div class="section-title">Cases by Status</div>
          <div class="chart-canvas-wrap chart-sm"><canvas id="chart-member-status"></canvas></div>
        </div>
      </div>

      ${s.stale.length > 0 ? `
      <div class="tile mt-5" style="border-left:4px solid var(--red)">
        <div class="section-title">⚠ Stale Cases — Not Updated 5+ Days</div>
        <div id="tbl-member-stale"></div>
      </div>` : ""}

      ${s.await_.length > 0 ? `
      <div class="tile mt-5" style="border-left:4px solid var(--yellow)">
        <div class="section-title">⏳ Awaiting Feedback Cases</div>
        <div id="tbl-member-await"></div>
      </div>` : ""}

      <div class="tile mt-5">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
          <div class="section-title mb-0">All Cases
            <span style="font-size:11px;font-weight:400;color:var(--text-tertiary);margin-left:6px">${s.cases.length} total</span>
          </div>
        </div>
        <div id="tbl-member-all"></div>
      </div>
    `;

    document.getElementById("back-to-all")?.addEventListener("click", () => {
      _selectedMember = "";
      const inp = document.getElementById("member-search-input");
      const clr = document.getElementById("member-search-clear");
      if (inp) inp.value = "";
      if (clr) clr.style.display = "none";
      render();
    });

    try { Charts.trendLine("chart-member-trend", trend); } catch(e) {}
    try { Charts.statusDonut("chart-member-status", statusData); } catch(e) {}

    const extraCols = [{
      key: "_days", label: "Days Stale", sortable: true,
      render: row => {
        const days  = Utils.daysDiff(Utils.parseDate(row.Updated) || Utils.parseDate(row.Created));
        const color = days >= 10 ? "var(--red)" : days >= 5 ? "var(--yellow)" : "var(--text-tertiary)";
        return `<span style="color:${color};font-family:var(--font-mono);font-weight:600">${days}d</span>`;
      },
      sortValue: row => Utils.daysDiff(Utils.parseDate(row.Updated) || Utils.parseDate(row.Created))
    }];

    if (s.stale.length > 0)  Table.render(document.getElementById("tbl-member-stale"),  s.stale,  { showActions: false, extraCols });
    if (s.await_.length > 0) Table.render(document.getElementById("tbl-member-await"), s.await_, { showActions: false, extraCols });
    Table.render(document.getElementById("tbl-member-all"), s.cases, { showActions: false, extraCols });
  }

  /* ── Export ──────────────────────────────────────────── */
  function exportMembersTable(stats, slaDays) {
    const headers = ["Member","Total","Active","Closed (7d)","Awaiting Feedback","In Progress","Perf Cases","Stale (5d+)","Avg Days Open",`SLA % (≤${slaDays}d)`,"Health Score"];
    const rows = stats.map(s => [
      Utils.shortName(s.member), s.cases.length, s.open.length, s.closed7d,
      s.await_.length, s.inprog.length, s.perf.length, s.stale.length, s.avgDays,
      s.slaPct !== null ? s.slaPct : "", s.health
    ].map(v => `"${v}"`).join(","));
    const csv  = [headers.join(","), ...rows].join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement("a");
    a.href = url;
    a.download = `member_dashboard_${new Date().toISOString().slice(0,10)}.csv`;
    document.body.appendChild(a); a.click();
    setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 1000);
  }

  return { render };
})();
