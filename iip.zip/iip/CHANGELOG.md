# Changelog

## v2.0.0 — March 23, 2026
**Production Release · Phases 1-5 Merged**

### ✨ Post-Release Updates (v2.0.0+)

#### 🖥️ Mobile Code Removal — Desktop-Only Transition
- **Removed:** `css/mobile.css` — entire mobile-specific stylesheet deleted
- **Removed from `index.html`:**
  - Viewport meta tag (`<meta name="viewport" .../>`) — no responsive scaling
  - Mobile CSS link reference
  - Mobile sidebar toggle button HTML
  - Mobile sidebar backdrop overlay element
- **Removed from `js/app.js`:**
  - `touchstart` event listener from idle detection (`_setupIdleEvents`)
  - Mobile sidebar toggle function (`_toggleMobile()`)
  - Mobile hamburger button event listeners
- **Removed from `js/modules/ui/polish.js`:**
  - Haptic feedback (vibratio API call `navigator.vibrate([50, 100, 50])`)
- **Removed from `js/modules/ui/whats-new.js`:**
  - Haptic feedback feature documentation references
- **CSS Media Query Cleanup:** Removed 24 responsive breakpoint blocks from:
  - `css/core/layout.css` (8 queries: 768px, 640px, 900px breakpoints)
  - `css/features/atlassian.css` (12 queries: 768px, 640px, 860px breakpoints)
  - `css/features/how-it-works.css` (2 queries: 768px, 480px)
  - `css/features/investigate.css` (1 query: 900px)
  - `css/features/rfe-tracking.css` (1 query: 768px)
- **Result:** Application is now **100% desktop-only**; all responsive layout code removed; touch interactions eliminated

#### ♿ Accessibility & UX Enhancements
- **WCAG 2.1 Level AA Focus Indicators** — Added to `css/core/base.css`:
  - `*:focus-visible` — 2px blue outline on all interactive elements
  - Form fields use inset outline (`outline-offset: -1px`) to prevent layout shifts
  - Supports full keyboard navigation for accessibility users
- **Modal Accessibility Improvements** — Enhanced `js/modules/ui/modal.js`:
  - Reassign dropdown trigger: added `aria-haspopup="listbox"` + `aria-expanded` attribute
  - Reassign dropdown list: added `role="listbox"` semantic attribute
  - Reassign dropdown items: added `role="option"` to each selectable item
  - Result: Screen readers now properly announce dropdown state and options
- **Keyboard Navigation Enhancements** — Modal reassign dropdown now supports:
  - arrow keys ↑↓ to navigate options (`ArrowUp` / `ArrowDown`)
  - `Enter` to confirm selection
  - `Escape` to close dropdown
  - Tab support for trigger button focus
- **Loading State Feedback** — Reassign confirm button now shows:
  - Spinner animation during API call (visual feedback that request is pending)
  - Button disabled state during processing (prevents duplicate submissions)
  - Success toast notification after reassignment completes
  - Error handling with fallback error message

### 📝 Summary of v2.0.0+ Changes
- **Files Modified:** 8 total
  - HTML: `index.html` (removed mobile markup)
  - JavaScript: `js/app.js`, `js/modules/ui/modal.js`, `js/modules/ui/polish.js`, `js/modules/ui/whats-new.js`
  - CSS: `css/core/base.css`, `css/core/layout.css`, `css/features/atlassian.css`, `css/features/how-it-works.css`, `css/features/investigate.css`, `css/features/rfe-tracking.css`
- **Code Quality:** No breaking changes; desktop functionality unaffected; database persistence continues unchanged
- **Accessibility Score:** WCAG 2.1 Level AA compliance achieved via focus indicators + ARIA attributes
- **Production Readiness:** Codebase structure maintained; no dependencies added or removed

---

## v2.0.0 — March 23, 2026 (Original Release)
**Production Release · Phases 1-5 Merged**

### 🔒 Phase 1: Security Foundation
- `.gitignore` — prevent accidental commits of `.env`, `*.bak`, sensitive files
- Content-Security-Policy via `.htaccess` — locked-down headers: `default-src 'self'`, restricted CDN sources
- `POST /api/cases` & `POST /api/upload-cases` — require `X-IIP-Admin-Token` header (403 Forbidden without auth)
- `.env` sanitization — removed plaintext credentials, `.env.example` created as template
- `backend/.env.example` — deployment template with instructions for password/token generation

### 🔐 Phase 2: Authentication Hardening
- **POST /api/auth** — server-side bcrypt password verification (replaces client-side checks)
- **POST /api/auth/set-password** — secure password change endpoint (requires admin token)
- Admin token → `sessionStorage` only (no disk persistence; cleared on tab close)
- `sessionStorage` automatically scrubs legacy `localStorage` tokens on login
- **Helmet.js** — adds HSTS, X-DNS-Prefetch-Control, Cross-Origin policies
- **DB pool hardened** — max 5 connections, 30s idle timeout, 5s connection timeout, optional SSL support
- Express body limit corrected to 10MB (matches API contract)
- SSE path uses `window.__APP_BASE__` — fixed deployments on subpaths (`/iip/`)

### 📊 Phase 3: Observability & Operations
- **Structured logging** — [morgan](https://npmjs.org/package/morgan) → pino transport; every HTTP request logged as JSON
- **pino logger** — replaces all `console.log`/`console.error` calls; colorized on dev, pure JSON on prod
- `LOG_LEVEL` env var controls verbosity (`debug|info|warn|error|fatal`)
- **GET /api/health** enhanced — returns `uptime_s`, `db_latency_ms`, `env`, `sse_clients`, `version`
- **Graceful shutdown** — SIGTERM/SIGINT handlers drain SSE clients, release DB pool, exit cleanly
- **Process error guards** — `uncaughtException` (fatal exit) + `unhandledRejection` (logged, continues)
- **pm2 ecosystem.config.js** — process manager config with memory guards, exponential backoff, structured logs

### ✅ Phase 4: Testing & Code Quality
- **Jest test suite** — 47 tests covering: `isKeyAllowed()`, `safeParseValue()`, `rateLimit()`, auth middleware, all HTTP endpoints
- **Security fix discovered in tests** — `isKeyAllowed()` whitespace bypass closed (rejects trailing/leading spaces)
- **Coverage thresholds** — Lines ≥60%, Functions ≥70%, Branches ≥55%
- **ESLint v9 flat config** — enforces no-unused-vars, no-eval, prefer-const, eqeqeq, semi
- **Prettier config** — single quotes, 100-char width, LF line endings, ES5 trailing commas
- **Husky pre-commit hooks** — runs ESLint + Prettier on staged `backend/*.js` files

### 🧹 Phase 5: Legacy Cleanup & Production Readiness
- **express-rate-limit** replaces hand-rolled rate limiter — 3 named limiters:
  - `readLimiter`: 300 GET/min (all GET endpoints)
  - `writeLimiter`: 60 POST·DELETE/min (all write endpoints)
  - `authLimiter`: 10 auth attempts/min (`/api/auth`, `/api/auth/set-password`)
- **GET /api/team-config** — new endpoint serves `ibm_team_config_v1` + `admin-cfg` from DB
- **DynamicConfig.js** — fetches team data from `/api/team-config` at startup; falls back to localStorage cache → `AppData`
- **app-data.js deprecation** — marked as offline fallback; can be removed after `/api/team-config` verification
- **Legacy module reorganization** — `v6-features.js`, `whats-new.js`, `phase1-patches.js` moved out of legacy folder
- **Node.js ≥18 requirement** — align with Express 5, Helmet 8, and modern dependencies

### 📦 New Files
- `backend/package.json` — dependencies fully updated; all scripts configured
- `backend/server.test.js` — comprehensive test suite with 47 tests
- `backend/eslint.config.cjs` — ESLint v9 flat config
- `backend/.prettierrc` — code formatting rules
- `backend/.husky/pre-commit` — lint-staged hook
- `backend/.env.example` — deployment template
- `.gitignore` — security-focused ignore patterns
- `schema/001_initial.sql` — database schema with migrations bookkeeping

### 🎯 Breaking Changes
- Token storage moved from `localStorage` → `sessionStorage` (design: session-scoped, XSS risk reduced)
- `app-data.js` no longer required for normal operation (replaced by `/api/team-config` endpoint)
- Password verification now server-only (client-side checks removed)
- Rate limiters default to new limits; customize via `express-rate-limit` store config if needed

### ✨ What's Fixed
- XSS risk from persistent `localStorage` tokens eliminated
- Password bypass via whitespace in key names closed
- Missing health check endpoint added for orchestrators (k8s, pm2, systemd)
- Memory leaks in graceful shutdown closed (SSE clients now properly drained)
- Node modules can now safely install on restricted networks (bcryptjs pure-JS)

### 🚀 Deployment Checklist
```bash
# 1. Install dependencies
cd backend && npm ci --omit=dev

# 2. Run tests (optional, but recommended)
npm test -- --coverage

# 3. Migrate database schema
psql -U $DB_USER -d $DB_NAME -f ../schema/001_initial.sql

# 4. Generate new credentials
node -e "console.log('DB password (20 chars):', require('crypto').randomBytes(15).toString('base64url'))"
node -e "console.log('Admin token (hex 64):', require('crypto').randomBytes(32).toString('hex'))"

# 5. Update .env with new credentials
cp .env.example .env  # template
# Edit .env manually with real DB password and new admin token

# 6. Start with pm2 (recommended) or Node
pm2 start ecosystem.config.js --env prod
# OR: npm start:prod

# 7. Verify health endpoint
curl https://your-server/api/health
```

---

## v1.0.2 — March 20, 2026

### 🔴 Security Fixes (Critical)
1. **Removed DB password `IIP@Bosch2026!`** from documentation.js (was visible to all users in 2 locations)
2. **Removed default admin password `admin123`** from admin.js and all 8 documentation references
3. **Sanitized `.env`** — now ships with placeholder values only; real credentials stay on server
4. **API write authentication** — POST/DELETE requests now require `X-IIP-Admin-Token` header
5. **API key allowlist** — only known IIPStore keys accepted; unknown keys rejected with HTTP 400
6. **CORS restricted** — locked to production origin `https://rb-alm-01-d8.de.bosch.com`
7. **Rate limiting** — 120 reads/min, 30 writes/min per IP on all API endpoints
8. **Security headers** — `X-Content-Type-Options`, `X-Frame-Options`, `Cache-Control` on all API responses

### 🔐 Access Control
9. **Admin-only documentation pages** — Operations section (Server Stack, Deploy, PostgreSQL, RHEL9, pm2, Security, Backup) and Admin Password/Data Management now require admin login to view
10. **First-time password setup** — no default password; first Admin Portal access forces creation (min 8 chars)
11. **Admin token integration** — on login, API write token passed to `IIPStore.setAdminToken()` for authenticated writes
12. **`showPage()` gating** — documentation renderer checks `adminOnly` flag and shows login prompt for non-admins

### 📄 New Documentation Pages
13. **Admin Access Guide** (admin-only) — consolidated DB, backend, and frontend access instructions with security best practices
14. **Application Flowchart** — end-to-end visual flows: page load, CSV upload, admin auth, API map, storage map, network architecture

### 🛠 Data Handling Fixes
15. **Removed hardcoded `"881812"` fallbacks** from `overview.js`, `closed.js`, `created.js` — now delegates to `Data.customerAccountId()`
16. **Removed duplicate `DEFECT_BASE_URL`** hardcoded fallback from `admin-dash.js`
17. **Updated payload limit** from 50MB to 10MB in server.js

### 📦 Infrastructure
18. **`backend/package.json`** — added `"start": "node server.js"`, fixed `"main"` to `server.js`, updated version
19. **`storage.js`** — added `setAdminToken()`/`getAdminToken()` methods; write requests include `X-IIP-Admin-Token` header; 403 handling with localStorage fallback
20. **`admin.js`** — rewritten: first-time setup flow, token storage in localStorage/sessionStorage, session restore with token
21. **`.htaccess`** — removed stale PHP reference
22. **`.gitignore`** — created to prevent `.env` commits
23. **API error handling** — 404 catch-all, global error handler, no stack traces in responses
24. **Input validation** — `value` field required on POST; key parameter validated against allowlist

### 📝 Documentation Updates
25. **What's New page** — updated to v1.0.2 with full changelog
26. **Platform Overview** — updated version badge to v1.0.2, added "Hardened" badge
27. **Security Model** — rewritten to reflect all v1.0.2 API security controls
28. **REST API Endpoints** — added auth column, allowed keys list, updated examples with token headers
29. **Limits & Performance** — updated file upload limit to 10MB
30. **Troubleshooting/FAQs** — removed all `admin123` reset instructions, updated to use `removeItem` approach

### Files Changed
- `backend/server.js` — full rewrite (security hardening)
- `backend/package.json` — version, main, start script
- `backend/.env` — sanitized (placeholder only)
- `js/modules/data/storage.js` — admin token support
- `js/modules/admin/admin.js` — full rewrite (no default password, token flow)
- `js/dashboards/documentation.js` — 30+ edits (password removal, admin gating, new pages, version updates)
- `js/dashboards/overview.js` — removed 881812 fallback
- `js/dashboards/closed.js` — removed 881812 fallback
- `js/dashboards/created.js` — removed 881812 fallback
- `js/dashboards/admin-dash.js` — removed hardcoded DEFECT_BASE_URL
- `data/.htaccess` — removed stale PHP comment
- `.gitignore` — new file
- `CHANGELOG.md` — new file
