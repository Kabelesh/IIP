#!/usr/bin/env node
/* ================================================================
   backend/seed-db.js  — One-time DB seed from app-data.js  v2.2
   ================================================================
   Reads the existing app-data.js and seeds ALL data into
   PostgreSQL so every user gets full data on next page load.

   USAGE:
     cd /var/www/html/iip/backend
     node seed-db.js

   REQUIREMENTS:
     • .env with DB credentials and IIP_ADMIN_TOKEN
     • app-data.js at ../js/data/app-data.js
   ================================================================ */
require('dotenv').config();
const { Pool } = require('pg');
const vm   = require('vm');
const fs   = require('fs');
const path = require('path');

const APP_DATA_PATH = path.resolve(__dirname, '../js/data/app-data.js');
const ADMIN_TOKEN   = process.env.IIP_ADMIN_TOKEN;

if (!ADMIN_TOKEN) {
  console.error('❌  IIP_ADMIN_TOKEN not set in .env — cannot write to DB.');
  process.exit(1);
}

/* ── Read and parse app-data.js ────────────────────────────────── */
console.log(`\n📂  Reading: ${APP_DATA_PATH}`);
if (!fs.existsSync(APP_DATA_PATH)) {
  console.error('❌  app-data.js not found at', APP_DATA_PATH);
  process.exit(1);
}

const code = fs.readFileSync(APP_DATA_PATH, 'utf8');
const fileSizeMB = (fs.statSync(APP_DATA_PATH).size / 1024 / 1024).toFixed(2);
console.log(`📦  File size: ${fileSizeMB} MB`);

/* The file declares: const AppData = (() => { ... })();
   We replace "const AppData =" with "var __iip_data =" and wrap
   in a function so vm.runInNewContext can return the value cleanly. */
let AppData = null;
try {
  const extractCode = '(function() { '
    + code.replace(/const\s+AppData\s*=\s*/, 'var __iip_data = ')
    + '; return __iip_data; })()';
  AppData = vm.runInNewContext(extractCode, {});
} catch(e) {
  console.error('❌  Failed to parse app-data.js:', e.message);
  process.exit(1);
}

if (!AppData || typeof AppData !== 'object') {
  console.error('❌  AppData object not found or invalid.');
  process.exit(1);
}

console.log('✅  AppData parsed successfully');

/* Report what sections are available */
const sections = [];
if (AppData.allDashboardData) {
  const k = Object.keys(AppData.allDashboardData).length;
  sections.push(`allDashboardData (${k} keys)`);
}
if (AppData.rfeData?.rows)          sections.push('rfeData');
if (AppData.performanceCases?.length) sections.push(`performanceCases (${AppData.performanceCases.length})`);
if (AppData.performanceMeta)        sections.push('performanceMeta');
if (AppData.changeHistory?.length)  sections.push(`changeHistory (${AppData.changeHistory.length})`);
if (AppData.teamMembers?.length)    sections.push(`teamMembers (${AppData.teamMembers.length})`);
console.log('   Sections:', sections.join('  |  ') || 'basic config only (no allDashboardData — upload app-data.js via Admin Portal to get full data)');
console.log('');

/* ── PostgreSQL ─────────────────────────────────────────────────── */
const pool = new Pool({
  host:     process.env.DB_HOST,
  port:     parseInt(process.env.DB_PORT, 10),
  database: process.env.DB_NAME,
  user:     process.env.DB_USER,
  password: process.env.DB_PASSWORD,
});

function isEmpty(v) {
  if (v === null || v === undefined) return true;
  if (typeof v === 'string' && v.trim() === '') return true;
  if (Array.isArray(v) && v.length === 0) return true;
  if (typeof v === 'object' && !Array.isArray(v) && Object.keys(v).length === 0) return true;
  return false;
}

async function upsert(client, key, value) {
  if (isEmpty(value)) return false;
  await client.query(
    'INSERT INTO iip_kv (key,value,updated_at) VALUES($1,$2,NOW()) ' +
    'ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value,updated_at=NOW()',
    [key, JSON.stringify(value)]
  );
  return true;
}

async function seed() {
  const client = await pool.connect();
  let written = 0, skipped = 0, alreadySet = 0;

  try {
    await client.query('BEGIN');
    console.log('🔄  Seeding keys into PostgreSQL...\n');

    /* ── Step 1: allDashboardData blob (contains all dynamic keys) ── */
    const all = AppData.allDashboardData;
    if (all && typeof all === 'object') {
      for (const [key, rawValue] of Object.entries(all)) {
        if (!key || !rawValue) { skipped++; continue; }
        // Values stored as raw JSON strings — parse before upserting
        let parsed;
        try { parsed = JSON.parse(rawValue); } catch(e) { parsed = rawValue; }
        const ok = await upsert(client, key, parsed);
        if (ok) {
          written++;
          const sz = rawValue.length;
          console.log(`  ✓  ${key.padEnd(48)} ${sz > 0 ? (sz/1024).toFixed(1)+'KB' : ''}`);
        } else {
          skipped++;
          console.log(`  ⚪  ${key.padEnd(48)} (empty — skipped)`);
        }
      }
    } else {
      console.log('  ℹ️   No allDashboardData found — seeding explicit sections only.');
      console.log('      For full data, export app-data.js from Admin Portal and re-run.\n');
    }

    /* ── Step 2: Explicit named sections (may not be in allDashboardData) ── */
    const explicit = [
      ['ibm_rfe_tracking_v1',          AppData.rfeData?.rows],
      ['ibm_rfe_tracking_metadata_v1', AppData.rfeData?.metadata],
      ['ibm_rfe_tracking_last_update', AppData.rfeData?.lastUpdate],
      ['admin-perf-cases',             AppData.performanceCases],
      ['admin-non-perf-cases',         AppData.nonPerformanceCases],
      ['admin-perf-meta',              AppData.performanceMeta],
      ['admin-change-history',         AppData.changeHistory],
      ['admin-cfg',                    AppData.config],
      ['admin-members',                AppData.teamMembers],
      ['admin-emails',                 AppData.teamEmails],
      ['admin-expertise',              AppData.expertiseConnect],
      ['admin-escalation',             AppData.bdEscalation],
      ['admin-lead',                   AppData.teamLead],
      ['admin-customers',              AppData.customerContacts],
      ['admin-alm',                    AppData.almResponsible],
      ['admin-ibm-dir',                AppData.ibmDirectory],
    ];

    for (const [key, value] of explicit) {
      // Check if already written via allDashboardData above
      const existing = await client.query('SELECT 1 FROM iip_kv WHERE key=$1', [key]);
      if (existing.rows.length > 0) {
        alreadySet++;
        continue;
      }
      const ok = await upsert(client, key, value);
      if (ok) {
        written++;
        console.log(`  ✓  ${key.padEnd(48)} (explicit section)`);
      } else {
        skipped++;
      }
    }

    await client.query('COMMIT');

    console.log('\n' + '═'.repeat(62));
    console.log(`✅  Seed complete!`);
    console.log(`   Keys written        : ${written}`);
    console.log(`   Keys already in DB  : ${alreadySet}`);
    console.log(`   Keys skipped        : ${skipped} (empty)`);
    console.log('═'.repeat(62));
    console.log('\n📋  Verify in PostgreSQL:');
    console.log('    sudo -u postgres psql -d iip_db -c "SELECT key, updated_at FROM iip_kv ORDER BY updated_at DESC;"');
    console.log('\n🔄  The Node.js API server is already running — no restart needed.');
    console.log('    (Only server.js changes require a restart)\n');
    console.log('🌐  Open app in a fresh/incognito browser to verify all data appears.\n');

  } catch(e) {
    await client.query('ROLLBACK');
    console.error('\n❌  Seed failed, rolled back:', e.message);
    console.error(e.stack);
    process.exit(1);
  } finally {
    client.release();
    await pool.end();
  }
}

seed().catch(e => {
  console.error('❌  Unexpected error:', e.message);
  process.exit(1);
});
