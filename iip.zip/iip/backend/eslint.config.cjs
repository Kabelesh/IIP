// eslint.config.cjs  — ESLint v9 flat config for iip-backend
// Run:  npm run lint
//       npm run lint:fix
'use strict';

const js = require('@eslint/js');

module.exports = [
  js.configs.recommended,
  {
    files: ['server.js', 'server.test.js', 'seed-db.js'],
    languageOptions: {
      ecmaVersion: 2022,
      sourceType: 'commonjs',
      globals: {
        // Node globals
        require:   'readonly',
        module:    'readonly',
        exports:   'readonly',
        __dirname: 'readonly',
        __filename:'readonly',
        process:   'readonly',
        console:   'readonly',
        setTimeout:'readonly',
        clearTimeout:'readonly',
        setInterval:'readonly',
        clearInterval:'readonly',
        Date:      'readonly',
        Buffer:    'readonly',
        // Jest globals (test file)
        describe:  'readonly',
        test:      'readonly',
        expect:    'readonly',
        beforeAll: 'readonly',
        afterAll:  'readonly',
        beforeEach:'readonly',
        afterEach: 'readonly',
        jest:      'readonly',
      },
    },
    rules: {
      // ── Errors — hard fails ──────────────────────────────────
      'no-unused-vars':          ['error', { argsIgnorePattern: '^_', varsIgnorePattern: '^_' }],
      'no-undef':                'error',
      'no-unreachable':          'error',
      'no-duplicate-case':       'error',
      'no-self-assign':          'error',

      // ── Style — warnings (fix with --fix) ────────────────────
      'eqeqeq':                  ['warn', 'always', { null: 'ignore' }],
      'no-var':                  'warn',
      'prefer-const':            'warn',
      'no-console':              'warn',   // use pino logger instead
      'curly':                   ['warn', 'multi-line'],
      'semi':                    ['warn', 'always'],

      // ── Security hints ───────────────────────────────────────
      'no-eval':                 'error',
      'no-implied-eval':         'error',
      'no-new-func':             'error',
    },
  },
  {
    // Relax no-console inside test files — jest output is fine
    files: ['server.test.js'],
    rules: { 'no-console': 'off', 'prefer-const': 'off' },
  },
];
