/* ================================================================
   backend/server.js  —  IIP API Server  v4.0  (Phase 5)
   ----------------------------------------------------------------
   v3.0 changes:
   - GET  /api/cases          — fetch all cases (no auth needed, read-only)
   - POST /api/cases          — save cases (admin token required)
   - GET  /api/events         — Server-Sent Events for instant push
   - Instant cross-user notification on upload (replaces 30s polling)
   - All previous v2.0 endpoints retained for compatibility

   Phase 2 hardening (v3.0.1):
   - bcryptjs (pure-JS) replaces native bcrypt addon — proxy-safe install
   - Robust JSON.parse for legacy plaintext password values in DB
   - Helmet.js security headers
   - DB pool: max connections, idle/connection timeouts, SSL support
   - Body limit corrected to 10mb
   - SSE path uses __APP_BASE__

   Phase 3 observability (v3.1.0):
   - morgan HTTP access logging → pino transport (JSON on prod, pretty on dev)
   - pino structured logger replaces all console.log / console.error calls
   - GET /api/health now returns uptime, version, db latency, environment
   - Graceful shutdown: drains SSE clients, releases DB pool, exits cleanly
   - process uncaughtException + unhandledRejection guards
   - ibm_error_log_v1 added to ALLOWED_KEYS for frontend error reports

   Phase 5 (v4.0.0):
   - express-rate-limit replaces hand-rolled _rateMap (Redis-ready)
   - GET /api/team-config — serve team members, emails, config from DB
   ================================================================ */
require('dotenv').config();
const express      = require('express');
const { Pool }     = require('pg');
const cors         = require('cors');
const crypto       = require('crypto');
const helmet       = require('helmet');
const bcrypt       = require('bcryptjs');
const morgan       = require('morgan');
const pino         = require('pino');
const rateLimit    = require('express-rate-limit');

/* ── Structured logger ────────────────────────────────────────── */
const IS_PROD = process.env.NODE_ENV === 'production';
const log = pino({
  level: process.env.LOG_LEVEL || 'info',
  ...(IS_PROD
    ? {}  // production: pure JSON — pipe to file via pm2 / stdout redirect
    : { transport: { target: 'pino-pretty', options: { colorize: true, translateTime: 'SYS:standard' } } }
  ),
});

const app = express();

// Helmet: sets HSTS, Referrer-Policy, Permissions-Policy, X-DNS-Prefetch-Control etc.
app.use(helmet({ contentSecurityPolicy: false })); // CSP handled by .htaccess

/* ── HTTP access logging via morgan → pino ────────────────────── */
// morgan writes combined-format lines; we pipe each line into pino at 'info'
app.use(morgan('combined', {
  stream: { write: (msg) => log.info({ type: 'http' }, msg.trimEnd()) },
}));

const ALLOWED_ORIGIN = process.env.CORS_ORIGIN || 'https://rb-alm-01-d8.de.bosch.com';
app.use(cors({
  origin: (origin, cb) => {
    if (!origin || origin === ALLOWED_ORIGIN) return cb(null, true);
    cb(new Error('CORS: origin not allowed'));
  },
  methods: ['GET', 'POST', 'DELETE'],
  allowedHeaders: ['Content-Type', 'X-IIP-Admin-Token'],
}));

app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  next();
});

app.use(express.json({ limit: '10mb' }));

const pool = new Pool({
  host:                    process.env.DB_HOST,
  port:                    parseInt(process.env.DB_PORT, 10),
  database:                process.env.DB_NAME,
  user:                    process.env.DB_USER,
  password:                process.env.DB_PASSWORD,
  max:                     5,                // max simultaneous connections
  idleTimeoutMillis:       30000,            // release idle connections after 30s
  connectionTimeoutMillis: 5000,             // fail fast if DB unreachable
  ssl: process.env.DB_SSL === 'true'
    ? { rejectUnauthorized: process.env.DB_SSL_REJECT_UNAUTHORIZED !== 'false' }
    : false,
});

/* ── SSE client registry ──────────────────────────────────────── */
const _sseClients = new Set();

function _broadcast(eventName, data) {
  const msg = `event: ${eventName}\ndata: ${JSON.stringify(data)}\n\n`;
  for (const res of _sseClients) {
    try { res.write(msg); } catch(e) { _sseClients.delete(res); }
  }
}

/* ── Key allowlist ────────────────────────────────────────────── */
const ALLOWED_KEYS = new Set([
  'ibm_cases_raw_v1', 'ibm_cases_overrides_v1', 'ibm_reopened_cases_v1',
  'ibm_import_log_v1', 'ibm_tracker_persist_v1', 'ibm_team_config_v1',
  'ibm_team_config_v1_cache', 'ibm_wtracker_comments_v1', 'ibm_wtracker_history',
  'ibm_wtracker_linkmap_v1', 'ibm_wtracker_seeded_v5', 'ibm_wtracker_seed_v1',
  'ibm_rfe_tracking_v1', 'ibm_rfe_tracking_metadata_v1', 'ibm_rfe_tracking_last_update',
  'ibm_perf_comments_v1', 'ibm_investigate_archive_v1', 'ibm_knowledge_base_v2',
  'admin_pwd_hash', 'ibm_admin_pwd_v1', 'ibm_data_version_v1',
  'ibm_error_log_v1',  // Phase 3: frontend JS error reports
]);

const ALLOWED_PREFIXES = ['ibm_wtracker_', 'ibm_cases_raw_', 'admin-'];

function isKeyAllowed(key) {
  if (!key || typeof key !== 'string') return false;
  const k = key.trim();
  if (!k || k !== key) return false;          // reject leading/trailing whitespace
  if (ALLOWED_KEYS.has(k)) return true;
  return ALLOWED_PREFIXES.some(p => k.startsWith(p));
}

/* ── Rate limiters (express-rate-limit) ───────────────────────── */
// Drop-in replacement for the hand-rolled _rateMap.
// To switch to Redis in production, install `rate-limit-redis` and uncomment:
//   const RedisStore = require('rate-limit-redis');
//   const { createClient } = require('redis');
//   const redisClient = createClient({ url: process.env.REDIS_URL });
//   redisClient.connect();
// Then pass `store: new RedisStore({ sendCommand: (...args) => redisClient.sendCommand(args) })`
// to each limiter below.

const rateLimitOpts = {
  standardHeaders: true,   // Return `RateLimit-*` headers
  legacyHeaders: false,    // Disable `X-RateLimit-*` headers
  message: { ok: false, error: 'Rate limit exceeded. Try again in 1 minute.' },
};

const readLimiter = rateLimit({
  ...rateLimitOpts,
  windowMs: 60 * 1000,
  max: 300,
});

const writeLimiter = rateLimit({
  ...rateLimitOpts,
  windowMs: 60 * 1000,
  max: 60,
});

const authLimiter = rateLimit({
  ...rateLimitOpts,
  windowMs: 60 * 1000,
  max: 10,
});

/* ── Write-auth (admin only operations) ──────────────────────── */
const ADMIN_TOKEN = process.env.IIP_ADMIN_TOKEN || crypto.randomBytes(24).toString('hex');

function requireWriteAuth(req, res, next) {
  const token = req.headers['x-iip-admin-token'];
  if (!token || token !== ADMIN_TOKEN) {
    return res.status(403).json({ ok: false, error: 'Forbidden: invalid or missing admin token.' });
  }
  next();
}

function validateKey(req, res, next) {
  const key = req.params.key;
  if (!key || !isKeyAllowed(key)) {
    return res.status(400).json({ ok: false, error: `Key "${key}" is not in the allowed key list.` });
  }
  next();
}

/* ── Safe JSON parse — handles both raw strings and JSON-encoded values ── */
function safeParseValue(v) {
  if (typeof v !== 'string') return v;
  if (v.startsWith('"') || v.startsWith('{') || v.startsWith('[')) {
    try { return JSON.parse(v); } catch(e) {}
  }
  return v;
}

/* ═══════════════════════════════════════════════════════════════
   AUTH ROUTES  (Phase 2)
   ═══════════════════════════════════════════════════════════════ */

/**
 * POST /api/auth
 * Body: { password: string }
 * Returns: { ok: true, token: string } on success, 401 on failure.
 *
 * Hash stored in DB under key 'admin_pwd_hash'.
 * On first call, migrates legacy plaintext 'ibm_admin_pwd_v1' to bcrypt hash.
 */
app.post('/api/auth', authLimiter, async (req, res) => {
  const { password } = req.body || {};
  if (!password || typeof password !== 'string') {
    return res.status(400).json({ ok: false, error: 'Missing password.' });
  }
  try {
    // Fetch stored hash
    const hashRow = await pool.query("SELECT value FROM iip_kv WHERE key = 'admin_pwd_hash'");
    let hash = hashRow.rows.length ? safeParseValue(hashRow.rows[0].value) : null;

    // Migration: if no hash yet, check legacy plaintext key and hash it now
    if (!hash) {
      const legacyRow = await pool.query("SELECT value FROM iip_kv WHERE key = 'ibm_admin_pwd_v1'");
      if (legacyRow.rows.length) {
        const legacyPwd = safeParseValue(legacyRow.rows[0].value);
        if (typeof legacyPwd === 'string' && legacyPwd.length >= 8) {
          hash = await bcrypt.hash(legacyPwd, 12);
          await pool.query(
            "INSERT INTO iip_kv(key,value,updated_at) VALUES('admin_pwd_hash',$1,NOW()) ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value,updated_at=NOW()",
            [JSON.stringify(hash)]
          );
        }
      }
    }

    if (!hash) {
      return res.status(401).json({ ok: false, error: 'No admin password configured. Set one in the Admin Portal.' });
    }

    const match = await bcrypt.compare(password, hash);
    if (!match) {
      return res.status(401).json({ ok: false, error: 'Incorrect password.' });
    }

    res.json({ ok: true, token: ADMIN_TOKEN });
  } catch(e) {
    log.error({ err: e }, '[IIP-API] /api/auth error');
    res.status(500).json({ ok: false, error: 'Auth failed.' });
  }
});

/**
 * POST /api/auth/set-password
 * Body: { currentPassword: string, newPassword: string }
 * Requires admin token. Hashes new password and stores in DB.
 */
app.post('/api/auth/set-password', authLimiter, requireWriteAuth, async (req, res) => {
  const { currentPassword, newPassword } = req.body || {};
  if (!newPassword || newPassword.length < 8) {
    return res.status(400).json({ ok: false, error: 'New password must be at least 8 characters.' });
  }
  try {
    const hashRow = await pool.query("SELECT value FROM iip_kv WHERE key = 'admin_pwd_hash'");
    if (hashRow.rows.length) {
      const hash = safeParseValue(hashRow.rows[0].value);
      if (currentPassword) {
        const match = await bcrypt.compare(currentPassword, hash);
        if (!match) return res.status(401).json({ ok: false, error: 'Current password incorrect.' });
      }
    }
    const newHash = await bcrypt.hash(newPassword, 12);
    await pool.query(
      "INSERT INTO iip_kv(key,value,updated_at) VALUES('admin_pwd_hash',$1,NOW()) ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value,updated_at=NOW()",
      [JSON.stringify(newHash)]
    );
    // Remove legacy plaintext key if it exists
    await pool.query("DELETE FROM iip_kv WHERE key='ibm_admin_pwd_v1'");
    res.json({ ok: true });
  } catch(e) {
    log.error({ err: e }, '[IIP-API] /api/auth/set-password error');
    res.status(500).json({ ok: false, error: 'Failed to set password.' });
  }
});

/* ═══════════════════════════════════════════════════════════════
   ROUTES
   ═══════════════════════════════════════════════════════════════ */

/* Health check */
app.get('/api/health', readLimiter, async (req, res) => {
  const t0 = Date.now();
  try {
    await pool.query('SELECT 1');
    const dbLatencyMs = Date.now() - t0;
    res.json({
      ok:          true,
      version:     '3.1',
      env:         process.env.NODE_ENV || 'development',
      uptime_s:    Math.floor(process.uptime()),
      db:          'connected',
      db_latency_ms: dbLatencyMs,
      sse_clients: _sseClients.size,
      ts:          new Date().toISOString(),
    });
  } catch (e) {
    log.error({ err: e }, '[IIP-API] /api/health DB check failed');
    res.status(500).json({ ok: false, error: 'Database connection failed', ts: new Date().toISOString() });
  }
});

/* ── SERVER-SENT EVENTS — instant push to all connected browsers ── */
app.get('/api/events', (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no'); // disable nginx buffering
  res.flushHeaders();

  res.write(`event: connected\ndata: {"ts":${Date.now()}}\n\n`);

  _sseClients.add(res);

  const heartbeat = setInterval(() => {
    try { res.write(`: heartbeat\n\n`); } catch(e) { clearInterval(heartbeat); }
  }, 25000);

  req.on('close', () => {
    clearInterval(heartbeat);
    _sseClients.delete(res);
  });
});

/* ── CASES ────────────────────────────────────────────────────── */

/* GET /api/cases — fetch all cases from DB */
app.get('/api/cases', readLimiter, async (req, res) => {
  try {
    const r = await pool.query("SELECT value, updated_at FROM iip_kv WHERE key = 'ibm_cases_raw_v1'");
    if (!r.rows.length || r.rows[0].value === null) {
      return res.json({ cases: null, updatedAt: null });
    }
    res.json({ cases: r.rows[0].value, updatedAt: r.rows[0].updated_at });
  } catch(e) {
    res.status(500).json({ error: 'Failed to fetch cases' });
  }
});

/* POST /api/cases — save cases, broadcast to all users via SSE */
app.post('/api/cases', writeLimiter, requireWriteAuth, async (req, res) => {
  try {
    const { cases } = req.body;
    if (!Array.isArray(cases)) {
      return res.status(400).json({ ok: false, error: 'Body must have a "cases" array.' });
    }
    const versionTs = Date.now();
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      await client.query(
        'INSERT INTO iip_kv (key,value,updated_at) VALUES($1,$2,NOW()) ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value,updated_at=NOW()',
        ['ibm_cases_raw_v1', JSON.stringify(cases)]
      );
      await client.query(
        'INSERT INTO iip_kv (key,value,updated_at) VALUES($1,$2,NOW()) ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value,updated_at=NOW()',
        ['ibm_data_version_v1', JSON.stringify(versionTs)]
      );
      await client.query('COMMIT');
      _broadcast('data-updated', { versionTs, count: cases.length });
      res.json({ ok: true, count: cases.length, versionTs });
    } catch(e) {
      await client.query('ROLLBACK');
      res.status(500).json({ error: 'Failed to save cases' });
    } finally {
      client.release();
    }
  } catch(e) {
    res.status(500).json({ error: 'Failed to save cases' });
  }
});

/* ── Legacy /api/upload-cases (kept for backward compat) ──────── */
app.post('/api/upload-cases', writeLimiter, requireWriteAuth, async (req, res) => {
  req.url = '/api/cases';
  app._router.handle(req, res, () => {});
});

/* ── KV Store endpoints ───────────────────────────────────────── */

app.get('/api/store/:key', readLimiter, validateKey, async (req, res) => {
  try {
    const r = await pool.query('SELECT value FROM iip_kv WHERE key = $1', [req.params.key]);
    res.json({ value: r.rows.length ? r.rows[0].value : null });
  } catch (e) {
    res.status(500).json({ error: 'Failed to read key' });
  }
});

app.post('/api/store/:key', writeLimiter, validateKey, requireWriteAuth, async (req, res) => {
  try {
    const { value } = req.body;
    if (value === undefined) return res.status(400).json({ ok: false, error: 'Missing "value".' });
    await pool.query(
      'INSERT INTO iip_kv (key,value,updated_at) VALUES($1,$2,NOW()) ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value,updated_at=NOW()',
      [req.params.key, JSON.stringify(value)]
    );
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: 'Failed to write key' });
  }
});

app.delete('/api/store/:key', writeLimiter, validateKey, requireWriteAuth, async (req, res) => {
  try {
    await pool.query('DELETE FROM iip_kv WHERE key=$1', [req.params.key]);
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: 'Failed to delete key' });
  }
});

app.get('/api/store', readLimiter, async (req, res) => {
  try {
    const r = await pool.query('SELECT key,updated_at FROM iip_kv ORDER BY updated_at DESC');
    res.json({ keys: r.rows });
  } catch (e) {
    res.status(500).json({ error: 'Failed to list keys' });
  }
});

app.get('/api/store-prefix/:prefix', readLimiter, async (req, res) => {
  const prefix = req.params.prefix;
  if (!ALLOWED_PREFIXES.some(p => prefix.startsWith(p) || p.startsWith(prefix) || prefix === p.replace('_',''))) {
    return res.status(400).json({ ok: false, error: `Prefix "${prefix}" is not allowed.` });
  }
  try {
    const r = await pool.query("SELECT key,value FROM iip_kv WHERE key LIKE $1", [prefix + '%']);
    const entries = {};
    r.rows.forEach(row => { entries[row.key] = row.value; });
    res.json({ entries });
  } catch (e) {
    res.status(500).json({ error: 'Failed to read prefix' });
  }
});

app.post('/api/store-bulk-get', readLimiter, async (req, res) => {
  const { keys } = req.body;
  if (!Array.isArray(keys) || keys.length === 0) {
    return res.status(400).json({ ok: false, error: 'Body must have a "keys" array.' });
  }
  const allowed = keys.filter(isKeyAllowed);
  if (allowed.length === 0) return res.json({ entries: {} });
  try {
    const placeholders = allowed.map((_, i) => `$${i + 1}`).join(',');
    const r = await pool.query(`SELECT key,value FROM iip_kv WHERE key IN (${placeholders})`, allowed);
    const entries = {};
    r.rows.forEach(row => { entries[row.key] = row.value; });
    res.json({ entries });
  } catch (e) {
    res.status(500).json({ error: 'Failed to bulk-get' });
  }
});

app.post('/api/store-bulk-set', writeLimiter, requireWriteAuth, async (req, res) => {
  const { entries } = req.body;
  if (!entries || typeof entries !== 'object') {
    return res.status(400).json({ ok: false, error: 'Body must have an "entries" object.' });
  }
  const pairs = Object.entries(entries).filter(([k]) => isKeyAllowed(k));
  if (pairs.length === 0) return res.json({ ok: true, written: 0 });
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    for (const [key, value] of pairs) {
      await client.query(
        'INSERT INTO iip_kv (key,value,updated_at) VALUES($1,$2,NOW()) ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value,updated_at=NOW()',
        [key, JSON.stringify(value)]
      );
    }
    await client.query('COMMIT');
    res.json({ ok: true, written: pairs.length });
  } catch (e) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: 'Failed to bulk-set' });
  } finally {
    client.release();
  }
});

/* GET /api/config — serve live team config from DB */
app.get('/api/config', readLimiter, async (req, res) => {
  try {
    const r = await pool.query("SELECT value FROM iip_kv WHERE key = 'admin-cfg'");
    if (r.rows.length && r.rows[0].value) {
      res.setHeader('Cache-Control', 'public, max-age=300');
      return res.json({ ok: true, config: r.rows[0].value });
    }
    res.json({ ok: true, config: null });
  } catch(e) {
    res.status(500).json({ error: 'Failed to fetch config' });
  }
});

/* GET /api/team-config — serve team members, emails, config from DB
   Phase 5: replaces the 3.6 MB static app-data.js bundle.
   Reads ibm_team_config_v1 (the dynamic config blob saved by the admin panel)
   and admin-cfg (app-level config). The frontend DynamicConfig module fetches
   this on startup and caches in localStorage, so AppData.js is no longer needed. */
app.get('/api/team-config', readLimiter, async (req, res) => {
  try {
    const keys = ['ibm_team_config_v1', 'admin-cfg'];
    const r = await pool.query(
      'SELECT key, value FROM iip_kv WHERE key = ANY($1)',
      [keys]
    );
    const result = {};
    for (const row of r.rows) {
      try { result[row.key] = typeof row.value === 'string' ? JSON.parse(row.value) : row.value; }
      catch { result[row.key] = row.value; }
    }
    res.setHeader('Cache-Control', 'public, max-age=300');
    res.json({ ok: true, data: result });
  } catch(e) {
    log.error({ err: e }, '[IIP-API] /api/team-config failed');
    res.status(500).json({ ok: false, error: 'Failed to fetch team config' });
  }
});

/* Public write keys — allowed without admin token */
const PUBLIC_WRITE_KEYS = new Set([
  'ibm_rfe_tracking_v1',
  'ibm_rfe_tracking_metadata_v1',
  'ibm_rfe_tracking_last_update',
  'ibm_investigate_archive_v1',
  'ibm_error_log_v1',  // Phase 3: frontend JS error reports (no admin token needed)
]);

app.post('/api/store-public/:key', writeLimiter, async (req, res) => {
  const key = req.params.key;
  if (!PUBLIC_WRITE_KEYS.has(key)) {
    return res.status(403).json({ ok: false, error: `Key "${key}" is not publicly writable.` });
  }
  try {
    const { value } = req.body;
    if (value === undefined) return res.status(400).json({ ok: false, error: 'Missing "value".' });
    await pool.query(
      'INSERT INTO iip_kv (key,value,updated_at) VALUES($1,$2,NOW()) ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value,updated_at=NOW()',
      [key, JSON.stringify(value)]
    );
    res.json({ ok: true });
  } catch(e) {
    res.status(500).json({ error: 'Failed to write key' });
  }
});

app.use((req, res) => res.status(404).json({ ok: false, error: 'Endpoint not found' }));
app.use((err, req, res, _next) => {
  log.error({ err }, '[IIP-API] Unhandled error');
  res.status(500).json({ ok: false, error: 'Internal server error' });
});

/* ── Process-level guards ─────────────────────────────────────── */
process.on('uncaughtException', (err) => {
  log.fatal({ err }, '[IIP-API] uncaughtException — shutting down');
  process.exit(1);
});

process.on('unhandledRejection', (reason) => {
  log.error({ reason }, '[IIP-API] unhandledRejection');
});

/* ── Graceful shutdown ────────────────────────────────────────── */
function shutdown(signal) {
  log.info({ signal }, '[IIP-API] Graceful shutdown initiated');
  server.close(async () => {
    for (const sseRes of _sseClients) { try { sseRes.end(); } catch (_) {} }
    _sseClients.clear();
    log.info('[IIP-API] SSE clients drained');
    try { await pool.end(); log.info('[IIP-API] DB pool released'); }
    catch (e) { log.warn({ err: e }, '[IIP-API] DB pool release error'); }
    log.info('[IIP-API] Shutdown complete');
    process.exit(0);
  });
  setTimeout(() => {
    log.error('[IIP-API] Forced exit after 10 s shutdown timeout');
    process.exit(1);
  }, 10_000).unref();
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT',  () => shutdown('SIGINT'));

/* ── Start ────────────────────────────────────────────────────── */
const PORT = process.env.API_PORT || 3001;
const server = app.listen(PORT, '127.0.0.1', () => {
  log.info({ port: PORT, env: process.env.NODE_ENV || 'development' }, 'IIP API server v3.1 started');
  if (!process.env.IIP_ADMIN_TOKEN) {
    log.warn('[SECURITY] No IIP_ADMIN_TOKEN in .env — ephemeral token in use. Add to .env!');
    log.warn({ token: ADMIN_TOKEN }, 'Ephemeral IIP_ADMIN_TOKEN');
  }
});

module.exports = app; // Required for supertest integration tests
