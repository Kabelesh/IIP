/* ================================================================
   pm2 ecosystem.config.js — IIP API Server
   ----------------------------------------------------------------
   Usage:
     pm2 start ecosystem.config.js              # start with current NODE_ENV
     pm2 start ecosystem.config.js --env prod   # force production profile
     pm2 restart iip-api --update-env           # reload after .env change
     pm2 logs iip-api                           # tail live logs
     pm2 monit                                  # interactive monitor
     pm2 save && pm2 startup                    # survive reboots (run as root)
   ================================================================ */

module.exports = {
  apps: [
    {
      /* ── Identity ───────────────────────────────────────────── */
      name:             'iip-api',
      script:           'server.js',
      cwd:              __dirname,

      /* ── Concurrency ────────────────────────────────────────── */
      // Fork mode — single process.
      // Switch to cluster mode only after replacing the in-memory rate
      // limiter with rate-limit-redis (Phase 4), otherwise each worker
      // maintains its own counter Map and limits won't hold cluster-wide.
      instances:        1,
      exec_mode:        'fork',

      /* ── Memory guard ───────────────────────────────────────── */
      // Restart if heap exceeds 400 MB (tune to your RHEL9 allocation)
      max_memory_restart: '400M',

      /* ── Restart policy ─────────────────────────────────────── */
      // Exponential back-off: 100 ms, 200 ms, 400 ms … up to 10 s
      restart_delay:    100,
      exp_backoff_restart_delay: 100,
      max_restarts:     10,     // give up after 10 rapid failures
      min_uptime:       '5s',   // must stay up 5 s to count as healthy

      /* ── Graceful reload ────────────────────────────────────── */
      // server.js handles SIGINT → drains SSE, releases pool, exits 0
      kill_timeout:     12000,  // ms before pm2 force-kills (> our 10 s guard)
      wait_ready:       false,  // set true and emit process.send('ready') if needed

      /* ── Logging ────────────────────────────────────────────── */
      // Pino writes structured JSON to stdout; pm2 captures it here.
      // Feed out_file into a log shipper (Filebeat, Fluentd) for ELK.
      out_file:         '/var/log/iip/iip-api.out.log',
      error_file:       '/var/log/iip/iip-api.err.log',
      merge_logs:       true,   // combine stdout+stderr into one stream
      log_date_format:  '',     // pino already stamps every line with ISO ts

      /* ── Rotation ───────────────────────────────────────────── */
      // Requires: pm2 install pm2-logrotate
      // Configure via: pm2 set pm2-logrotate:max_size 50M
      //                pm2 set pm2-logrotate:retain 14

      /* ── Watch ──────────────────────────────────────────────── */
      // Disabled in production — use pm2 restart/reload instead.
      watch:            false,

      /* ── Environment profiles ───────────────────────────────── */
      // Default profile (development / staging)
      env: {
        NODE_ENV:  'development',
        LOG_LEVEL: 'debug',
      },

      // Production profile — activate with: pm2 start ... --env prod
      env_prod: {
        NODE_ENV:  'production',
        LOG_LEVEL: 'info',
      },
    },
  ],
};
