/* ================================================================
   backend/server.test.js  —  IIP API Unit + Integration Tests
   ----------------------------------------------------------------
   Run:  npm test
   Coverage: npm run test:coverage

   Strategy:
   - Pure-logic functions (isKeyAllowed, safeParseValue) are tested
     by extracting them from the module via a lightweight re-export
     shim so we never actually start the HTTP server or connect to DB.
   - Middleware (rateLimit, validateKey, requireWriteAuth) is tested
     with hand-crafted mock req/res/next objects — no Supertest needed.
   - HTTP integration (health, auth, store, cases, store-public) uses
     Supertest against a fully mocked DB pool, so tests run offline
     with no real PostgreSQL.
   ================================================================ */

'use strict';

/* ── 1. Inline re-implementations of pure helpers ──────────────
   We copy the exact logic from server.js so tests never import the
   server (which would try to pool.connect() on load).  When the
   server logic changes the tests will catch drift immediately.    */

// ── isKeyAllowed ─────────────────────────────────────────────────
const ALLOWED_KEYS = new Set([
  'ibm_cases_raw_v1', 'ibm_cases_overrides_v1', 'ibm_reopened_cases_v1',
  'ibm_import_log_v1', 'ibm_tracker_persist_v1', 'ibm_team_config_v1',
  'ibm_team_config_v1_cache', 'ibm_wtracker_comments_v1', 'ibm_wtracker_history',
  'ibm_wtracker_linkmap_v1', 'ibm_wtracker_seeded_v5', 'ibm_wtracker_seed_v1',
  'ibm_rfe_tracking_v1', 'ibm_rfe_tracking_metadata_v1', 'ibm_rfe_tracking_last_update',
  'ibm_perf_comments_v1', 'ibm_investigate_archive_v1', 'ibm_knowledge_base_v2',
  'admin_pwd_hash', 'ibm_admin_pwd_v1', 'ibm_data_version_v1',
  'ibm_error_log_v1',
]);

const ALLOWED_PREFIXES = ['ibm_wtracker_', 'ibm_cases_raw_', 'admin-'];

function isKeyAllowed(key) {
  if (!key || typeof key !== 'string') return false;
  const k = key.trim();
  if (!k || k !== key) return false;          // reject leading/trailing whitespace
  if (ALLOWED_KEYS.has(k)) return true;
  return ALLOWED_PREFIXES.some(p => k.startsWith(p));
}

// ── safeParseValue ───────────────────────────────────────────────
function safeParseValue(v) {
  if (typeof v !== 'string') return v;
  if (v.startsWith('"') || v.startsWith('{') || v.startsWith('[')) {
    try { return JSON.parse(v); } catch (e) { /* fall through */ }
  }
  return v;
}

// ── rateLimit factory (same logic as server.js) ──────────────────
function makeRateLimit() {
  const _rateMap = new Map();
  const RATE_WINDOW_MS = 60 * 1000;

  return function rateLimit(limit) {
    return (req, res, next) => {
      const ip  = req.ip || (req.connection && req.connection.remoteAddress) || '127.0.0.1';
      const key = ip + ':' + limit;
      const now = Date.now();
      let entry = _rateMap.get(key);
      if (!entry || now - entry.start > RATE_WINDOW_MS) {
        entry = { start: now, count: 0 };
        _rateMap.set(key, entry);
      }
      entry.count++;
      if (entry.count > limit) {
        return res.status(429).json({ ok: false, error: 'Rate limit exceeded. Try again in 1 minute.' });
      }
      next();
    };
  };
}

// ── requireWriteAuth (same logic as server.js) ───────────────────
const TEST_ADMIN_TOKEN = 'test-admin-token-abc123';

function requireWriteAuth(req, res, next) {
  const token = req.headers['x-iip-admin-token'];
  if (!token || token !== TEST_ADMIN_TOKEN) {
    return res.status(403).json({ ok: false, error: 'Forbidden: invalid or missing admin token.' });
  }
  next();
}

// ── validateKey (same logic as server.js) ────────────────────────
function validateKey(req, res, next) {
  const key = req.params && req.params.key;
  if (!key || !isKeyAllowed(key)) {
    return res.status(400).json({ ok: false, error: `Key "${key}" is not in the allowed key list.` });
  }
  next();
}

/* ── Helpers ────────────────────────────────────────────────────── */
function mockRes() {
  const res = {
    _status: 200,
    _body:   null,
    status(code) { this._status = code; return this; },
    json(body)   { this._body   = body; return this; },
  };
  return res;
}

function mockReq(overrides = {}) {
  return { ip: '127.0.0.1', headers: {}, params: {}, body: {}, ...overrides };
}

/* ════════════════════════════════════════════════════════════════
   TEST SUITES
   ════════════════════════════════════════════════════════════════ */

describe('isKeyAllowed()', () => {

  describe('falsy / empty inputs', () => {
    test('returns false for null',      () => expect(isKeyAllowed(null)).toBe(false));
    test('returns false for undefined', () => expect(isKeyAllowed(undefined)).toBe(false));
    test('returns false for ""',        () => expect(isKeyAllowed('')).toBe(false));
    test('returns false for 0',         () => expect(isKeyAllowed(0)).toBe(false));
  });

  describe('exact allowlist hits', () => {
    test('ibm_cases_raw_v1',        () => expect(isKeyAllowed('ibm_cases_raw_v1')).toBe(true));
    test('ibm_team_config_v1',      () => expect(isKeyAllowed('ibm_team_config_v1')).toBe(true));
    test('ibm_knowledge_base_v2',   () => expect(isKeyAllowed('ibm_knowledge_base_v2')).toBe(true));
    test('admin_pwd_hash',          () => expect(isKeyAllowed('admin_pwd_hash')).toBe(true));
    test('ibm_error_log_v1',        () => expect(isKeyAllowed('ibm_error_log_v1')).toBe(true));
    test('ibm_investigate_archive_v1', () => expect(isKeyAllowed('ibm_investigate_archive_v1')).toBe(true));
    test('ibm_data_version_v1',     () => expect(isKeyAllowed('ibm_data_version_v1')).toBe(true));
  });

  describe('prefix hits', () => {
    test('ibm_wtracker_ prefix',     () => expect(isKeyAllowed('ibm_wtracker_anything_v99')).toBe(true));
    test('ibm_cases_raw_ prefix',    () => expect(isKeyAllowed('ibm_cases_raw_2026_01')).toBe(true));
    test('admin- prefix',            () => expect(isKeyAllowed('admin-cfg')).toBe(true));
    test('admin- prefix long key',   () => expect(isKeyAllowed('admin-some-long-key')).toBe(true));
  });

  describe('rejections', () => {
    test('unknown key',              () => expect(isKeyAllowed('totally_random_key')).toBe(false));
    test('partial prefix no dash',   () => expect(isKeyAllowed('adminconfig')).toBe(false));
    test('SQL injection attempt',    () => expect(isKeyAllowed("'; DROP TABLE iip_kv; --")).toBe(false));
    test('path traversal attempt',   () => expect(isKeyAllowed('../etc/passwd')).toBe(false));
    test('ibm_ without full prefix', () => expect(isKeyAllowed('ibm_random_v1')).toBe(false));
    test('mixed case variant',       () => expect(isKeyAllowed('IBM_CASES_RAW_V1')).toBe(false));
    test('trailing whitespace',      () => expect(isKeyAllowed('ibm_cases_raw_v1 ')).toBe(false));
    test('leading whitespace',       () => expect(isKeyAllowed(' ibm_cases_raw_v1')).toBe(false));
    test('tab character in key',     () => expect(isKeyAllowed('ibm_cases_raw_v1\t')).toBe(false));
  });

  describe('all 21 ALLOWED_KEYS are individually allowed', () => {
    for (const key of ALLOWED_KEYS) {
      test(key, () => expect(isKeyAllowed(key)).toBe(true));
    }
  });
});

/* ────────────────────────────────────────────────────────────── */

describe('safeParseValue()', () => {

  test('returns non-string values unchanged (number)',  () => expect(safeParseValue(42)).toBe(42));
  test('returns non-string values unchanged (null)',    () => expect(safeParseValue(null)).toBeNull());
  test('returns non-string values unchanged (object)', () => {
    const obj = { a: 1 };
    expect(safeParseValue(obj)).toBe(obj);
  });

  test('parses JSON string → object', () =>
    expect(safeParseValue('{"key":"val"}')).toEqual({ key: 'val' }));

  test('parses JSON array string → array', () =>
    expect(safeParseValue('[1,2,3]')).toEqual([1, 2, 3]));

  test('parses quoted JSON string → string value', () =>
    expect(safeParseValue('"hello"')).toBe('hello'));

  test('returns raw string if not JSON-prefixed', () =>
    expect(safeParseValue('plaintext')).toBe('plaintext'));

  test('returns raw string on malformed JSON', () =>
    expect(safeParseValue('{bad json')).toBe('{bad json'));

  test('returns raw string on malformed array', () =>
    expect(safeParseValue('[1,2,')).toBe('[1,2,'));

  test('returns empty string unchanged', () =>
    expect(safeParseValue('')).toBe(''));
});

/* ────────────────────────────────────────────────────────────── */

describe('rateLimit() middleware', () => {
  let rateLimit;

  beforeEach(() => {
    // Fresh _rateMap for each test — no bleed between tests
    rateLimit = makeRateLimit();
  });

  test('passes through under the limit', () => {
    const mid  = rateLimit(5);
    const next  = jest.fn();
    const res   = mockRes();
    for (let i = 0; i < 5; i++) {
      mid(mockReq(), res, next);
    }
    expect(next).toHaveBeenCalledTimes(5);
    expect(res._status).toBe(200); // never touched
  });

  test('blocks at count > limit (not >=)', () => {
    const mid  = rateLimit(3);
    const next  = jest.fn();

    // 3 allowed
    for (let i = 0; i < 3; i++) mid(mockReq(), mockRes(), next);
    expect(next).toHaveBeenCalledTimes(3);

    // 4th must be blocked
    const res4 = mockRes();
    mid(mockReq(), res4, next);
    expect(res4._status).toBe(429);
    expect(res4._body.ok).toBe(false);
    expect(res4._body.error).toMatch(/rate limit/i);
    expect(next).toHaveBeenCalledTimes(3); // not called again
  });

  test('different IPs have independent counters', () => {
    const mid   = rateLimit(2);
    const next   = jest.fn();

    mid(mockReq({ ip: '10.0.0.1' }), mockRes(), next);
    mid(mockReq({ ip: '10.0.0.1' }), mockRes(), next);

    const res3 = mockRes();
    mid(mockReq({ ip: '10.0.0.1' }), res3, next); // 3rd from same IP → blocked
    expect(res3._status).toBe(429);

    const resB = mockRes();
    mid(mockReq({ ip: '10.0.0.2' }), resB, next); // 1st from different IP → allowed
    expect(resB._status).toBe(200);
    expect(next).toHaveBeenCalledTimes(3); // 2 from IP1 + 1 from IP2
  });

  test('falls back to connection.remoteAddress when req.ip is absent', () => {
    const mid  = rateLimit(2);
    const next  = jest.fn();
    const req   = { headers: {}, params: {}, body: {}, connection: { remoteAddress: '192.168.1.5' } };
    mid(req, mockRes(), next);
    expect(next).toHaveBeenCalledTimes(1);
  });
});

/* ────────────────────────────────────────────────────────────── */

describe('requireWriteAuth() middleware', () => {

  test('calls next() with correct token', () => {
    const next = jest.fn();
    const req  = mockReq({ headers: { 'x-iip-admin-token': TEST_ADMIN_TOKEN } });
    requireWriteAuth(req, mockRes(), next);
    expect(next).toHaveBeenCalledTimes(1);
  });

  test('returns 403 with no token', () => {
    const next = jest.fn();
    const res  = mockRes();
    requireWriteAuth(mockReq(), res, next);
    expect(res._status).toBe(403);
    expect(res._body.ok).toBe(false);
    expect(next).not.toHaveBeenCalled();
  });

  test('returns 403 with wrong token', () => {
    const next = jest.fn();
    const res  = mockRes();
    const req  = mockReq({ headers: { 'x-iip-admin-token': 'wrong-token' } });
    requireWriteAuth(req, res, next);
    expect(res._status).toBe(403);
    expect(next).not.toHaveBeenCalled();
  });

  test('returns 403 with empty string token', () => {
    const next = jest.fn();
    const res  = mockRes();
    const req  = mockReq({ headers: { 'x-iip-admin-token': '' } });
    requireWriteAuth(req, res, next);
    expect(res._status).toBe(403);
    expect(next).not.toHaveBeenCalled();
  });

  test('is case-sensitive — partial match is rejected', () => {
    const next = jest.fn();
    const res  = mockRes();
    const req  = mockReq({ headers: { 'x-iip-admin-token': TEST_ADMIN_TOKEN.slice(0, 10) } });
    requireWriteAuth(req, res, next);
    expect(res._status).toBe(403);
  });
});

/* ────────────────────────────────────────────────────────────── */

describe('validateKey() middleware', () => {

  test('calls next() for a valid key', () => {
    const next = jest.fn();
    const req  = mockReq({ params: { key: 'ibm_cases_raw_v1' } });
    validateKey(req, mockRes(), next);
    expect(next).toHaveBeenCalledTimes(1);
  });

  test('calls next() for a valid prefix key', () => {
    const next = jest.fn();
    const req  = mockReq({ params: { key: 'admin-cfg' } });
    validateKey(req, mockRes(), next);
    expect(next).toHaveBeenCalledTimes(1);
  });

  test('returns 400 for an unknown key', () => {
    const next = jest.fn();
    const res  = mockRes();
    const req  = mockReq({ params: { key: 'evil_key' } });
    validateKey(req, res, next);
    expect(res._status).toBe(400);
    expect(res._body.ok).toBe(false);
    expect(res._body.error).toMatch(/not in the allowed key list/);
    expect(next).not.toHaveBeenCalled();
  });

  test('returns 400 when key param is missing', () => {
    const next = jest.fn();
    const res  = mockRes();
    validateKey(mockReq({ params: {} }), res, next);
    expect(res._status).toBe(400);
    expect(next).not.toHaveBeenCalled();
  });

  test('returns 400 for SQL injection in key', () => {
    const next = jest.fn();
    const res  = mockRes();
    const req  = mockReq({ params: { key: "'; DROP TABLE iip_kv; --" } });
    validateKey(req, res, next);
    expect(res._status).toBe(400);
  });
});

/* ────────────────────────────────────────────────────────────── */

describe('PUBLIC_WRITE_KEYS contract', () => {
  // These keys must stay publicly writable — changing them breaks the frontend
  const REQUIRED_PUBLIC_KEYS = [
    'ibm_rfe_tracking_v1',
    'ibm_rfe_tracking_metadata_v1',
    'ibm_rfe_tracking_last_update',
    'ibm_investigate_archive_v1',
    'ibm_error_log_v1',
  ];

  // We verify via isKeyAllowed (all public keys must also be in ALLOWED_KEYS)
  for (const key of REQUIRED_PUBLIC_KEYS) {
    test(`"${key}" is in ALLOWED_KEYS`, () => {
      expect(isKeyAllowed(key)).toBe(true);
    });
  }
});

/* ────────────────────────────────────────────────────────────── */

describe('HTTP integration — /api/health', () => {
  let app, request;

  beforeAll(async () => {
    // Stub pg Pool before requiring server
    jest.resetModules();
    jest.mock('pg', () => {
      const query = jest.fn().mockResolvedValue({ rows: [{ '?column?': 1 }] });
      const connect = jest.fn().mockResolvedValue({ query, release: jest.fn() });
      return { Pool: jest.fn(() => ({ query, connect, end: jest.fn() })) };
    });

    // Set required env vars
    process.env.DB_HOST     = 'localhost';
    process.env.DB_PORT     = '5432';
    process.env.DB_NAME     = 'iip_db';
    process.env.DB_USER     = 'iip_user';
    process.env.DB_PASSWORD = 'test';
    process.env.IIP_ADMIN_TOKEN = TEST_ADMIN_TOKEN;
    process.env.NODE_ENV    = 'test';

    // Require supertest lazily (installed as devDependency)
    request = require('supertest');
    const mod = require('./server');
    app = mod;
  });

  afterAll(() => jest.resetModules());

  test('GET /api/health → 200 with expected shape', async () => {
    const res = await request(app).get('/api/health');
    expect(res.status).toBe(200);
    expect(res.body.ok).toBe(true);
    expect(res.body.version).toBe('3.1');
    expect(typeof res.body.uptime_s).toBe('number');
    expect(res.body.db).toBe('connected');
    expect(typeof res.body.db_latency_ms).toBe('number');
    expect(typeof res.body.ts).toBe('string');
  });

  test('GET /api/nonexistent → 404', async () => {
    const res = await request(app).get('/api/nonexistent');
    expect(res.status).toBe(404);
    expect(res.body.ok).toBe(false);
  });
});

/* ────────────────────────────────────────────────────────────── */

describe('HTTP integration — /api/store/:key (auth + key validation)', () => {
  let app, request, mockPool;

  beforeAll(async () => {
    jest.resetModules();
    mockPool = {
      query:   jest.fn().mockResolvedValue({ rows: [] }),
      connect: jest.fn().mockResolvedValue({ query: jest.fn().mockResolvedValue({ rows: [] }), release: jest.fn() }),
      end:     jest.fn(),
    };
    jest.mock('pg', () => ({ Pool: jest.fn(() => mockPool) }));

    process.env.IIP_ADMIN_TOKEN = TEST_ADMIN_TOKEN;
    process.env.NODE_ENV = 'test';
    request = require('supertest');
    app = require('./server');
  });

  afterAll(() => jest.resetModules());

  test('GET /api/store/ibm_cases_raw_v1 → 200 (no auth needed)', async () => {
    mockPool.query.mockResolvedValueOnce({ rows: [{ value: { data: 'test' } }] });
    const res = await request(app).get('/api/store/ibm_cases_raw_v1');
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty('value');
  });

  test('GET /api/store/evil_key → 400 invalid key', async () => {
    const res = await request(app).get('/api/store/evil_key');
    expect(res.status).toBe(400);
    expect(res.body.ok).toBe(false);
  });

  test('POST /api/store/ibm_cases_raw_v1 without token → 403', async () => {
    const res = await request(app)
      .post('/api/store/ibm_cases_raw_v1')
      .send({ value: { test: true } });
    expect(res.status).toBe(403);
    expect(res.body.ok).toBe(false);
  });

  test('POST /api/store/ibm_cases_raw_v1 with valid token → 200', async () => {
    mockPool.query.mockResolvedValueOnce({ rows: [] });
    const res = await request(app)
      .post('/api/store/ibm_cases_raw_v1')
      .set('x-iip-admin-token', TEST_ADMIN_TOKEN)
      .send({ value: { test: true } });
    expect(res.status).toBe(200);
    expect(res.body.ok).toBe(true);
  });

  test('POST /api/store/ibm_cases_raw_v1 with missing value body → 400', async () => {
    const res = await request(app)
      .post('/api/store/ibm_cases_raw_v1')
      .set('x-iip-admin-token', TEST_ADMIN_TOKEN)
      .send({});
    expect(res.status).toBe(400);
  });

  test('DELETE /api/store/ibm_cases_raw_v1 without token → 403', async () => {
    const res = await request(app).delete('/api/store/ibm_cases_raw_v1');
    expect(res.status).toBe(403);
  });

  test('DELETE /api/store/ibm_cases_raw_v1 with valid token → 200', async () => {
    mockPool.query.mockResolvedValueOnce({ rows: [] });
    const res = await request(app)
      .delete('/api/store/ibm_cases_raw_v1')
      .set('x-iip-admin-token', TEST_ADMIN_TOKEN);
    expect(res.status).toBe(200);
    expect(res.body.ok).toBe(true);
  });
});

/* ────────────────────────────────────────────────────────────── */

describe('HTTP integration — /api/store-public/:key', () => {
  let app, request, mockPool;

  beforeAll(async () => {
    jest.resetModules();
    mockPool = {
      query:   jest.fn().mockResolvedValue({ rows: [] }),
      connect: jest.fn(),
      end:     jest.fn(),
    };
    jest.mock('pg', () => ({ Pool: jest.fn(() => mockPool) }));
    process.env.IIP_ADMIN_TOKEN = TEST_ADMIN_TOKEN;
    process.env.NODE_ENV = 'test';
    request = require('supertest');
    app = require('./server');
  });

  afterAll(() => jest.resetModules());

  test('POST /api/store-public/ibm_error_log_v1 without auth token → 200', async () => {
    const res = await request(app)
      .post('/api/store-public/ibm_error_log_v1')
      .send({ value: [{ msg: 'test error', ts: Date.now() }] });
    expect(res.status).toBe(200);
    expect(res.body.ok).toBe(true);
  });

  test('POST /api/store-public/ibm_rfe_tracking_v1 → 200', async () => {
    const res = await request(app)
      .post('/api/store-public/ibm_rfe_tracking_v1')
      .send({ value: {} });
    expect(res.status).toBe(200);
  });

  test('POST /api/store-public/private_secret_key → 403', async () => {
    const res = await request(app)
      .post('/api/store-public/private_secret_key')
      .send({ value: {} });
    expect(res.status).toBe(403);
    expect(res.body.ok).toBe(false);
  });

  test('POST /api/store-public/admin_pwd_hash → 403 (not publicly writable)', async () => {
    const res = await request(app)
      .post('/api/store-public/admin_pwd_hash')
      .send({ value: 'hacked' });
    expect(res.status).toBe(403);
  });

  test('POST /api/store-public/ibm_error_log_v1 with missing value → 400', async () => {
    const res = await request(app)
      .post('/api/store-public/ibm_error_log_v1')
      .send({});
    expect(res.status).toBe(400);
  });
});

/* ────────────────────────────────────────────────────────────── */

describe('HTTP integration — /api/auth', () => {
  let app, request, mockPool;

  beforeAll(async () => {
    jest.resetModules();
    const bcrypt = require('bcryptjs');
    const correctHash = await bcrypt.hash('CorrectPass1!', 12);

    mockPool = {
      query: jest.fn().mockImplementation((sql) => {
        if (sql.includes("'admin_pwd_hash'"))  return Promise.resolve({ rows: [{ value: JSON.stringify(correctHash) }] });
        if (sql.includes("'ibm_admin_pwd_v1'")) return Promise.resolve({ rows: [] });
        return Promise.resolve({ rows: [] });
      }),
      connect: jest.fn(),
      end: jest.fn(),
    };
    jest.mock('pg', () => ({ Pool: jest.fn(() => mockPool) }));
    process.env.IIP_ADMIN_TOKEN = TEST_ADMIN_TOKEN;
    process.env.NODE_ENV = 'test';
    request = require('supertest');
    app = require('./server');
  });

  afterAll(() => jest.resetModules());

  test('POST /api/auth with correct password → 200 + token', async () => {
    const res = await request(app)
      .post('/api/auth')
      .send({ password: 'CorrectPass1!' });
    expect(res.status).toBe(200);
    expect(res.body.ok).toBe(true);
    expect(res.body.token).toBe(TEST_ADMIN_TOKEN);
  });

  test('POST /api/auth with wrong password → 401', async () => {
    const res = await request(app)
      .post('/api/auth')
      .send({ password: 'WrongPassword' });
    expect(res.status).toBe(401);
    expect(res.body.ok).toBe(false);
  });

  test('POST /api/auth with no body → 400', async () => {
    const res = await request(app)
      .post('/api/auth')
      .send({});
    expect(res.status).toBe(400);
  });
});
