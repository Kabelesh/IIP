-- ================================================================
-- schema/001_initial.sql — IIP Database Schema
-- Migration: 001 · Initial schema (iip_kv table + indexes)
-- Target DB:  iip_db (PostgreSQL 14+)
-- Run as:     psql -U iip_user -d iip_db -f 001_initial.sql
-- Idempotent: yes — all statements use IF NOT EXISTS / OR REPLACE
-- ================================================================

-- ── Migration bookkeeping ──────────────────────────────────────
-- A lightweight migrations table lets you track which SQL files
-- have been applied. Future migrations (002_add_audit_log.sql etc.)
-- should insert a row here when they run.
CREATE TABLE IF NOT EXISTS schema_migrations (
  version     TEXT        NOT NULL PRIMARY KEY,   -- e.g. '001_initial'
  applied_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  description TEXT
);

-- Skip this migration if it has already been applied.
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM schema_migrations WHERE version = '001_initial'
  ) THEN
    RAISE NOTICE 'Migration 001_initial already applied — skipping.';
    RETURN;
  END IF;

  -- ── Core KV store ───────────────────────────────────────────
  -- iip_kv is the single persistent store for the entire IIP platform.
  -- Keys are application-defined strings (see ALLOWED_KEYS in server.js).
  -- Values are stored as JSONB so PostgreSQL can index inside them if needed.
  CREATE TABLE IF NOT EXISTS iip_kv (
    key         TEXT        NOT NULL PRIMARY KEY,
    value       JSONB       NOT NULL,
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  -- Index for time-based queries (e.g. "what changed since X?")
  CREATE INDEX IF NOT EXISTS iip_kv_updated_at_idx
    ON iip_kv (updated_at DESC);

  -- ── Application user (least-privilege) ──────────────────────
  -- The API connects as iip_user. Grant only what it needs.
  -- Run this block as a superuser if iip_user doesn't exist yet.
  -- (Wrapped in a DO block so it's a no-op if already granted.)
  -- NOTE: create the role outside this script if it doesn't exist:
  --   CREATE ROLE iip_user LOGIN PASSWORD 'CHANGE_ME';
  DO $grant$
  BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'iip_user') THEN
      GRANT CONNECT ON DATABASE iip_db TO iip_user;
      GRANT USAGE   ON SCHEMA  public  TO iip_user;
      GRANT SELECT, INSERT, UPDATE, DELETE
        ON TABLE iip_kv, schema_migrations TO iip_user;
    END IF;
  END $grant$;

  -- ── Record this migration ────────────────────────────────────
  INSERT INTO schema_migrations (version, description)
  VALUES ('001_initial', 'iip_kv table + updated_at index');

  RAISE NOTICE 'Migration 001_initial applied successfully.';
END $$;


-- ================================================================
-- RESTORE PROCEDURE
-- ================================================================
--
-- Full backup (run from the DB server or any host with pg_dump):
--
--   pg_dump \
--     --host=localhost --port=5432 \
--     --username=iip_user \
--     --format=custom \          # compressed, supports parallel restore
--     --file=/var/backups/iip/iip_db_$(date +%Y%m%d_%H%M%S).dump \
--     iip_db
--
-- Restore:
--
--   pg_restore \
--     --host=localhost --port=5432 \
--     --username=iip_user \
--     --dbname=iip_db \
--     --no-owner --no-privileges \
--     /var/backups/iip/iip_db_20260323_020000.dump
--
-- Point-in-time restore requires WAL archiving — enable in postgresql.conf:
--   archive_mode = on
--   archive_command = 'cp %p /var/backups/iip/wal/%f'
--
-- ================================================================
-- CRON BACKUP TEMPLATE (add to crontab -e as iip_user or root)
-- ================================================================
--
--   # Daily full backup at 02:00, keep 14 days
--   0 2 * * * pg_dump \
--     --username=iip_user --format=custom \
--     --file=/var/backups/iip/iip_db_$(date +\%Y\%m\%d_\%H\%M\%S).dump \
--     iip_db \
--     && find /var/backups/iip -name "iip_db_*.dump" -mtime +14 -delete
--
-- Verify the backup is readable:
--   pg_restore --list /var/backups/iip/iip_db_YYYYMMDD_HHmmss.dump | head -20
--
-- ================================================================
