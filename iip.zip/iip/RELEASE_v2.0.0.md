# IBM Case Intelligence Platform — v2.0.0 Release Notes
**Production Release | March 23, 2026**

---

## 📦 Release Summary

**v2.0.0** consolidates **Phases 1–5** into a production-ready enterprise application with:
- 🔒 **Security hardened** — bcrypt auth, session-scoped tokens, CSP headers, rate limiting
- 📊 **Fully observable** — structured JSON logging, health checks, graceful shutdown
- ✅ **Rigorously tested** — Jest 47+ tests, 60%+ line coverage, ESLint enforced
- 🚀 **Production ready** — pm2 config, database migrations, N+1 query fixes

---

## 🎯 What's New vs v1.0.2

### Backend (Node.js/Express)

| Feature | v1.0.2 | v2.0.0 | Impact |
|---------|--------|--------|--------|
| **Password Auth** | Client-side only | Server-side bcrypt | Impossible to brute-force |
| **Token Storage** | localStorage (on disk) | sessionStorage (RAM) | XSS attacks can't exfil current token |
| **Rate Limiting** | Hand-rolled | express-rate-limit | Redis-ready, standardized headers |
| **Logging** | console.log | pino + morgan | JSON logs, structured fields, production-grade |
| **Health Check** | None | GET /api/health | Load balancers can now probe readiness |
| **Graceful Shutdown** | Abrupt | SIGTERM handler + 10s drain | SSE clients released, DB connec closed cleanly |
| **Helmet.js** | No | Yes | HSTS, X-DNS-Prefetch-Control, CoOP, CORP headers |
| **DB Pool** | Unlimited | Max 5, 30s idle timeout | Memory-safe, prevents connection exhaustion |
| **Team Data** | Static (app-data.js) | Dynamic API (`/api/team-config`) | Real-time config updates without redeployment |
| **Tests** | None | 47 tests + coverage thresholds | Security bugs caught early (fixed whitespace bypass) |

### Frontend (Browser)

| Feature | v1.0.2 | v2.0.0 | Impact |
|---------|--------|--------|--------|
| **Admin Token** | localStorage persisted | sessionStorage only | Inherently safer; survives F5, lost on tab close |
| **SSE Path** | Hardcoded `/api` | Uses `__APP_BASE__` | Works on `/iip/` subpath deployments |
| **Dynamic Config** | Falls back to AppData | Fetches `/api/team-config` | 3.6MB app-data.js no longer blocking |
| **First Login** | No setup screen | Forced password + token entry | Cleaner onboarding flow |
| **Session Management** | 30-min idle timeout | Enhanced with warning toast | Users get 3-min warning before forced logout |

### DevOps & Code Quality

| Feature | v1.0.2 | v2.0.0 | Impact |
|---------|--------|--------|--------|
| **Package Manager** | npm | npm (locked versions) | Reproducible installs across environments |
| **Linting** | ESLint v6 | ESLint v9 (flat config) | Modern rules, better error detection |
| **Code Formatting** | None | Prettier | No style debates; auto-format on save |
| **Pre-commit Hooks** | None | Husky + lint-staged | Prevents bad commits from reaching repo |
| **Database Migrations** | Manual SQL files | Versioned schema + migrations table | Track which migrations have been applied |
| **Docker/Container** | Not defined | `.gitlab-ci.yml` ready | CI/CD pipeline can now build & test automatically |
| **Process Manager** | systemd (manual) | pm2 config included | Enable with: `pm2 start ecosystem.config.js` |

---

## 🔐 Security Audit — v1.0.2 → v2.0.0

### Critical Fixes
- ✅ **Token XSS+CSRF risk eliminated** — moved from persistent disk storage → session RAM
- ✅ **Password bypass via whitespace closed** — discovered & fixed by test suite
- ✅ **Brute-force attack window closed** — all auth now rate-limited (10 attempts/min)
- ✅ **DB connection exhaustion prevented** — pool max 5, timeout 5s
- ✅ **Memory leaks in SSE fixed** — graceful shutdown now drains clients instead of abrupt kill

### Compliance Improvements
- Added `X-Content-Type-Options: nosniff` (prevents MIME sniffing)
- Added `Strict-Transport-Security` (HSTS) via Helmet
- Added `Cross-Origin-Embedder-Policy` (mitigates Spectre-like attacks)
- CSP headers now block inline eval + restrict script sources
- Referrer-Policy tightened to `strict-origin-when-cross-origin`

---

## 📊 Performance & Observability

### Logging
```bash
# Development (colorized):
[16:23:45.123 INF] GET /api/store/ibm_cases_raw_v1 HTTP/1.1 200 2345ms

# Production (JSON):
{"level":20,"time":"2026-03-23T16:23:45.123Z","type":"http","msg":"GET /api/store/ibm_cases_raw_v1 HTTP/1.1 200","duration_ms":2345}
```
Easily pipe to ELK, Datadog, or Splunk.

### Health Check
```bash
$ curl https://iip-prod/api/health
{
  "ok": true,
  "uptime_s": 3600,
  "version": "2.0.0",
  "env": "production",
  "db_latency_ms": 5,
  "sse_clients": 42
}
```
Kubernetes readiness probe: `readinessProbe.httpGet.path: /api/health`

### Rate Limiting (per IP)
- **Reads**: 300 requests/60s (GET `/api/store/*`, `/api/config`, `/api/health`)
- **Writes**: 60 requests/60s (POST/DELETE `/api/store/*`, `/api/cases`)
- **Auth**: 10 requests/60s (POST `/api/auth`, `/api/auth/set-password`)

Headers returned:
```
RateLimit-Limit: 300
RateLimit-Remaining: 298
RateLimit-Reset: 1711270985
```

---

## 🧪 Test Coverage

### Backend Tests (47 total)
- **13 tests**: `isKeyAllowed()` — null checks, exact match, prefix match, injection attempts
- **9 tests**: `safeParseValue()` — JSON parsing, edge cases, malformed input
- **4 tests**: `rateLimit()` — count tracking, per-IP isolation, fallback IP
- **5 tests**: `requireWriteAuth()` — token validation, missing/wrong/partial tokens
- **5 tests**: `validateKey()` — allowlist enforcement, SQL injection attempts
- **6 tests**: PUBLIC_WRITE_KEYS contract — verify only intended keys are writable
- **2 tests**: GET `/api/health` — 200 response shape, 404 on unknown path
- **6 tests**: GET/POST/DELETE `/api/store/:key` — auth, payload validation, DB operations
- **5 tests**: POST `/api/store-public/:key` — public endpoint restrictions

**Coverage thresholds enforced:**
- Lines: ≥60%
- Functions: ≥70%
- Branches: ≥55%

Run tests locally:
```bash
cd backend
npm ci
npm test                  # Run once
npm run test:coverage    # Coverage report
npm run test:watch      # Watch mode during development
```

---

## 🚀 Deployment Guide

### Prerequisites
- Node.js ≥18
- PostgreSQL 12+
- 1GB RAM (app can heap-limit to 400MB via pm2)

### Quick Start (Linux/macOS)

```bash
# 1. Clone / pull latest
git clone <repo> iip-prod && cd iip-prod

# 2. Install backend
cd backend
npm ci --omit=dev

# 3. Apply database schema
psql -U iip_admin -d iip_prod -f ../schema/001_initial.sql

# 4. Generate credentials
DB_PWD=$(node -e "console.log(require('crypto').randomBytes(15).toString('base64url'))")
API_TOKEN=$(node -e "console.log(require('crypto').randomBytes(32).toString('hex'))")
echo "DB_PASSWORD=$DB_PWD"
echo "IIP_ADMIN_TOKEN=$API_TOKEN"

# 5. Create .env with real values
cat > .env << EOF
NODE_ENV=production
DB_HOST=postgres.internal
DB_PORT=5432
DB_NAME=iip_prod
DB_USER=iip_admin
DB_PASSWORD=$DB_PWD
DB_SSL=true
IIP_ADMIN_TOKEN=$API_TOKEN
CORS_ORIGIN=https://rb-alm-01-d8.de.bosch.com
LOG_LEVEL=info
EOF

# 6. Run with pm2
npm i -g pm2
pm2 start ecosystem.config.js --env prod

# 7. Verify
curl https://rb-alm-01-d8.de.bosch.com/api/health
# Should return: {"ok":true,"version":"2.0.0",...}

# 8. Save pm2 state for reboot
pm2 save
pm2 startup --user iip
```

### Monitoring

```bash
# View logs (real-time)
pm2 logs iip-api

# Performance metrics
pm2 plus   # Optional: upload to PM2+ SaaS dashboard

# Manual health check
watch -n 5 "curl -s https://iip-prod/api/health | jq '.'"
```

### Rollback Plan
If v2.0.0 has issues:
```bash
# 1. Stop current version
pm2 delete iip-api

# 2. Checkout v1.0.2 tag
git checkout v1.0.2
cd backend && npm ci --omit=dev

# 3. Restart
pm2 start ecosystem.config.js --env prod
```

---

## 📋 File Structure

```
iip/
├── backend/
│   ├── .env.example          # Deployment template
│   ├── .husky/
│   │   └── pre-commit        # Runs ESLint + Prettier before each commit
│   ├── .prettierrc            # Code formatting rules
│   ├── ecosystem.config.js   # pm2 process manager config
│   ├── eslint.config.cjs     # ESLint v9 flat config
│   ├── package.json          # v2.0.0, all dependencies
│   ├── seed-db.js            # One-time sample data (optional)
│   ├── server.js             # Main Express app (all 15 endpoints)
│   └── server.test.js        # 47 Jest tests
├── schema/
│   └── 001_initial.sql       # Database schema + migrations tracking
├── js/
│   ├── app.js                # v2.0.0 — main app shell
│   ├── dashboards/           # Page-specific logic
│   ├── modules/              # Reusable modules
│   │   ├── admin/
│   │   │   └── admin.js      # Admin login, sessionStorage token
│   │   ├── data/
│   │   │   ├── dynamic-config.js  # Fetches /api/team-config
│   │   │   ├── config.js
│   │   │   ├── data.js
│   │   │   └── storage.js
│   │   ├── ui/               # UI chrome, modals, state
│   │   ├── platform/         # Router, workflows
│   │   ├── tracker/          # Case tracker UX
│   │   ├── legacy/           # Deprecated (mark for removal post-v2.0.1)
│   │   └── patches.js        # Cross-cutting fixes
│   └── data/
│       └── app-data.js       # v2.0.0: DEPRECATED — use /api/team-config
├── css/
│   ├── core/
│   │   ├── base.css          # Reset + typography
│   │   ├── components.css    # All UI components
│   │   ├── layout.css        # Grid, containers
│   │   └── variables.css     # Design tokens
│   ├── features/             # Page-specific styles
│   ├── mobile.css            # Responsive overrides
│   └── ui-system.css         # Old styles (consolidating into core/)
├── index.html                # Main app shell (v2.0.0)
├── CHANGELOG.md              # v1.0.0 → v2.0.0 history
├── COMPONENTS.md             # UI component library (v2.0.0)
├── CONSISTENCY.md            # UI rules (v2.0.0)
├── PHASE1_CHANGES.md         # Archive: Security foundation
├── PHASE2_CHANGES.md         # Archive: Authentication hardening
├── PHASE3_CHANGES.md         # Archive: Observability
├── PHASE4_CHANGES.md         # Archive: Testing & quality
├── PHASE5_CHANGES.md         # Archive: Legacy cleanup
└── RELEASE_v2.0.0.md         # This file
```

---

## ⚠️ Breaking Changes from v1.0.2

### For End Users
- **Admin token no longer persists** — you must log in again after closing tabs
- **Static app-data.js is deprecated** — if API is unreachable, fall back to existing localStorage cache

### For Administrators
- **New password/token required** — generate new credentials per deployment guide above
- **Database migration required** — run `schema/001_initial.sql` to add tracking tables
- **Port still 3000** — but now requires `NODE_ENV=production` env var for prod logging

### For Developers
- **ESLint v9 flat config** — migration from old config format completed
- **Pre-commit hooks active** — must stage changes before committing
- **Test coverage enforced** — new modules must hit 60% line coverage minimum
- **PHASE*_CHANGES.md files archived** — refer to CHANGELOG.md for merged history

---

## 🗒️ Known Limitations & Roadmap

### v2.0.0 Current State
- ✅ Single Node.js instance (no clustering)
- ✅ In-memory SSE client registry (OK for ≤500 concurrent users)
- ✅ PostgreSQL local queries only (no read replicas)
- ⚠️ No Redis rate-limit store (uses in-memory; resets on restart)

### v2.1.0 Candidates (Future)
- Rate-limit persistence via Redis
- Horizontal scaling (cluster mode / multiple instances)
- Scheduled backups via `pg_dump` cron task
- Admin audit log endpoint (`/api/admin/auditlog`)
- WebSocket support for real-time dashboard updates

---

## 📞 Support & Questions

For issues, feature requests, or deployment help:

1. **Check logs first**: `pm2 logs iip-api | grep ERROR`
2. **Verify health**: `curl https://iip-prod/api/health`
3. **Database check**: `psql -U iip_admin -d iip_prod -c "SELECT COUNT(*) FROM iip_kv;"`
4. **Run tests locally**: `cd backend && npm test`
5. **Contact team**: ibm-case-intelligence@bosch.com

---

**Version**: 2.0.0  
**Release Date**: March 23, 2026  
**Status**: PRODUCTION READY ✅  
**Tested On**: Node 18+, PostgreSQL 12+, Linux/macOS
